// base relativa: o dist/ abre em qualquer pasta da hospedagem (raiz ou subpasta)
import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
});
