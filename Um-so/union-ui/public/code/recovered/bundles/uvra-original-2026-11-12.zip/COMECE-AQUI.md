# Uvra: comece aqui

1. Abra esta pasta no Claude Code, no Codex ou na sua IA de código.
2. Cole o prompt (ele está no PROMPT.md) ou escreva para a IA: "siga o PROMPT.md".
3. Responda às perguntas dela e deixe ela trabalhar até o fim. Se parar no meio, escreva "continue".

O CLAUDE.md e o AGENTS.md são o mesmo guia: a IA lê sozinha, não precisa colar.

## Passo a passo completo

1. Abra a pasta no Claude Code ou no Codex, cole o prompt inteiro e responda às perguntas: montar a demo, fazer o site da sua vinícola ou usar só algumas peças.
2. Deixe a IA trabalhar até o fim: ela instala tudo, monta o filme a partir dos clipes (leva alguns minutos) e só então abre a demo. Se ela parar no meio, escreva "continue".
3. Peça "abre o site para eu ver" e abra o link que ela mostrar (algo como localhost:5360).
4. Role devagar: a câmera atravessa o público da galeria, entra no quadro e a pintura ganha vida; o filme segue do vinhedo à colheita, à prensa, à adega e à taça.
5. Continue: as três garrafas aparecem na mesa e "Ver os vinhos" abre a vitrine dos rótulos por cima do filme; no fim, o banquete vira um quadro na mesma galeria do começo.
6. Peça à IA o link para abrir no celular (na mesma rede Wi-Fi) e role com o dedo: o filme vem recortado em pé, cada piparote anda mais ou menos uma cena e nada escapa para o lado.
7. Peça para trocar nome, textos, rótulos, preços, visitas, clube e contatos pelos seus; a IA segue a seção "Personalizar" do guia e diz o que ainda é da demo.
8. O filme e as garrafas da vitrine foram pintados por IA e mostram uma vinícola inventada: para a sua história ou os seus rótulos, a IA explica o caminho (fotos das suas garrafas ou novas imagens e clipes pelas receitas).
9. Para publicar, peça "gera a versão final" e suba a pasta dist/ na sua hospedagem (Netlify, Hostinger, Vercel ou outra); ela tem uns 130 MB por causa do filme.
