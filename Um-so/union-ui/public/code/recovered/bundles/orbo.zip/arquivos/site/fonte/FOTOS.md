# Fotos da ORBO

Fotos de banco (Unsplash e Pexels), licença conferida na página de cada uma em 2026-11-06. As duas licenças
permitem uso comercial sem atribuição; o crédito fica como registro. As fotos não vão no pacote da entrega:
`npm run fotos` (`fonte/fotos.mjs`) baixa cada uma do CDN de origem, com até 2000 px no lado maior, para
`fonte/fotos/<vaga>.jpg`, e grava o recorte de cada vaga em `public/img/<vaga>.webp` (sharp, WebP q78; o estúdio q74).
Trabalhos 720 × 900 (4:5), estúdio 1760 × 990 (16:9, sem a faixa da esquerda), avaliações 640 × 480 (4:3).

- `trabalhos/01`: ObjectType RAW, Unsplash, https://unsplash.com/photos/a-white-sports-car-with-detailed-rims-o6XyyJ9rOXE. "Free to use under the Unsplash License" (não é Unsplash+)
- `trabalhos/02`: Patrick Langwallner, Unsplash, https://unsplash.com/photos/a-black-car-is-parked-in-a-garage-afnQQfeMjUs. "Free to use under the Unsplash License" (não é Unsplash+)
- `trabalhos/03`: Oleksandr Chumak, Unsplash, https://unsplash.com/photos/purple-porsche-911-parked-in-front-of-white-building-SOZsVnwgvIs. "Free to use under the Unsplash License" (não é Unsplash+)
- `trabalhos/04`: Spencer Davis, Unsplash, https://unsplash.com/photos/silver-coupe-parked-near-wall-okfGOQAfjt4. "Free to use under the Unsplash License" (não é Unsplash+)
- `trabalhos/05`: Martin Katler, Unsplash, https://unsplash.com/photos/blue-bmw-m-3-coupe-7RzPuV3-xyI. "Free to use under the Unsplash License" (não é Unsplash+)
- `trabalhos/06`: Petko Boiadjiev, Unsplash, https://unsplash.com/photos/a-close-up-of-a-cars-tail-light-7uXyTJ4HBDQ. "Free to use under the Unsplash License" (não é Unsplash+)
- `estudio/01`: Jae Park, Pexels, https://www.pexels.com/photo/black-bmw-m-3-coupe-3849554/. "License: Free" (link para pexels.com/license) e botão "Free download"; sem conteúdo pago
- `parede/01`: Dan Gold, Unsplash, https://unsplash.com/photos/teal-volkswagen-beetle-parked-near-brown-house-xBRQfR2bqNI. "Free to use under the Unsplash License" (não é Unsplash+)
- `parede/02`: Bestami Sarıkaya, Unsplash, https://unsplash.com/photos/white-sedan-on-gray-asphalt-road-during-daytime-73XAgT8DOpo. "Free to use under the Unsplash License" (não é Unsplash+)
- `parede/03`: Talia, Unsplash, https://unsplash.com/photos/red-jeep-wrangler-on-road-during-daytime-sBPnD3jzQ7g. "Free to use under the Unsplash License" (não é Unsplash+)
- `parede/04`: Jon Matthews, Unsplash, https://unsplash.com/photos/dark-blue-sports-car-parked-in-front-of-garage-7n6UjbmX7r8. "Free to use under the Unsplash License" (não é Unsplash+)
- `parede/05`: Marvin Alexander Avila, Unsplash, https://unsplash.com/photos/a-small-red-car-parked-on-a-city-street-_wYhqW1TXSw. "Free to use under the Unsplash License" (não é Unsplash+)
- `parede/06`: RKTW extend, Unsplash, https://unsplash.com/photos/blue-bmw-m-3-on-road-during-daytime-DpGNVXCH5_8. "Free to use under the Unsplash License" (não é Unsplash+)
