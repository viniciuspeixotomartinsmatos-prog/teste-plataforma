# Receitas da ORBO

Na ORBO nada é imagem gerada por IA. São três tipos de peça:

- **O carro 3D** (hero, mapa de serviços e fecho): um modelo gratuito, ao vivo no navegador. A cor, o desenho técnico e as áreas acesas são código.
- **13 fotos de banco** (trabalhos, estúdio e avaliações): Unsplash e Pexels, com licença livre. Elas não vêm no pacote: o script `npm run fotos` baixa cada uma do site de origem e faz o recorte.
- **O resto** (a faixa da abertura, a meia-lua, o papel, os fios, os botões) é CSS e SVG.

## As fotos

`fonte/fotos.mjs` (rodado com `npm run fotos`) faz três coisas para cada vaga:

1. Baixa a foto do site de origem, com até 2000 px no lado maior, para `fonte/fotos/<vaga>.jpg`.
2. Recorta na proporção da vaga, pelo `foco` dela: 0 encosta o recorte na esquerda ou no topo, 1 na direita ou no pé, 0,5 centraliza.
3. Grava o WebP em `public/img/<vaga>.webp`.

Quando uma foto não baixa (sem internet, ou o site de origem mudou), o erro mostra a página da foto. Baixe por ela, salve em `fonte/fotos/<vaga>.jpg` e rode `npm run fotos -- <vaga>`.

| vaga | onde aparece | proporção e tamanho | foto da demo | o que a vaga pede |
|---|---|---|---|---|
| `trabalhos/01` | 1ª carta de "Entregues" | 4:5, 720 × 900 | [Porsche 911 branco, luz âmbar](https://unsplash.com/photos/a-white-sports-car-with-detailed-rims-o6XyyJ9rOXE) | carro inteiro ou um detalhe forte (farol, roda, lanterna), fundo escuro ou de estúdio |
| `trabalhos/02` | 2ª carta | 4:5 | [Polestar 2 preto na garagem](https://unsplash.com/photos/a-black-car-is-parked-in-a-garage-afnQQfeMjUs) | idem |
| `trabalhos/03` | 3ª carta | 4:5 | [Audi TT roxo com neon](https://unsplash.com/photos/purple-porsche-911-parked-in-front-of-white-building-SOZsVnwgvIs) | idem |
| `trabalhos/04` | 4ª carta | 4:5 | [Porsche 356 prata](https://unsplash.com/photos/silver-coupe-parked-near-wall-okfGOQAfjt4) | idem |
| `trabalhos/05` | 5ª carta | 4:5, recorte pelo pé | [BMW M4 azul no estúdio](https://unsplash.com/photos/blue-bmw-m-3-coupe-7RzPuV3-xyI) | idem |
| `trabalhos/06` | 6ª carta | 4:5 | [Renault Mégane, lanterna](https://unsplash.com/photos/a-close-up-of-a-cars-tail-light-7uXyTJ4HBDQ) | idem |
| `estudio/01` | "O estúdio", tela cheia | 16:9, 1760 × 990, sem a faixa da esquerda | [BMW preto fosco sob luminárias de LED](https://www.pexels.com/photo/black-bmw-m-3-coupe-3849554/) | o box com luz de inspeção no teto, carro escuro, espaço livre embaixo à esquerda para a legenda |
| `parede/01` a `parede/06` | as seis polaroides das avaliações | 4:3, 640 × 480 | [Fusca](https://unsplash.com/photos/teal-volkswagen-beetle-parked-near-brown-house-xBRQfR2bqNI), [Corolla](https://unsplash.com/photos/white-sedan-on-gray-asphalt-road-during-daytime-73XAgT8DOpo), [Wrangler](https://unsplash.com/photos/red-jeep-wrangler-on-road-during-daytime-sBPnD3jzQ7g), [911 azul](https://unsplash.com/photos/dark-blue-sports-car-parked-in-front-of-garage-7n6UjbmX7r8), [Fiat 500](https://unsplash.com/photos/a-small-red-car-parked-on-a-city-street-_wYhqW1TXSw), [Swift](https://unsplash.com/photos/blue-bmw-m-3-on-road-during-daytime-DpGNVXCH5_8) | o carro do cliente, de lado ou de três quartos, na rua ou na garagem: foto "de celular", com luz do dia, de propósito diferente das fotos de estúdio dos trabalhos |

Os créditos de cada foto estão em `fonte/FOTOS.md`.

**Trocar por fotos próprias** (o melhor caminho): salve a foto como `fonte/fotos/<vaga>.jpg` (ex.: `fonte/fotos/trabalhos/02.jpg`) e rode `npm run fotos -- trabalhos/02`. O arquivo salvo tem prioridade sobre o download. Se o carro ficar cortado, ajuste o `foco` da vaga no começo de `fonte/fotos.mjs` (e `zoom` acima de 1 para fechar o recorte). Antes de usar, confira:

- a resolução: pelo menos 900 px no lado da vaga;
- a placa, que deve ficar ilegível ou fora do recorte;
- o rosto de cliente, só com autorização.

**Trocar por outras fotos de banco:**

- **Onde procurar:** no Unsplash, só as fotos com "Free to use under the Unsplash License" (as do Unsplash+ são pagas). No Pexels, todas são livres.
- **Termos que funcionam:** "car detailing", "black car garage", "car headlight dark", "sports car studio", "car ceramic coating", "led garage ceiling".
- **O que pôr no script:** o endereço da imagem no `cdn` da vaga e a página dela no `pagina`, ou salve o arquivo como acima.
- **Licença:** as duas permitem uso comercial sem crédito. Não podem ser revendidas soltas, como foto, mas dentro do site estão liberadas.

**Custo:** zero.

## O carro 3D

**O modelo:** "Aston Martin db11", de Black Snow, no [Sketchfab](https://sketchfab.com/3d-models/aston-martin-db11-0ce56f01b1ff40b3a4e36bc56873dbc7), licença [CC-BY 4.0](http://creativecommons.org/licenses/by/4.0/).

- **Crédito:** uso comercial permitido, com crédito ao autor. A linha "Modelo 3D: ..." no rodapé do site é esse crédito e fica enquanto o DB11 estiver no site (`fonte/db11-licenca.txt`).
- **Preparo:** feito uma vez no Blender (gratuito) com `fonte/prepara_db11.py`. O script:
  - tira o cofre do motor e os emblemas;
  - subdivide a lataria (de cima, a malha grossa aparece);
  - reduz pela metade as peças que não aparecem de cima;
  - exporta sem UV (o acabamento é matcap e não usa textura), com compressão Draco.

  O arquivo foi de 11 MB para 1,16 MB.

  ```
  blender --background --factory-startup --python fonte/prepara_db11.py -- caminho/scene.gltf public/modelo/db11.glb
  ```

**O carro serve para qualquer estética:** é um esportivo preto sem marca à vista. Por isso o caminho mais simples é mantê-lo. A cor da pintura muda no código, sem modelo novo: veja "Cor do carro" no guia.

**Outro carro.** Só com um modelo 3D novo, e não sai por prompt. Leva de uma a duas horas com a IA ajudando:

1. **Escolher.** No Sketchfab, filtre por "Downloadable" e licença CC-BY ou CC0 (as duas permitem uso comercial).
   - Olhe o modelo **de cima** no visualizador do site: é o único ângulo que aparece.
   - Prefira os que separam pintura, vidros, rodas, pneus, faróis e interior em materiais com nome, e que tenham até ~300 mil faces.
   - Modelo de jogo com tudo num material só não serve: o desenho técnico e as áreas dos serviços dependem dessas peças separadas.
2. **Baixar** o glTF (precisa de conta gratuita no Sketchfab).
3. **Preparar** com uma cópia de `fonte/prepara_db11.py`, trocando três nomes no começo do script:
   - `FORA`: as peças a apagar, que não aparecem de cima (motor, suspensão);
   - `EMBLEMAS`: os materiais dos emblemas;
   - `PINTURA`: os materiais da lataria.
4. **Exportar** para `public/modelo/<nome>.glb` (até ~2 MB) e trocar o caminho `'/modelo/db11.glb'` em `src/gl/palco.js`.
5. **Ensinar o palco a ler o modelo novo.** Em `src/gl/palco.js`, troque os nomes de malha e material do DB11 pelos do modelo novo (o guia lista cada um em "Outro carro"):
   - a função `classe()`;
   - a caixa da cabine (`seat_F|steer`);
   - as peças do PPF (`_hood_`, `bumper_F`, `mirror`, `_body_`, `_door_L_`);
   - os faróis (`headlight`).

   Depois, acerte o `data-ancora` de cada serviço no `index.html` (o ponto do carro onde o fio termina).
6. **Atualizar o crédito** do rodapé com o modelo, o autor e a licença novos (CC0 não exige crédito).

**Custo:** zero (Sketchfab e Blender gratuitos).

**Sem 3D:** a página não tem versão sem o carro, porque ele é a peça central da hero, da passagem e do mapa de serviços. Quem não quer um carro 3D deve escolher outra template.
