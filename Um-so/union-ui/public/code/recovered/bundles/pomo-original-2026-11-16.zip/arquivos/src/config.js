// Tudo o que muda de uma marca para outra fica aqui: o nome, a frase do anel, os sabores (cores do rótulo, a fruta de
// papel, os textos da ficha) e o contato. Os rótulos das garrafas são desenhados a partir deste arquivo
// (src/marca/rotulo.js): trocar um nome ou uma cor redesenha a embalagem, sem imagem nova.

export const MARCA = {
  nome: 'Pomo',
  linha: 'sucos do pé',
  anel: 'do pé para a garrafa · no mesmo dia · ',
  selo: '100% fruta · sem açúcar · sem água · ',
  volume: '300 ml',
  whatsapp: '5500000000000', // [preencher] número com DDI e DDD, só dígitos
  email: 'oi@pomo.example', // [preencher]
};

// Cada sabor:
// - fundo, fruta, folha, detalhe, semente: as cores da arte do rótulo (o fundo claro, a fruta de papel, a folha, o
//   miolo e as sementes)
// - faixa e letra: a faixa de baixo do rótulo e a cor das letras sobre ela
// - card: o fundo do card na grade e do hover
// - frutas: quais frutas de papel entram no rótulo (src/marca/frutas.js), a primeira é a principal
// - garrafa: o arquivo em public/garrafas/ (a foto do vidro sem rótulo, com o suco)
export const SABORES = [
  {
    id: 'laranja', nome: 'Laranja', sub: 'suco integral', garrafa: 'laranja',
    fundo: '#ffc15e', fruta: '#f2711c', folha: '#2e7d3a', detalhe: '#ffe2a6', faixa: '#c9461a', letra: '#fff4e0', card: '#ffe0b0',
    frutas: ['laranja', 'folha'],
    tipo: 'Cítrico', descricao: 'Laranja-pera colhida madura e prensada no mesmo dia. Doce, com a acidez no fundo, do jeito que sai da fruta.',
    ingredientes: 'suco integral de laranja (100%)', combina: 'Café da manhã, bolo de fubá, pão na chapa e a marmita do almoço.',
    validade: '15 dias na geladeira', tamanhos: ['300 ml', '1 L'], safra: [5, 6, 7, 8, 9, 10, 11],
  },
  {
    id: 'uva', nome: 'Uva', sub: 'suco integral', garrafa: 'uva',
    fundo: '#cfa9e6', fruta: '#5b2a6e', folha: '#3f7a35', detalhe: '#9b6bb8', faixa: '#3d1a4f', letra: '#f6eafd', card: '#ead8f5',
    frutas: ['uva', 'folha'],
    tipo: 'Encorpado', descricao: 'Uva bordô de casca grossa, prensada com a casca. Escuro, encorpado e doce de si, sem nada de açúcar.',
    ingredientes: 'suco integral de uva (100%)', combina: 'Queijo meia cura, castanhas e a mesa do fim de semana.',
    validade: '30 dias fechado; 5 dias aberto', tamanhos: ['300 ml', '1 L'], safra: [12, 1, 2, 3],
  },
  {
    id: 'maracuja', nome: 'Maracujá', sub: 'suco integral', garrafa: 'maracuja',
    fundo: '#ffd84a', fruta: '#f0a500', folha: '#2f7a3b', detalhe: '#ffe98f', semente: '#2b1a12', faixa: '#2f6b2f', letra: '#fff6d0', card: '#fff0b3',
    frutas: ['maracuja', 'folha'],
    tipo: 'Azedinho', descricao: 'Maracujá-amarelo batido com a polpa e coado uma vez só. Azedo na medida, cheiroso e grosso.',
    ingredientes: 'polpa e suco integral de maracujá (100%)', combina: 'Tarde quente, gelo e uma folha de hortelã.',
    validade: '10 dias na geladeira', tamanhos: ['300 ml'], safra: [9, 10, 11, 12, 1, 2, 3, 4],
  },
  {
    id: 'caju', nome: 'Caju', sub: 'suco integral', garrafa: 'caju',
    fundo: '#ffcf5a', fruta: '#e8412c', folha: '#3f7a35', detalhe: '#8a5a2b', faixa: '#b52a1c', letra: '#fff1df', card: '#ffe3a3',
    frutas: ['caju', 'folha'],
    tipo: 'Travoso', descricao: 'Caju do fim do ano, prensado inteiro. Amarra a boca de leve, como a fruta no pé.',
    ingredientes: 'suco integral de caju (100%)', combina: 'Peixe na brasa, tapioca e castanha torrada.',
    validade: '10 dias na geladeira', tamanhos: ['300 ml', '1 L'], safra: [9, 10, 11, 12],
  },
  {
    id: 'goiaba', nome: 'Goiaba', sub: 'suco integral', garrafa: 'goiaba',
    fundo: '#ffc4ce', fruta: '#ef6a86', folha: '#6f9a3a', detalhe: '#ff9db0', semente: '#ffe7c2', faixa: '#4f7d2e', letra: '#fff0f2', card: '#ffdde3',
    frutas: ['goiaba', 'folha'],
    tipo: 'Cremoso', descricao: 'Goiaba vermelha passada na peneira fina. Grosso, perfumado, quase um néctar sem açúcar.',
    ingredientes: 'polpa e suco integral de goiaba (100%)', combina: 'Queijo branco, pão de queijo e lanche da escola.',
    validade: '10 dias na geladeira', tamanhos: ['300 ml'], safra: [1, 2, 3, 4],
  },
  {
    id: 'abacaxi', nome: 'Abacaxi', sub: 'com hortelã', garrafa: 'abacaxi',
    fundo: '#ffe27a', fruta: '#f2b705', folha: '#2f8a4b', detalhe: '#c98a06', faixa: '#2f8a4b', letra: '#fffbe0', card: '#fff1bd',
    frutas: ['abacaxi', 'hortela'],
    tipo: 'Refrescante', descricao: 'Abacaxi pérola com folhas de hortelã da horta, batidos juntos. Doce, gelado e verde no fim.',
    ingredientes: 'suco integral de abacaxi (97%), hortelã fresca (3%)', combina: 'Churrasco, praia e domingo à tarde.',
    validade: '7 dias na geladeira', tamanhos: ['300 ml', '1 L'], safra: [10, 11, 12, 1, 2],
  },
  {
    id: 'limao', nome: 'Limão', sub: 'com gengibre', garrafa: 'limao',
    fundo: '#dcee9e', fruta: '#6fb52f', folha: '#2f6b2f', detalhe: '#d9a25b', faixa: '#2f6b2f', letra: '#f4fbe0', card: '#eaf5c4',
    frutas: ['limao', 'gengibre', 'folha'],
    tipo: 'Picante', descricao: 'Limão-taiti espremido na hora com gengibre ralado. Ácido, ardido e acordado.',
    ingredientes: 'suco integral de limão (92%), gengibre fresco (8%)', combina: 'Depois do treino, com água com gás ou num copo de gelo.',
    validade: '7 dias na geladeira', tamanhos: ['300 ml'], safra: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
  },
  {
    id: 'manga', nome: 'Manga', sub: 'suco integral', garrafa: 'manga',
    fundo: '#ffd166', fruta: '#f59b1c', folha: '#2f7a3b', detalhe: '#ef5a2b', faixa: '#e0661f', letra: '#fff3da', card: '#ffe6ad',
    frutas: ['manga', 'folha'],
    tipo: 'Encorpado', descricao: 'Manga palmer madura no pé, sem fiapo. Grosso como a fruta, doce como o fim de tarde.',
    ingredientes: 'polpa e suco integral de manga (100%)', combina: 'Granola, iogurte e a fruta da sobremesa.',
    validade: '10 dias na geladeira', tamanhos: ['300 ml', '1 L'], safra: [10, 11, 12, 1],
  },
  {
    id: 'melancia', nome: 'Melancia', sub: 'suco integral', garrafa: 'melancia',
    fundo: '#ffb9be', fruta: '#e83b45', folha: '#2f8a4b', detalhe: '#ff8a92', semente: '#1d1d1d', faixa: '#2f8a4b', letra: '#fff0f0', card: '#ffd9dc',
    frutas: ['melancia', 'folha'],
    tipo: 'Leve', descricao: 'Melancia sem semente batida e coada. Leve, aguado do jeito bom, para beber de garrafa inteira.',
    ingredientes: 'suco integral de melancia (100%)', combina: 'Sol forte, piscina e almoço de verão.',
    validade: '5 dias na geladeira', tamanhos: ['300 ml', '1 L'], safra: [11, 12, 1, 2, 3],
  },
  {
    id: 'jabuticaba', nome: 'Jabuticaba', sub: 'suco integral', garrafa: 'jabuticaba',
    fundo: '#8d6aa0', fruta: '#2b1a2e', folha: '#3f7a35', detalhe: '#b38b5a', faixa: '#1f1222', letra: '#f1e6f5', card: '#e2d4ea',
    frutas: ['jabuticaba', 'folha'],
    tipo: 'Da estação', descricao: 'Jabuticaba sabará catada no tronco nas três semanas em que ela dá. Some rápido: sai uma leva por ano.',
    ingredientes: 'suco integral de jabuticaba (100%)', combina: 'Sobremesa, queijo forte e visita de vó.',
    validade: '30 dias fechado; 5 dias aberto', tamanhos: ['300 ml'], safra: [8, 9, 10],
  },
];

export const POR_ID = Object.fromEntries(SABORES.map((s) => [s.id, s]));
