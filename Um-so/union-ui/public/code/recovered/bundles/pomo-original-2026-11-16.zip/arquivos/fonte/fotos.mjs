// As fotos (galeria e pomar): cada fonte/bruto/foto-<nome>.png do Codex vira public/fotos/<nome>.webp (1536),
// <nome>-1200.webp e <nome>-800.webp. Sem a foto ainda, --provisorio grava um marcador no lugar (a garrafa sobre a
// cor do sabor), só para a página montar; a foto de verdade substitui o arquivo.
// Rodar da raiz do projeto: node fonte/fotos.mjs [--provisorio] (ou node arquivos/fonte/fotos.mjs)
import { existsSync, mkdirSync } from 'node:fs';
import sharp from 'sharp';

const NOMES = { mesa: 'laranja', maracuja: 'maracuja', cafe: 'laranja', caixote: 'caju', verao: 'melancia', pomar: null };
const dir = new URL('.', import.meta.url).pathname;
const pub = `${process.cwd()}/public/fotos/`;
mkdirSync(pub, { recursive: true });
const provisorio = process.argv.includes('--provisorio');

async function grava(img, nome) {
  for (const [w, suf] of [[1536, ''], [1200, '-1200'], [800, '-800']])
    await sharp(img).resize({ width: w, height: Math.round((w * 2) / 3), fit: 'cover' }).webp({ quality: w > 1200 ? 78 : 80, effort: 6 }).toFile(`${pub}${nome}${suf}.webp`);
}

for (const [nome, garrafa] of Object.entries(NOMES)) {
  const bruto = `${dir}bruto/foto-${nome}.png`;
  if (existsSync(bruto)) { await grava(bruto, nome); console.log('foto', nome); continue; }
  if (!provisorio) { console.log('(sem a foto', nome + ')'); continue; }
  const fundo = garrafa ? '#2a5a3a' : '#3d6b3f';
  const base = sharp({ create: { width: 1536, height: 1024, channels: 4, background: fundo } });
  const camadas = [];
  if (garrafa) {
    const g = await sharp(`${dir}refs-fotos/render-${garrafa}.png`).resize({ height: 760 }).toBuffer();
    camadas.push({ input: g, left: 600, top: 130 });
  }
  const txt = Buffer.from(`<svg width="1536" height="1024"><text x="60" y="980" font-family="Helvetica" font-size="34" fill="rgba(255,255,255,.55)">provisório · ${nome}</text></svg>`);
  camadas.push({ input: txt, left: 0, top: 0 });
  await grava(await base.composite(camadas).png().toBuffer(), nome);
  console.log('provisório', nome);
}
