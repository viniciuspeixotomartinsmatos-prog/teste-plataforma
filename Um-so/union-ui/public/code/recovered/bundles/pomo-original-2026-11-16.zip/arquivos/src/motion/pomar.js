// O pomar: a foto num card que cresce até a tela cheia (as bordas e o raio somem, a foto desce do zoom) presa à
// rolagem, com a frase entrando por marco quando ela enche a tela; depois as frutas de papel sobem em velocidades
// diferentes (paralaxe) em volta do mote, que aparece por marco.
import gsap from 'gsap';
import { FRUTAS } from '../marca/frutas.js';
import { SABORES } from '../config.js';
import { REDUZIDO, alturaTela, clamp, faixa, suave, CELULAR } from './ease.js';

// x, y (em % do bloco), tamanho (vw), velocidade (telas de deslocamento ao longo do bloco), giro
const FRUTAS_POMAR = [
  // só nas duas colunas de fora: o miolo fica livre para o mote, que passa preso no meio da tela
  ['laranja', 4, 6, 26, 0.55, -12], ['caju', 72, 0, 20, 0.9, 16], ['uva', 18, 40, 17, 0.35, 8],
  ['maracuja', 80, 36, 22, 0.7, -20], ['abacaxi', 0, 64, 21, 1.0, 10], ['melancia', 66, 70, 26, 0.45, -8],
  ['manga', 24, 84, 15, 1.2, 24], ['goiaba', 86, 86, 16, 0.8, 14],
];

const coresDe = (id) => {
  const s = SABORES.find((x) => x.frutas[0] === id);
  return s ? [s.fruta, s.folha, s.detalhe, s.semente ?? s.faixa] : ['#2e7d3a'];
};

export function criarPomar({ lenis }) {
  const caixa = document.querySelector('[data-pomar-foto]');
  const moldura = document.querySelector('[data-pomar-moldura]');
  const frase = document.querySelector('[data-pomar-frase]');
  const bloco = document.querySelector('[data-pomar-frutas]');
  const mote = document.querySelector('[data-pomar-mote]');

  const frutas = FRUTAS_POMAR.map(([id, x, y, t, v, r]) => {
    const fr = FRUTAS[id], cores = coresDe(id);
    const el = document.createElement('span');
    el.className = 'pomar__fruta';
    const cel = CELULAR();
    el.style.cssText = `--x:${x}%;--y:${y}%;--t:${cel ? t * 1.52 : t}vw`;
    el.innerHTML = `<svg viewBox="0 0 ${fr.w} ${fr.h}" aria-hidden="true">${fr.partes.map((p) => `<path d="${p.d}" fill="${cores[p.tom] ?? cores[0]}"/>`).join('')}</svg>`;
    bloco.append(el);
    return { el, v, r };
  });

  let vh = alturaTela(), tCaixa = 0, tBloco = 0, hBloco = 0;
  const y0 = () => (lenis ? lenis.scroll : scrollY);
  function medir() {
    vh = alturaTela();
    const y = y0();
    tCaixa = caixa.getBoundingClientRect().top + y;
    const r = bloco.getBoundingClientRect();
    tBloco = r.top + y;
    hBloco = r.height;
  }
  medir();
  addEventListener('resize', medir);
  new ResizeObserver(medir).observe(document.body);

  gsap.ticker.add(() => {
    const y = y0();
    // a foto: de card a tela cheia enquanto o alto dela sobe da metade da tela até o topo
    if (y > tCaixa - vh * 1.2 && y < tCaixa + vh * 2) {
      const q = REDUZIDO ? 1 : suave(faixa(y, tCaixa - vh * 0.7, tCaixa));
      const lado = (CELULAR() ? 14 : 24) * (1 - q);
      moldura.style.setProperty('--in-l', `${lado.toFixed(2)}px`);
      moldura.style.setProperty('--in-r', `${(16 * (1 - q)).toFixed(2)}px`);
      moldura.style.setProperty('--foto-esc', (1.12 - 0.12 * q).toFixed(4));
      frase.classList.toggle('is-on', q > 0.92);
    }
    // as frutas: o bloco atravessa a tela; cada uma sobe na sua velocidade
    if (y > tBloco - vh * 1.1 && y < tBloco + hBloco + vh * 0.1) {
      const p = clamp((y + vh - tBloco) / (hBloco + vh));
      for (const f of frutas) {
        const d = REDUZIDO ? 0 : (0.5 - p) * f.v * vh;
        f.el.style.transform = `translate3d(0, ${d.toFixed(1)}px, 0) rotate(${(f.r * (0.4 + p)).toFixed(2)}deg)`;
      }
      mote.classList.toggle('is-on', p > 0.3 && p < 0.86);
    }
  });
}
