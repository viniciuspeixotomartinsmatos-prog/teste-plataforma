// O rodapé: o nome gigante sobe letra a letra quando aparece; os links de pedido viram WhatsApp e e-mail do config.
import { MARCA } from '../config.js';

export function criarRodape({ raiz }) {
  // o nome gigante, letra a letra (cada uma sobe com um atraso)
  const nomeEl = raiz.querySelector('[data-rodape-nome]');
  nomeEl.innerHTML = [...MARCA.nome.toUpperCase()].map((l, i) => `<span style="--i:${i}">${l === ' ' ? '&nbsp;' : l}</span>`).join('');
  const msg = encodeURIComponent(`Oi! Quero fazer um pedido de sucos ${MARCA.nome}.`);
  raiz.querySelectorAll('[data-whatsapp]').forEach((a) => {
    a.href = `https://wa.me/${MARCA.whatsapp}?text=${msg}`;
    a.target = '_blank';
    a.rel = 'noopener';
  });
  raiz.querySelectorAll('[data-email]').forEach((a) => { a.href = `mailto:${MARCA.email}`; });
  const ano = raiz.querySelector('[data-ano]');
  if (ano) ano.textContent = String(new Date().getFullYear());
  new IntersectionObserver(([en]) => { if (en.isIntersecting) raiz.classList.add('is-visto'); }, { threshold: 0.2 }).observe(raiz);

  // o nome gigante cabe inteiro na largura: mede o nome a 100 px e acha o tamanho que enche a linha
  const nome = nomeEl;
  function encaixa() {
    nome.style.fontSize = '100px';
    nome.style.justifyContent = 'flex-start';
    const natural = [...nome.children].reduce((w, s) => w + s.getBoundingClientRect().width, 0);
    const alvo = nome.parentElement.clientWidth;
    nome.style.fontSize = `${((100 * alvo * 0.985) / natural).toFixed(2)}px`;
    nome.style.justifyContent = '';
  }
  (document.fonts?.ready ?? Promise.resolve()).then(encaixa);
  addEventListener('resize', encaixa);
}
