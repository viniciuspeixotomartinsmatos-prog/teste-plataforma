// Os sabores: os cards da grade, montados do config. Cada card tem a garrafa (rótulo pelo cilindro, girado uma vez
// quando aparece) e, atrás dela, as frutas de papel do sabor, escondidas no meio do card. Aceso (hover de verdade,
// foco ou toque), o card inclina, ganha a cor do sabor e as frutas saltam para fora, vazando da borda; o rótulo vira
// um pouco. O clique leva ao sabor.
import gsap from 'gsap';
import { SABORES } from '../config.js';
import { FRUTAS } from '../marca/frutas.js';
import { elementoGarrafa } from '../marca/garrafa.js';
import { rolando } from './rolando.js';
import { MOUSE, mola, passoMola } from './ease.js';

// onde cada fruta pousa, em % do card: x, y, tamanho (largura do card), giro final; as duas últimas são folhas
const POUSOS = [
  [6, 16, 46, -24], [94, 10, 40, 28], [2, 58, 40, 14], [97, 56, 46, -18], [50, -5, 28, 40], [88, 92, 28, -30],
];

function svgFruta(id, cores) {
  const fr = FRUTAS[id];
  return `<svg viewBox="0 0 ${fr.w} ${fr.h}" aria-hidden="true">${fr.partes.map((p) => `<path d="${p.d}" fill="${cores[p.tom] ?? cores[0]}"/>`).join('')}</svg>`;
}

export function criarSabores({ raiz, rotulos, cursor, aoEscolher }) {
  const grade = raiz.querySelector('[data-grade]');
  const cards = SABORES.map((s, i) => {
    const li = document.createElement('li');
    li.className = 'card';
    li.style.setProperty('--s-fundo', s.fundo);
    li.style.setProperty('--s-faixa', s.faixa);
    li.style.setProperty('--inclina', `${i % 2 ? 2.5 : -2.5}deg`);
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'card__btn';
    btn.setAttribute('aria-label', `${s.nome}${s.sub === 'suco integral' ? '' : ` ${s.sub}`}: ver o sabor`);
    // as frutas: a principal quatro vezes e as de apoio (ou folhas) nas duas últimas
    const [principal, ...apoio] = s.frutas;
    const cores = [s.fruta, s.folha, s.detalhe, s.semente ?? s.faixa];
    const frutas = document.createElement('div');
    frutas.className = 'card__frutas';
    frutas.innerHTML = POUSOS.map(([x, y, t, r], k) => {
      const id = k < 4 ? principal : apoio[(k - 4) % apoio.length] || 'folha';
      const c = id === 'folha' || id === 'hortela' ? [s.folha, s.folha] : id === 'gengibre' ? [s.detalhe] : cores;
      return `<span class="card__fruta" style="--fx:${x}%;--fy:${y}%;--ft:${t}%;--fr0:${r * -0.6}deg;--fr1:${r}deg;--fi:${k}">${svgFruta(id, c)}</span>`;
    }).join('');
    const g = elementoGarrafa(s, { classe: 'card__garrafa', sizes: '(max-width: 760px) 20vw, 9vw' });
    const nome = document.createElement('span');
    nome.className = 'card__nome';
    nome.innerHTML = `<b>${s.nome}</b><small>${s.sub === 'suco integral' ? s.tipo : s.sub}</small>`;
    btn.append(frutas, g, nome);
    li.append(btn);
    grade.append(li);
    return { s, li, btn, g, rot: null, giro: mola(), aceso: false, visto: false };
  });

  const acende = (c, sim) => {
    if (c.aceso === sim) return;
    c.aceso = sim;
    c.li.classList.toggle('is-aceso', sim);
  };
  for (const c of cards) {
    c.btn.addEventListener('pointerenter', (e) => {
      if (e.pointerType !== 'mouse' || rolando.on) return;
      acende(c, true);
      cursor?.mostra('Ver o sabor');
    });
    c.btn.addEventListener('pointerleave', (e) => {
      if (e.pointerType !== 'mouse') return;
      acende(c, false);
      cursor?.esconde();
    });
    // a rolagem passa os cards por baixo do cursor parado: nada acende; o primeiro movimento de verdade acende
    c.btn.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' && !rolando.on && !c.aceso) { acende(c, true); cursor?.mostra('Ver o sabor'); } });
    c.btn.addEventListener('focus', () => { if (c.btn.matches(':focus-visible')) acende(c, true); });
    c.btn.addEventListener('blur', () => acende(c, false));
    // toque: o card acende no dedo e o clique leva ao sabor logo depois
    c.btn.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') acende(c, true); });
    c.btn.addEventListener('pointercancel', () => acende(c, false));
    c.btn.addEventListener('click', () => {
      cursor?.esconde();
      setTimeout(() => acende(c, false), 260);
      aoEscolher?.(c.s, c);
    });
  }
  rolando.sub((sim) => { if (sim) cards.forEach((c) => acende(c, false)); });

  // os rótulos: ligados quando a grade chega perto da tela; desenhados quando mudam
  let ligado = false, perto = false;
  new IntersectionObserver(([en]) => {
    perto = en.isIntersecting;
    if (perto && !ligado) {
      ligado = true;
      for (const c of cards) c.rot = rotulos.liga(c.g, c.s, { escalaMax: 1.08, densidade: Math.min(devicePixelRatio || 1, 2) });
    }
  }, { rootMargin: '600px 0px' }).observe(raiz);
  addEventListener('resize', () => cards.forEach((c) => c.rot && rotulos.medir(c.rot)));

  let t0 = performance.now();
  gsap.ticker.add(() => {
    const agora = performance.now();
    const dt = Math.min(1 / 30, (agora - t0) / 1000);
    t0 = agora;
    if (!perto || !ligado) return;
    for (const c of cards) {
      passoMola(c.giro, c.aceso ? 0.07 : 0, 90, 11, dt);
      if (rotulos.desenha(c.rot, c.giro.v)) c.g.classList.add('tem-rotulo');
    }
  });
  void MOUSE;
  return { cards };
}
