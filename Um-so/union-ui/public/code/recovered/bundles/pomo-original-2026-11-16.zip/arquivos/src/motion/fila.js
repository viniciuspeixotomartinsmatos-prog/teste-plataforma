// A fila do hero: as dez garrafas numa trilha levemente inclinada que corre em laço. A do meio é a maior e a mais
// acesa; as das pontas encolhem, escurecem e desfocam. Cada garrafa tem molas próprias (giro do rótulo, inclinação,
// subida e puxão), com rigidez sorteada pela razão áurea para nunca se mexerem em bloco.
//
// A home é uma tela só (motion/troca.js): a roda e o trackpad, nos dois sentidos, andam a fila em vez de rolar a
// página; o dedo também, de lado ou de pé; as setas do teclado andam de sabor em sabor. O gesto é livre e com embalo,
// e a fila para onde ele deixar; parada por alguns segundos (e sem o mouse em cima de uma garrafa), ela faz um
// reajuste bem leve até a garrafa mais perto ficar no meio. O rótulo gira contra o movimento e volta à frente quando
// a fila para. Com
// mouse: o cursor puxa a garrafa mais perto e vira o rótulo para ele; parado sobre uma garrafa, o rótulo dá uma volta
// inteira; a pílula "Arraste" só aparece na faixa das garrafas. O clique (sem arrasto) abre a página do produto, e a
// garrafa clicada voa até lá: cada uma guarda a pose do último quadro.
import gsap from 'gsap';
import { SABORES, MARCA } from '../config.js';
import { elementoGarrafa } from '../marca/garrafa.js';
import { MOUSE, REDUZIDO, CELULAR, alturaTela, clamp, mola, passoMola, idaVolta, saida3 } from './ease.js';

const DEGRAU = [-0.05, 0.035, -0.022, 0.055, -0.04, 0.026, -0.032, 0.046, -0.012, 0.02]; // em alturas de garrafa
const VEL_MAX = 2400; // px/s em que o giro e o desfoque de movimento chegam ao máximo
const CICLO = 1.6; // s da volta inteira do rótulo no hover
const ESPERA_HOVER = 0.26; // s parado sobre a garrafa antes da volta

export function criarFila({ raiz, rotulos, cursor, lenis, aoEscolher }) {
  const fila = raiz.querySelector('[data-fila]');
  const trilho = raiz.querySelector('[data-trilho]');
  const anel = raiz.querySelector('.hero__anel');
  // a frase do anel vem do config, repetida duas vezes para fechar a volta
  const frase = raiz.querySelector('[data-anel]');
  if (frase && MARCA.anel) frase.textContent = `${MARCA.anel}${MARCA.anel}`.trim();
  // com poucos sabores a volta não fecha na tela larga (a garrafa que sai por um lado apareceria entrando pelo
  // outro): abaixo de dez, a lista se repete; as cópias não entram no teclado nem no leitor de tela
  const lista = [];
  while (lista.length < 10) lista.push(...SABORES);
  if (SABORES.length >= 10) lista.length = SABORES.length;
  const N = lista.length;

  const itens = lista.map((s, i) => {
    const copia = i >= SABORES.length;
    const li = document.createElement('li');
    li.className = 'hero__item';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'hero__btn';
    btn.setAttribute('aria-label', `${s.nome}${s.sub === 'suco integral' ? '' : ` ${s.sub}`}: ver o sabor`);
    if (copia) { btn.tabIndex = -1; li.setAttribute('aria-hidden', 'true'); }
    const g = elementoGarrafa(s, { carregar: i < 6 || i === N - 1 ? 'eager' : 'lazy', sizes: '(max-width: 760px) 60vw, 22vw' });
    btn.append(g);
    li.append(btn);
    trilho.append(li);
    return {
      i, s, li, btn, g, rot: null,
      giro: mola(), incl: mola(), sobe: mola(), px: mola(), py: mola(),
      k: 70 * (0.92 + 0.16 * ((i * 0.618034) % 1)),
      sobre: false, paradoDesde: -1, ciclo: -1, entra: 0, ordem: 0, visivel: false,
    };
  });

  // ——— medidas ———
  let vw = 0, vh = 0, hb = 0, gw = 0, S = 0, span = 0, folga = 0, cy = 0, ang = 0, cel = false;
  function medir() {
    vw = innerWidth;
    vh = alturaTela();
    cel = CELULAR();
    hb = cel ? Math.min(vh * 0.38, vw * 0.9) : Math.min(vh * 0.4, vw * 0.25);
    gw = hb * (itens[0].g.style.getPropertyValue('--asp') || 0.44);
    S = cel ? vw * 0.47 : Math.max(gw * 1.45, vw * 0.162);
    span = N * S;
    folga = (span - vw) / 2;
    cy = vh * (cel ? 0.47 : 0.53);
    ang = cel ? 0.035 : 0.085;
    trilho.style.setProperty('--g-w', `${gw.toFixed(1)}px`);
    for (const it of itens) if (it.rot) rotulos.medir(it.rot);
  }

  // ——— estado da fila ———
  let X = 0, alvo = 0, vel = 0, t0 = performance.now(), ultimoGesto = performance.now();
  let mx = -1e4, my = -1e4, mouseNaCena = false, presenca = 0, pxs = 0, pys = 0;
  let introInicio = -1, ativa = true;
  let eixo = 'x'; // eixo do arrasto no toque, decidido nos primeiros 6 px

  const largura = () => gw;
  /** posição base (antes da curva) da garrafa i na tela, em px */
  const bruto = (i, x) => ((((i * S + x + folga) % span) + span) % span) - folga;

  /** X que põe a garrafa i no meio da tela, o mais perto do X atual */
  function xDoMeio(i) {
    const alvoBruto = vw / 2;
    let x = alvoBruto - i * S;
    const k = Math.round((alvo - x) / span);
    return x + k * span;
  }
  const centraliza = (i) => { alvo = xDoMeio(i); ajuste = null; ultimoGesto = performance.now(); };

  // ——— o reajuste: parada há alguns segundos, a garrafa mais perto desliza bem devagar até o meio ———
  let ajuste = null; // { v }: a mola do reajuste em curso (px/s)
  const AJUSTE_ESPERA = 1600; // ms de fila parada antes do reajuste
  const AJUSTE_K = 6; // mola leve (amortecimento crítico): parte parada, ~90 px/s no máximo, ~1,8 s para chegar
  /** a garrafa que fica mais perto do meio com a fila em x */
  function maisPerto(x) {
    let melhor = 0, d = Infinity;
    for (const it of itens) { const b = Math.abs(bruto(it.i, x) - vw / 2); if (b < d) { d = b; melhor = it.i; } }
    return melhor;
  }

  // ——— entrada (depois da abertura) ———
  function entrar() {
    introInicio = performance.now();
    // a ordem de entrada é da esquerda para a direita na tela
    const ordem = itens.map((it) => ({ it, x: bruto(it.i, X) })).sort((a, b) => a.x - b.x);
    ordem.forEach(({ it }, n) => { it.ordem = n; });
  }

  // ——— rótulos: liga as garrafas ao cilindro, primeiro as da tela ———
  function ligarRotulos() {
    // escala até 1,34 (a do meio com o ímã do cursor); o voo usa a garrafa da página do produto, não esta
    for (const it of itens) it.rot = rotulos.liga(it.g, it.s, { escalaMax: 1.34, densidade: Math.min(devicePixelRatio || 1, 1.6) });
  }

  // ——— gestos ———
  let arrasto = null; // { id, x0, alvo0, ultimoX, ultimoT, v, ativo }
  let arrastouEm = 0;
  fila.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || !ativa) return;
    arrasto = { id: e.pointerId, x0: e.clientX, y0: e.clientY, alvo0: alvo, ultimoX: e.clientX, ultimoY: e.clientY, ultimoT: e.timeStamp, v: 0, ativo: false };
  });
  fila.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'mouse') { mx = e.clientX; my = e.clientY; mouseNaCena = true; }
    if (!arrasto || e.pointerId !== arrasto.id) return;
    // no toque o dedo de pé também anda a fila (a home não rola): subir o dedo é como rolar para baixo
    const dy = e.pointerType === 'mouse' ? 0 : e.clientY - arrasto.y0;
    let dx = e.clientX - arrasto.x0;
    if (!arrasto.ativo) {
      if (Math.hypot(dx, dy) < 6) return;
      eixo = Math.abs(dy) > Math.abs(dx) ? 'y' : 'x';
      arrasto.ativo = true;
      ajuste = null;
      try { fila.setPointerCapture(e.pointerId); } catch {}
      fila.classList.add('is-arrastando');
      cursor?.mostra('Arraste');
    }
    const dt = Math.max(1, e.timeStamp - arrasto.ultimoT);
    const passo = eixo === 'y' ? e.clientY - arrasto.ultimoY : e.clientX - arrasto.ultimoX;
    if (eixo === 'y') dx = dy;
    arrasto.v = arrasto.v * 0.7 + (passo / dt) * 0.3; // px/ms filtrado
    arrasto.ultimoX = e.clientX;
    arrasto.ultimoY = e.clientY;
    arrasto.ultimoT = e.timeStamp;
    alvo = arrasto.alvo0 + dx * 1.15;
    ultimoGesto = performance.now();
  });
  const solta = (e) => {
    if (!arrasto || (e.pointerId !== undefined && e.pointerId !== arrasto.id)) return;
    if (arrasto.ativo) {
      alvo += clamp(arrasto.v, -3.2, 3.2) * 260; // embalo (o ajuste entra quando ele acaba)
      arrastouEm = performance.now();
      try { fila.releasePointerCapture(arrasto.id); } catch {}
      fila.classList.remove('is-arrastando');
    }
    arrasto = null;
  };
  fila.addEventListener('pointerup', solta);
  fila.addEventListener('pointercancel', solta);
  fila.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') { mouseNaCena = false; cursor?.esconde(); } });
  // o clique logo depois de um arrasto não escolhe nada
  fila.addEventListener('click', (e) => { if (performance.now() - arrastouEm < 120) { e.preventDefault(); e.stopPropagation(); } }, true);

  // a roda e o trackpad, nos dois sentidos, andam a fila: a home não rola (o troca.js trava a página e chama empurra)
  function empurra(d) {
    if (ajuste) { alvo = X; ajuste = null; } // a roda pega a fila de onde ela está
    alvo -= d * 1.1;
    ultimoGesto = performance.now();
  }

  // a pílula "Arraste" só na faixa das garrafas (a trilha é inclinada: a faixa acompanha), nunca na tela inteira
  const naFaixa = (x, y) => Math.abs(y - (cy + (x - vw / 2) * Math.tan(ang))) < hb * 0.78;
  function dica(e) {
    if (e.pointerType !== 'mouse' || !ativa || arrasto?.ativo) return;
    if (e.target.closest?.('.hero__btn')) return; // em cima da garrafa: "Ver o sabor"
    if (naFaixa(e.clientX, e.clientY)) cursor?.mostra('Arraste'); else cursor?.esconde();
  }
  void lenis;

  // garrafas: hover, foco, clique
  itens.forEach((it) => {
    it.btn.addEventListener('pointerenter', (e) => {
      if (e.pointerType !== 'mouse' || !ativa) return;
      it.sobre = true;
      it.paradoDesde = performance.now();
      if (!arrasto?.ativo) cursor?.mostra('Ver o sabor');
    });
    it.btn.addEventListener('pointerleave', (e) => {
      if (e.pointerType !== 'mouse') return;
      it.sobre = false;
      it.paradoDesde = -1;
      if (!arrasto?.ativo && mouseNaCena && ativa) { if (naFaixa(e.clientX, e.clientY)) cursor?.mostra('Arraste'); else cursor?.esconde(); }
    });
    it.btn.addEventListener('focus', () => { if (!it.btn.matches(':focus-visible')) return; centraliza(it.i); });
    it.btn.addEventListener('click', () => { if (ativa) aoEscolher?.(it.s, it); });
    it.btn.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      e.preventDefault();
      const U = SABORES.length;
      const prox = itens[((it.i % U) + (e.key === 'ArrowRight' ? 1 : U - 1)) % U];
      prox.btn.focus();
      centraliza(prox.i);
    });
  });
  fila.addEventListener('pointermove', dica);

  // a fila só trabalha na home (o troca.js liga e desliga)

  // ——— o quadro ———
  function quadro() {
    const agora = performance.now();
    const dt = Math.min(1 / 30, Math.max(0.001, (agora - t0) / 1000));
    t0 = agora;
    if (!ativa || !vw) return;

    // o reajuste: sem gesto há AJUSTE_ESPERA, a fila parada e o mouse fora das garrafas
    if (!ajuste && !arrasto?.ativo && introInicio > 0 && agora - ultimoGesto > AJUSTE_ESPERA && Math.abs(vel) < 3 && !itens.some((it) => it.sobre)) {
      const meio = xDoMeio(maisPerto(X));
      if (Math.abs(meio - X) > 1) { alvo = meio; ajuste = { v: 0 }; }
    }

    const ant = X;
    if (ajuste) {
      // mola com amortecimento crítico, partindo parada: acelera de leve e chega sem passar do meio
      ajuste.v += ((alvo - X) * AJUSTE_K - ajuste.v * 2 * Math.sqrt(AJUSTE_K)) * dt;
      X += ajuste.v * dt;
      if (Math.abs(alvo - X) < 0.05 && Math.abs(ajuste.v) < 0.5) { X = alvo; ajuste = null; }
    } else {
      const kx = arrasto?.ativo ? 16 : 3.4;
      X += (alvo - X) * (1 - Math.exp(-kx * dt));
      if (Math.abs(alvo - X) < 0.05) X = alvo;
    }
    vel = (X - ant) / dt;
    const rapido = Math.min(1, Math.abs(vel) / VEL_MAX);

    // presença do mouse (para o ímã e a paralaxe acenderem e apagarem macio)
    const comMouse = MOUSE.matches && mouseNaCena && !REDUZIDO;
    presenca += ((comMouse ? 1 : 0) - presenca) * (1 - Math.exp(-3 * dt));
    if (comMouse) {
      pxs += ((mx / vw) * 2 - 1 - pxs) * (1 - Math.exp(-4 * dt));
      pys += ((my / vh) * 2 - 1 - pys) * (1 - Math.exp(-4 * dt));
    }
    raiz.style.setProperty('--px', (pxs * presenca).toFixed(4));
    raiz.style.setProperty('--py', (pys * presenca).toFixed(4));

    // entrada da forma e do anel
    const ie = introInicio < 0 ? 0 : clamp((agora - introInicio) / 1150);
    const ief = saida3(ie);
    raiz.style.setProperty('--forma-o', ief.toFixed(3));
    raiz.style.setProperty('--forma-y', `${((1 - ief) * 60).toFixed(1)}px`);
    raiz.style.setProperty('--anel-o', ief.toFixed(3));
    const giroAnel = X * (cel ? -0.035 : -0.016) - (1 - ief) * 18;
    anel.style.setProperty('--anel-giro', `${giroAnel.toFixed(2)}deg`);

    const tg = Math.tan(ang);
    // a garrafa do meio leva a classe is-meio (a gravação da prévia clica nela)
    let meio = null, dMeio = Infinity;
    for (const it of itens) { const d = Math.abs(bruto(it.i, X) - vw / 2); if (d < dMeio) { dMeio = d; meio = it; } }
    for (const it of itens) it.li.classList.toggle('is-meio', it === meio);
    for (const it of itens) {
      const b = bruto(it.i, X);
      const q = b / vw;
      const xs = (q + 0.085 * Math.tanh((q - 0.5) / 0.16)) * vw;
      const bossa = q >= 0 && q <= 1 ? Math.sin(q * Math.PI) : 0;
      const dist = Math.abs(q - 0.5) / (S / vw);
      let esc = (0.58 + bossa * (1.32 - 0.58)) * (1 - 0.08 * Math.min(1, dist));
      const brilho = 0.74 + bossa * 0.32;
      const desfoque = Math.min(cel ? 1.6 : 3.5, dist * dist * 0.5) + rapido * rapido * (cel ? 1.2 : 2.6);
      const onda = Math.sin(((it.i * S + X) / (3 * S)) * Math.PI * 2) * (cel ? 8 : 14);
      const y = cy + (xs - vw / 2) * tg + DEGRAU[it.i % DEGRAU.length] * hb;

      // entrada: da esquerda para a direita, subindo e dando uma volta no rótulo
      const e0 = introInicio < 0 ? 0 : clamp((agora - introInicio - 180 - it.ordem * 70) / 1150);
      const ee = REDUZIDO ? 1 : saida3(e0);

      // alvos das molas: o giro contra o movimento, o ímã do cursor
      let aGiro = (vel / VEL_MAX) * 38 * (REDUZIDO ? 0 : 1);
      aGiro = clamp(aGiro, -38, 38);
      let aIncl = -Math.sign(vel) * rapido * 6, aSobe = 0, aPx = 0, aPy = 0;
      if (presenca > 0.001) {
        const dx = mx - xs, dy = my - y;
        const sig = gw * 1.7;
        const perto = Math.exp(-(dx * dx + dy * dy) / (sig * sig));
        const lado = Math.tanh(dx / sig);
        aGiro += -lado * 30 * presenca * (0.3 + 0.7 * perto);
        aIncl += lado * 5 * perto * presenca;
        aSobe = 0.05 * perto * presenca;
        aPx = lado * 16 * perto * presenca + pxs * presenca * -8 * esc;
        aPy = Math.tanh(dy / (hb * 0.8)) * 16 * perto * presenca + pys * presenca * -5 * esc;
      }
      passoMola(it.giro, aGiro, it.k, 9, dt);
      passoMola(it.incl, aIncl, it.k, 9, dt);
      passoMola(it.sobe, aSobe, it.k, 9, dt);
      passoMola(it.px, aPx, it.k, 9, dt);
      passoMola(it.py, aPy, it.k, 9, dt);

      // volta inteira: parado sobre a garrafa (ou recém-chegado nela depois de um gesto)
      let ciclo = 0;
      if (it.sobre && !arrasto?.ativo && Math.abs(vel) < S * 1.2 && it.ciclo < 0 && it.paradoDesde > 0 && agora - it.paradoDesde > ESPERA_HOVER * 1000) {
        it.ciclo = agora;
        it.paradoDesde = -1;
      }
      if (it.ciclo > 0) {
        const p = (agora - it.ciclo) / 1000 / CICLO;
        if (p >= 1) it.ciclo = -1; else ciclo = idaVolta(p);
      }

      esc *= (1 + it.sobe.v) * (0.9 + 0.1 * ee);
      const w = gw, h = gw / (it.g.style.getPropertyValue('--asp') || 0.44);
      const tx = xs - w / 2 + it.px.v;
      const ty = y - h / 2 + it.py.v + (1 - ee) * 56;
      it.li.style.transform = `translate3d(${tx.toFixed(1)}px, ${ty.toFixed(1)}px, 0) rotate(${(onda + it.incl.v).toFixed(2)}deg) scale(${esc.toFixed(4)})`;
      it.li.style.opacity = ee.toFixed(3);
      it.li.style.filter = `brightness(${brilho.toFixed(3)})${desfoque > 0.3 ? ` blur(${desfoque.toFixed(2)}px)` : ''}`;
      it.li.style.zIndex = String(Math.round(esc * 100));
      // a pose na tela (centro, altura visível, rotação) e o giro do rótulo: de onde a garrafa sai quando é escolhida
      it.pose = { cx: tx + w / 2, cy: ty + h / 2, h: h * esc, rot: onda + it.incl.v, brilho };

      it.visivel = xs + (w * esc) / 2 > -40 && xs - (w * esc) / 2 < vw + 40;
      if (it.rot && it.visivel) {
        const giro = it.giro.v / 360 + ciclo + (1 - ee) * 1;
        it.pose.giro = giro;
        if (rotulos.desenha(it.rot, giro) && !it.g.classList.contains('tem-rotulo')) it.g.classList.add('tem-rotulo');
      }
    }
  }

  medir();
  X = alvo = xDoMeio(0); // a primeira garrafa no meio da tela
  addEventListener('resize', medir);
  gsap.ticker.add(quadro);

  return {
    itens,
    entrar,
    ligarRotulos,
    medir,
    /** desenha uma vez todas as garrafas da tela (a abertura espera isso antes de sair) */
    desenhaVisiveis() {
      quadro();
      return itens.filter((it) => it.visivel);
    },
    centraliza,
    /** põe a garrafa i no meio na hora, sem andar (a volta da página do produto) */
    centralizaJa(i) { X = alvo = xDoMeio(i); ajuste = null; vel = 0; ultimoGesto = performance.now(); },
    empurra,
    /** anda um sabor para um lado (setas do teclado na home) */
    passo(n) {
      const atual = this.meio;
      centraliza(((atual.i + n) % N + N) % N);
    },
    liga(sim) { ativa = sim; t0 = performance.now(); },
    get meio() {
      let melhor = itens[0], d = Infinity;
      for (const it of itens) { const b = Math.abs(bruto(it.i, X) - vw / 2); if (b < d) { d = b; melhor = it; } }
      return melhor;
    },
  };
}
