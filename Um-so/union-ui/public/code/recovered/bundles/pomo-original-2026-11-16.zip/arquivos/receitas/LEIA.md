# Receitas das imagens da Pomo

Três coisas no site parecem imagem e não são: **os rótulos das garrafas**, **as frutas de papel recortado** (da
abertura, dos cards, do pomar, da safra e do selo dos rótulos) e **o pomo verde do hero**. Tudo isso é desenhado em
código, a partir do `src/config.js` e do `src/marca/frutas.js`: trocar a marca, um sabor ou uma cor redesenha a
embalagem sozinho, sem gerar nada.

O que é imagem gerada por IA:

- **as garrafas** (`public/garrafas/`): o vidro com o suco, a tampa e o reflexo, **sem rótulo** (o rótulo é desenhado
  por cima, num canvas, pelo site);
- **as fotos** (`public/fotos/`): as cinco da galeria e a do pomar.

Os prompts estão em `prompts/`, em inglês, que é como os geradores respondem melhor. Qualquer gerador de imagem que
aceite imagem de referência serve (o do ChatGPT, o Gemini, o Midjourney, o Ideogram, o Flux); nenhum passo depende de
uma conta específica.

## A ordem

1. **O estilo das garrafas** (`estilo-garrafas.txt`): foto de estúdio, de frente, com a câmera um pouco acima (a tampa
   aparece como uma elipse fina), três garrafas iguais lado a lado, **vidro liso, sem rótulo nem escrita**, cheias de
   suco até o gargalo, num fundo cinza-claro liso sem sombra. Esse fundo é o que deixa recortar a garrafa sozinha
   depois; o vidro sem rótulo é o que deixa o site enrolar o rótulo por cima.
2. **A primeira leva** (`garrafas-a.txt`: laranja, uva e maracujá): gere sem referência e escolha com calma. Ela vira
   o modelo das outras: a mesma garrafa, a mesma luz, o mesmo tamanho no quadro.
3. **As outras levas** (`garrafas-b.txt` a `garrafas-d.txt`): uma por vez, anexando a imagem da primeira leva. Cada
   prompt já diz "use the attached image as the exact reference" e muda só a cor dos sucos. A leva `d` tem dois sabores
   a mais (tangerina e acerola), que o site não usa: estão lá para quem quiser um sabor a mais.
4. **Recortar e medir**: salve cada leva como `arquivos/fonte/bruto/garrafas-a.png` (`-b`, `-c`, `-d`) e rode, da
   raiz do projeto, `npm install -E -D sharp@0.35.5` e depois `node arquivos/fonte/garrafas.mjs`. O script separa as
   três garrafas de cada imagem, recorta o fundo (no macOS, sozinho; em outro sistema, recorte antes com qualquer
   removedor de fundo e salve o PNG transparente como `arquivos/fonte/bruto/recorte-a.png`), limpa a beirada do vidro
   (senão sobra um fio cinza do estúdio sobre o fundo escuro), grava os WebP em `public/garrafas/` e **mede o corpo
   reto de cada garrafa** em `src/marca/garrafas.json`. É essa medida que diz ao site onde o rótulo encosta: garrafa de
   outro formato funciona sem mexer no código, desde que o corpo seja um cilindro reto.
5. **As fotos** (`estilo-fotos.txt` e os `foto-*.txt`): para a garrafa sair igual à do site, anexe a garrafa já com o
   rótulo. Abra o site em `http://localhost:5173/arquivos/fonte/garrafa.html?sabor=maracuja` (troque o sabor pelo
   `id` do `config.js`), salve a garrafa como imagem (clique com o botão direito ou um print) e anexe no prompt da
   foto. Cada `foto-*.txt` diz quais garrafas aparecem nela. A `foto-pomar.txt` não leva garrafa.
6. **Converter as fotos**: salve cada uma como `arquivos/fonte/bruto/foto-<nome>.png` (`mesa`, `maracuja`, `cafe`,
   `caixote`, `verao`, `pomar`) e rode `node arquivos/fonte/fotos.mjs`. Ele grava cada foto em três larguras (1536,
   1200 e 800) em `public/fotos/`, cortada em 3:2.

## Tamanhos no site

- `public/garrafas/<sabor>.webp`: a garrafa inteira com fundo transparente, até 1100 px de altura (as do Codex saem
  com uns 800); `<sabor>-640.webp`: 640 px de altura, para o celular.
- `public/fotos/<nome>.webp`: 1536 × 1024 (3:2), mais `-1200` e `-800`.

## Os rótulos (em código, não em imagem)

`src/marca/rotulo.js` desenha a arte plana de cada sabor num canvas: em cima, o fundo claro com as frutas de papel e a
marca; embaixo, a faixa escura com o nome do sabor na frente e, nas costas, ingredientes, modo de guardar, tabela
nutricional e um código de barras de enfeite; o selo redondo fica à esquerda da marca. As cores vêm de cada sabor do
`config.js` (`fundo`, `fruta`, `folha`, `detalhe`, `semente`, `faixa`, `letra`). A tabela nutricional da demo é de
exemplo: no produto de verdade, os números vêm do laudo do produto.

## As frutas de papel (em código)

`node arquivos/fonte/frutas.mjs` gera `src/marca/frutas.js` (os contornos) e uma folha de prova,
`arquivos/fonte/frutas-previa.png`. Cada fruta é um polígono de poucos lados, um pouco torto, como cortado à tesoura;
cada parte tem um tom (0 a fruta, 1 a folha ou a casca, 2 o miolo, 3 as sementes) que o site pinta com as cores do
sabor. Para uma fruta nova, copie uma parecida no script (a `laranja` para fruta redonda, a `manga` para fruta torta,
a `uva` para cacho) e ajuste os pontos.

## Custo e alternativas

Cada imagem leva de 1 a 3 minutos. A série inteira (4 levas de garrafas e 6 fotos) cabe numa tarde e, nos planos de
assinatura dos geradores, não tem custo à parte. Sem gerar nada:

- **garrafas**: as da demo servem para qualquer suco de cor parecida (a laranja serve para tangerina, a uva para açaí,
  a maracujá para cajá). O rótulo é que muda, e ele sai do código;
- **fotos**: o pomar é genérico (fileiras de laranjeiras, sem marca) e pode ficar; as cinco da galeria mostram as
  garrafas com o nome POMO e, com outra marca, têm de ser trocadas. Fotos reais do produto da pessoa funcionam melhor
  que geradas: luz de janela, a garrafa com fruta de verdade em volta.
