// O rótulo de cada sabor, desenhado num canvas a partir do config.js: a arte plana que depois enrola no cilindro
// (src/marca/cilindro.js). A largura é a volta da garrafa menos a faixa sem rótulo; o meio (x = 0,5) é a frente.
// Em cima, o fundo claro com as frutas de papel e a marca; embaixo, a faixa escura com o nome do sabor na frente e a
// ficha (ingredientes e tabela) nas costas; o selo redondo fica em cima da divisa.
import { MARCA } from '../config.js';
import { FRUTAS } from './frutas.js';

const SERIFA = '"Bodoni Moda Variable", "Bodoni Moda", Didot, serif';
const SANS = '"Figtree Variable", Figtree, system-ui, sans-serif';

/** espera as fontes que o rótulo usa (o canvas desenharia com a fonte de reserva) */
export function fontesDoRotulo() {
  if (!document.fonts?.load) return Promise.resolve();
  return Promise.all([
    document.fonts.load(`400 80px ${SERIFA}`, 'POMO Maracujá'),
    document.fonts.load(`italic 400 30px ${SERIFA}`, 'sucos do pé'),
    document.fonts.load(`600 20px ${SANS}`, 'INGREDIENTES 300 ml'),
    document.fonts.load(`400 20px ${SANS}`, 'Informação nutricional'),
  ]).catch(() => {});
}

// sorteio com semente (o mesmo rótulo sai sempre igual)
function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
const semente = (txt) => [...txt].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);

const caminhos = new Map();
const path = (d) => {
  let p = caminhos.get(d);
  if (!p) caminhos.set(d, (p = new Path2D(d)));
  return p;
};

/** desenha uma fruta de papel centrada em (x, y), com a maior medida = tam, girada em a (radianos) */
export function fruta(ctx, id, x, y, tam, a, cores) {
  const fr = FRUTAS[id];
  if (!fr) return;
  const s = tam / Math.max(fr.w, fr.h);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(a);
  ctx.scale(s, s);
  ctx.translate(-fr.w / 2, -fr.h / 2);
  for (const p of fr.partes) {
    ctx.fillStyle = cores[p.tom] ?? cores[0];
    ctx.fill(path(p.d));
  }
  ctx.restore();
}

/** texto em arco (o selo): letras espaçadas pela volta inteira, começando no alto */
function textoEmAnel(ctx, txt, cx, cy, r, tam, cor) {
  ctx.save();
  ctx.fillStyle = cor;
  ctx.font = `600 ${tam}px ${SANS}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const letras = [...txt.toUpperCase()];
  const passo = (Math.PI * 2) / letras.length;
  letras.forEach((l, i) => {
    const a = -Math.PI / 2 + i * passo;
    ctx.save();
    ctx.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    ctx.rotate(a + Math.PI / 2);
    ctx.fillText(l, 0, 0);
    ctx.restore();
  });
  ctx.restore();
}

/** código de barras de mentira, só de enfeite (barras de largura sorteada) */
function barras(ctx, x, y, w, h, cor, seed) {
  const rnd = rng(seed);
  ctx.fillStyle = cor;
  let px = x;
  while (px < x + w) {
    const bw = 1.2 + Math.floor(rnd() * 3) * 1.1;
    if (rnd() > 0.42) ctx.fillRect(px, y, bw, h);
    px += bw + 1.1;
  }
}

/**
 * Desenha o rótulo plano do sabor.
 * @param sabor um item de SABORES
 * @param largura largura do canvas em px (a altura sai do aspecto)
 * @param aspecto largura ÷ altura da arte (vem da medida da garrafa)
 */
export function desenhaRotulo(sabor, { largura = 1536, aspecto = 2.08, canvas } = {}) {
  const L = 1000, H = Math.round(L / aspecto); // unidades de desenho
  const c = canvas ?? document.createElement('canvas');
  c.width = largura;
  c.height = Math.round(largura / aspecto);
  const ctx = c.getContext('2d');
  ctx.save();
  ctx.scale(c.width / L, c.height / H);

  const cores = [sabor.fruta, sabor.folha, sabor.detalhe, sabor.semente ?? sabor.faixa];
  // as frutas de apoio: a folha e a hortelã na cor da folha, o gengibre na cor do detalhe
  const coresDe = (id) => (id === 'folha' || id === 'hortela' ? [sabor.folha, sabor.folha] : id === 'gengibre' ? [sabor.detalhe] : cores);
  const rnd = rng(semente(sabor.id));
  const divisa = Math.round(H * 0.625);

  // fundo claro
  ctx.fillStyle = sabor.fundo;
  ctx.fillRect(0, 0, L, H);

  // as frutas de papel em volta da garrafa inteira, fora da caixa da marca (frente, no alto)
  const [principal, ...outras] = sabor.frutas;
  const lugares = [
    [70, 70, 250], [215, 210, 210], [330, 40, 150], [700, 60, 170], [800, 215, 230], [950, 70, 240],
    [-30, 230, 190], [1030, 230, 190], [470, 255, 120], [560, 270, 110],
  ];
  lugares.forEach(([x, y, t], i) => {
    const id = i % 3 === 2 && outras.length ? outras[Math.floor(i / 3) % outras.length] : principal;
    fruta(ctx, id, x + (rnd() - 0.5) * 30, y + (rnd() - 0.5) * 24, t * (0.92 + rnd() * 0.16), (rnd() - 0.5) * 1.1, coresDe(id));
  });
  // folhinhas soltas entre elas
  for (let i = 0; i < 7; i++) {
    const x = 40 + ((i * 151 + rnd() * 60) % 960), y = 30 + rnd() * (divisa - 80);
    if (x > 330 && x < 670 && y < 200) continue;
    fruta(ctx, 'folha', x, y, 70 + rnd() * 40, rnd() * Math.PI * 2, [sabor.folha, sabor.folha]);
  }

  // a marca na frente, no alto, com um respiro do fundo atrás para ler sobre as frutas
  ctx.save();
  ctx.fillStyle = sabor.fundo;
  ctx.beginPath();
  ctx.ellipse(500, 112, 170, 92, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = sabor.faixa;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  // o nome cabe em 300 unidades (nome comprido encolhe)
  let marcaTam = 92;
  ctx.font = `400 ${marcaTam}px ${SERIFA}`;
  const mw = ctx.measureText(MARCA.nome.toUpperCase()).width;
  if (mw > 300) { marcaTam = Math.floor((marcaTam * 300) / mw); ctx.font = `400 ${marcaTam}px ${SERIFA}`; }
  ctx.fillText(MARCA.nome.toUpperCase(), 500, 128);
  ctx.font = `italic 400 30px ${SERIFA}`;
  ctx.fillText(MARCA.linha, 500, 168);
  ctx.restore();

  // divisa: fio claro duplo
  ctx.fillStyle = sabor.letra;
  ctx.fillRect(0, divisa - 7, L, 3);
  ctx.fillStyle = sabor.faixa;
  ctx.fillRect(0, divisa - 4, L, H - divisa + 4);
  ctx.fillStyle = sabor.letra;
  ctx.fillRect(0, divisa + 1, L, 1.5);

  // frente da faixa: o nome do sabor (cabe em 400 unidades) e o complemento com o volume
  ctx.save();
  ctx.fillStyle = sabor.letra;
  ctx.textAlign = 'center';
  let nomeTam = 90;
  ctx.font = `400 ${nomeTam}px ${SERIFA}`;
  const larg = ctx.measureText(sabor.nome).width;
  if (larg > 400) { nomeTam = Math.floor(nomeTam * (400 / larg)); ctx.font = `400 ${nomeTam}px ${SERIFA}`; }
  ctx.fillText(sabor.nome, 500, divisa + 98);
  ctx.font = `italic 400 27px ${SERIFA}`;
  ctx.fillText(`${sabor.sub} · ${MARCA.volume}`, 500, divisa + 142);
  ctx.restore();

  // costas, à esquerda (de 22 a 232): ingredientes e modo de guardar
  ctx.save();
  ctx.fillStyle = sabor.letra;
  ctx.textAlign = 'left';
  ctx.font = `600 13px ${SANS}`;
  ctx.fillText('INGREDIENTES', 24, divisa + 36);
  ctx.font = `400 14px ${SANS}`;
  ctx.font = `400 13px ${SANS}`;
  quebra(ctx, `${capitaliza(sabor.ingredientes)}. Não contém glúten.`, 24, divisa + 55, 206, 17);
  ctx.font = `600 13px ${SANS}`;
  ctx.fillText('CONSERVE', 24, divisa + 110);
  ctx.font = `400 13px ${SANS}`;
  quebra(ctx, 'Agite antes de beber. Na geladeira, e em 3 dias depois de aberto.', 24, divisa + 129, 206, 17);
  ctx.restore();

  // costas, à direita (de 768 a 976): tabela nutricional em fios
  ctx.save();
  ctx.fillStyle = sabor.letra;
  const tx = 768, tw = 208;
  ctx.font = `600 13px ${SANS}`;
  ctx.textAlign = 'left';
  ctx.fillText('INFORMAÇÃO NUTRICIONAL', tx, divisa + 36);
  ctx.font = `400 12px ${SANS}`;
  ctx.fillText('porção de 200 ml (1 copo)', tx, divisa + 52);
  const linhas = [['Valor energético', '94 kcal'], ['Carboidratos', '22 g'], ['Açúcares totais', '18 g'], ['Açúcares adicionados', '0 g'], ['Sódio', '0 mg']];
  linhas.forEach(([k, v], i) => {
    const y = divisa + 74 + i * 19;
    ctx.globalAlpha = 0.5;
    ctx.fillRect(tx, y - 13, tw, 0.8);
    ctx.globalAlpha = 1;
    ctx.font = `400 13px ${SANS}`;
    ctx.textAlign = 'left';
    ctx.fillText(k, tx, y);
    ctx.textAlign = 'right';
    ctx.fillText(v, tx + tw, y);
  });
  ctx.restore();

  // código de barras nas costas, numa caixa clara no alto (como nos rótulos de verdade)
  ctx.save();
  ctx.fillStyle = sabor.letra;
  ctx.beginPath();
  ctx.roundRect(842, 40, 128, 104, 8);
  ctx.fill();
  barras(ctx, 856, 52, 100, 62, sabor.faixa, semente(sabor.nome));
  ctx.fillStyle = sabor.faixa;
  ctx.font = `400 11px ${SANS}`;
  ctx.textAlign = 'center';
  ctx.fillText('7 890000 000000', 906, 132);
  ctx.restore();

  // o selo redondo sobre a divisa, à esquerda da frente
  const sx = 296, sy = divisa - 92, sr = 60; // à esquerda da marca, no alto: não encosta no nome
  ctx.fillStyle = sabor.letra;
  ctx.beginPath();
  ctx.arc(sx, sy, sr, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = sabor.faixa;
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(sx, sy, sr - 6, 0, Math.PI * 2);
  ctx.stroke();
  textoEmAnel(ctx, MARCA.selo, sx, sy, sr - 18, 12.5, sabor.faixa);
  fruta(ctx, principal, sx, sy, 46, -0.2, cores);


  ctx.restore();
  return c;
}

function capitaliza(t) { return t.charAt(0).toUpperCase() + t.slice(1); }
function quebra(ctx, txt, x, y, w, lh) {
  let linha = '';
  for (const p of txt.split(' ')) {
    const t = linha ? `${linha} ${p}` : p;
    if (ctx.measureText(t).width > w && linha) { ctx.fillText(linha, x, y); y += lh; linha = p; } else linha = t;
  }
  if (linha) ctx.fillText(linha, x, y);
}
