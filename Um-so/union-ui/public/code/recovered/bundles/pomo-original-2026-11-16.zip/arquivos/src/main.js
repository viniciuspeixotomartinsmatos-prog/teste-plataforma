// O CSS não entra por aqui: vem em <link> no index.html (importado pelo JS, a página aparecia crua no recarregamento).
window.__pomo = true; // avisa a trava do index.html que o JS subiu
import gsap from 'gsap';
import { criarScroll } from './motion/smooth.js';
import { criarGuia } from './motion/guia.js';
import { scrollbar } from './motion/scrollbar.js';
import './motion/rolando.js';
import { criarCursor } from './motion/cursor.js';
import { criarRotulos } from './marca/garrafa.js';
import { criarFila } from './motion/fila.js';
import { abertura } from './motion/abertura.js';
import { criarSabor } from './motion/sabor.js';
import { SABORES, POR_ID } from './config.js';
import { criarTroca } from './motion/troca.js';
import { criarNav } from './motion/nav.js';
import { criarSabores } from './motion/sabores.js';
import { criarFotos } from './motion/fotos.js';
import { criarPomar } from './motion/pomar.js';
import { criarSafra } from './motion/safra.js';
import { criarRodape } from './motion/rodape.js';

// nada transiciona do estilo de antes do CSS: as transições voltam depois do primeiro quadro pintado
requestAnimationFrame(() => requestAnimationFrame(() => document.documentElement.classList.add('assentou')));
if (location.hash === '') scrollTo(0, 0);

const lenis = criarScroll();
if (import.meta.env.DEV) window.__lenis = lenis;
criarGuia({ lenis });
scrollbar({ lenis });

const cursor = criarCursor();
const rotulos = criarRotulos({ largura: innerWidth <= 760 ? 1280 : 1536 });
const hero = document.querySelector('[data-hero]');
const sabor = criarSabor({ raiz: document.querySelector('[data-sabor-secao]'), rotulos, lenis });
// o endereço pode já trazer um sabor (#uva): a página do produto abre nele
const doEndereco = POR_ID[location.hash.slice(1)];
sabor.mostra(doEndereco ?? SABORES[0]);
let troca = null;
const fila = criarFila({
  raiz: hero, rotulos, cursor, lenis,
  aoEscolher(s, it) { troca.abrir(s, { origem: { fila: it } }); },
});
troca = criarTroca({ lenis, sabor, fila, cursor });
sabor.titulo(troca.modo === 'produto');
if (import.meta.env.DEV) { window.__sabor = sabor; window.__troca = troca; }

criarNav({ lenis, navega: troca.navega });
// âncoras da página (nav, logo e rodapé) vão pela troca: "#topo" volta à fila, as seções rolam (na home, abrem antes)
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href^="#"]');
  if (!a || a.closest('[data-menu-painel]')) return;
  e.preventDefault();
  troca.navega(a.getAttribute('href'));
});
criarFotos({ raiz: document.querySelector('.fotos'), cursor });
criarPomar({ lenis });
criarSafra({ raiz: document.querySelector('#safra') });
criarRodape({ raiz: document.querySelector('.rodape') });
criarSabores({
  raiz: document.querySelector('#sabores'), rotulos, cursor,
  aoEscolher(s, card) { troca.abrir(s, { origem: { card } }); },
});
if (import.meta.env.DEV) window.__fila = fila;

// a primeira tela está pronta quando as fontes chegaram e as garrafas da tela têm foto e rótulo
const pronto = (async () => {
  await Promise.all([rotulos.fontes, document.fonts?.load('400 40px Zodiak').catch(() => {})]);
  fila.ligarRotulos();
  const t = performance.now();
  await new Promise((fim) => {
    const confere = () => {
      const vis = fila.itens.filter((it) => it.visivel);
      const ok = vis.length > 0 && vis.every((it) => it.g.classList.contains('tem-rotulo') && it.g.querySelector('img').complete);
      if (ok || performance.now() - t > 4500) { gsap.ticker.remove(confere); fim(); }
    };
    gsap.ticker.add(confere);
  });
})();

abertura({
  pronto, lenis,
  aoSair() {
    fila.entrar();
    document.documentElement.dataset.pronto = '1';
  },
});
// uma seção no endereço (#safra): a página do produto abre já nela
const secaoDoEndereco = !doEndereco && location.hash.length > 1 && location.hash !== '#topo' ? document.querySelector(location.hash) : null;
if (secaoDoEndereco) addEventListener('load', () => { sabor.medir(); lenis ? lenis.scrollTo(secaoDoEndereco, { immediate: true, force: true }) : secaoDoEndereco.scrollIntoView(); }, { once: true });
