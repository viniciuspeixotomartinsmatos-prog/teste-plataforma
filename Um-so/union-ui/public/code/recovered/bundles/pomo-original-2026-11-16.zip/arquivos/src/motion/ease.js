// Curvas da marca e o que a página sabe do aparelho.
import gsap from 'gsap';
import { CustomEase } from 'gsap/CustomEase';

gsap.registerPlugin(CustomEase);

// as mesmas do tokens.css: saída longa e macia, entrada seca, ida e volta para os deslizes
CustomEase.create('pm-out', '0.22, 1, 0.36, 1');
CustomEase.create('pm-in', '0.64, 0, 0.78, 0');
CustomEase.create('pm-io', '0.76, 0, 0.24, 1');

export const REDUZIDO = matchMedia('(prefers-reduced-motion: reduce)').matches;
export const MOUSE = matchMedia('(hover: hover) and (pointer: fine)');
export const CELULAR = () => innerWidth <= 760;
export const TOQUE = matchMedia('(hover: none)');

/** rola a página até y com animação: no mouse pelo Lenis; no toque, a rolagem nativa (o Lenis não conduz o dedo e
    um scrollTo dele no toque não faz nada) */
export function rolarAte(lenis, y, duracao = 1.5) {
  if (lenis && !TOQUE.matches) lenis.scrollTo(y, { duration: duracao, easing: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2), force: true });
  else scrollTo({ top: y, behavior: 'smooth' });
}

// a altura das cenas é 100svh (a tela com as barras do navegador abertas). O innerHeight cresce quando a barra do
// Safari some no meio da rolagem: medir por ele mudaria o tamanho das peças em pleno movimento.
const regua = document.createElement('div');
regua.style.cssText = 'position:fixed;left:0;top:0;width:0;height:100svh;visibility:hidden;pointer-events:none';
document.body.append(regua);
export const alturaTela = () => regua.offsetHeight || innerHeight;

export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
/** onde v está entre a e b, de 0 a 1 */
export const faixa = (v, a, b) => clamp((v - a) / (b - a));
/** fração de aproximação por quadro que dá a mesma suavidade em qualquer taxa de quadros (k = fração a 60 fps) */
export const amortece = (k, dt) => 1 - Math.pow(1 - k, dt * 60);
export const suave = (t) => t * t * (3 - 2 * t);
export const saida3 = (t) => 1 - Math.pow(1 - t, 3);
export const idaVolta = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

/** mola amortecida: { v, vel } que persegue o alvo; k = rigidez, d = amortecimento */
export const mola = () => ({ v: 0, vel: 0 });
export function passoMola(m, alvo, k, d, dt) {
  m.vel += ((alvo - m.v) * k - m.vel * d) * dt;
  m.v += m.vel * dt;
  if (Math.abs(m.vel) < 1e-4 && Math.abs(alvo - m.v) < 1e-4) { m.v = alvo; m.vel = 0; }
  return m.v;
}
