// A garrafa: a foto do vidro sem rótulo (public/garrafas/) e, por cima, um <canvas> 2D onde o cilindro desenha o
// rótulo. Este módulo junta as medidas de cada foto (src/marca/garrafas.json, geradas por fonte/garrafas.mjs), as
// artes dos rótulos (src/marca/rotulo.js) e o WebGL compartilhado (src/marca/cilindro.js).
import gsap from 'gsap';
import MEDIDAS from './garrafas.json';
import { criarCilindro } from './cilindro.js';
import { desenhaRotulo, fontesDoRotulo } from './rotulo.js';

export const LACUNA = 0.085; // fração da volta sem rótulo: ali aparece o suco
export const INCLINACAO = 0.075; // rad: a câmera da foto olha um pouco de cima

/** medidas do rótulo na foto da garrafa, em frações da foto */
export function geometria(garrafa) {
  const m = MEDIDAS[garrafa] ?? Object.values(MEDIDAS)[0];
  const aspecto = m.w / m.h;
  const { topo, base, esq, dir } = m.corpo;
  const faixa = [topo + 0.05, base - 0.065];
  const raio = ((dir - esq) * aspecto) / 2 * 1.008; // um fio além do vidro: o papel fica por fora
  const centro = (esq + dir) / 2;
  const arte = (2 * Math.PI * raio * (1 - LACUNA)) / (faixa[1] - faixa[0]); // largura ÷ altura da arte plana
  return { aspecto, faixa, raio, centro, arte };
}

const base = import.meta.env.BASE_URL;
/** endereços da foto da garrafa (a menor primeiro) */
export const fotoDa = (garrafa) => ({
  src: `${base}garrafas/${garrafa}-640.webp`,
  srcset: `${base}garrafas/${garrafa}-640.webp 280w, ${base}garrafas/${garrafa}.webp 351w`,
});

/** cria o elemento de uma garrafa (foto + canvas); o canvas ganha tamanho em medir() */
export function elementoGarrafa(sabor, { classe = '', sizes = '20vw', carregar = 'lazy' } = {}) {
  const el = document.createElement('div');
  el.className = `garrafa ${classe}`.trim();
  el.dataset.sabor = sabor.id;
  el.style.setProperty('--asp', geometria(sabor.garrafa).aspecto.toFixed(4));
  const img = document.createElement('img');
  const f = fotoDa(sabor.garrafa);
  img.className = 'garrafa__vidro';
  img.src = f.src;
  img.srcset = f.srcset;
  img.sizes = sizes;
  img.alt = '';
  img.decoding = 'async';
  img.loading = carregar;
  img.draggable = false;
  const cv = document.createElement('canvas');
  cv.className = 'garrafa__rotulo';
  cv.setAttribute('aria-hidden', 'true');
  el.append(img, cv);
  return el;
}

/**
 * Os rótulos: um cilindro só, as texturas dos sabores criadas quando a primeira garrafa daquele sabor aparece.
 * desenha(garrafa, giro) só redesenha se o giro mudou (quantizado em 1/2400 de volta) ou se pediram (sujo).
 */
export function criarRotulos({ largura = 1536 } = {}) {
  let cil = null;
  try { cil = criarCilindro(); } catch (e) { console.warn('cilindro:', e); }
  const texturas = new Map();
  const fontes = fontesDoRotulo();

  function textura(sabor) {
    let t = texturas.get(sabor.id);
    if (!t) {
      const g = geometria(sabor.garrafa);
      const c = desenhaRotulo(sabor, { largura: cil ? largura : 1024, aspecto: g.arte });
      if (cil) {
        t = cil.textura(sabor.id, c);
        c.width = c.height = 1; // a arte já está na GPU: solta a memória do canvas
      } else t = c; // sem WebGL a arte fica no canvas para a reserva em 2D
      texturas.set(sabor.id, t);
    }
    return t;
  }

  /** reserva sem WebGL: a arte enrolada em fatias de 1 px (o meio largo, as bordas apertadas) e uma sombra lateral */
  function desenha2d(item, giro) {
    const { ctx, g } = item;
    const W = ctx.canvas.width, H = ctx.canvas.height;
    const arte = textura(item.sabor);
    const impresso = 1 - LACUNA;
    const cx = g.centro * W, r = (g.raio / g.aspecto) * W;
    const y0 = g.faixa[0] * H, y1 = g.faixa[1] * H;
    ctx.clearRect(0, 0, W, H);
    for (let x = Math.ceil(cx - r); x < cx + r; x++) {
      const a = Math.asin(Math.max(-1, Math.min(1, (x + 0.5 - cx) / r)));
      const s = (((a / (Math.PI * 2) + impresso * 0.5 + giro) % 1) + 1) % 1;
      if (s >= impresso) continue;
      ctx.drawImage(arte, (s / impresso) * arte.width, 0, 1, arte.height, x, y0, 1.2, y1 - y0);
    }
    const sombra = ctx.createLinearGradient(cx - r, 0, cx + r, 0);
    sombra.addColorStop(0, 'rgba(0,0,0,0.38)');
    sombra.addColorStop(0.3, 'rgba(0,0,0,0)');
    sombra.addColorStop(0.75, 'rgba(0,0,0,0.05)');
    sombra.addColorStop(1, 'rgba(0,0,0,0.42)');
    ctx.globalCompositeOperation = 'source-atop';
    ctx.fillStyle = sombra;
    ctx.fillRect(cx - r, y0, r * 2, y1 - y0);
    ctx.globalCompositeOperation = 'source-over';
  }

  /** prepara uma garrafa para desenho: canvas no tamanho máximo em que ela aparece */
  function liga(el, sabor, { escalaMax = 1, densidade = Math.min(devicePixelRatio || 1, 1.6) } = {}) {
    const cv = el.querySelector('.garrafa__rotulo');
    const g = geometria(sabor.garrafa);
    const item = { el, cv, ctx: cv.getContext('2d'), sabor, g, giro: NaN, sujo: true, escalaMax, densidade };
    medir(item);
    return item;
  }
  function medir(item) {
    const w = item.el.offsetWidth;
    if (!w) return;
    const px = Math.round(w * item.escalaMax * item.densidade);
    const ph = Math.round(px / item.g.aspecto);
    if (item.cv.width !== px || item.cv.height !== ph) { item.cv.width = px; item.cv.height = ph; item.sujo = true; }
  }

  // no máximo uma arte nova por quadro: desenhar e subir um rótulo leva ~10–25 ms, e vários juntos travariam a
  // abertura (a física e o contador pulariam quadros)
  let quadroDaUltima = -1;
  function desenha(item, giro) {
    if (!item.cv.width) return false;
    if (!texturas.has(item.sabor.id)) {
      if (gsap.ticker.frame === quadroDaUltima) return false;
      quadroDaUltima = gsap.ticker.frame;
    }
    // sem WebGL o desenho em 2D é mais caro: menos passos de giro
    const q = cil ? Math.round(giro * 2400) / 2400 : Math.round(giro * 240) / 240;
    if (!item.sujo && q === item.giro) return false;
    if (cil && !cil.perdido()) cil.desenha(item.ctx, { textura: textura(item.sabor), ...item.g, incl: INCLINACAO, giro: q, lacuna: LACUNA });
    else if (!cil) desenha2d(item, q);
    else return false;
    item.giro = q;
    item.sujo = false;
    return true;
  }

  return { fontes, liga, medir, desenha, ok: !!cil };
  // (com o contexto WebGL perdido, as garrafas ficam no último rótulo desenhado até o navegador devolver o contexto)
}
