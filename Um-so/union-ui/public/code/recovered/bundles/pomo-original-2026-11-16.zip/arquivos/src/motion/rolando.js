// Rolando: o hover descansa enquanto a página rola e só volta quando o mouse se mexe. Com o cursor parado no meio da
// tela, a rolagem passa cards e botões por baixo dele, e o hover acenderia sozinho. A classe .is-scrolling entra no
// <html> com o primeiro evento de rolagem (o Lenis também dispara o scroll nativo) e sai no primeiro movimento de
// mouse depois de a rolagem parar; o CSS só aplica o hover sem ela. O clique, o foco e o toque continuam valendo.
// A cauda da rolagem suave (o Lenis ainda anda menos de 3 px por quadro durante quase 1 s) não conta como rolagem:
// com ela o card quase não se mexe por baixo do cursor, e contar fazia o hover demorar um segundo para pegar.
const html = document.documentElement;
const subs = new Set();
let on = false, still = true, timer = 0, px = NaN, py = NaN, yAnt = scrollY;

function set(v) {
  if (v === on) return;
  on = v;
  html.classList.toggle('is-scrolling', v);
  subs.forEach((f) => f(v));
}

addEventListener('scroll', () => {
  const d = Math.abs(scrollY - yAnt);
  yAnt = scrollY;
  if (d < 3) return; // a cauda da rolagem suave
  set(true);
  still = false;
  clearTimeout(timer);
  timer = setTimeout(() => { still = true; }, 60);
}, { passive: true });

// o mouse mexeu de verdade: a posição na tela mudou (o Safari deixa movementX/Y em zero fora do pointer lock). Na fase
// de captura, antes dos cards: o mesmo movimento que libera o hover já acende o card
addEventListener('pointermove', (e) => {
  if (e.pointerType !== 'mouse') return;
  const moved = e.clientX !== px || e.clientY !== py;
  px = e.clientX; py = e.clientY;
  if (on && still && moved) set(false);
}, { passive: true, capture: true });

export const rolando = {
  get on() { return on; },
  /** f(true) quando a rolagem começa, f(false) quando o mouse volta a mexer depois dela */
  sub(f) { subs.add(f); },
};
