// A troca entre a home e a página do produto, como num site de duas páginas, mas sem corte: a mesma garrafa nunca
// sai de cena.
//
// A home é uma tela só (html.modo-inicio): a página não rola; a roda, o trackpad, o dedo e as setas andam a fila.
// Clicar numa garrafa abre a página do produto daquele sabor (html.modo-produto): a fila, o pomo e o anel somem, e a
// garrafa clicada desce até o pé da tela, de costas, girando o rótulo; o nome entra por máscara e a página passa a
// rolar, com a garrafa subindo por cima dele (motion/sabor.js). Um card da grade faz o mesmo de onde estiver: a
// página some num véu creme, volta ao alto com o sabor novo, e a garrafa do card voa até o pé. O logo, "Início" e o
// voltar do navegador levam de volta à fila. Como num site de páginas: abrir um sabor e voltar à home entram no
// histórico (#laranja, #uva... e o endereço sem nada), e o voltar do navegador refaz o caminho.
import gsap from 'gsap';
import { SABORES, POR_ID } from '../config.js';
import { REDUZIDO, rolarAte } from './ease.js';

export function criarTroca({ lenis, sabor, fila, cursor }) {
  const html = document.documentElement;
  const hero = document.querySelector('[data-hero]');
  // a página do produto: as seções do <main> depois do hero e o rodapé (ficam inertes na home)
  const produto = [...document.querySelectorAll('main > section:not([data-hero]), [data-produto]')];
  const veu = document.createElement('div');
  veu.className = 'veu';
  veu.setAttribute('aria-hidden', 'true');
  document.body.append(veu);
  let modo = html.classList.contains('modo-produto') ? 'produto' : 'inicio';
  let ocupado = false, escondida = null;

  const alto = () => (lenis ? lenis.scroll : scrollY);
  function noAlto() {
    lenis?.scrollTo(0, { immediate: true, force: true });
    scrollTo(0, 0);
  }

  function aplica(m) {
    modo = m;
    html.classList.toggle('modo-inicio', m === 'inicio');
    html.classList.toggle('modo-produto', m === 'produto');
    for (const el of produto) el.inert = m === 'inicio';
    hero.inert = m === 'produto';
    fila.liga(m === 'inicio');
    if (m === 'inicio') lenis?.stop();
    else if (!html.classList.contains('abertura-on')) lenis?.start();
  }
  aplica(modo);

  /** a pose de um card da grade na tela (o card inclina e cresce no hover) */
  function poseDoCard(c) {
    const r = c.g.getBoundingClientRect();
    const ang = (el) => { const m = new DOMMatrixReadOnly(getComputedStyle(el).transform); return Math.atan2(m.b, m.a); };
    const th = ang(c.btn) + ang(c.g);
    const asp = parseFloat(c.g.style.getPropertyValue('--asp')) || 0.44;
    const h = r.height / (Math.cos(th) + asp * Math.abs(Math.sin(th)));
    return { cx: r.left + r.width / 2, cy: r.top + r.height / 2, h, rot: (th * 180) / Math.PI, giro: c.giro.v };
  }

  /**
   * abre a página do produto do sabor s. origem: { fila: item } (garrafa da home) ou { card } (grade); sem origem,
   * a página aparece num véu (link de seção na home, histórico). secao: elemento para onde rolar depois.
   */
  async function abrir(s, { origem = null, secao = null, historia = true } = {}) {
    if (ocupado || !s) return;
    ocupado = true;
    cursor?.esconde();
    if (historia && history.state?.pomo !== s.id) history.pushState({ pomo: s.id }, '', `#${s.id}`);
    const deInicio = modo === 'inicio';
    const fonte = origem?.fila ? { el: origem.fila.li, pose: origem.fila.pose } : origem?.card ? { el: origem.card.g, pose: poseDoCard(origem.card) } : null;
    sabor.mostra(s);

    // sem voo: véu creme por cima de tudo, troca por baixo, véu sai
    if (!fonte?.pose || REDUZIDO || secao) {
      await gsap.to(veu, { autoAlpha: 1, duration: REDUZIDO ? 0 : 0.3, ease: 'pm-out' });
      aplica('produto');
      hero.classList.remove('is-saindo');
      sabor.titulo(true);
      if (secao) lenis ? lenis.scrollTo(secao, { immediate: true, force: true }) : secao.scrollIntoView();
      else noAlto();
      sabor.medir();
      await gsap.to(veu, { autoAlpha: 0, duration: REDUZIDO ? 0 : 0.4, ease: 'pm-out' });
      ocupado = false;
      return;
    }

    // com voo: a garrafa de origem some no mesmo instante em que a do produto aparece no lugar dela
    if (deInicio) fila.liga(false); // a fila para de responder ao mouse (nada de pílula "Arraste" no caminho)
    cursor?.esconde();
    sabor.titulo(false);
    await sabor.pronta();
    fonte.el.style.visibility = 'hidden';
    escondida = fonte.el;
    if (deInicio) {
      noAlto();
      hero.classList.add('is-saindo');
    } else {
      gsap.to(veu, { autoAlpha: 1, duration: 0.3, ease: 'pm-out' });
    }
    const voo = sabor.voa(fonte.pose);
    await new Promise((r) => setTimeout(r, deInicio ? 380 : 330));
    if (deInicio) {
      aplica('produto');
      hero.classList.remove('is-saindo');
    } else {
      noAlto();
      sabor.medir();
      fonte.el.style.visibility = '';
      escondida = null;
      gsap.to(veu, { autoAlpha: 0, duration: 0.42, ease: 'pm-out' });
    }
    setTimeout(() => sabor.titulo(true), deInicio ? 180 : 260);
    await voo;
    ocupado = false;
  }

  /** de volta à fila: a home aparece por cima, com o sabor aberto no meio e as garrafas entrando de novo */
  async function voltar({ historia = true } = {}) {
    if (modo === 'inicio' || ocupado) return;
    ocupado = true;
    cursor?.esconde();
    if (historia) history.pushState(null, '', location.pathname + location.search);
    const atual = sabor.atual ?? SABORES[0];
    const i = fila.itens.findIndex((it) => it.s === atual);
    if (escondida) { escondida.style.visibility = ''; escondida = null; }
    for (const it of fila.itens) it.li.style.visibility = '';
    fila.centralizaJa(Math.max(0, i));
    hero.classList.add('is-entrando');
    aplica('inicio');
    fila.entrar();
    requestAnimationFrame(() => hero.classList.remove('is-entrando'));
    await new Promise((r) => setTimeout(r, 450));
    noAlto();
    sabor.titulo(false);
    ocupado = false;
  }

  // a roda e o trackpad na home andam a fila (a página não rola)
  addEventListener('wheel', (e) => {
    if (modo !== 'inicio' || html.classList.contains('menu-aberto') || html.classList.contains('abertura-on')) return;
    if (e.ctrlKey) return; // pinça de zoom
    if (e.cancelable) e.preventDefault();
    if (ocupado) return;
    const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    fila.empurra(e.deltaMode === 1 ? d * 32 : d);
  }, { passive: false });

  // o teclado na home: setas e página andam a fila; Enter abre a do meio
  addEventListener('keydown', (e) => {
    if (modo !== 'inicio' || ocupado || html.classList.contains('menu-aberto') || html.classList.contains('abertura-on')) return;
    if (e.target.closest?.('input, textarea, select')) return;
    const naGarrafa = e.target.closest?.('.hero__btn');
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' '].includes(e.key) && !(naGarrafa && e.key === ' ')) {
      if (naGarrafa && e.key === 'ArrowRight') return; // a garrafa focada cuida das setas de lado
      e.preventDefault();
      fila.passo(1);
    } else if (['ArrowLeft', 'ArrowUp', 'PageUp'].includes(e.key)) {
      if (naGarrafa && e.key === 'ArrowLeft') return;
      e.preventDefault();
      fila.passo(-1);
    } else if (e.key === 'Enter' && !naGarrafa) {
      e.preventDefault();
      abrir(fila.meio.s, { origem: { fila: fila.meio } });
    }
  });

  // o voltar e o avançar do navegador
  addEventListener('popstate', (e) => {
    const s = e.state?.pomo ? POR_ID[e.state.pomo] : POR_ID[location.hash.slice(1)];
    if (!s) { voltar({ historia: false }); return; }
    if (modo === 'inicio' || sabor.atual !== s) abrir(s, { historia: false });
  });

  /** os links de âncora: "#topo" volta à fila; na home, os outros abrem o produto do sabor do meio e rolam até lá */
  function navega(href) {
    if (href === '#topo') { voltar(); return; }
    const alvo = document.querySelector(href);
    if (!alvo) return;
    if (modo === 'inicio') { abrir(fila.meio.s, { secao: href === '#sabor' ? null : alvo }); return; }
    if (href === '#sabor') { rolarAte(lenis, 0); return; }
    rolarAte(lenis, alvo.getBoundingClientRect().top + alto());
  }

  return {
    abrir, voltar, navega,
    get modo() { return modo; },
  };
}
