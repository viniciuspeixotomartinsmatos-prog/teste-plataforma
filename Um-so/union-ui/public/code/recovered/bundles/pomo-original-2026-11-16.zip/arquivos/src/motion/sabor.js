// O sabor: o alto da página do produto. O nome gigante fica preso enquanto a garrafa sobe do pé, girando o rótulo das
// costas para a frente, e para por cima dele; depois a ficha. mostra(sabor) troca tudo (nome, ficha, garrafa) e é
// chamada pela troca (motion/troca.js) quando uma garrafa da fila ou um card da grade abre o produto.
//
// A garrafa que chega é a mesma que foi clicada: voa(pose) tira a garrafa desta cena para uma camada fixa por cima de
// tudo, põe na pose da que foi clicada (centro, altura, inclinação e giro do rótulo) e a leva até o pé da tela, de
// costas, onde a rolagem assume (a pose final é a mesma que quadro() desenha com a página no alto). O nome entra por
// máscara, linha a linha, depois que ela pousa.
import gsap from 'gsap';
import { MARCA } from '../config.js';
import { elementoGarrafa } from '../marca/garrafa.js';
import { REDUZIDO, alturaTela, clamp, idaVolta, saida3, lerp, CELULAR } from './ease.js';

/** as duas linhas do nome: "Suco de / Laranja" ou "Abacaxi com / hortelã" */
export function linhasDoNome(s) {
  if (s.sub === 'suco integral') return ['Suco de', s.nome];
  const [com, ...resto] = s.sub.split(' ');
  return [`${s.nome} ${com}`, resto.join(' ')];
}

const GIRO_PE = -0.5; // o rótulo no pé da tela: de costas (ingredientes e tabela à mostra)

export function criarSabor({ raiz, rotulos, lenis }) {
  const $ = (sel) => raiz.querySelector(sel);
  const cena = $('.sabor__cena');
  const fixo = $('.sabor__fixo');
  const caixa = $('[data-s-garrafa]');
  let atual = null, item = null, topo = 0, vh = 0, larg = 0, voando = false;

  function medir() {
    vh = alturaTela();
    larg = innerWidth;
    topo = cena.getBoundingClientRect().top + (lenis ? lenis.scroll : scrollY);
    if (item) rotulos.medir(item);
  }

  // o nome fica sempre em duas linhas: se a mais larga não cabe (ABACAXI COM no celular), o corpo diminui só ali
  const tituloEl = $('.sabor__titulo');
  function encaixa() {
    tituloEl.style.fontSize = '';
    const cabe = tituloEl.clientWidth - 2 * Math.max(16, larg * 0.03);
    const maior = Math.max(...[...tituloEl.querySelectorAll('.linha')].map((l) => l.scrollWidth));
    if (maior > cabe) tituloEl.style.fontSize = `${(parseFloat(getComputedStyle(tituloEl).fontSize) * cabe / maior).toFixed(1)}px`;
  }

  function mostra(s) {
    if (atual === s) return;
    atual = s;
    const [l1, l2] = linhasDoNome(s);
    $('[data-s-linha1]').textContent = l1;
    $('[data-s-linha2]').textContent = l2;
    encaixa();
    $('[data-s-nome-sr]').textContent = `${l1} ${l2}`;
    $('[data-s-tipo]').textContent = s.tipo;
    $('[data-s-descr]').textContent = s.descricao;
    $('[data-s-ingr]').textContent = `${s.ingredientes}. Sem açúcar, sem água, sem conservante.`;
    $('[data-s-combina]').textContent = s.combina;
    $('[data-s-validade]').textContent = s.validade;
    $('[data-s-tamanhos]').innerHTML = s.tamanhos.map((t) => `<li>${t}</li>`).join('');
    raiz.style.setProperty('--sabor-card', s.card);
    const el = elementoGarrafa(s, { carregar: 'eager', sizes: '(max-width: 760px) 70vw, 30vw' });
    el.querySelector('img').alt = `Garrafa de ${l1.toLowerCase()} ${l2.toLowerCase()} ${MARCA.nome}, ${MARCA.volume}`;
    caixa.replaceChildren(el);
    caixa.style.setProperty('--asp', el.style.getPropertyValue('--asp'));
    item = rotulos.liga(el, s, { escalaMax: 1.06, densidade: Math.min(devicePixelRatio || 1, 2) });
  }

  /** a pose da garrafa com a página no alto: no pé da tela, um pouco à direita e inclinada (a mesma de quadro()) */
  function pose(e) {
    const h = caixa.offsetHeight;
    const y0 = vh * 0.78, y1 = vh * (larg <= 760 ? 0.22 : 0.19);
    const ty = y0 + (y1 - y0) * e;
    return {
      tx: (1 - e) * larg * 0.02, ty,
      rot: 11 * (1 - e) - 4 * e,
      esc: 0.96 + 0.08 * e,
      giro: GIRO_PE * (1 - e) + Math.sin(e * Math.PI) * 0.04,
      cx: larg / 2 + (1 - e) * larg * 0.02, cy: ty + h / 2,
    };
  }

  // a subida: presa à rolagem dentro da cena, suavizada pelo Lenis
  function quadro() {
    if (!item || voando) return;
    const y = lenis ? lenis.scroll : scrollY;
    if (y < topo - vh * 1.2 || y > topo + vh * 2.2) return; // longe da tela: nada a fazer
    const p = clamp((y - topo) / (vh * (CELULAR() ? 0.62 : 0.95))); // no celular a cena presa é mais curta
    const e = REDUZIDO ? 1 : idaVolta(p);
    const q = pose(e);
    caixa.style.transform = `translate3d(calc(-50% + ${q.tx.toFixed(1)}px), ${q.ty.toFixed(1)}px, 0) rotate(${q.rot.toFixed(2)}deg) scale(${q.esc.toFixed(4)})`;
    if (rotulos.desenha(item, q.giro)) item.el.classList.add('tem-rotulo');
  }

  /** espera a foto da garrafa nova (no máximo um quarto de segundo) para o voo não começar com o vidro vazio */
  async function pronta() {
    const img = caixa.querySelector('img');
    if (!img || img.complete) return;
    await Promise.race([img.decode().catch(() => {}), new Promise((r) => setTimeout(r, 250))]);
  }

  /**
   * leva a garrafa da pose de origem (na tela: cx, cy, h visível, rot em graus, giro do rótulo em voltas) até o pé
   * da tela. Resolve quando ela pousa e a rolagem assume.
   */
  function voa(de, { duracao = 0.95 } = {}) {
    medir();
    const ate = pose(0);
    const w = caixa.offsetWidth, h = caixa.offsetHeight;
    const hFim = h * ate.esc;
    // o rótulo dá entre meia e uma volta e meia para trás no caminho, e chega de costas
    let dg = (((ate.giro - de.giro) % 1) + 1) % 1 - 1;
    if (dg > -0.4) dg -= 1;
    voando = true;
    document.body.append(caixa);
    caixa.classList.add('is-voando');
    const o = { t: 0 };
    const desenha = () => {
      const t = o.t, ep = idaVolta(t), er = saida3(t);
      const cx = lerp(de.cx, ate.cx, ep), cy = lerp(de.cy, ate.cy, ep);
      const s = lerp(de.h, hFim, ep) / h;
      const r = lerp(de.rot, ate.rot, er);
      caixa.style.transform = `translate3d(${(cx - w / 2).toFixed(1)}px, ${(cy - h / 2).toFixed(1)}px, 0) rotate(${r.toFixed(2)}deg) scale(${s.toFixed(4)})`;
      if (rotulos.desenha(item, de.giro + dg * er)) item.el.classList.add('tem-rotulo');
    };
    desenha();
    return new Promise((fim) => {
      gsap.to(o, {
        t: 1, duration: duracao, ease: 'none', onUpdate: desenha,
        onComplete() { pousa(); fim(); },
      });
    });
  }

  /** a garrafa volta para a cena, na pose de página no alto, e a rolagem assume */
  function pousa() {
    fixo.append(caixa);
    caixa.classList.remove('is-voando');
    voando = false;
    medir();
    quadro();
  }

  /** o nome e os rótulos dos lados: escondidos (antes da garrafa chegar) ou entrando por máscara */
  function titulo(sim) {
    raiz.classList.toggle('is-titulo-fora', !sim);
  }

  medir();
  addEventListener('resize', () => { medir(); encaixa(); });
  new ResizeObserver(medir).observe(document.body);
  document.fonts?.ready.then(encaixa);
  gsap.ticker.add(quadro);
  return { mostra, medir, pronta, voa, titulo, get atual() { return atual; }, get topo() { return topo; } };
}
