// As frutas de papel recortado da Pomo: polígonos de poucos lados, um pouco tortos, como cortados à tesoura.
// Gera src/marca/frutas.js (os caminhos, para o canvas dos rótulos, a abertura com física e o hover dos cards) e uma
// folha de prova em fonte/frutas-previa.png.
// Rodar da raiz do projeto: node fonte/frutas.mjs (ou node arquivos/fonte/frutas.mjs)
import { writeFileSync } from 'node:fs';
import sharp from 'sharp';

const R = 300; // todas desenhadas numa caixa de 300 × 300 (mais larga ou mais alta quando a fruta pede)

// sorteio com semente: a mesma fruta sai sempre igual
function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
const f = (n) => Math.round(n * 10) / 10;
const caminho = (pts) => `M${pts.map(([x, y]) => `${f(x)} ${f(y)}`).join('L')}Z`;

/** contorno em polígono: r(θ) dá o raio em cada ângulo; n lados; tremido = fração do raio */
function contorno(cx, cy, r, n, tremido, seed, giro = 0) {
  const rnd = rng(seed);
  const pts = [];
  for (let i = 0; i < n; i++) {
    const t = giro + (i / n) * Math.PI * 2 + (rnd() - 0.5) * (Math.PI / n) * 0.5;
    const k = 1 + (rnd() - 0.5) * 2 * tremido;
    const [rx, ry] = r(t);
    pts.push([cx + Math.cos(t) * rx * k, cy + Math.sin(t) * ry * k]);
  }
  return pts;
}
const elipse = (rx, ry) => () => [rx, ry];

/** folha: dois arcos de poucos lados entre a base e a ponta */
function folha(x0, y0, x1, y1, largura, lados = 4, seed = 1) {
  const rnd = rng(seed);
  const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy);
  const nx = -dy / L, ny = dx / L;
  const pts = [[x0, y0]];
  for (let i = 1; i < lados; i++) {
    const t = i / lados, w = Math.sin(t * Math.PI) * largura * (0.9 + rnd() * 0.2);
    pts.push([x0 + dx * t + nx * w, y0 + dy * t + ny * w]);
  }
  pts.push([x1, y1]);
  for (let i = lados - 1; i > 0; i--) {
    const t = i / lados, w = Math.sin(t * Math.PI) * largura * (0.9 + rnd() * 0.2);
    pts.push([x0 + dx * t - nx * w, y0 + dy * t - ny * w]);
  }
  return pts;
}
/** folha serrilhada (hortelã) */
function folhaSerra(x0, y0, x1, y1, largura, dentes = 6) {
  const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy);
  const nx = -dy / L, ny = dx / L;
  const lado = (s) => {
    const p = [];
    for (let i = 1; i < dentes * 2; i++) {
      const t = i / (dentes * 2), w = Math.sin(t * Math.PI) * largura * (i % 2 ? 1 : 0.82);
      p.push([x0 + dx * t + s * nx * w, y0 + dy * t + s * ny * w]);
    }
    return p;
  };
  return [[x0, y0], ...lado(1), [x1, y1], ...lado(-1).reverse()];
}
/** cabinho: um retângulo torto */
function cabo(x0, y0, x1, y1, w) {
  const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy);
  const nx = (-dy / L) * w / 2, ny = (dx / L) * w / 2;
  return [[x0 - nx, y0 - ny], [x1 - nx * 0.7, y1 - ny * 0.7], [x1 + nx * 0.7, y1 + ny * 0.7], [x0 + nx, y0 + ny]];
}
/** coroa de pontas (abacaxi, cálice da goiaba) */
function coroa(cx, cy, pontas, raio, abertura, base, seed) {
  const rnd = rng(seed);
  const pts = [];
  for (let i = 0; i < pontas; i++) {
    const a = -Math.PI / 2 + (i / (pontas - 1) - 0.5) * abertura;
    const a0 = a - abertura / pontas / 2, a1 = a + abertura / pontas / 2;
    const r = raio * (0.75 + rnd() * 0.35) * (1 - Math.abs(i / (pontas - 1) - 0.5) * 0.5);
    if (i === 0) pts.push([cx + Math.cos(a0) * base, cy + Math.sin(a0) * base * 0.5]);
    pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    pts.push([cx + Math.cos(a1) * base, cy + Math.sin(a1) * base * 0.5]);
  }
  return pts;
}
/** cacho: círculos de poucos lados (uva, jabuticaba) */
const bolinha = (cx, cy, r, seed, n = 9) => contorno(cx, cy, elipse(r, r), n, 0.05, seed);

// ——— as frutas ———
// cada uma: partes [{ d, tom }] em que tom 0 é a cor da fruta, 1 a folha/coroa/casca, 2 o detalhe (miolo, rubor,
// castanha) e 3 as sementes
const FRUTAS = {};
const add = (id, nome, w, h, partes) => { FRUTAS[id] = { id, nome, w, h, partes }; };

// laranja: quase redonda, folha e cabinho
add('laranja', 'laranja', R, R, [
  { tom: 0, d: caminho(contorno(150, 168, elipse(112, 108), 13, 0.035, 11, 0.2)) },
  { tom: 1, d: caminho(folha(160, 66, 248, 22, 26, 4, 3)) },
  { tom: 1, d: caminho(cabo(150, 70, 158, 46, 9)) },
]);
// uva: cacho de bolinhas num triângulo de ponta para baixo, cabo e folha
{
  const bagos = [];
  const fileiras = [[5, 88], [4, 132], [4, 172], [3, 210], [2, 246], [1, 278]];
  let seed = 20;
  fileiras.forEach(([n, y], fi) => {
    for (let i = 0; i < n; i++) {
      const x = 150 + (i - (n - 1) / 2) * 44 + (fi % 2 ? 8 : -4);
      bagos.push({ tom: 0, d: caminho(bolinha(x, y, 25, seed++)) });
    }
  });
  add('uva', 'uva', R, R + 10, [
    ...bagos,
    { tom: 1, d: caminho(cabo(150, 64, 140, 20, 10)) },
    { tom: 1, d: caminho(folha(146, 40, 248, 30, 34, 5, 7)) },
  ]);
}
// maracujá: ovo de poucos lados com o cabinho torto e uma folha fina
{
  const rnd = rng(33);
  const sementes = [];
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2 + rnd() * 0.3, r = i % 2 ? 46 : 74;
    const x = 150 + Math.cos(a) * r, y = 160 + Math.sin(a) * r * 0.96;
    sementes.push({ tom: 3, d: caminho(contorno(x, y, elipse(7, 9), 5, 0.1, 300 + i, a)) });
  }
  add('maracuja', 'maracujá', R, R, [
    { tom: 0, d: caminho(contorno(150, 160, elipse(122, 118), 13, 0.03, 31, 0.1)) },
    { tom: 2, d: caminho(contorno(150, 160, elipse(100, 96), 12, 0.04, 32, 0.3)) },
    ...sementes,
  ]);
}
// caju: o pedúnculo em sino (largo em cima) e a castanha pendurada embaixo
{
  const corpo = [[86, 70], [130, 52], [176, 54], [214, 74], [222, 116], [212, 160], [196, 196], [176, 224], [150, 236], [124, 226], [104, 198], [88, 160], [76, 114]];
  const castanha = [[150, 226], [178, 232], [196, 252], [188, 278], [160, 292], [128, 288], [112, 268], [124, 252], [146, 250]];
  add('caju', 'caju', R, R + 10, [
    { tom: 0, d: caminho(corpo) },
    { tom: 2, d: caminho(castanha) },
    { tom: 1, d: caminho(cabo(148, 56, 156, 26, 10)) },
  ]);
}
// goiaba: redonda, um pouco de pera, com o cálice em coroa na ponta de baixo e uma folha
{
  const rnd = rng(43);
  const sementes = [];
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 + rnd() * 0.25;
    sementes.push({ tom: 3, d: caminho(contorno(150 + Math.cos(a) * 44, 166 + Math.sin(a) * 50, elipse(6, 6), 5, 0.1, 400 + i, a)) });
  }
  add('goiaba', 'goiaba', R, R, [
    { tom: 1, d: caminho(contorno(150, 164, (t) => [112 + Math.sin(t) * 8, 124], 13, 0.03, 41, 0.3)) },
    { tom: 0, d: caminho(contorno(150, 166, (t) => [98 + Math.sin(t) * 7, 110], 12, 0.035, 42, 0.5)) },
    { tom: 2, d: caminho(contorno(150, 166, elipse(30, 36), 8, 0.06, 44, 0.2)) },
    ...sementes,
    { tom: 1, d: caminho(cabo(150, 44, 156, 18, 9)) },
  ]);
}
// abacaxi: corpo oval facetado e a coroa de folhas pontudas
{
  const losangos = [];
  for (let fi = 0; fi < 5; fi++) for (let i = 0; i < 4 - (fi % 2 ? 1 : 0) + (fi > 0 && fi < 4 ? 0 : -1); i++) {
    const n = 4 - (fi % 2 ? 1 : 0) + (fi > 0 && fi < 4 ? 0 : -1);
    const x = 150 + (i - (n - 1) / 2) * 40, y = 168 + fi * 38;
    losangos.push({ tom: 2, d: caminho([[x, y - 12], [x + 9, y], [x, y + 12], [x - 9, y]]) });
  }
  add('abacaxi', 'abacaxi', R, R + 60, [
    { tom: 1, d: caminho(coroa(150, 136, 9, 132, 2.1, 58, 12)) },
    { tom: 0, d: caminho(contorno(150, 244, elipse(96, 116), 14, 0.025, 51, 0.15)) },
    ...losangos,
  ]);
}
// limão: oval com bicos nas pontas, deitado, com folha
{
  const rnd = rng(61);
  const pts = [];
  const n = 14;
  for (let i = 0; i < n; i++) {
    const t = (i / n) * Math.PI * 2;
    const bico = Math.pow(Math.abs(Math.cos(t)), 6) * 22;
    pts.push([150 + Math.cos(t) * (112 + bico) * (1 + (rnd() - 0.5) * 0.05), 168 + Math.sin(t) * 88 * (1 + (rnd() - 0.5) * 0.05)]);
  }
  add('limao', 'limão', R, R, [
    { tom: 0, d: caminho(pts) },
    { tom: 1, d: caminho(folha(132, 84, 64, 20, 22, 4, 13)) },
  ]);
}
// manga: gota torta (rim), com cabinho e folha comprida
{
  const pts = [[104, 92], [150, 64], [202, 66], [244, 98], [262, 150], [250, 206], [214, 250], [164, 272], [116, 264], [86, 232], [84, 190], [100, 150], [96, 120]];
  const rubor = [[150, 64], [202, 66], [244, 98], [262, 150], [254, 186], [226, 150], [196, 112], [160, 92]];
  add('manga', 'manga', R, R, [
    { tom: 0, d: caminho(pts) },
    { tom: 2, d: caminho(rubor) },
    { tom: 1, d: caminho(cabo(150, 64, 138, 34, 9)) },
    { tom: 1, d: caminho(folha(140, 40, 34, 34, 22, 5, 17)) },
  ]);
}
// melancia: fatia em leque com a casca em arco
{
  const polpa = [[150, 52]];
  const casca = [];
  const n = 9;
  for (let i = 0; i <= n; i++) {
    const a = Math.PI * (0.18 + (i / n) * 0.64);
    polpa.push([150 + Math.cos(a) * 196 * -1 + 0, 52 + Math.sin(a) * 196]);
  }
  for (let i = n; i >= 0; i--) {
    const a = Math.PI * (0.18 + (i / n) * 0.64);
    casca.push([150 - Math.cos(a) * 196, 52 + Math.sin(a) * 196]);
  }
  for (let i = 0; i <= n; i++) {
    const a = Math.PI * (0.18 + (i / n) * 0.64);
    casca.push([150 - Math.cos(a) * 228, 52 + Math.sin(a) * 228]);
  }
  // sementes: losangos pequenos dentro da polpa
  const sementes = [[150, 150], [112, 176], [188, 176], [128, 212], [172, 212], [150, 196]].map(([x, y], i) => ({
    tom: 3, d: caminho([[x, y - 9], [x + 5, y], [x, y + 9], [x - 5, y]].map(([px, py]) => [px + (i % 2) * 2, py])),
  }));
  add('melancia', 'melancia', R, R, [{ tom: 0, d: caminho(polpa) }, { tom: 1, d: caminho(casca) }, ...sementes]);
}
// jabuticaba: bolinhas grudadas num galho
add('jabuticaba', 'jabuticaba', R, R, [
  { tom: 1, d: caminho([[20, 210], [120, 168], [290, 120], [292, 132], [124, 182], [26, 222]]) },
  { tom: 0, d: caminho(bolinha(92, 150, 50, 71, 10)) },
  { tom: 0, d: caminho(bolinha(168, 196, 58, 72, 11)) },
  { tom: 0, d: caminho(bolinha(236, 104, 44, 73, 10)) },
  { tom: 0, d: caminho(bolinha(70, 246, 40, 74, 9)) },
]);
// folha solta, hortelã e gengibre (enchimento da abertura e dos rótulos)
add('folha', 'folha', R, R, [{ tom: 1, d: caminho(folha(40, 250, 262, 44, 66, 5, 81)) }, { tom: 0, d: caminho(cabo(20, 272, 52, 240, 10)) }]);
add('hortela', 'hortelã', R, R, [{ tom: 1, d: caminho(folhaSerra(60, 252, 244, 52, 70, 6)) }]);
add('gengibre', 'gengibre', R, R, [{
  tom: 0, d: caminho([[40, 170], [70, 128], [104, 136], [118, 96], [150, 82], [168, 110], [158, 140], [198, 128], [230, 96], [262, 112], [258, 150], [232, 176], [250, 210], [222, 236], [184, 220], [150, 236], [108, 228], [70, 214]]),
}]);

// ——— saída ———
const js = `// Gerado por fonte/frutas.mjs: não editar à mão.
// Frutas de papel recortado: cada parte tem um tom (0 a fruta, 1 a folha ou coroa, 2 o detalhe) e um caminho SVG.
export const FRUTAS = ${JSON.stringify(FRUTAS, null, 1)};
`;
writeFileSync(`${process.cwd()}/src/marca/frutas.js`, js);

// folha de prova: as frutas em duas cores de amostra
const TONS = {
  laranja: ['#f47a1f', '#2f7a3b', '#ffd27a'], uva: ['#5b2a6e', '#3f7a35', '#b98ad0'], maracuja: ['#f2b705', '#2b1a12', '#ffd84a'],
  caju: ['#e8412c', '#3f7a35', '#8a5a2b'], goiaba: ['#f2708a', '#6f9a3a', '#ff9db0', '#ffe7c2'], abacaxi: ['#f2b705', '#2f8a4b', '#c98a06'],
  limao: ['#7bbf3a', '#2f7a3b', '#e9f2b0'], manga: ['#f7a823', '#2f7a3b', '#ef5a2b'], melancia: ['#e83b45', '#2f8a4b', '#ff8a92', '#1d1d1d'],
  jabuticaba: ['#2b1a2e', '#6b4a2b', '#5b2a6e'], folha: ['#2f6b2f', '#3f9a45', '#000'], hortela: ['#3f9a45', '#3f9a45', '#000'],
  gengibre: ['#d9a25b', '#000', '#000'],
};
const ids = Object.keys(FRUTAS);
const cols = 5, cel = 260;
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${cols * cel}" height="${Math.ceil(ids.length / cols) * cel}" style="background:#fbf3e6">
<rect width="100%" height="100%" fill="#fbf3e6"/>
${ids.map((id, i) => {
  const fr = FRUTAS[id], s = (cel - 40) / Math.max(fr.w, fr.h);
  const x = (i % cols) * cel + (cel - fr.w * s) / 2, y = Math.floor(i / cols) * cel + (cel - fr.h * s) / 2;
  return `<g transform="translate(${x} ${y}) scale(${s})">${fr.partes.map((p) => `<path d="${p.d}" fill="${TONS[id][p.tom]}"/>`).join('')}</g>`;
}).join('\n')}
</svg>`;
await sharp(Buffer.from(svg)).png().toFile(new URL('./frutas-previa.png', import.meta.url).pathname);
console.log(`${ids.length} frutas`);

// ——— a forma do hero: o pomo gigante (polígono de 15 lados) com uma folha pequena e o cabinho no alto ———
{
  const corpo = contorno(150, 170, elipse(118, 116), 15, 0.022, 901, -Math.PI / 2 + 0.1);
  const folhaH = folha(155, 57, 190, 36, 9, 4, 902);
  const caboH = cabo(150, 58, 152, 46, 4.5);
  const forma = { corpo: caminho(corpo), folha: caminho(folhaH), cabo: caminho(caboH) };
  writeFileSync(new URL('./forma-hero.json', import.meta.url), JSON.stringify(forma, null, 1));
  console.log('forma do hero em fonte/forma-hero.json');
}
