// A abertura: as frutas de papel caem com física de verdade (matter.js), batem e se empilham até encher a tela, por
// cima do contador. O contador é o carregamento: só chega a 100% quando as fontes, as fotos das garrafas da primeira
// tela e os rótulos delas estão prontos (e nunca antes de ~1,7 s). Então a varredura na cor de destaque sobe do pé,
// cobre tudo e sai pelo alto, descobrindo o hero, que entra por baixo dela.
//
// Rolar, apertar uma tecla ou arrastar o dedo leva a abertura direto ao fim. Clicar numa fruta dá um empurrão nelas.
import Matter from 'matter-js';
import gsap from 'gsap';
import { FRUTAS } from '../marca/frutas.js';
import { SABORES } from '../config.js';
import { CELULAR, alturaTela, clamp } from './ease.js';

const { Engine, Bodies, Body, Composite, Sleeping, Vertices } = Matter;

const MIN_MS = 1700; // o contador nunca chega a 100 antes disso
const MAX_MS = 6500; // se algo travar, a abertura sai assim mesmo

// as cores de cada fruta vêm do sabor em que ela é a principal; folha, hortelã e gengibre têm cor própria
function coresDaFruta(id) {
  const s = SABORES.find((x) => x.frutas[0] === id);
  if (s) return [s.fruta, s.folha, s.detalhe, s.semente ?? s.faixa];
  if (id === 'gengibre') return ['#d9a25b'];
  return ['#2e7d3a', '#3f9a45'];
}

/** pontos do polígono de um caminho "M x y L x y ... Z" */
const pontos = (d) => d.replace(/[MZ]/g, '').split('L').map((p) => p.trim().split(/\s+/).map(Number));

/** casco convexo (cadeia monótona) */
function casco(pts) {
  const p = [...pts].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cruz = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const baixo = [], cima = [];
  for (const q of p) { while (baixo.length >= 2 && cruz(baixo.at(-2), baixo.at(-1), q) <= 0) baixo.pop(); baixo.push(q); }
  for (const q of p.reverse()) { while (cima.length >= 2 && cruz(cima.at(-2), cima.at(-1), q) <= 0) cima.pop(); cima.push(q); }
  return baixo.slice(0, -1).concat(cima.slice(0, -1));
}

function svgDaFruta(id) {
  const fr = FRUTAS[id];
  const cores = coresDaFruta(id);
  return `<svg viewBox="0 0 ${fr.w} ${fr.h}" aria-hidden="true">${fr.partes.map((p) => `<path d="${p.d}" fill="${cores[p.tom] ?? cores[0]}"/>`).join('')}</svg>`;
}

/**
 * @param pronto Promise que resolve quando a primeira tela está carregada (fontes, fotos, rótulos)
 * @param aoSair chamado quando a varredura começa a descobrir a página (o hero entra aqui)
 */
export function abertura({ pronto, aoSair, lenis }) {
  const html = document.documentElement;
  const raiz = document.querySelector('.abertura');
  if (!html.classList.contains('abertura-on') || !raiz) {
    aoSair?.();
    return;
  }
  lenis?.stop();
  const palco = raiz.querySelector('[data-palco]');
  const conta = raiz.querySelector('[data-conta]');
  const varre = raiz.querySelector('[data-varre]');
  const t0 = performance.now();
  let carregou = false, saindo = false;
  pronto.then(() => { carregou = true; });

  // o contador aparece com a fonte certa (sem piscar a de reserva)
  document.fonts?.load('400 120px Zodiak', '0123456789%').then(() => raiz.classList.add('tem-fonte'));
  setTimeout(() => raiz.classList.add('tem-fonte'), 900);

  // ——— as frutas ———
  const vw = innerWidth, vh = alturaTela();
  const cel = CELULAR();
  const base = cel ? vw * 0.36 : Math.min(vw * 0.17, vh * 0.31);
  const ids = ['laranja', 'uva', 'maracuja', 'caju', 'goiaba', 'abacaxi', 'limao', 'manga', 'melancia', 'jabuticaba', 'folha', 'gengibre'];
  const area = vw * vh * 1.32; // o casco convexo deixa vãos: um terço a mais de fruta para a pilha encher a tela
  const n = clamp(Math.round(area / (base * base * 0.62)), 14, cel ? 22 : 46);
  // pilha estável: mais iterações de contato que o padrão (6 e 4) e passo fixo (abaixo); com passo variável e a
  // gravidade alta, os polígonos empilhados tremiam e trocavam de lugar em vez de assentar
  const engine = Engine.create({ enableSleeping: true, positionIterations: 14, velocityIterations: 10 });
  engine.gravity.y = 3.35;
  const muro = { isStatic: true, restitution: 0.2, friction: 0.6 };
  const G = 400;
  Composite.add(engine.world, [
    Bodies.rectangle(vw / 2, vh + G / 2, vw * 3, G, muro),
    Bodies.rectangle(-G / 2, vh / 2 - vh, G, vh * 4, muro),
    Bodies.rectangle(vw + G / 2, vh / 2 - vh, G, vh * 4, muro),
  ]);
  let sorte = 11;
  const rnd = () => ((sorte = (sorte * 1664525 + 1013904223) >>> 0) / 4294967296);
  const corpos = [];
  for (let i = 0; i < n; i++) {
    const id = ids[i % ids.length];
    const fr = FRUTAS[id];
    const t = base * (id === 'folha' || id === 'gengibre' ? 0.8 : 1) * (0.86 + rnd() * 0.3);
    const s = t / Math.max(fr.w, fr.h);
    const w = fr.w * s, h = fr.h * s;
    const el = document.createElement('div');
    el.className = 'abertura__fruta';
    el.style.width = `${w}px`;
    el.style.height = `${h}px`;
    el.innerHTML = svgDaFruta(id);
    palco.append(el);
    const vert = casco(fr.partes.flatMap((p) => pontos(p.d))).map(([x, y]) => ({ x: x * s, y: y * s }));
    const x = w * 0.6 + rnd() * Math.max(1, vw - w * 1.2);
    const y = -(h * 0.6) - i * (cel ? 46 : 26) - rnd() * 90;
    const corpo = Bodies.fromVertices(x, y, [vert], {
      restitution: 0, friction: 0.9, frictionStatic: 1.4, frictionAir: 0.025, slop: 0.12, sleepThreshold: 14, angle: (rnd() - 0.5) * 0.6,
    });
    // o centro de massa do casco não é o centro da caixa: guarda o deslocamento para o DOM acompanhar o corpo
    const { x: cx, y: cy } = Vertices.centre(vert);
    el.style.transformOrigin = `${cx}px ${cy}px`;
    corpos.push({ el, corpo, ox: cx, oy: cy, px: NaN, py: NaN, pa: NaN });
  }
  Composite.add(engine.world, corpos.map((c) => c.corpo));

  // o DOM só muda quando a fruta anda de verdade: os tremores de menos de meio pixel do contato não chegam à tela
  function desenha() {
    for (const c of corpos) {
      const { x, y } = c.corpo.position, a = c.corpo.angle;
      if (Math.abs(x - c.px) < 0.5 && Math.abs(y - c.py) < 0.5 && Math.abs(a - c.pa) < 0.006) continue;
      c.px = x; c.py = y; c.pa = a;
      c.el.style.transform = `translate3d(${(x - c.ox).toFixed(1)}px, ${(y - c.oy).toFixed(1)}px, 0) rotate(${a.toFixed(4)}rad)`;
    }
  }
  desenha();

  // clique: empurrão radial nas frutas perto do ponto
  raiz.addEventListener('pointerdown', (e) => {
    const R = cel ? 260 : 420;
    for (const c of corpos) {
      const dx = c.corpo.position.x - e.clientX, dy = c.corpo.position.y - e.clientY, d = Math.hypot(dx, dy);
      if (d > R) continue;
      Sleeping.set(c.corpo, false);
      const f = 1 - d / R, ux = d ? dx / d : 0, uy = d ? dy / d : -1, v = 24 * (0.35 + 0.65 * f);
      Body.setVelocity(c.corpo, { x: c.corpo.velocity.x + ux * v, y: c.corpo.velocity.y + uy * v - 14 * f });
      Body.setAngularVelocity(c.corpo, c.corpo.angularVelocity + ux * f * 0.18);
    }
  });

  // pressa: rolar, tecla ou dedo arrastando levam ao fim
  const pressa = () => sair(true);
  const opts = { passive: true };
  addEventListener('wheel', pressa, opts);
  addEventListener('keydown', pressa);
  addEventListener('touchmove', pressa, opts);

  // ——— o relógio da física e do contador ———
  const PASSO = 1000 / 120; // a física anda sempre no mesmo passo (o matter.js fica instável com passo variável)
  let ultimo = performance.now(), parado = 0, mostrado = 0, sobra = 0;
  function passo() {
    const agora = performance.now();
    const dt = Math.min(1000 / 30, agora - ultimo);
    ultimo = agora;
    if (!saindo) {
      sobra += dt;
      while (sobra >= PASSO) { Engine.update(engine, PASSO); sobra -= PASSO; }
    }
    desenha();
    // contador: anda pelo tempo (chega a 100 em MIN_MS) e espera em 92 enquanto a primeira tela não carregou
    const tempo = clamp((agora - t0) / MIN_MS);
    const alvo = Math.min(tempo * 100, carregou ? 100 : 92);
    mostrado += (alvo - mostrado) * 0.2;
    const v = Math.min(100, Math.round(mostrado));
    if (conta.textContent !== String(v)) conta.textContent = String(v);
    // assentou: quase todas dormindo ou lentas por 10 quadros
    const lentas = corpos.filter((c) => c.corpo.isSleeping || (c.corpo.speed < 0.25 && Math.abs(c.corpo.angularSpeed) < 0.02)).length;
    parado = lentas >= corpos.length * 0.9 ? parado + 1 : 0;
    const acabou = agora - t0 > MAX_MS || (carregou && v >= 100 && agora - t0 > MIN_MS && (parado > 10 || agora - t0 > 2700));
    if (acabou) sair(false);
  }
  gsap.ticker.add(passo);

  function sair(depressa) {
    if (saindo) return;
    saindo = true;
    removeEventListener('wheel', pressa, opts);
    removeEventListener('keydown', pressa);
    removeEventListener('touchmove', pressa, opts);
    const d = depressa ? 0.62 : 1;
    const tl = gsap.timeline();
    tl.set(varre, { yPercent: 100, autoAlpha: 1 })
      .to(conta.parentElement, { autoAlpha: 0, duration: 0.25 * d }, 0)
      .to(varre, { yPercent: 0, duration: 0.6 * d, ease: 'pm-io' }, 0)
      .add(() => {
        palco.remove();
        raiz.classList.add('is-varrendo');
        gsap.ticker.remove(passo);
        html.classList.remove('abertura-on');
        if (!html.classList.contains('modo-inicio')) lenis?.start(); // a home não rola (motion/troca.js)
        aoSair?.();
      })
      .to(varre, { yPercent: -100, duration: 0.75 * d, ease: 'pm-io' })
      .add(() => {
        raiz.remove();
        Composite.clear(engine.world, false);
        Engine.clear(engine);
      });
  }
}
