// A nav fica presa ao alto da página (nav.css): rola embora com ela e só volta quando a página volta ao alto. O menu
// desce do alto; Esc fecha; o clique num item vai pela troca (motion/troca.js): "Início" volta à fila e, na home, as
// seções abrem a página do produto.
export function criarNav({ lenis, navega }) {
  const html = document.documentElement;
  const nav = document.querySelector('[data-nav]');
  const botao = nav.querySelector('[data-menu]');
  const painel = document.querySelector('[data-menu-painel]');
  const txtBotao = botao.querySelectorAll('.pilula__txt > span');
  let aberto = false;

  function abre(sim) {
    aberto = sim;
    html.classList.toggle('menu-aberto', sim);
    botao.setAttribute('aria-expanded', String(sim));
    painel.setAttribute('aria-hidden', String(!sim));
    painel.inert = !sim;
    txtBotao.forEach((s) => { s.textContent = sim ? 'Fechar' : 'Menu'; });
    if (sim) {
      lenis?.stop();
      // o item da seção em que a página está fica marcado (na home, "Início")
      const y = (lenis ? lenis.scroll : scrollY) + innerHeight * 0.4;
      let atual = null;
      for (const a of painel.querySelectorAll('.menu__item')) {
        if (html.classList.contains('modo-inicio')) { if (a.getAttribute('href') === '#topo') atual = a; continue; }
        if (a.getAttribute('href') === '#topo') continue;
        const alvo = document.querySelector(a.getAttribute('href'));
        if (alvo && alvo.getBoundingClientRect().top + (lenis ? lenis.scroll : scrollY) <= y) atual = a;
      }
      painel.querySelectorAll('.menu__item').forEach((a) => a.setAttribute('aria-current', String(a === atual)));
    } else {
      if (!html.classList.contains('modo-inicio')) lenis?.start(); // a home não rola
    }
  }
  botao.addEventListener('click', () => abre(!aberto));
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && aberto) { abre(false); botao.focus(); } });
  painel.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    e.preventDefault();
    abre(false);
    setTimeout(() => navega(a.getAttribute('href')), 120);
  });
  return { abre };
}
