// As garrafas: recorta cada leva do Codex (fonte/bruto/garrafas-*.png, três garrafas por imagem) com o recorte de
// objeto do macOS, separa as garrafas, mede o corpo reto (onde o rótulo encosta) e grava:
//   public/garrafas/<sabor>.webp (até 1100 de altura) e <sabor>-640.webp, com alfa
//   src/marca/garrafas.json: proporção de cada garrafa e a faixa do rótulo, em frações da imagem
// Rodar da raiz do projeto (as saídas são relativas a ela; as imagens brutas ficam em bruto/, ao lado do script):
//   node fonte/garrafas.mjs            (ou node arquivos/fonte/garrafas.mjs)
// Cada leva é uma imagem com três garrafas lado a lado (bruto/garrafas-<leva>.png); os sabores de cada leva estão
// em LEVAS, da esquerda para a direita. O recorte usa o Vision do macOS (recorta.swift); em outro sistema, recorte
// antes com qualquer removedor de fundo e salve o PNG transparente como bruto/recorte-<leva>.png.
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import sharp from 'sharp';

const LEVAS = {
  a: ['laranja', 'uva', 'maracuja'],
  b: ['caju', 'goiaba', 'abacaxi'],
  c: ['limao', 'manga', 'melancia'],
  d: ['jabuticaba', 'tangerina', 'acerola'],
};
const dir = new URL('.', import.meta.url).pathname;
const pub = `${process.cwd()}/public/garrafas/`;
mkdirSync(pub, { recursive: true });
const medidas = {};

for (const [leva, sabores] of Object.entries(LEVAS)) {
  const bruto = `${dir}bruto/garrafas-${leva}.png`;
  if (!existsSync(bruto)) { console.log(`(sem a leva ${leva})`); continue; }
  const recorte = `${dir}bruto/recorte-${leva}.png`;
  if (!existsSync(recorte)) execFileSync('swift', [`${dir}recorta.swift`, bruto, recorte], { stdio: 'inherit' });

  const { data, info } = await sharp(recorte).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width: W, height: H } = info;
  // cor do fundo de estúdio, medida nos cantos da imagem original
  const orig = await sharp(bruto).removeAlpha().raw().toBuffer();
  const fundo = [0, 1, 2].map((c) => {
    let s = 0, n = 0;
    for (const [x0, y0] of [[0, 0], [W - 40, 0], [0, H - 40], [W - 40, H - 40]])
      for (let y = y0; y < y0 + 40; y++) for (let x = x0; x < x0 + 40; x++) { s += orig[(y * W + x) * 3 + c]; n++; }
    return s / n;
  });
  // borda. A máscara do Vision é macia (~10 px de rampa) e a beirada do vidro mostra o cinza do estúdio através dele:
  // no escuro vira um halo claro. Na faixa de 12 px junto da borda, o alfa cai na proporção da semelhança com a cor
  // do fundo (medida na foto original) e o que sobra semitransparente perde a cor do fundo misturada.
  // (o alfa desfocado: só o miolo da garrafa continua em 255; o erode do sharp cresce o claro em vez de encolher)
  const miolo = await sharp(data, { raw: { width: W, height: H, channels: 4 } }).extractChannel(3).blur(5).raw().toBuffer();
  for (let i = 0; i < W * H; i++) {
    if (!data[i * 4 + 3] || miolo[i] > 250) continue;
    const o = i * 3;
    const d = Math.hypot(orig[o] - fundo[0], orig[o + 1] - fundo[1], orig[o + 2] - fundo[2]);
    const chave = Math.max(0, Math.min(1, (d - 12) / 30));
    const a = (data[i * 4 + 3] / 255) * chave;
    data[i * 4 + 3] = Math.round(a * 255);
    if (a > 0.02 && a < 0.98) for (let c = 0; c < 3; c++) {
      const v = (orig[o + c] - (1 - a) * fundo[c]) / a;
      data[i * 4 + c] = Math.max(0, Math.min(255, Math.round(v)));
    }
  }
  const limpo = await sharp(data, { raw: { width: W, height: H, channels: 4 } }).png().toBuffer();
  const alfa = (x, y) => data[(y * W + x) * 4 + 3];
  // colunas com garrafa
  const col = new Array(W).fill(0);
  for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) if (alfa(x, y) > 128) col[x]++;
  const trechos = [];
  for (let x = 0, ini = -1; x <= W; x++) {
    const tem = x < W && col[x] > 20;
    if (tem && ini < 0) ini = x;
    if (!tem && ini >= 0) { if (x - ini > 60) trechos.push([ini, x]); ini = -1; }
  }
  if (trechos.length !== sabores.length) throw new Error(`leva ${leva}: ${trechos.length} garrafas, esperava ${sabores.length}`);

  for (const [i, [x0, x1]] of trechos.entries()) {
    // caixa da garrafa
    let y0 = H, y1 = 0;
    for (let y = 0; y < H; y++) for (let x = x0; x < x1; x++) if (alfa(x, y) > 128) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    const m = 6;
    const cx0 = Math.max(0, x0 - m), cy0 = Math.max(0, y0 - m), cw = Math.min(W, x1 + m) - cx0, ch = Math.min(H, y1 + 1 + m) - cy0;
    // largura de cada linha (bordas com alfa > 128)
    const larg = [];
    for (let y = cy0; y < cy0 + ch; y++) {
      let l = -1, r = -1;
      for (let x = cx0; x < cx0 + cw; x++) if (alfa(x, y) > 128) { if (l < 0) l = x; r = x; }
      larg.push(l < 0 ? [0, 0, 0] : [r - l + 1, l - cx0, r - cx0]);
    }
    const maxW = Math.max(...larg.map((v) => v[0]));
    // corpo reto: o trecho contínuo mais longo de linhas com 98,5% da largura máxima
    let melhor = [0, 0];
    for (let y = 0, ini = -1; y <= ch; y++) {
      const ok = y < ch && larg[y][0] >= maxW * 0.985;
      if (ok && ini < 0) ini = y;
      if (!ok && ini >= 0) { if (y - ini > melhor[1] - melhor[0]) melhor = [ini, y]; ini = -1; }
    }
    const [ct, cb] = melhor;
    const meio = larg[Math.round((ct + cb) / 2)];
    const sabor = sabores[i];
    const fr = (v, t) => +(v / t).toFixed(4);
    medidas[sabor] = {
      w: cw, h: ch,
      corpo: { topo: fr(ct, ch), base: fr(cb, ch), esq: fr(meio[1], cw), dir: fr(meio[2] + 1, cw) },
    };
    const peca = sharp(limpo).extract({ left: cx0, top: cy0, width: cw, height: ch });
    const png = await peca.png().toBuffer();
    await sharp(png).resize({ height: Math.min(1100, ch), withoutEnlargement: true }).webp({ quality: 84, alphaQuality: 90, effort: 6 }).toFile(`${pub}${sabor}.webp`);
    await sharp(png).resize({ height: 640 }).webp({ quality: 82, alphaQuality: 90, effort: 6 }).toFile(`${pub}${sabor}-640.webp`);
    console.log(sabor, cw, ch, JSON.stringify(medidas[sabor].corpo));
  }
}
const arq = `${process.cwd()}/src/marca/garrafas.json`;
writeFileSync(arq, JSON.stringify(medidas, null, 1));
console.log(`ok: ${Object.keys(medidas).length} garrafas`);
