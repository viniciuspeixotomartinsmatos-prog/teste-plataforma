// O rótulo do cursor: uma pílula clara com a folha da marca que acompanha o mouse sobre o que dá para clicar ou
// arrastar ("Ver o sabor", "Arraste"). Só com mouse; no toque ela nem aparece (pecas.css).
import gsap from 'gsap';
import { MOUSE } from './ease.js';

export function criarCursor() {
  const el = document.querySelector('.cursor-rotulo');
  if (!el) return null;
  const txt = el.querySelector('[data-cursor-txt]');
  let x = -300, y = -300, ax = -300, ay = -300, primeiro = true;
  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse') return;
    ax = e.clientX; ay = e.clientY;
    if (primeiro) { x = ax; y = ay; primeiro = false; }
  }, { passive: true });
  gsap.ticker.add(() => {
    x += (ax - x) * 0.32;
    y += (ay - y) * 0.32;
    el.style.transform = `translate3d(${x.toFixed(1)}px, ${y.toFixed(1)}px, 0)`;
  });
  return {
    mostra(t) {
      if (!MOUSE.matches) return;
      if (txt.textContent !== t) txt.textContent = t;
      el.classList.add('is-on');
    },
    esconde() { el.classList.remove('is-on'); },
  };
}
