// O cilindro: um WebGL só para todas as garrafas, fora da página. Para desenhar o rótulo de uma garrafa, ele
// renderiza um tubo iluminado com a arte do sabor e copia o resultado para o <canvas> 2D daquela garrafa (drawImage).
// Girar a garrafa é deslizar a arte no tubo (deslocamento de UV); a faixa sem rótulo é descartada e ali aparece a foto
// do vidro com o suco, que fica por baixo. Sem Three.js: um shader, uma malha e nada mais.
//
// O canvas de cada garrafa cobre a foto inteira da garrafa (mesma proporção). As medidas vêm em frações da foto:
// corpo.esq/dir (as bordas do vidro na altura do rótulo) e rotulo.topo/base (a faixa do rótulo).

const LADOS = 160;

const VERT = `
attribute vec2 aPos; // x: ângulo em voltas (0..1, 0 = frente), y: 0 em cima, 1 embaixo
uniform float uAspecto;   // largura ÷ altura da foto
uniform float uCentro;    // centro do corpo, em frações da largura
uniform float uRaio;      // raio, em frações da altura
uniform vec2 uFaixa;      // topo e base do rótulo, em frações da altura
uniform float uIncl;      // inclinação da câmera (rad): a frente desce, as bordas do rótulo viram um sorriso
varying float vAng;
varying float vV;
void main() {
  float a = (aPos.x - 0.5) * 6.2831853; // de -π a π, 0 na frente
  float y = mix(uFaixa.x, uFaixa.y, aPos.y);
  float px = uCentro * uAspecto + sin(a) * uRaio;      // em alturas
  float py = y * cos(uIncl) + cos(a) * uRaio * sin(uIncl);
  vAng = a;
  vV = aPos.y;
  gl_Position = vec4(px / uAspecto * 2.0 - 1.0, 1.0 - py * 2.0, 0.0, 1.0);
}`;

const FRAG = `
#extension GL_OES_standard_derivatives : enable
precision highp float;
uniform sampler2D uArte;
uniform float uGiro;    // voltas
uniform float uLacuna;  // fração da volta sem rótulo
uniform vec3 uLuz;      // direção da luz (x para a direita, y para cima, z para quem olha)
uniform float uAmb;
uniform float uDifusa;
uniform float uBrilho;
varying float vAng;
varying float vV;
void main() {
  float c = cos(vAng);
  if (c < -0.02) discard; // metade de trás
  float impresso = 1.0 - uLacuna;
  // posição na volta do rótulo: a frente (ângulo 0) mostra o meio da arte quando o giro é 0
  float s = fract(vAng / 6.2831853 + impresso * 0.5 + uGiro);
  float w = fwidth(s) * 1.5;
  float dentro = smoothstep(0.0, w, s) * (1.0 - smoothstep(impresso - w, impresso, s));
  if (dentro <= 0.001) discard;
  vec4 t = texture2D(uArte, vec2(clamp(s / impresso, 0.0, 1.0), vV));
  vec3 cor = pow(t.rgb, vec3(2.2));
  vec3 n = vec3(sin(vAng), 0.0, c);
  vec3 l = normalize(uLuz);
  float dif = max(dot(n, l), 0.0);
  vec3 h = normalize(l + vec3(0.0, 0.0, 1.0));
  float esp = pow(max(dot(n, h), 0.0), 28.0) * uBrilho;
  float borda = mix(0.62, 1.0, smoothstep(0.0, 0.55, c)); // o papel escurece onde vira para trás
  vec3 luz = cor * (uAmb + dif * uDifusa) * borda + esp;
  vec3 srgb = pow(clamp(luz, 0.0, 1.0), vec3(1.0 / 2.2));
  float alfa = dentro * smoothstep(-0.02, 0.06, c);
  gl_FragColor = vec4(srgb * alfa, alfa);
}`;

export function criarCilindro() {
  const canvas = document.createElement('canvas');
  canvas.width = 2; canvas.height = 2;
  const opts = { alpha: true, premultipliedAlpha: true, antialias: true, depth: false, stencil: false, preserveDrawingBuffer: false, powerPreference: 'low-power' };
  const gl2 = canvas.getContext('webgl2', opts);
  const gl = gl2 || canvas.getContext('webgl', opts);
  if (!gl) return null;
  if (!gl2) gl.getExtension('OES_standard_derivatives');
  const aniso = gl.getExtension('EXT_texture_filter_anisotropic');
  const maxAniso = aniso ? Math.min(8, gl.getParameter(aniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT)) : 0;

  // no WebGL2 o shader vira GLSL ES 3.0 (lá as derivadas são nativas); no WebGL1 fica o 1.0 com a extensão
  const para300 = (src, frag) => {
    let s = src.replace('#extension GL_OES_standard_derivatives : enable', '');
    if (frag) {
      s = s.replace(/varying /g, 'in ').replace(/texture2D\(/g, 'texture(').replace(/gl_FragColor/g, 'saida')
        .replace('precision highp float;', 'precision highp float;\nout vec4 saida;');
    } else s = s.replace(/attribute /g, 'in ').replace(/varying /g, 'out ');
    return `#version 300 es\n${s.trim()}`;
  };
  const sh = (tipo, src) => {
    const s = gl.createShader(tipo);
    gl.shaderSource(s, gl2 ? para300(src, tipo === gl.FRAGMENT_SHADER) : src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
    return s;
  };
  const prog = gl.createProgram();
  gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT));
  gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  gl.useProgram(prog);
  const U = {};
  for (const n of ['uAspecto', 'uCentro', 'uRaio', 'uFaixa', 'uIncl', 'uArte', 'uGiro', 'uLacuna', 'uLuz', 'uAmb', 'uDifusa', 'uBrilho'])
    U[n] = gl.getUniformLocation(prog, n);

  // o tubo: uma faixa de triângulos, LADOS colunas, só a metade da frente é usada (o resto é descartado)
  const pts = [];
  for (let i = 0; i <= LADOS; i++) { const x = i / LADOS; pts.push(x, 0, x, 1); }
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pts), gl.STATIC_DRAW);
  const aPos = gl.getAttribLocation(prog, 'aPos');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

  gl.disable(gl.DEPTH_TEST);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  gl.uniform1i(U.uArte, 0);
  gl.uniform3f(U.uLuz, -0.62, 0.35, 0.72);
  gl.uniform1f(U.uAmb, 0.5);
  gl.uniform1f(U.uDifusa, 0.68);
  gl.uniform1f(U.uBrilho, 0.07);

  const texturas = new Map();

  /** sobe a arte (canvas ou imagem) como textura; devolve o objeto que o desenho usa */
  function textura(chave, fonte) {
    let t = texturas.get(chave);
    if (!t) { t = gl.createTexture(); texturas.set(chave, t); }
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, fonte);
    const pot = (n) => (n & (n - 1)) === 0;
    const mip = gl2 || (pot(fonte.width) && pot(fonte.height));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, mip ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
    if (mip) gl.generateMipmap(gl.TEXTURE_2D);
    if (maxAniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, maxAniso);
    return t;
  }
  function solta(chave) {
    const t = texturas.get(chave);
    if (t) { gl.deleteTexture(t); texturas.delete(chave); }
  }

  /**
   * desenha o rótulo no canvas 2D de destino
   * @param ctx contexto 2D do canvas da garrafa (o canvas já no tamanho certo)
   * @param g { textura, aspecto, centro, raio, faixa:[topo, base], incl, giro, lacuna }
   */
  function desenha(ctx, g) {
    const w = ctx.canvas.width, h = ctx.canvas.height;
    if (canvas.width < w || canvas.height < h) {
      canvas.width = Math.max(canvas.width, w);
      canvas.height = Math.max(canvas.height, h);
    }
    gl.viewport(0, 0, w, h);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, g.textura);
    gl.uniform1f(U.uAspecto, g.aspecto);
    gl.uniform1f(U.uCentro, g.centro);
    gl.uniform1f(U.uRaio, g.raio);
    gl.uniform2f(U.uFaixa, g.faixa[0], g.faixa[1]);
    gl.uniform1f(U.uIncl, g.incl);
    gl.uniform1f(U.uGiro, g.giro);
    gl.uniform1f(U.uLacuna, g.lacuna);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, (LADOS + 1) * 2);
    ctx.clearRect(0, 0, w, h);
    // o viewport fica no canto de baixo do canvas do WebGL
    ctx.drawImage(canvas, 0, canvas.height - h, w, h, 0, 0, w, h);
  }

  return { gl, textura, solta, desenha, webgl2: !!gl2, perdido: () => gl.isContextLost() };
}
