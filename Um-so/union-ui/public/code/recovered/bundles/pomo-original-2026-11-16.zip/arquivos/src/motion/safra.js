// Safra: as linhas da tabela saem do config (meses de cada sabor). A aba "Na safra agora" mostra o que dá neste mês
// (pelo relógio de quem visita) e "Logo mais", o resto, com o mês em que volta; as linhas entram uma a uma.
import { SABORES } from '../config.js';
import { FRUTAS } from '../marca/frutas.js';

const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

/** "maio a novembro", "o ano todo" */
function periodo(meses) {
  if (meses.length >= 12) return 'o ano todo';
  return `${MESES[meses[0] - 1]} a ${MESES[meses.at(-1) - 1]}`;
}
/** quantos meses até o sabor voltar */
function falta(meses, agora) {
  for (let d = 1; d <= 12; d++) if (meses.includes(((agora - 1 + d) % 12) + 1)) return d;
  return 12;
}

function icone(s) {
  const fr = FRUTAS[s.frutas[0]];
  const cores = [s.fruta, s.folha, s.detalhe, s.semente ?? s.faixa];
  return `<svg viewBox="0 0 ${fr.w} ${fr.h}" aria-hidden="true">${fr.partes.map((p) => `<path d="${p.d}" fill="${cores[p.tom] ?? cores[0]}"/>`).join('')}</svg>`;
}

export function criarSafra({ raiz }) {
  const corpo = raiz.querySelector('[data-safra-linhas]');
  const abas = [...raiz.querySelectorAll('[data-aba]')];
  const mes = new Date().getMonth() + 1;
  raiz.querySelector('[data-safra-mes]').textContent = `Em ${MESES[mes - 1]} · caixas com 6 e 12 garrafas`;
  const agora = SABORES.filter((s) => s.safra.includes(mes));
  const depois = SABORES.filter((s) => !s.safra.includes(mes)).sort((a, b) => falta(a.safra, mes) - falta(b.safra, mes));

  function linhas(lista, quando) {
    corpo.innerHTML = lista.map((s, k) => `
      <div class="safra__linha" role="row" style="--k:${k}">
        <span class="safra__sabor" role="cell">${icone(s)}<b>${s.nome}${s.sub === 'suco integral' ? '' : ` ${s.sub}`}</b>${quando === 'agora' ? '<span class="safra__agora">agora</span>' : ''}</span>
        <span role="cell">${quando === 'agora' ? (s.safra.length >= 12 ? 'O ano todo' : `De ${periodo(s.safra)}`) : `Volta em ${MESES[s.safra[0] - 1]}`}</span>
        <span role="cell">${s.tamanhos.join(' · ')}</span>
      </div>`).join('');
    requestAnimationFrame(() => requestAnimationFrame(() => corpo.querySelectorAll('.safra__linha').forEach((l) => l.classList.add('is-on'))));
  }
  function escolhe(qual) {
    abas.forEach((a) => {
      const sim = a.dataset.aba === qual;
      a.classList.toggle('is-ativa', sim);
      a.setAttribute('aria-selected', String(sim));
    });
    linhas(qual === 'agora' ? agora : depois, qual);
  }
  abas.forEach((a) => a.addEventListener('click', () => escolhe(a.dataset.aba)));
  // as linhas só entram quando a tabela chega na tela
  let primeira = true;
  new IntersectionObserver(([en]) => {
    if (en.isIntersecting && primeira) { primeira = false; escolhe('agora'); }
  }, { rootMargin: '-10% 0px' }).observe(raiz.querySelector('.safra__tabela'));
}
