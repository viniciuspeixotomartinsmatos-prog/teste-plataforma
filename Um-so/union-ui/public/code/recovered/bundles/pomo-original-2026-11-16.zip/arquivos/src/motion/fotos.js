// A fila de fotos: uma volta sem fim (as cinco fotos repetidas antes e depois), sempre com uma foto no meio da tela e
// as vizinhas cortadas nas bordas. Arrastar (mouse ou dedo de lado) anda a fila com embalo e, quando ela para, a foto
// mais perto do meio se encaixa nele; o trackpad de lado e as setas do teclado andam de foto em foto. Com mouse, a
// pílula "Arraste" segue o cursor e as fotos andam um pouco por dentro da moldura (paralaxe lateral).
// No toque, o dedo de pé continua rolando a página (touch-action: pan-y).
import gsap from 'gsap';
import { MOUSE, REDUZIDO } from './ease.js';

export function criarFotos({ raiz, cursor }) {
  const trilho = raiz.querySelector('[data-fotos]');
  if (!trilho) return;
  const originais = [...trilho.children];
  const N = originais.length;
  // uma cópia antes e outra depois fecham a volta; ficam fora do leitor de tela
  const copia = (el) => { const c = el.cloneNode(true); c.setAttribute('aria-hidden', 'true'); c.querySelector('img').alt = ''; return c; };
  trilho.prepend(...originais.map(copia));
  trilho.append(...originais.map(copia));
  const itens = [...trilho.children];
  const imgs = itens.map((el) => el.querySelector('img'));

  let passo = 0, larg = 0, vw = 0;
  function medir() {
    vw = innerWidth;
    larg = originais[0].offsetWidth;
    const gap = parseFloat(getComputedStyle(trilho).columnGap) || 0;
    passo = larg + gap;
  }

  // X: a posição da fila em px (X = k·passo põe a foto k no meio); alvo: para onde ela se encaixa
  let X = 0, alvo = 0, arrasto = null, t0 = performance.now(), solto = true;
  const volta = () => passo * N;

  trilho.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    arrasto = { id: e.pointerId, x0: e.clientX, X0: X, ult: e.clientX, t: e.timeStamp, v: 0, ativo: false };
  });
  trilho.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'mouse') cursor?.mostra('Arraste');
    if (!arrasto || e.pointerId !== arrasto.id) return;
    const dx = e.clientX - arrasto.x0;
    if (!arrasto.ativo) {
      if (Math.abs(dx) < 6) return;
      arrasto.ativo = true;
      solto = false;
      try { trilho.setPointerCapture(e.pointerId); } catch {}
      trilho.classList.add('is-arrastando');
    }
    const dt = Math.max(1, e.timeStamp - arrasto.t);
    arrasto.v = arrasto.v * 0.7 + ((e.clientX - arrasto.ult) / dt) * 0.3; // px/ms
    arrasto.ult = e.clientX;
    arrasto.t = e.timeStamp;
    X = arrasto.X0 - dx;
  });
  const solta = (e) => {
    if (!arrasto || (e.pointerId !== undefined && e.pointerId !== arrasto.id)) return;
    if (arrasto.ativo) {
      trilho.classList.remove('is-arrastando');
      try { trilho.releasePointerCapture(arrasto.id); } catch {}
      // embalo: a foto onde a fila iria parar sozinha vira o alvo, no máximo uma além da mais perto (um piparote, uma foto)
      const lanca = REDUZIDO ? 0 : -arrasto.v * 320;
      const k = Math.round(X / passo);
      alvo = Math.min(k + 1, Math.max(k - 1, Math.round((X + lanca) / passo))) * passo;
      solto = true;
    }
    arrasto = null;
  };
  trilho.addEventListener('pointerup', solta);
  trilho.addEventListener('pointercancel', solta);
  trilho.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') cursor?.esconde(); });

  // trackpad de lado: anda a fila e encaixa na foto seguinte quando o gesto acaba
  let fimRoda = 0;
  trilho.addEventListener('wheel', (e) => {
    if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
    e.preventDefault();
    X += e.deltaX;
    solto = false;
    clearTimeout(fimRoda);
    fimRoda = setTimeout(() => { alvo = Math.round(X / passo) * passo; solto = true; }, 140);
  }, { passive: false });

  trilho.addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    alvo = Math.round(alvo / passo) * passo + (e.key === 'ArrowRight' ? passo : -passo);
    solto = true;
  });

  // a fila só trabalha perto da tela
  let perto = false;
  new IntersectionObserver(([en]) => { perto = en.isIntersecting; }, { rootMargin: '200px 0px' }).observe(raiz);

  let ultimoTx = NaN;
  function quadro() {
    const agora = performance.now();
    const dt = Math.min(1 / 30, (agora - t0) / 1000);
    t0 = agora;
    if (!perto || !passo) return;
    if (solto) {
      X += (alvo - X) * (1 - Math.exp(-(REDUZIDO ? 30 : 7) * dt));
      if (Math.abs(alvo - X) < 0.1) X = alvo;
    }
    // a volta: X e o alvo andam juntos uma volta inteira quando passam das pontas (nada pula na tela)
    const v = volta();
    if (X > v * 1.5) { X -= v; alvo -= v; if (arrasto) arrasto.X0 -= v; }
    if (X < -v * 0.5) { X += v; alvo += v; if (arrasto) arrasto.X0 += v; }
    // a foto 0 da volta do meio fica no meio da tela quando X = 0; parada, a fila não escreve nada
    const tx = Math.round(((vw - larg) / 2 - v - X) * 10) / 10;
    if (tx === ultimoTx) return;
    ultimoTx = tx;
    trilho.style.transform = `translate3d(${tx}px, 0, 0)`;
    if (!MOUSE.matches || REDUZIDO) return;
    // paralaxe lateral: cada foto anda um pouco contra a posição dela na tela
    for (let i = 0; i < itens.length; i++) {
      const esq = tx + i * passo;
      if (esq + larg < -40 || esq > vw + 40) continue;
      const q = (esq + larg / 2) / vw - 0.5;
      imgs[i].style.translate = `${(-q * 5).toFixed(2)}% 0`;
    }
  }

  medir();
  addEventListener('resize', () => { medir(); alvo = Math.round(alvo / passo) * passo; X = alvo; ultimoTx = NaN; });
  gsap.ticker.add(quadro);
}
