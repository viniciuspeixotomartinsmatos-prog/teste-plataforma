// Seção "Dois lados": a moldura da foto aérea abre ao entrar (do tamanho da grade até a borda) e fecha ao sair;
// a foto aproxima devagar enquanto as folhas passam. Só imagem acompanha a rolagem; texto entra por marco.
import { aoRolar, seguir, limitar } from './rolagem.js';

const reduz = matchMedia('(prefers-reduced-motion: reduce)');
const suave = t => 1 - Math.pow(1 - t, 3);

export function lados(secao) {
  const moldura = secao.querySelector('[data-moldura]');
  const foto = secao.querySelector('[data-foto]');
  if (!moldura || !foto) return;

  let cx = null;
  let zoom = null;
  aoRolar(({ vh, vw }) => {
    const r = secao.getBoundingClientRect();
    const top = r.top;
    const bottom = r.bottom;
    const altura = r.height;
    if (bottom < -vh || top > vh * 2) return false;
    const entra = limitar((vh - top) / (vh * 0.95));
    const preso = limitar(-top / Math.max(1, altura - vh));
    const sai = limitar((vh - bottom) / (vh * 0.85));
    const maxCx = reduz.matches ? 0 : Math.min(vw * 0.07, 110);
    const alvoCx = maxCx * (1 - suave(entra)) + maxCx * sai * sai;
    const alvoZoom = reduz.matches ? 1 : 1.2 - 0.12 * suave(entra) - 0.08 * preso;
    if (cx === null) { cx = alvoCx; zoom = alvoZoom; }
    let anda1;
    let anda2;
    [cx, anda1] = seguir(cx, alvoCx, 0.16, 0.08);
    [zoom, anda2] = seguir(zoom, alvoZoom, 0.1, 0.0002);
    moldura.style.setProperty('--cx', `${cx.toFixed(2)}px`);
    foto.style.setProperty('--zoom', zoom.toFixed(4));
    return anda1 || anda2;
  });
}
