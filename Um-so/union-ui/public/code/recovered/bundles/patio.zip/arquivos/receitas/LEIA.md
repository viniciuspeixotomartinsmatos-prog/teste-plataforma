# Receitas: de onde vêm as fotos da Pátio

O site usa seis fotos. As **quatro dos cards do hero foram geradas por IA** a partir das receitas desta pasta e **já vêm no pacote**, em `arquivos/fotos/`. As **duas de largura cheia** (`patio` e `fim`) são **fotos reais de banco** do Unsplash, com a **Licença Unsplash** (uso comercial livre, sem pagar e sem precisar dar crédito; não é Unsplash+): elas não vêm no pacote, baixe pelos links abaixo. As telas do app (o painel do síndico e o celular do morador), os ícones, o logo e os widgets de vidro são feitos em código e já vêm em `arquivos/telas/`.

Não há vídeo nem 3D neste site. Trocar as fotos pelas da sua marca é só trocar arquivos.

## As fotos da demo

| nome | onde aparece | foto | autor | link |
|---|---|---|---|---|
| `reservas` | card 01 do hero (Reservas) e rodapé | área de churrasqueira com pergolado de madeira e mesa longa, no jardim do clube | gerada por IA | `arquivos/fotos/reservas.jpg` (receita `reservas.txt`) |
| `portaria` | card 02 do hero (Portaria), rodapé e página Entrar | entrada da torre com portas de vidro, marquise de ripas e plantas | gerada por IA | `arquivos/fotos/portaria.jpg` (receita `portaria.txt`) |
| `boletos` | card 03 do hero (Boletos) e rodapé | piscina do condomínio entre palmeiras, com espreguiçadeiras | gerada por IA | `arquivos/fotos/boletos.jpg` (receita `boletos.txt`) |
| `avisos` | card 04 do hero (Avisos) e rodapé | salão de assembleia com cadeiras de madeira e janelas para o jardim | gerada por IA | `arquivos/fotos/avisos.jpg` (receita `avisos.txt`) |
| `patio` | fundo fixo da seção "Dois lados" | condomínio visto de cima, com piscinas, clube e jardim | Leo_Visions | https://unsplash.com/photos/a-large-pool-surrounded-by-trees-and-buildings-RSTsnGDZXqU |
| `fim` | seção "Teste grátis" | duas torres no fim de tarde acima da mata | Klara Kulikova | https://unsplash.com/photos/a-couple-of-tall-buildings-HMnXUQReCzA |

Baixar o original das fotos do Unsplash (a maior resolução): `https://unsplash.com/photos/<id>/download?force=true`, onde o id é o fim do link (por exemplo `NC93wBz11e0`). Salve como `fotos-originais/<nome>.jpg` na raiz do projeto.

## Passo a passo

1. **Baixar** as duas fotos do Unsplash pelos links acima para `fotos-originais/` (`patio.jpg` e `fim.jpg`). As quatro dos cards já estão em `arquivos/fotos/`: o script as encontra sozinho (uma foto sua com o mesmo nome em `fotos-originais/` tem prioridade).
2. **Preparar** com o script: `npm i -D -E sharp@0.35.5` e `node arquivos/fonte/fotos.mjs`. Ele recorta, aplica o mesmo tratamento de cor em todas (saturação mais baixa, preto um pouco levantado, um toque quente, para parecerem uma sessão só) e grava os WebP em `public/img/` nos tamanhos que a página usa:
   - cards do hero: `<nome>-900.webp` e `<nome>-1300.webp` (retrato, ~0,85:1);
   - fotos de largura cheia: `patio-1600.webp`, `patio-2880.webp` (paisagem, ~1,7:1, sem o horizonte da cidade), `fim-1600.webp`, `fim-2880.webp` (3:2);
   - recorte vertical para o celular: `patio-alto-1100.webp`, `fim-alto-1100.webp`;
   - miniaturas do rodapé: `<nome>-mini.webp` (240 × 240).
3. **Conferir** cada foto antes de usar: nada de logo, marca, placa legível, letreiro ou ponto turístico reconhecível. Na foto `patio` da demo, o recorte deixa de fora o horizonte da cidade ao fundo.

Custo: zero para montar a demo. Ferramentas: qualquer navegador para baixar; o `sharp` (instalado pelo npm) para preparar. Sem o script, qualquer editor que exporte WebP serve, desde que mantenha as proporções e os tamanhos acima.

## Com as fotos da sua marca

Um app de condomínio fica mais forte com **fotos de prédios de verdade**: o condomínio de um cliente (com autorização), o prédio da administradora ou fotos de banco escolhidas com o mesmo cuidado. O que cada vaga pede:

- **Cards do hero** (quatro, um por função): uma foto por área comum que combine com a função: torres e área verde (reservas), a entrada do prédio (portaria), a piscina ou o jardim (boletos), o salão ou o espaço gourmet (avisos). Fotos verticais ou quadradas, com o assunto no terço de cima: a metade de baixo fica sob o título branco, e o canto de cima à direita fica sob o widget de vidro.
- **Fundo da seção "Dois lados"**: uma foto vista de cima (drone) do conjunto de prédios, com bastante verde. É ela que fica parada atrás das telas do síndico e do morador, então precisa funcionar inteira, sem um ponto que chame atenção demais.
- **Seção "Teste grátis"**: uma foto com céu claro na metade de cima (o título preto fica sobre o céu, à direita) e os prédios livres à esquerda. Luz de fim de tarde fecha a página com calor.
- Todas com a mesma luz e o mesmo clima; o script iguala a cor, mas não salva uma foto escura, tremida ou de celular na vertical numa vaga horizontal.

Fotos de banco boas para procurar no Unsplash ou no Pexels: "apartment courtyard aerial", "residential towers park", "apartment building entrance", "condominium pool", "outdoor kitchen terrace", "apartment buildings sunset". Use só as de licença livre (no Unsplash, as que dizem "Free to use under the Unsplash License"; nunca as marcadas com Unsplash+).

## Gerar fotos novas para os cards

As quatro fotos dos cards saíram de **um parágrafo de estilo comum** (`estilo.txt`: luz de fim de manhã com névoa, condomínio com muita vegetação tropical, concreto claro e madeira, cor apagada, enquadramento vertical com o alto e a base calmos para o widget e o título) **mais uma linha de assunto por card** (`reservas.txt`, `portaria.txt`, `boletos.txt`, `avisos.txt`). Para gerar outra, cole o estilo inteiro e troque só o assunto, em qualquer gerador de imagem (ChatGPT, Gemini, Midjourney): é o estilo repetido que faz as quatro parecerem uma sessão só. Peça retrato (4:5 ou 2:3), confira em tamanho cheio que não apareceu texto, placa nem logo, e salve em `fotos-originais/<nome>.jpg` antes de rodar o script. Custo: o do plano do gerador, alguns minutos por imagem.

Foto gerada pode parecer perfeita demais: se parecer, peça luz mais irregular, sombras desiguais e um pouco de desgaste (o `estilo.txt` já pede isso).

## Sem fotos novas

O site funciona com as fotos da demo enquanto a marca não tem as dela. Para trocar uma vaga de cada vez, basta gravar a foto nova com o mesmo nome em `public/img/` (nos tamanhos do passo 2) e recarregar.
