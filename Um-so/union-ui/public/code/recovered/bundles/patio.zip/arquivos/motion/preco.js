// Preço: o pátio verde do logo (o quadrado do meio do símbolo) nasce na margem e cresce com a rolagem até ser o card inteiro.
// O conteúdo só entra (por tempo) com o card aberto. Calculadora: R$ 4,90 por unidade.
import { aoRolar, seguir, limitar } from './rolagem.js';

const reduz = matchMedia('(prefers-reduced-motion: reduce)');
const POR_UNIDADE = 4.9;
const brl = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const suave = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export function preco(secao) {
  if (!secao) return;
  const fundo = secao.querySelector('[data-preco-fundo]');
  calculadora(secao.querySelector('[data-calc]'));
  if (reduz.matches) { secao.classList.add('is-aberto'); return; }

  let esq = 0;
  let lado = 23;
  // a margem da página vem de uma variável CSS com clamp(): uma sonda mede o valor em px
  const sonda = document.createElement('div');
  sonda.style.cssText = 'position:absolute;visibility:hidden;width:var(--margin);height:0;pointer-events:none';
  secao.append(sonda);
  const medir = () => {
    const inset = parseFloat(getComputedStyle(secao).marginLeft) || 0;
    esq = Math.max(0, sonda.offsetWidth - inset);
    lado = innerWidth < 761 ? 18 : 23;
  };
  medir();
  addEventListener('resize', medir);
  new ResizeObserver(medir).observe(secao);

  let p = null;
  let aberto = false;
  aoRolar(({ vh }) => {
    const r = secao.getBoundingClientRect();
    const top = r.top;
    const altura = r.height;
    const largura = r.width;
    // passou direto (rolagem rápida, link de âncora): o card fica aberto, sem animar
    if (!aberto && r.bottom < vh * 0.5) { p = 1; aberto = true; secao.classList.add('is-aberto', 'sem-entrada'); }
    if (top > vh * 1.6 || top + altura < -vh) { if (p === 1) desenhar(1, largura, altura); return false; }
    // começa com o topo do card a 92% da tela; abre por completo com o topo a 22% (42% no celular)
    // no celular o card é alto e estreito: cresce numa distância menor
    let alvo = limitar((vh * 0.92 - top) / (vh * (innerWidth < 761 ? 0.5 : 0.7)));
    if (aberto) alvo = 1; // abriu, fica aberto (o texto entra uma vez só)
    if (p === null) p = alvo;
    let anda;
    // longe do alvo (rolagem rápida), alcança mais depressa
    [p, anda] = seguir(p, alvo, Math.abs(alvo - p) > 0.3 ? 0.3 : 0.14, 0.0004);
    desenhar(suave(p), largura, altura);
    if (!aberto && p > 0.8) { aberto = true; secao.classList.add('is-aberto'); }
    return anda;
  });

  // cresce como quadrado até encostar numa das medidas do card e então estica na outra
  function desenhar(e, largura, altura) {
    const lad = lado + (Math.max(largura, altura) - lado) * e;
    const w = Math.min(lad, largura);
    const h = Math.min(lad, altura);
    const x = esq * (1 - e);
    fundo.style.setProperty('--cl', `${x.toFixed(1)}px`);
    fundo.style.setProperty('--ct', '0px');
    fundo.style.setProperty('--cr', `${Math.max(0, largura - x - w).toFixed(1)}px`);
    fundo.style.setProperty('--cb', `${Math.max(0, altura - h).toFixed(1)}px`);
    fundo.style.setProperty('--craio', `${(2 + 30 * Math.min(1, e * 1.6)).toFixed(1)}px`);
  }
}

function calculadora(el) {
  if (!el) return;
  const range = el.querySelector('[data-range]');
  const unidades = el.querySelector('[data-unidades]');
  const total = el.querySelector('[data-total]');
  let mostrado = Number(range.value) * POR_UNIDADE;
  let raf = 0;
  const atualizar = () => {
    const n = Number(range.value);
    const min = Number(range.min);
    const max = Number(range.max);
    range.style.setProperty('--pct', `${((n - min) / (max - min)) * 100}%`);
    unidades.textContent = n;
    const alvo = n * POR_UNIDADE;
    cancelAnimationFrame(raf);
    const de = mostrado;
    const t0 = performance.now();
    const passo = agora => {
      const t = Math.min(1, (agora - t0) / 360);
      mostrado = de + (alvo - de) * (1 - Math.pow(1 - t, 3));
      total.textContent = brl.format(mostrado);
      if (t < 1) raf = requestAnimationFrame(passo);
    };
    raf = requestAnimationFrame(passo);
  };
  range.addEventListener('input', atualizar);
  atualizar();
}
