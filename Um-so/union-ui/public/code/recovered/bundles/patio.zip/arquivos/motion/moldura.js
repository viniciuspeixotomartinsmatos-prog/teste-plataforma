// Molduras de foto de seção ([data-abre]): abrem da largura da grade até a borda ao entrar, e a foto anda devagar dentro.
import { aoRolar, seguir, limitar } from './rolagem.js';

const reduz = matchMedia('(prefers-reduced-motion: reduce)');
const suave = t => 1 - Math.pow(1 - t, 3);

export function molduras() {
  if (reduz.matches) return;
  for (const el of document.querySelectorAll('[data-abre]')) {
    const foto = el.querySelector('[data-abre-foto]');
    let cx = null;
    let py = null;
    aoRolar(({ vh, vw }) => {
      const r = el.getBoundingClientRect();
      const top = r.top;
      const altura = r.height;
      if (top > vh * 1.5 || top + altura < -vh * 0.5) return false;
      const entra = limitar((vh - top) / (vh * 0.9));
      const passa = limitar((vh - top) / (vh + altura)); // 0 entrando por baixo, 1 saindo por cima
      const maxCx = Math.min(vw * 0.07, 110);
      const alvoCx = maxCx * (1 - suave(entra));
      const alvoPy = (passa - 0.5) * -0.1 * altura;
      if (cx === null) { cx = alvoCx; py = alvoPy; }
      let a1;
      let a2;
      [cx, a1] = seguir(cx, alvoCx, 0.16, 0.08);
      [py, a2] = seguir(py, alvoPy, 0.12, 0.1);
      el.style.setProperty('--cx', `${cx.toFixed(2)}px`);
      foto?.style.setProperty('--py', `${py.toFixed(1)}px`);
      return a1 || a2;
    });
  }
}
