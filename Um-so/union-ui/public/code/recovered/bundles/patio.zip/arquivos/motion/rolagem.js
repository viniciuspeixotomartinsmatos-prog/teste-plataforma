// Estado de rolagem compartilhado: um laço só de requestAnimationFrame para tudo que acompanha a rolagem.
// Cada assinante recebe { y, vh, vw } e devolve true enquanto ainda está se movendo (suavização),
// para o laço parar sozinho quando nada mais anda.
const assinantes = new Set();
let rodando = false;
const estado = { y: scrollY, vh: innerHeight, vw: innerWidth };

function quadro() {
  estado.y = scrollY;
  let algumAnda = false;
  for (const fn of assinantes) if (fn(estado)) algumAnda = true;
  if (algumAnda) requestAnimationFrame(quadro);
  else rodando = false;
}

export function acordar() {
  if (rodando) return;
  rodando = true;
  requestAnimationFrame(quadro);
}

export function aoRolar(fn) {
  assinantes.add(fn);
  acordar();
  return () => assinantes.delete(fn);
}

addEventListener('scroll', acordar, { passive: true });
addEventListener('resize', () => { estado.vh = innerHeight; estado.vw = innerWidth; acordar(); });

// aproxima a de b; devolve [novo valor, ainda anda?]
export function seguir(a, b, k = 0.12, eps = 0.0005) {
  const d = b - a;
  if (Math.abs(d) < eps) return [b, false];
  return [a + d * k, true];
}

export const limitar = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));

// enquanto a página rola, o hover fica desligado (o cursor parado não acende nada no caminho)
export function semHoverRolando() {
  const html = document.documentElement;
  let ultimo = null;
  addEventListener('scroll', () => html.classList.add('is-scrolling'), { passive: true });
  addEventListener('pointermove', e => {
    if (e.pointerType !== 'mouse') return;
    const pos = `${e.clientX},${e.clientY}`;
    if (ultimo !== null && pos !== ultimo) html.classList.remove('is-scrolling');
    ultimo = pos;
  }, { passive: true });
}
