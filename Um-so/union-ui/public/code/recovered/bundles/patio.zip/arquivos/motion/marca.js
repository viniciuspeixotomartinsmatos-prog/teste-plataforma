// Com a sua marca: o leque de iPhones abre uma vez, por tempo, com quase metade do palco na tela.
// Rolando rápido ou chegando por âncora, abre mesmo assim (nunca fica no meio do caminho).
export function marca(leque) {
  if (!leque) return;
  const abrir = () => leque.classList.add('is-aberto');
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return abrir();
  const io = new IntersectionObserver(([e]) => {
    if (e.intersectionRatio < 0.45 && e.boundingClientRect.top > 0) return;
    abrir();
    io.disconnect();
  }, { threshold: [0, 0.45] });
  io.observe(leque);
}
