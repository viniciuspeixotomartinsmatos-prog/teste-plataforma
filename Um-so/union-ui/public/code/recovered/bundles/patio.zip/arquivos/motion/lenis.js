// Rolagem suave (Lenis): a roda e o trackpad deslizam com inércia; o toque continua nativo.
// A rolagem segue nativa por baixo (scrollY e o evento scroll valem), então os outros módulos não mudam.
// Com movimento reduzido, nada de Lenis: tudo fica na rolagem do navegador.
import Lenis from 'lenis';

export let lenis = null;

const suave = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export function rolagemSuave() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  lenis = new Lenis({ lerp: 0.1, autoRaf: true });

  // links de âncora: desliza até a seção (o Lenis respeita o scroll-margin-top de cada uma)
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href^="#"]');
    const id = a?.getAttribute('href');
    if (!id || id.length < 2) return;
    const alvo = document.querySelector(id);
    if (!alvo) return;
    e.preventDefault();
    lenis.scrollTo(id === '#topo' ? 0 : alvo, { duration: 1.2, easing: suave });
  });
}

// para a barra própria e o menu: com Lenis, pula sem inércia; sem ele, a rolagem do navegador
export function rolarPara(y) {
  if (lenis) lenis.scrollTo(y, { immediate: true });
  else scrollTo(0, y);
}
