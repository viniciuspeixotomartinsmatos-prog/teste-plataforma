// App do morador que se usa sozinho: início → liberar visita → visita liberada → de volta ao início com a visita na lista.
// Roda por tempo, só enquanto o celular está na tela. Com movimento reduzido fica parado no início, já com a visita.
const reduz = matchMedia('(prefers-reduced-motion: reduce)');

export function celular(el) {
  if (!el) return;
  const tela = el.querySelector('.celular__tela');
  const telas = Object.fromEntries([...el.querySelectorAll('[data-tela]')].map(t => [t.dataset.tela, t]));
  const toqueEl = el.querySelector('[data-toque]');
  const digita = el.querySelector('[data-digita]');
  const itemNovo = el.querySelector('[data-item-visita]');
  const atalho = el.querySelector('[data-alvo="visitas"]');
  const botao = el.querySelector('[data-alvo="liberar"]');
  const voltarBt = telas.ok?.querySelector('.app-botao');

  if (reduz.matches) { itemNovo.classList.add('is-on'); return; }

  let timers = [];
  let rodando = false;
  let pilha = ['inicio'];
  const depois = (ms, fn) => timers.push(setTimeout(fn, ms));
  const semTransicao = lista => {
    lista.forEach(t => t.classList.add('sem-transicao'));
    requestAnimationFrame(() => requestAnimationFrame(() => lista.forEach(t => t.classList.remove('sem-transicao'))));
  };

  // empilhar: a tela nova entra pela direita e a de baixo recua um pouco
  function empilhar(nome) {
    const topo = telas[pilha.at(-1)];
    topo.classList.remove('is-atual');
    topo.classList.add('is-atras');
    telas[nome].classList.remove('is-saindo', 'is-atras');
    telas[nome].classList.add('is-atual');
    pilha.push(nome);
  }

  // voltar: a tela de cima sai pela direita por cima de tudo; as do meio somem sem animar
  function voltarPara(nome) {
    const saindo = telas[pilha.at(-1)];
    const meio = pilha.slice(pilha.indexOf(nome) + 1, -1).map(n => telas[n]);
    semTransicao(meio);
    meio.forEach(t => t.classList.remove('is-atual', 'is-atras'));
    saindo.classList.remove('is-atual');
    saindo.classList.add('is-saindo');
    setTimeout(() => saindo.classList.remove('is-saindo'), 700);
    telas[nome].classList.remove('is-atras');
    telas[nome].classList.add('is-atual');
    pilha = pilha.slice(0, pilha.indexOf(nome) + 1);
  }

  function tocar(alvo) {
    const r = alvo.getBoundingClientRect();
    const t = tela.getBoundingClientRect();
    toqueEl.style.setProperty('--tx', `${r.left - t.left + r.width / 2}px`);
    toqueEl.style.setProperty('--ty', `${r.top - t.top + r.height / 2}px`);
    toqueEl.classList.remove('is-on');
    void toqueEl.offsetWidth;
    toqueEl.classList.add('is-on');
    alvo.classList.add('is-apertado');
    setTimeout(() => alvo.classList.remove('is-apertado'), 220);
  }

  function zerar() {
    semTransicao(Object.values(telas));
    for (const t of Object.values(telas)) t.classList.remove('is-atual', 'is-atras', 'is-saindo');
    telas.inicio.classList.add('is-atual');
    pilha = ['inicio'];
    digita.textContent = '';
  }

  function volta() {
    depois(1300, () => tocar(atalho));
    depois(1600, () => empilhar('visita'));
    const nome = digita.dataset.digita;
    for (let k = 1; k <= nome.length; k += 1) depois(2300 + k * 85, () => { digita.textContent = nome.slice(0, k); });
    depois(4300, () => tocar(botao));
    depois(4600, () => empilhar('ok'));
    depois(6800, () => tocar(voltarBt));
    depois(7100, () => voltarPara('inicio'));
    depois(7600, () => itemNovo.classList.add('is-on'));
    depois(11600, () => { itemNovo.classList.remove('is-on'); digita.textContent = ''; });
    depois(12700, volta);
  }

  function ligar() {
    if (rodando) return;
    rodando = true;
    zerar();
    itemNovo.classList.remove('is-on');
    volta();
  }
  function desligar() {
    rodando = false;
    timers.forEach(clearTimeout);
    timers = [];
    zerar();
    itemNovo.classList.add('is-on');
  }

  itemNovo.classList.add('is-on');
  new IntersectionObserver(([e]) => (e.isIntersecting ? ligar() : desligar()), { threshold: 0.4 }).observe(el);
  document.addEventListener('visibilitychange', () => (document.hidden ? desligar() : null));
}
