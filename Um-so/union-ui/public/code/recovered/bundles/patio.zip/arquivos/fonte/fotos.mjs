// Prepara as fotos do site: recorta, trata a cor (o mesmo tratamento em todas, para parecerem uma sessão só)
// e exporta os WebP nos tamanhos que a página usa, em public/img/.
//
// Uso, da raiz do projeto:
//   npm i -D -E sharp@0.35.5
//   node arquivos/fonte/fotos.mjs            (todas)
//   node arquivos/fonte/fotos.mjs reservas   (só uma)
//
// Originais: os quatro cards do hero vêm em arquivos/fotos/; patio e fim, baixe para fotos-originais/<nome>.jpg pelos
// links de arquivos/receitas/LEIA.md. Uma foto sua em fotos-originais/<nome>.jpg tem prioridade sobre a do pacote.
// Com fotos suas, ajuste os recortes abaixo: cada número é uma fração da foto original (0 a 1).
import sharp from 'sharp';
import fs from 'node:fs';
import path from 'node:path';

const raiz = process.cwd();
// os quatro cards do hero vêm no pacote (arquivos/fotos/, gerados por IA); patio e fim se baixam do Unsplash
const CARDS = ['reservas', 'portaria', 'boletos', 'avisos'];
const orig = n => {
  const sua = path.join(raiz, 'fotos-originais', `${n}.jpg`);
  if (fs.existsSync(sua) || !CARDS.includes(n)) return sua;
  return path.join(raiz, 'arquivos', 'fotos', `${n}.jpg`);
};
const saida = n => path.join(raiz, 'public/img', `${n}.webp`);

// recortes: [x, y, largura, altura] em fração da foto original
// card: os quatro cards do hero (retrato, ~0,85:1); largo: fotos de largura cheia; alto: recorte vertical do celular
// trat: sat (saturação), luz (brilho), contraste, levanta (preto levantado, 0 a 1), quente (−1 frio a 1 quente)
const FOTOS = {
  reservas: {
    recortes: { card: [0, 0.03, 1, 0.94] },
    tamanhos: { card: [1300, 900] },
    trat: { sat: 0.94, luz: 1.0, contraste: 0.96, levanta: 0.03, quente: 0.02 },
  },
  portaria: {
    recortes: { card: [0, 0.03, 1, 0.94] },
    tamanhos: { card: [1300, 900] },
    trat: { sat: 0.94, luz: 1.0, contraste: 0.96, levanta: 0.03, quente: 0.02 },
  },
  boletos: {
    recortes: { card: [0, 0.03, 1, 0.94] },
    tamanhos: { card: [1300, 900] },
    trat: { sat: 0.94, luz: 1.0, contraste: 0.96, levanta: 0.03, quente: 0.02 },
  },
  avisos: {
    recortes: { card: [0, 0.03, 1, 0.94] },
    tamanhos: { card: [1300, 900] },
    trat: { sat: 0.94, luz: 1.0, contraste: 0.96, levanta: 0.03, quente: 0.02 },
  },
  patio: {
    // o recorte de cima deixa de fora o horizonte da cidade
    recortes: { largo: [0, 0.22, 1, 0.78], alto: [0.27, 0.22, 0.44, 0.78] },
    tamanhos: { largo: [2880, 1600], alto: [1100] },
    trat: { sat: 0.8, luz: 1.02, contraste: 0.92, levanta: 0.04, quente: 0.03 },
  },
  fim: {
    recortes: { largo: [0, 0, 1, 1], alto: [0.2, 0, 0.36, 1] },
    tamanhos: { largo: [2880, 1600], alto: [1100] },
    trat: { sat: 0.9, luz: 1.0, contraste: 0.92, levanta: 0.035, quente: 0.0 },
  },
};

// miniaturas quadradas do rodapé: [x, y, lado] em fração da foto original
const MINI = { reservas: [0.05, 0.45, 0.75], portaria: [0.3, 0.3, 0.7], boletos: [0.3, 0.5, 0.7], avisos: [0.3, 0.45, 0.7] };

function tratar(img, t) {
  const c = t.contraste;
  const q = t.quente;
  const l = t.levanta * 255;
  return img
    .modulate({ saturation: t.sat, brightness: t.luz })
    .linear([c * (1 + q), c, c * (1 - q * 1.4)], [l + 6 * q, l, l - 4 * q]);
}

async function remendar(buf, meta, [x, y, w, h]) {
  const r = { left: Math.round(x * meta.width), top: Math.round(y * meta.height), width: Math.round(w * meta.width), height: Math.round(h * meta.height) };
  const patch = await sharp(buf).extract(r).blur(28).toBuffer();
  const mask = Buffer.from(`<svg width="${r.width}" height="${r.height}"><defs><radialGradient id="g"><stop offset="55%" stop-color="#fff"/><stop offset="100%" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="100%" height="100%" fill="url(#g)"/></svg>`);
  const suave = await sharp(patch).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer();
  return sharp(buf).composite([{ input: suave, left: r.left, top: r.top }]).toBuffer();
}

const nomes = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(FOTOS);
fs.mkdirSync(path.join(raiz, 'public/img'), { recursive: true });
for (const nome of nomes) {
  const f = FOTOS[nome];
  if (!fs.existsSync(orig(nome))) { console.log(`falta ${path.relative(raiz, orig(nome))}`); continue; }
  let buf = fs.readFileSync(orig(nome));
  const meta = await sharp(buf).metadata();
  if (f.remendo) buf = await remendar(buf, meta, f.remendo);
  for (const [corte, [x, y, w, h]] of Object.entries(f.recortes)) {
    const area = { left: Math.round(x * meta.width), top: Math.round(y * meta.height), width: Math.round(w * meta.width), height: Math.round(h * meta.height) };
    for (const largura of f.tamanhos[corte]) {
      const sufixo = corte === 'card' || corte === 'largo' ? `-${largura}` : `-${corte}-${largura}`;
      const out = saida(`${nome}${sufixo}`);
      await tratar(sharp(buf).extract(area), f.trat).resize({ width: largura }).webp({ quality: largura > 2000 ? 72 : 78, effort: 6 }).toFile(out);
      console.log(path.relative(raiz, out));
    }
  }
  if (MINI[nome]) {
    const [x, y, w] = MINI[nome];
    const lado = Math.round(w * meta.width);
    const area = { left: Math.round(x * meta.width), top: Math.round(y * meta.height), width: lado, height: Math.min(lado, meta.height - Math.round(y * meta.height)) };
    await tratar(sharp(buf).extract(area), f.trat).resize({ width: 240, height: 240, fit: 'cover' }).webp({ quality: 80 }).toFile(saida(`${nome}-mini`));
    console.log(`public/img/${nome}-mini.webp`);
  }
}
