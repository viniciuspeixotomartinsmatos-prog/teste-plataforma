import { defineConfig } from 'vite';
import fs from 'node:fs';
import path from 'node:path';

// Monta o index.html com uma seção por arquivo: <!-- @include src/sections/hero.html -->
// O HTML final sai estático (bom para busca e para quem abre sem JavaScript).
const raiz = import.meta.dirname;
const INCLUDE = /<!--\s*@include\s+(\S+)\s*-->/g;

function montar(html, profundidade = 0) {
  if (profundidade > 4) return html;
  return html.replace(INCLUDE, (_, arquivo) => montar(fs.readFileSync(path.resolve(raiz, arquivo), 'utf8'), profundidade + 1));
}

const parciais = () => ({
  name: 'parciais',
  transformIndexHtml: { order: 'pre', handler: html => montar(html) },
  handleHotUpdate({ file, server }) {
    if (file.endsWith('.html')) {
      server.ws.send({ type: 'full-reload' });
      return [];
    }
  },
});

export default defineConfig({
  plugins: [parciais()],
  build: {
    assetsInlineLimit: 0,
    rollupOptions: { input: { index: path.resolve(raiz, 'index.html'), entrar: path.resolve(raiz, 'entrar.html') } },
  },
});
