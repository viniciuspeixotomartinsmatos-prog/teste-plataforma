// Carrossel do hero: um gesto = um card. Setas, arrasto (mouse e dedo), teclado e gesto lateral do trackpad.
// O card que sai recua e some no lugar; o próximo desliza por cima dele. Nunca preso à rolagem da página.
const reduz = matchMedia('(prefers-reduced-motion: reduce)');
const AUTO_MS = 6000;

export function carrossel(secao) {
  const raiz = secao.querySelector('[data-carrossel]');
  if (!raiz) return;
  const cards = [...raiz.querySelectorAll('[data-cartao]')];
  const n = cards.length;
  const btAnt = secao.querySelector('[data-ant]');
  const btProx = secao.querySelector('[data-prox]');
  const contador = secao.querySelector('.contador__atual');
  const contadorVh = secao.querySelector('[data-contador-vh]');
  const legenda = secao.querySelector('[data-legenda]:not([data-cartao])'); // a legenda do trilho (os cards também têm data-legenda)

  let atual = 0;
  let p = 0; // fração arrastada: positivo = indo para o próximo
  let passo = 1;
  const tAnterior = new Map();

  // vão entre cards em px, lido de uma sonda com a largura da variável --card-gap
  const sonda = document.createElement('div');
  sonda.style.cssText = 'position:absolute;visibility:hidden;width:var(--card-gap);height:0;pointer-events:none';
  raiz.append(sonda);
  const medir = () => { passo = cards[0].offsetWidth + sonda.offsetWidth; };

  // distância circular até o card atual: 0 ativo, 1 cortado na borda, 2 fora da tela, −1 recolhido atrás
  const dist = i => {
    let d = (((i - atual) % n) + n) % n;
    if (d > n - 2) d -= n;
    return d;
  };

  function pose(t) {
    if (t >= 0) return { x: t * passo, s: 1, o: 1, img: t * 7 };
    const u = Math.max(t, -1);
    if (reduz.matches) return { x: 0, s: 1, o: Math.max(0, 1 + u * 1.4), img: 0 };
    return { x: 0, s: 1 + 0.075 * u, o: Math.max(0, 1 + u * 1.25), img: u * 7 };
  }

  function aplicar(semAnimar = false) {
    cards.forEach((c, i) => {
      const t = dist(i) - p;
      const { x, s, o, img } = pose(t);
      const antes = tAnterior.get(c);
      const salto = antes !== undefined && Math.abs(t - antes) > 1.5;
      if (salto || semAnimar) semTransicao(c, true);
      c.style.setProperty('--x', `${x.toFixed(2)}px`);
      c.style.setProperty('--s', s.toFixed(4));
      c.style.setProperty('--o', o.toFixed(3));
      c.style.setProperty('--img-x', `${img.toFixed(2)}%`);
      c.style.setProperty('--z', t >= -0.001 ? String(4 + Math.round(t)) : '2');
      c.classList.toggle('is-ativo', Math.abs(t) < 0.5);
      c.classList.toggle('is-proximo', Math.abs(t - 1) < 0.5);
      c.setAttribute('aria-hidden', Math.abs(t) < 0.5 ? 'false' : 'true');
      if (salto || semAnimar) requestAnimationFrame(() => requestAnimationFrame(() => semTransicao(c, false)));
      tAnterior.set(c, t);
    });
  }

  function semTransicao(c, ligado) {
    const img = c.querySelector('img');
    c.style.transition = ligado ? 'none' : '';
    if (img) img.style.transition = ligado ? 'none' : '';
  }

  // contador "01/04": o número rola para cima (próximo) ou para baixo (anterior)
  function contar(dir) {
    const velho = contador.querySelector('.contador__dig:not(.sai-cima):not(.sai-baixo)');
    const novo = document.createElement('span');
    novo.className = `contador__dig ${dir > 0 ? 'vem-baixo' : 'vem-cima'}`;
    novo.textContent = String(atual + 1).padStart(2, '0');
    contador.append(novo);
    larguraDig(novo);
    void novo.offsetWidth;
    novo.classList.remove('vem-baixo', 'vem-cima');
    if (velho) {
      velho.classList.add(dir > 0 ? 'sai-cima' : 'sai-baixo');
      setTimeout(() => velho.remove(), 700);
    }
    contadorVh.textContent = `Função ${atual + 1} de ${n}`;
  }

  // a largura do número acompanha o algarismo (o "/04" encosta no número, como no conceito)
  function larguraDig(el) {
    const w = el.getBoundingClientRect().width;
    const fs = parseFloat(getComputedStyle(contador).fontSize) || 1;
    contador.style.setProperty('--w-dig', `${(w / fs - 0.02).toFixed(3)}em`);
  }

  let tLegenda;
  function legendar() {
    clearTimeout(tLegenda);
    legenda.classList.add('is-saindo');
    tLegenda = setTimeout(() => {
      legenda.textContent = cards[atual].dataset.legenda;
      legenda.classList.remove('is-saindo');
      legenda.classList.add('is-entrando');
      void legenda.offsetWidth;
      legenda.classList.remove('is-entrando');
    }, 200);
  }

  function ir(delta, origem = 'gente') {
    if (origem !== 'auto') pararAuto();
    atual = (((atual + delta) % n) + n) % n;
    p = 0;
    aplicar();
    contar(delta);
    legendar();
  }

  btAnt?.addEventListener('click', () => ir(-1));
  btProx?.addEventListener('click', () => ir(1));

  // teclado: com o foco no carrossel ou nas setas
  secao.addEventListener('keydown', e => {
    if (!raiz.contains(e.target) && !e.target.closest('.setas')) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); ir(1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); ir(-1); }
  });

  // arrasto: decide a direção nos primeiros pixels; vertical fica com a página
  let arr = null;
  let acabouDeArrastar = false;
  raiz.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    arr = { x0: e.clientX, y0: e.clientY, id: e.pointerId, decidido: false, hist: [] };
  });
  raiz.addEventListener('pointermove', e => {
    if (!arr || e.pointerId !== arr.id) return;
    const dx = e.clientX - arr.x0;
    const dy = e.clientY - arr.y0;
    if (!arr.decidido) {
      if (Math.hypot(dx, dy) < 7) return;
      arr.decidido = true;
      if (Math.abs(dy) > Math.abs(dx)) { arr = null; return; }
      raiz.setPointerCapture(e.pointerId);
      raiz.classList.add('is-arrastando');
      cards.forEach(c => semTransicao(c, true));
      pararAuto();
    }
    arr.hist.push([performance.now(), dx]);
    if (arr.hist.length > 6) arr.hist.shift();
    const q = -dx / passo;
    p = Math.max(-1, Math.min(1, q));
    aplicar();
  });
  const soltar = e => {
    if (!arr || e.pointerId !== arr.id) return;
    const decidido = arr.decidido;
    const h = arr.hist;
    arr = null;
    if (!decidido) return;
    raiz.classList.remove('is-arrastando');
    cards.forEach(c => semTransicao(c, false));
    let vx = 0;
    if (h.length > 1) {
      const [t0, x0] = h[0];
      const [t1, x1] = h[h.length - 1];
      vx = (x1 - x0) / Math.max(1, t1 - t0);
    }
    acabouDeArrastar = true;
    setTimeout(() => { acabouDeArrastar = false; }, 60);
    if (p > 0.16 || vx < -0.35) ir(1);
    else if (p < -0.16 || vx > 0.35) ir(-1);
    else { p = 0; aplicar(); }
  };
  raiz.addEventListener('pointerup', soltar);
  raiz.addEventListener('pointercancel', soltar);
  // no toque, a captura implícita do card é solta quando o carrossel captura: só vale a do próprio carrossel
  raiz.addEventListener('lostpointercapture', e => { if (e.target === raiz) soltar(e); });

  raiz.addEventListener('click', e => {
    if (acabouDeArrastar) return;
    const c = e.target.closest('[data-cartao]');
    if (c?.classList.contains('is-proximo')) ir(1);
  });

  // gesto lateral do trackpad: um gesto inteiro anda um card só
  let soma = 0;
  let travado = false;
  let tGesto;
  raiz.addEventListener('wheel', e => {
    if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
    e.preventDefault();
    e.stopPropagation(); // o gesto lateral é do carrossel: não chega ao Lenis
    clearTimeout(tGesto);
    tGesto = setTimeout(() => { travado = false; soma = 0; }, 260);
    if (travado) return;
    soma += e.deltaX;
    if (Math.abs(soma) > 36) { ir(soma > 0 ? 1 : -1); travado = true; }
  }, { passive: false });

  // troca sozinha enquanto o hero está na tela e ninguém mexeu
  let auto = !reduz.matches;
  let visivel = false;
  let pausado = false;
  let tAuto;
  function agendar() {
    clearTimeout(tAuto);
    if (!auto || !visivel || pausado || document.hidden) return;
    tAuto = setTimeout(() => { ir(1, 'auto'); agendar(); }, AUTO_MS);
  }
  function pararAuto() { auto = false; clearTimeout(tAuto); }
  new IntersectionObserver(([e]) => { visivel = e.intersectionRatio > 0.45; agendar(); }, { threshold: [0, 0.45, 1] }).observe(raiz);
  const pausa = v => () => { pausado = v; agendar(); };
  raiz.addEventListener('pointerenter', pausa(true));
  raiz.addEventListener('pointerleave', pausa(false));
  secao.querySelector('.hero__trilho')?.addEventListener('pointerenter', pausa(true));
  secao.querySelector('.hero__trilho')?.addEventListener('pointerleave', pausa(false));
  secao.addEventListener('focusin', pausa(true));
  secao.addEventListener('focusout', pausa(false));
  document.addEventListener('visibilitychange', agendar);

  addEventListener('resize', () => { medir(); aplicar(true); });

  medir();
  aplicar();
  const dig0 = contador.querySelector('.contador__dig');
  if (dig0) document.fonts.ready.then(() => larguraDig(dig0));
  cards.forEach((c, i) => c.style.setProperty('--k', String(Math.max(0, dist(i)))));
  requestAnimationFrame(() => {
    raiz.classList.add('is-pronto');
    setTimeout(() => raiz.classList.add('is-vivo'), 1700);
  });

  // ir direto para um card (atalhos do rodapé)
  function irPara(i) {
    if (i === atual) return;
    let delta = (((i - atual) % n) + n) % n;
    if (delta > n / 2) delta -= n;
    const passo = Math.sign(delta);
    ir(passo);
    if (Math.abs(delta) > 1) setTimeout(() => irPara(i), 380);
  }

  return { ir, irPara, get atual() { return atual; } };
}
