// Painel do síndico vivo: chegam sozinhos uma reserva, uma visita e um boleto pago, só enquanto o painel está na tela.
const reduz = matchMedia('(prefers-reduced-motion: reduce)');
const fmt = new Intl.NumberFormat('pt-BR');

export function painel(el) {
  if (!el || reduz.matches) return;
  const aviso = el.querySelector('[data-painel-aviso]');
  const avisoTitulo = el.querySelector('[data-aviso-titulo]');
  const avisoTexto = el.querySelector('[data-aviso-texto]');
  const avisoIc = aviso.querySelector('use');
  const bloco = el.querySelector('[data-bloco-novo]');
  const barra = el.querySelector('[data-kpi-barra]');
  const kpi = nome => el.querySelector(`[data-kpi="${nome}"]`);
  const valores = { arrecadado: 58420, pct: 94, reservas: 11, visitas: 23 };

  function contar(nome, para, ms = 800) {
    const alvo = kpi(nome);
    const de = valores[nome];
    valores[nome] = para;
    alvo.closest('.kpi')?.classList.remove('is-mudou');
    void alvo.offsetWidth;
    alvo.closest('.kpi')?.classList.add('is-mudou');
    const t0 = performance.now();
    const passo = agora => {
      const t = Math.min(1, (agora - t0) / ms);
      const v = de + (para - de) * (1 - Math.pow(1 - t, 3));
      alvo.textContent = fmt.format(Math.round(v));
      if (t < 1) requestAnimationFrame(passo);
    };
    requestAnimationFrame(passo);
  }

  const EVENTOS = [
    { ic: 'i-cal', titulo: 'Nova reserva', texto: 'Salão de festas · sábado, 19h · apto 1204', faz: () => { bloco.classList.add('is-on'); setTimeout(() => bloco.classList.add('is-assentou'), 1400); contar('reservas', valores.reservas + 1); } },
    { ic: 'i-porta', titulo: 'Visita liberada', texto: 'Ana Lima · apto 1204 · até 22h', faz: () => contar('visitas', valores.visitas + 1) },
    { ic: 'i-boleto', titulo: 'Boleto pago', texto: 'Apto 803 · R$ 640,00 no Pix', faz: () => {
      contar('arrecadado', valores.arrecadado + 640, 1000);
      const pct = Math.min(99, valores.pct + 1);
      contar('pct', pct, 600);
      barra.style.setProperty('--p', (pct / 100).toFixed(2));
    } },
  ];

  let i = 0;
  let timers = [];
  let rodando = false;
  const depois = (ms, fn) => timers.push(setTimeout(fn, ms));

  function proximo() {
    const ev = EVENTOS[i % EVENTOS.length];
    avisoIc.setAttribute('href', `#${ev.ic}`);
    avisoTitulo.textContent = ev.titulo;
    avisoTexto.textContent = ev.texto;
    aviso.classList.add('is-on');
    depois(450, ev.faz);
    depois(2900, () => aviso.classList.remove('is-on'));
    i += 1;
    if (i % EVENTOS.length === 0) {
      // fim da volta: a reserva nova some devagar e tudo recomeça
      depois(4400, () => bloco.classList.remove('is-on', 'is-assentou'));
      depois(6200, proximo);
    } else depois(3700, proximo);
  }

  function ligar() { if (rodando) return; rodando = true; depois(900, proximo); }
  function desligar() { rodando = false; timers.forEach(clearTimeout); timers = []; aviso.classList.remove('is-on'); }

  new IntersectionObserver(([e]) => (e.isIntersecting ? ligar() : desligar()), { threshold: 0.35 }).observe(el);
  document.addEventListener('visibilitychange', () => (document.hidden ? desligar() : null));
}
