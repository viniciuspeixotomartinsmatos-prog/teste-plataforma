# Do Prompt ao Site: comece aqui

1. Abra esta pasta no Claude Code, no Codex ou na sua IA de código.
2. Cole o prompt (ele está no PROMPT.md) ou escreva para a IA: "siga o PROMPT.md".
3. Responda às perguntas dela e deixe ela trabalhar até o fim. Se parar no meio, escreva "continue".

O CLAUDE.md e o AGENTS.md são o mesmo guia: a IA lê sozinha, não precisa colar.

## Passo a passo completo

1. Abra o Claude Code na pasta, cole o prompt e responda às perguntas: o que o filme mostra e em que tela a caixa vira
2. Deixe a IA montar a demonstração primeiro; se ela parar no meio, diga "continue"
3. Confira os 4 quadros que ela mostra: o pedido digitando, o clique, o scan virando a página e o recuo
4. Assista ao filme: o pedido é enviado e um scan só transforma a caixa na primeira tela do site, que cresce até a tela cheia
5. No segundo ato, um novo pedido acrescenta uma seção, montada pelo mesmo scan
6. Para mostrar o seu site de verdade, mande o endereço ou um print da primeira tela em tamanho de computador
7. Peça a troca pelo seu produto: os textos digitados, a tela que a caixa vira, o fundo e as cores
8. Imagens recortadas (mascote, produto) a IA não muda por texto: mande as suas ou gere pelas receitas do pacote
9. Baixe a música indicada ou mande a sua, para a IA cortar a trilha nos graves
10. Peça o filme final: um MP4 em 1920×1080 com som, pronto para postar
