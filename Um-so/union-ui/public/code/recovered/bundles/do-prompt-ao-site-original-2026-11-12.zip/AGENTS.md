# Guia do projeto — Do Prompt ao Site

Filme de 1920×1080 a 30 fps, desenhado em HTML e renderizado quadro a quadro pelo Chromium headless. Um pedido é digitado numa caixa de prompt e enviado, e um scan transforma a caixa na primeira tela de um site. No segundo ato, um segundo pedido acrescenta uma seção, e a página inteira recua.

## Como o motor funciona

- `seek(f)` em `film.js` desenha o quadro `f`. Todo estilo é função pura do número do quadro: nada de transição de CSS, timer ou `Math.random` (o acaso vem de `hash()` com semente). Por isso o mesmo quadro sai sempre igual, e o render pode pular para qualquer ponto.
- Cada movimento é uma tabela de chaves: `kf(f, [[quadro, valor, curva?], ...])` interpola números ou listas. A curva de cada chave vale para o trecho que termina nela (`E.out`, `E.inOut`, `E.outP(2.4)`...).
- As fontes e as imagens carregam antes do primeiro quadro (`document.fonts.ready` e `decode()`). Sem isso, as palavras se atropelam na medição.
- A câmera do primeiro ato (`camera(f)`) é contínua: leva um ponto do mundo a um ponto da tela, com escala. O mergulho no botão e a volta ao plano aberto são movimentos, não cortes.
- A página (bloco PÁGINA do `index.html`) é desenhada em 1920×1080 e escalada para a largura do card. A altura vira a do card, como um site num navegador redimensionado. O scan recorta a página até a linha dele (`clip-path`), e por baixo continua a caixa com o pedido.

## Arquivos

| O quê | Onde |
|---|---|
| Textos digitados, rótulo do modelo (`''` esconde), liga/desliga do 2º ato | `conteudo.js` |
| Cena do prompt (céu, linhas finas, assunto recortado) | `index.html` (CENA DO PROMPT), `assets/salto.png`, `film.css` (`#sky`, `#glow`) |
| A tela que o card vira | `index.html` (bloco PÁGINA: `#hero`, `#content`, `#nav`), `assets/hero.png`, `film.css` |
| A seção do 2º ato | `index.html` (SEGUNDA SEÇÃO), `film.css` (`#studio` e seguintes), `film.js` (parte "estúdio") |
| Tempos e movimentos | `film.js`: `BOX` (caixa), `camera` (1º ato), `pageView` (recuos e rolagem), `seek` (scan, crescimento, 2º ato, cursor) |
| Cores do scan, do roxo da carga e do clique | `film.css` (`#scan`, `#sband`, `#wash`) e `film.js` (`#D97757`, o terracota do botão) |
| Efeitos sonoros | `audio/sfx/*.wav` |
| Plano da trilha (música, filtros, cada efeito com início e ganho) | `audio/trilha.json` |
| Ferramentas | `tools/quadros.mjs` (quadros soltos), `tools/render.mjs` (filme mudo), `tools/deixas.mjs` (quando cada letra chega), `tools/mix.py` (trilha), `tools/recorta.swift` (recorte no Mac) |

## Mapa de quadros

| Quadros | Segundos | O que acontece |
|---|---|---|
| 0–26 | 0,0–0,9 | A caixa sobe e cresce, a cena recua 7%, alças nos cantos; 30 letras no ritmo do teclado |
| 29–54 | 1,0–1,8 | Carga: tingimento roxo, grade de pontos e glifos nas bordas; a caixa inclina 12°; as alças voam aos cantos; de 40 a 48 o resto do pedido entra de uma vez e a caixa vira um cartão alto |
| 55–80 | 1,8–2,7 | O cursor aparece; de 58 a 73 a câmera mergulha no botão de enviar (3,19×) |
| 80–88 | 2,7–2,9 | Clique: o cursor achata, o botão estufa e fica terracota, a borda da caixa estufa |
| 90–105 | 3,0–3,5 | A câmera volta ao plano aberto |
| 104–122 | 3,5–4,1 | **O scan:** a faixa desce pelo card; acima dela, a página |
| 122–148 | 4,1–4,9 | O card cresce até a tela cheia |
| 161–214 | 5,4–7,1 | Recuo: a página encolhe para 1344 px sobre cinza #dddddd |
| 204–258 | 6,8–8,6 | 2º ato: a segunda caixa sobe e o segundo pedido é digitado |
| 256–278 | 8,5–9,3 | O cursor entra e clica (270) |
| 276–316 | 9,2–10,5 | A caixa entra na página, que volta à tela cheia e rola para a área ainda vazia |
| 296–330 | 9,9–11,0 | **O segundo scan** monta a seção |
| 330–414 | 11,0–13,8 | A seção ganha vida (na demonstração: agulha, clique e zoom automático na prévia) |
| 400–452 | 13,3–15,1 | Recuo final: a página inteira |
| 479 | 16,0 | Preto |

Sem o 2º ato (`SEGUNDO_ATO = false`), o filme tem 232 quadros (7,7 s) e para no recuo.

## Personalizar

Antes de mudar, três perguntas: o que o filme mostra, o que o card vira e se tem segundo ato. Depois:

| O quê | Onde | Precisa de material novo? |
|---|---|---|
| Pedido digitado e rótulo do modelo | `conteudo.js` | Não |
| Textos, cores e fontes da página | bloco PÁGINA do `index.html` e `film.css` | Não |
| Assunto à direita da página | `assets/hero.png` | Sim: imagem recortada (receitas) |
| Assunto no fundo da cena do prompt | `assets/salto.png` | Sim, ou apague o `<img id="subject">` |
| Ícone ao lado do nome, na nav | `assets/app-icon.png` | O logo da marca |
| A seção do 2º ato | bloco SEGUNDA SEÇÃO e a parte "estúdio" do `film.js` | Prints do produto, se a seção mostrar um |
| Música | `audio/trilha.json` (`musica`) | Um MP3 |

**A tela que o card vira**, do mais simples ao mais trabalhoso:
1. Manter a da demonstração e trocar só textos, cores e imagens.
2. Usar um print da primeira tela do site, com pelo menos 1920 px de largura, como `<img>` cobrindo o `#hero`, e deixar o `#content` vazio. É rápido, mas o texto do print não fica tão nítido quanto o HTML.
   Sem imagem nenhuma à direita, recomponha (título centralizado, ou um print do produto no lugar do assunto): a metade vazia fica pobre. Apagar o `#otter`, o `#smear` ou o `#subject` não quebra o filme.
3. Refazer a primeira tela do site em HTML e CSS, com as cores, as fontes e os textos reais (lendo o código ou o site). É o que fica mais bonito.

**Regras ao trocar**
- A premissa é um scan só. O card não escurece antes, não há segundo scan nem fusão, e o fundo não troca escondido.
- O assunto recortado tem de ser opaco e nítido; meio transparente sobre o céu, parece fantasma.
- Título em no máximo 2 linhas. Nenhum texto pode sair cortado em quadro nenhum.
- Fontes só gratuitas para uso comercial (Google Fonts, Fontsource pelo npm).
- Dados que a pessoa não deu (números, depoimentos, clientes) ficam `[preencher]`, nunca inventados.
- No fim, liste o que ainda é da demonstração.

**O que não se edita por texto:** as imagens recortadas são imagens. Para mudar a pose ou o personagem, gere outra (`arquivos/receitas/LEIA.md`).

## Som

O `audio/trilha.json` é o plano da trilha, e o `tools/mix.py` o executa: música, passa-baixas, efeitos e master em -14 LUFS / -1 dBTP.

- **Teclas:** dependem do texto digitado. Depois de trocar um pedido, rode `node tools/deixas.mjs > audio/deixas.json` e `python tools/mix.py --deixas audio/deixas.json`.
- **Os outros efeitos** estão presos à imagem. Cada um tem `deixa_s` (o momento na imagem) e `inicio_s` (onde o arquivo começa). Se um movimento mudar de quadro, some a mesma diferença aos dois. As principais deixas:
  - 1,35 s: carga
  - 2,20 s: mergulho
  - 2,70 s: clique
  - 3,23 s: volta
  - 4,08 e 4,09 s: subida e grave, quando o scan termina e o card cresce
  - 4,93 s: pop, quando o card cobre a tela
  - 6,67 s: assenta
  - 7,27 s: a barra sobe
  - 9,03 s: clique 2
  - 9,85 e 9,87 s: subida e grave, no segundo scan
  - 11,1 a 11,4 s: fichas
  - 12,1 s: clique na prévia
  - 12,4 s: zoom
  - 14,33 s: recuo
  - 15,07 s: assenta
- **Música:** em `musica.trechos`, cada trecho começa em `inicio_s` do filme, tocando a faixa a partir de `fonte_s`. Os graves caem em 1,72 s, 4,11 s e 9,87 s. Para outra faixa, ache os graves dela (onde o baixo entra forte) e acerte `fonte_s` para um grave cair em cada um desses pontos. O passa-baixas (`musica.passa_baixas`) fecha antes de cada clique e reabre no grave.
- **Filme curto:** `python tools/mix.py --dur 7.733`. Os efeitos marcados `"ato": 2` no `trilha.json` saem sozinhos. O mux com `apad` estica o som até o último quadro, que é preto.

## Conferir

- `npm run quadros -- quadros 20 82 114 200` e abrir as imagens. Para auditar o filme inteiro: `ffmpeg -i out/mudo.mp4 -vf "select='not(mod(n\,8))',scale=320:-1,tile=6x10" -frames:v 1 folha.jpg`.
- Compare sempre com o `referencia.mp4` nos mesmos tempos: composição, timing e nada cortado.
- Render: `npm run render` gera `out/mudo.mp4`. Junte o som com
  `ffmpeg -i out/mudo.mp4 -i audio/trilha.wav -map 0:v -map 1:a -c:v copy -af apad -c:a aac -b:a 256k -shortest -movflags +faststart out/filme.mp4`.
- Para outra duração ou formato (vertical 9:16), replaneje a composição antes: o card, a câmera e os recuos foram medidos para 1920×1080.
