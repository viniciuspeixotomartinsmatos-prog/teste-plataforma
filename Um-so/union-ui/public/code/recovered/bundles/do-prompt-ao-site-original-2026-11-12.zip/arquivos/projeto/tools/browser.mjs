// Chromium headless do Playwright. O channel 'chromium' usa a GPU do computador (WebGL e filtros mais rápidos).
// Antes da primeira vez: npx playwright install chromium
import { chromium } from 'playwright';
export const launch = () => chromium.launch({ channel: 'chromium', headless: true, args: ['--enable-gpu', '--ignore-gpu-blocklist'] });
