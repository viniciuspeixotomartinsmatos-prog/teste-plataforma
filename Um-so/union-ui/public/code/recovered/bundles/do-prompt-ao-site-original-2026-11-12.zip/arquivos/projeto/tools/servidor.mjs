// servidor estático da pasta do filme
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
const ROOT = join(import.meta.dirname, '..');
const TIPOS = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.css': 'text/css', '.woff': 'font/woff', '.svg': 'image/svg+xml', '.mp3': 'audio/mpeg' };
export function servidor(porta = 0) {
  const s = createServer(async (req, res) => {
    const p = normalize(decodeURIComponent(new URL(req.url, 'http://x').pathname)).replace(/^(\.\.[/\\])+/, '');
    const f = join(ROOT, p.endsWith('/') ? p + 'index.html' : p);
    try { const b = await readFile(f); res.writeHead(200, { 'content-type': TIPOS[extname(f)] || 'application/octet-stream' }); res.end(b); }
    catch { res.writeHead(404); res.end(); }
  });
  return new Promise(r => s.listen(porta, '127.0.0.1', () => r({ url: `http://127.0.0.1:${s.address().port}`, fechar: () => s.close() })));
}
if (import.meta.url === `file://${process.argv[1]}`) { const s = await servidor(+(process.argv[2] || 5180)); console.log(`${s.url}/index.html`); }
