// O que muda de um filme para outro. O resto (tempos, câmera, scan) fica em film.js.
// Os textos da página (o que o card vira) ficam no index.html, no bloco "PÁGINA".

// 1º ato: o pedido digitado na caixa. As 30 primeiras letras saem no ritmo do teclado; o resto entra de uma vez.
// Tamanho bom: de 300 a 450 caracteres (enche o cartão alto em 9 a 12 linhas).
export const PROMPT = 'Crie uma landing page premium para o ScreenOtter, um app de print e gravação de tela para Mac. Hero em tela cheia com a lontra do ícone recortada à direita e muito respiro à esquerda. Título branco e forte sobre prints que parecem prontos, um parágrafo curto e um botão arredondado “Download for Mac”. Nav mínima com o logo, os links e um selo no canto. Use o azul do ícone, tipografia Inter e bastante espaço em branco.';

// Rótulo do modelo ao lado do botão de enviar ('' esconde o rótulo).
export const MODELO = 'Opus 5.5';

// 2º ato: um segundo pedido acrescenta uma seção à página. false = filme curto (7,7 s), que termina no recuo da página.
export const SEGUNDO_ATO = true;

// O segundo pedido: 24 letras no ritmo do teclado, o resto de uma vez. Tamanho bom: de 80 a 120 caracteres.
export const PROMPT2 = 'Agora adicione o estúdio de gravação: o editor com a linha do tempo, o zoom automático e o cursor suave.';
