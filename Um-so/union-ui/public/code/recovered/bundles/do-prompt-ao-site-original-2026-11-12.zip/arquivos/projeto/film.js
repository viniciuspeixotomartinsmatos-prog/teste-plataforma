// Do prompt ao site: 480 quadros (16 s) a 30 fps, 1920x1080. Tudo é função pura do quadro: seek(f) desenha o quadro f.
// Sem transição de CSS, sem timer, sem Math.random: o acaso vem de hash com semente.

import { PROMPT, PROMPT2, MODELO, SEGUNDO_ATO } from './conteudo.js';

const $ = id => document.getElementById(id);
const W = 1920, H = 1080, FRAMES = SEGUNDO_ATO ? 480 : 232;

// ---------- utilidades ----------
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const mix = (a, b, t) => a + (b - a) * t;
const lerpV = (a, b, t) => Array.isArray(a) ? a.map((v, i) => mix(v, b[i], t)) : mix(a, b, t);
const E = {
  lin: t => t,
  in: t => t * t * t,
  out: t => 1 - (1 - t) ** 3,
  out4: t => 1 - (1 - t) ** 4,
  outP: p => t => 1 - (1 - t) ** p,
  inOut: t => t < .5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2,
  sine: t => .5 - Math.cos(Math.PI * t) / 2,
  back: t => { const c = 1.6; return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2; },
  hold: t => t < 1 ? 0 : 1,
};
// kf(f, [[quadro, valor, curva?], ...], curvaPadrão): a curva de cada chave vale para o trecho que termina nela
function kf(f, tab, ease = E.inOut) {
  if (f <= tab[0][0]) return tab[0][1];
  for (let i = 1; i < tab.length; i++) {
    const [f1, v1, e1] = tab[i];
    if (f <= f1) { const [f0, v0] = tab[i - 1]; return lerpV(v0, v1, (e1 || ease)((f - f0) / (f1 - f0))); }
  }
  return tab[tab.length - 1][1];
}
const hash = (a, b = 0, c = 0) => { let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul(c | 0, 2147483647); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
const hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
const rgb = c => `rgb(${c.map(Math.round).join(',')})`;
const px = v => v.toFixed(2) + 'px';
const vis = (el, on) => { el.style.display = on ? '' : 'none'; };

// ---------- textos ----------

// quadro em que cada letra do prompt chega
const typedAt = (() => {
  const t = [];
  // 30 letras de f4 a f26, com ritmo de teclado (rajadas e pausas nos espaços)
  const gaps = [];
  for (let i = 0; i < 29; i++) gaps.push((PROMPT[i] === ' ' ? 1.6 : .8) * (.55 + hash(i, 7) * .9));
  const sum = gaps.reduce((a, b) => a + b, 0);
  let f = 4; t.push(4);
  for (let i = 0; i < 29; i++) { f += gaps[i] / sum * 22; t.push(Math.floor(f)); }
  // o resto estoura de f40 a f48, ~50 por quadro
  const rest = PROMPT.length - 30;
  for (let i = 0; i < rest; i++) t.push(40 + Math.floor(i / rest * 8));
  return t;
})();
const C_IND = hex('#24249a'), C_BLUE = hex('#2f6bff'), C_MAR = hex('#7b1e3a'), C_INK = hex('#121212');
const typeColor = age => age < 4 ? lerpV(C_IND, C_BLUE, age / 4) : age < 8 ? lerpV(C_BLUE, C_MAR, (age - 4) / 4) : age < 13 ? lerpV(C_MAR, C_INK, (age - 8) / 5) : C_INK;

// ---------- montagem ----------
for (const id of ['model', 'bmodel']) { const m = $(id); m.querySelector('.rotulo').textContent = MODELO; m.classList.toggle('vazio', !MODELO); }
const txt = $('txt'), chars = [];
for (const ch of PROMPT) { const s = document.createElement('span'); s.textContent = ch; txt.appendChild(s); chars.push(s); }


// linhas do céu: dois círculos, duas horizontais, duas verticais, duas diagonais, brilhos de 4 pontas nos cruzamentos
(() => {
  const svg = $('lines');
  const st = 'fill="none" stroke="rgba(255,255,255,.55)" stroke-width="1.3"';
  const sp = (x, y, r) => `<path d="M${x} ${y - r}Q${x} ${y} ${x + r} ${y}Q${x} ${y} ${x} ${y + r}Q${x} ${y} ${x - r} ${y}Q${x} ${y} ${x} ${y - r}Z" fill="#fff"/>`;
  const hs = [262, 838], vs = [318, 1602];
  let s = `<circle cx="1440" cy="470" r="340" ${st}/><circle cx="1440" cy="470" r="212" ${st} opacity=".7"/>`;
  s += hs.map(y => `<line x1="0" y1="${y}" x2="1920" y2="${y}" ${st}/>`).join('');
  s += vs.map(x => `<line x1="${x}" y1="0" x2="${x}" y2="1080" ${st}/>`).join('');
  s += `<line x1="0" y1="1080" x2="1920" y2="-60" ${st} opacity=".6"/><line x1="160" y1="0" x2="1920" y2="1000" ${st} opacity=".6"/>`;
  for (const y of hs) for (const x of vs) s += sp(x, y, 15);
  s += sp(1440, 130, 11) + sp(1780, 470, 9);
  svg.innerHTML = s;
})();

// ---------- geometria ----------
// caixa no mundo do prompt: [x, y, w, h]
const BOX = f => kf(f, [
  [0, [884, 635, 709, 112]],
  [26, [570, 477, 778, 130], E.out4],
  [29, [570, 477, 778, 130]],
  [36, [541, 425, 833, 214], E.out],
  [44, [541, 227, 833, 640], E.inOut],
  [56, [575, 227, 766, 626], E.out],
]);
const BOX_END = [575, 227, 766, 626];
const SEND_W = [BOX_END[0] + BOX_END[2] - 22 - 32, BOX_END[1] + BOX_END[3] - 22 - 32]; // centro do botão no mundo

// câmera contínua (sem corte): o ponto F do mundo vai para o ponto S da tela, com escala s
function camera(f) {
  const C0 = [960, 540];
  const s = kf(f, [[0, 1.07], [29, 1, E.out], [48, 1], [58, 1.03, E.sine], [73, 3.19, E.inOut], [90, 3.3, E.sine], [105, 1, E.inOut]]);
  const F = kf(f, [[0, C0], [48, C0], [58, [1300, 600], E.sine], [73, SEND_W, E.inOut], [90, SEND_W], [105, C0, E.inOut]]);
  const S = kf(f, [[0, C0], [48, C0], [58, [1300, 600], E.sine], [73, [1060, 640], E.inOut], [90, [1060, 640]], [105, C0, E.inOut]]);
  return { s, F, S };
}
const toScreen = (c, x, y) => [(x - c.F[0]) * c.s + c.S[0], (y - c.F[1]) * c.s + c.S[1]];
const camT = c => `translate(${px(c.S[0] - c.F[0] * c.s)},${px(c.S[1] - c.F[1] * c.s)}) scale(${c.s.toFixed(5)})`;

// página depois do primeiro site: escala, centro vertical, rolagem e altura da janela
function pageView(f) {
  const s = kf(f, [[161, 1], [214, .7, E.outP(2.7)], [280, .7], [312, 1, E.inOut], [400, 1], [452, .415, E.inOut], [479, .424, E.lin]]);
  const cy = kf(f, [[161, 540], [204, 540], [232, 470, E.inOut], [248, 470], [258, 425, E.inOut], [280, 425], [312, 540, E.inOut]]);
  const scroll = kf(f, [[282, 0], [316, 1080, E.inOut], [400, 1080], [452, 0, E.inOut]]);
  const hv = f >= 400 ? 2160 - scroll : 1080;
  return { s, cy, scroll, hv };
}

// ---------- segundo prompt ----------
const typedAt2 = (() => {
  const t = [], gaps = [];
  for (let i = 0; i < 23; i++) gaps.push((PROMPT2[i] === ' ' ? 1.6 : .8) * (.55 + hash(i, 17) * .9));
  const sum = gaps.reduce((a, b) => a + b, 0);
  let f = 224; t.push(224);
  for (let i = 0; i < 23; i++) { f += gaps[i] / sum * 20; t.push(Math.floor(f)); }
  const rest = PROMPT2.length - 24;
  for (let i = 0; i < rest; i++) t.push(250 + Math.floor(i / rest * 6));
  return t;
})();
const btxt = $('btxt'), chars2 = [];
for (const ch of PROMPT2) { const s = document.createElement('span'); s.textContent = ch; btxt.appendChild(s); chars2.push(s); }

// ---------- estúdio: montagem dos itens ----------
const ICONS = {
  Media: '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M5 17l5-5 4 4 2-2 4 4"/>',
  Annotations: '<path d="M4 20l4-1 11-11-3-3L5 16z"/>', Zoom: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5M11 8.5v5M8.5 11h5"/>',
  Cursor: '<path d="M6 4l12 7-5 1.5 3 5.5-2.5 1.5-3-5.5L7 17z"/>', Audio: '<path d="M4 10v4M8 7v10M12 4v16M16 8v8M20 11v2"/>',
  Text: '<path d="M5 6h14M12 6v13"/>', Appearance: '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 0 0 16z" fill="currentColor"/>',
  Crop: '<path d="M7 3v14h14M3 7h14v14"/>',
};
const side = $('side'), sideItems = [];
for (const [k, d] of Object.entries(ICONS)) {
  const li = document.createElement('li'); if (k === 'Zoom') li.className = 'on';
  li.innerHTML = `<svg viewBox="0 0 24 24">${d}</svg>${k}`; side.appendChild(li); sideItems.push(li);
}
(() => { const r = $('ruler'); let s = ''; for (let i = 0; i <= 20; i++) { const x = i / 20 * 100; s += i % 5 === 0 ? `<span style="left:${x}%">${i}s</span>` : `<i style="left:${x}%"></i>`; } r.innerHTML = s; })();
const chips = [...document.querySelectorAll('.chip')];
const inspRows = [...document.querySelectorAll('#insp .ia')];
const CHIP_AT = [332, 336, 340];

// ---------- quadro ----------
const el = Object.fromEntries(['world', 'scene', 'subject', 'page', 'hero', 'heroZoom', 'smear', 'smearDev', 'otter', 'box', 'boxFill', 'caret',
  'model', 'send', 'bulge', 'clip', 'content', 'nav', 'ascii', 'handles', 'wash', 'pink', 'grain', 'veil', 'cursor', 'black', 'stage',
  'pg', 'pgIn', 'scan', 'studioBase', 'bar', 'barFill', 'bcaret', 'bsend', 'bmodel', 'studio', 'sband', 'eyebrow', 'sh', 'sp', 'win', 'pv', 'pvImg', 'pvCur', 'pvRing', 'clipBar', 'head', 'txt'].map(k => [k, $(k)]));
// elementos que a página pode não ter (assunto, rastro): um que falte vira um nó solto e o quadro não quebra
for (const k in el) if (!el[k]) el[k] = k === 'subject' ? null : document.createElement(k === 'smearDev' ? 'i' : 'div');
const handles = [...el.handles.children];
const actx = el.ascii.getContext('2d'), gctx = el.grain.getContext('2d');
const gimg = gctx.createImageData(960, 540);

function grain(f, amt) {
  const d = gimg.data;
  for (let i = 0, n = 960 * 540; i < n; i++) {
    const v = hash(i, f, 11) * 255;
    d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = v; d[i * 4 + 3] = 255;
  }
  gctx.putImageData(gimg, 0, 0);
  el.grain.style.opacity = amt;
}

// campo da carga: grade de pontos que se acende do centro para fora + glifos nas bordas
const GLY = ['%', '@', '#', '⨸', '%', '#'];
function field(f) {
  actx.clearRect(0, 0, W, H);
  const a = kf(f, [[29, 0], [35, 1, E.out], [44, 1], [54, 0, E.inOut]]);
  if (a <= 0) return;
  const ring = kf(f, [[29, 120], [42, 1300, E.out]]);
  for (let y = 11; y < H; y += 22) for (let x = 11; x < W; x += 22) {
    const d = Math.hypot(x - 960, y - 560);
    if (d > ring) continue;
    const edge = clamp((ring - d) / 260);
    const al = a * edge * (.18 + .22 * hash(x, y, 5));
    actx.fillStyle = `rgba(255,255,255,${al.toFixed(3)})`;
    actx.fillRect(x - 1.5, y - 1.5, 3, 3);
  }
  actx.font = '500 24px Menlo, monospace';
  actx.textAlign = 'center'; actx.textBaseline = 'middle';
  const cw = 26, ch = 32, cols = Math.ceil(W / cw), rows = Math.ceil(H / ch);
  const reach = kf(f, [[29, 0], [36, 300, E.out], [44, 340], [54, 80, E.inOut]]);
  const fq = Math.floor(f / 2);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const x = c * cw + cw / 2, y = r * ch + ch / 2;
    const d = Math.min(x, W - x);
    if (d > reach) continue;
    const dens = 1 - d / reach;
    if (hash(c, r, 3) > dens * 1.1) continue;
    actx.fillStyle = `rgba(255,255,255,${(a * (.2 + .7 * dens) * (.5 + hash(c, r, 9) * .5)).toFixed(3)})`;
    actx.fillText(GLY[Math.floor(hash(c, r, fq) * GLY.length)], x, y);
  }
}

// digitação: letras com cor de chegada; devolve a última letra visível
function typeInto(list, at, f) {
  let last = -1;
  for (let i = 0; i < list.length; i++) {
    const on = f >= at[i], s = list[i].style;
    s.visibility = on ? 'visible' : 'hidden';
    if (on) { s.color = rgb(typeColor(f - at[i])); last = i; }
  }
  return last;
}

// faixa ciano descendo sobre um fundo: escurece e apaga o texto acima dela
function bandFill(b, dark) {
  return [
    `linear-gradient(180deg, rgba(0,0,0,0) ${b - 7}%, rgba(100,235,255,.95) ${b - 1.5}%, rgba(225,252,255,.95) ${b}%, rgba(0,0,0,0) ${b + 2.5}%)`,
    `linear-gradient(180deg, rgba(14,18,30,0) 0%, rgba(14,18,30,0) ${100 - dark - 18}%, rgba(14,18,30,1) ${100 - dark}%)`,
    `linear-gradient(180deg, #16192a 0%, #16192a ${b - 4}%, #c4c6cc ${b}%)`,
  ].join(',');
}

// um item que entra: sobe e aparece
const enter = (f, f0, len = 22) => E.out4(clamp((f - f0) / len));

function seek(f) {
  f = Math.round(f);
  const fp = SEGUNDO_ATO ? f : Math.min(f, 214);   // sem 2º ato, a página para no recuo
  const cam = f <= 105;          // câmera contínua até o plano aberto
  const c = camera(f);

  // ----- mundo -----
  vis(el.scene, f < 148);
  let worldT = 'none', hv = H, ps = 1, pv = null;
  if (cam) worldT = camT(c);
  else if (f >= 161) {
    pv = pageView(fp); ps = pv.s; hv = pv.hv;
    worldT = `translate(${px(W / 2 * (1 - ps))},${px(pv.cy - hv / 2 * ps)}) scale(${ps.toFixed(5)})`;
  }
  el.world.style.transform = worldT;
  el.world.style.height = px(hv);
  const framed = ps < .999;
  el.world.style.borderRadius = framed ? px(clamp((1 - ps) / .15) * 22 / ps) : '0px';
  el.world.style.overflow = f >= 161 ? 'hidden' : 'visible';
  el.world.style.boxShadow = framed ? `0 ${px(40 / ps)} ${px(90 / ps)} ${px(-30 / ps)} rgba(20,25,40,${(clamp((1 - ps) / .15) * .35).toFixed(3)})` : 'none';
  el.page.style.transform = pv ? `translateY(${px(-pv.scroll)})` : 'none';
  if (el.subject) el.subject.style.cssText = 'left:1010px;top:190px;width:860px';

  // ----- o card: prompt embaixo, página por cima revelada pelo scan, depois cresce até a tela -----
  const band = kf(f, [[104, 0], [122, 1, E.inOut]]);           // posição do scan no card (0 a 1)
  const grow = kf(f, [[122, 0], [148, 1, E.outP(2.4)]]);        // o card cresce até a tela cheia
  const [cx, cy, cw, ch] = lerpV(BOX_END, [0, 0, W, H], grow);
  const rad = mix(18, 0, grow);

  // caixa do prompt (o card antes do scan)
  let bx, by, bw, bh, rotX = 0;
  if (f < 104) {
    [bx, by, bw, bh] = BOX(Math.min(f, 56));
    rotX = kf(f, [[29, 0], [36, 12, E.out], [50, 0, E.inOut]]);
  } else [bx, by, bw, bh] = BOX_END;
  el.box.style.cssText = `width:${px(bw)};height:${px(bh)};transform:translate(${px(bx)},${px(by)}) rotateX(${rotX.toFixed(3)}deg);border-radius:18px`;
  vis(el.box, f < 123);
  el.model.style.cssText = `right:${px(22 + 64 + 18)};bottom:${px(22 + 21)}`;
  const press = kf(f, [[80, 0], [83, 1, E.out], [88, 0, E.inOut]]);
  const flash = kf(f, [[80, 0], [82, 1, E.out], [86, 1], [94, 0, E.inOut]]);
  el.send.style.cssText = `right:22px;bottom:22px;background:${rgb(lerpV(hex('#111111'), hex('#D97757'), flash))};transform:scale(${(1 + .12 * press).toFixed(4)})`;
  el.bulge.style.cssText = `right:${px(22 + 32 - 50)};bottom:${px(-6 * press)};opacity:${press > .01 ? 1 : 0}`;
  vis(el.bulge, f < 96);
  el.boxFill.style.background = '#fff';
  const last = typeInto(chars, typedAt, f);
  const typing = last >= 0 && f - typedAt[last] < 6;
  if (last >= 0) {
    const chr = chars[last];
    el.caret.style.left = px(34 + chr.offsetLeft + chr.offsetWidth + 2); el.caret.style.top = px(30 + chr.offsetTop + 3);
  } else { el.caret.style.left = '34px'; el.caret.style.top = '33px'; }
  vis(el.caret, f < 62 && (typing || Math.floor(f / 16) % 2 === 0));

  // a página, desenhada na largura do card (janela de 1920 por ch/s, como um site redimensionado)
  const showPage = f >= 104;
  vis(el.pg, showPage);
  if (showPage) {
    const sc = cw / W, vh = ch / sc;
    el.pgIn.style.transform = `translate(${px(cx)},${px(cy)}) scale(${sc.toFixed(5)})`;
    el.hero.style.height = px(f >= 161 ? H : vh);
    el.content.style.transform = `translateY(${px((vh - H) / 2)})`;
    const vis_h = f < 122 ? band * ch : ch;
    el.pg.style.clipPath = f >= 148 ? 'none' : `inset(${px(cy)} ${px(W - cx - cw)} ${px(2160 - cy - vis_h)} ${px(cx)} round ${px(rad)} ${px(rad)} ${px(f < 122 ? 0 : rad)} ${px(f < 122 ? 0 : rad)})`;
    el.heroZoom.style.transform = `scale(${kf(f, [[104, 1.08], [160, 1.0, E.outP(1.6)]]).toFixed(5)})`;
    if (el.smearDev) el.smearDev.setAttribute('stdDeviation', `${kf(f, [[104, 40], [161, 40], [214, 80, E.sine]]).toFixed(1)} 0`);
    if (el.smear) el.smear.style.transform = `translateX(${px(kf(f, [[104, -40], [161, -60], [214, -150, E.sine]]))}) scaleX(${kf(f, [[104, 1.3], [161, 1.38], [214, 1.75, E.sine]]).toFixed(3)})`;
    if (el.smear) el.smear.style.opacity = kf(f, [[104, .32], [161, .36], [214, .55, E.sine]]);
  }
  // a linha do scan, com um rastro ciano por cima
  const scanOn = f >= 103 && f <= 124;
  vis(el.scan, scanOn);
  if (scanOn) {
    const y = cy + band * ch, hh = Math.min(170, band * ch);
    el.scan.style.cssText = `left:${px(cx)};width:${px(cw)};top:${px(y - hh)};height:${px(hh)};opacity:${kf(f, [[103, 0], [105, 1], [120, 1], [124, 0]]).toFixed(3)}`;
  }

  // ----- estúdio: a página rola para uma área ainda crua e o scan monta a seção -----
  const st = SEGUNDO_ATO && f >= 280;
  vis(el.studio, st); vis(el.studioBase, st);
  if (st) {
    const bandS = kf(f, [[296, 0], [330, 1080, E.outP(1.4)]]);
    el.studio.style.clipPath = f >= 331 ? 'none' : `inset(0 0 ${px(1080 - bandS)} 0)`;
    el.sband.style.transform = `translateY(${px(bandS - 260)})`;
    el.sband.style.opacity = kf(f, [[296, 1], [327, 1], [332, 0]]);
    el.clipBar.style.transform = `scaleX(${kf(f, [[328, 0], [344, 1, E.inOut]]).toFixed(4)})`;
    chips.forEach((chp, i) => { const p = kf(f, [[CHIP_AT[i], 0], [CHIP_AT[i] + 8, 1, E.back]]); chp.style.opacity = clamp(p * 3); chp.style.scale = p.toFixed(4); });
    const hx = kf(f, [[330, 6], [430, 74, E.lin]]);
    el.head.style.left = `calc(110px + (100% - 134px) * ${(hx / 100).toFixed(4)})`;
    el.head.style.opacity = kf(f, [[330, 0], [336, 1]]);
    const [px0, py0] = kf(f, [[330, [230, 290]], [362, [455, 175], E.inOut]]);
    el.pvCur.style.transform = `translate(${px(px0 - 34 * .156)},${px(py0 - 34 * .109)}) scale(${(1 - .12 * kf(f, [[362, 0], [364, 1, E.out], [370, 0, E.inOut]])).toFixed(3)})`;
    const ring = clamp((f - 363) / 14);
    el.pvRing.style.cssText = `left:${px(px0)};top:${px(py0)};opacity:${f >= 363 ? (1 - ring).toFixed(3) : 0};transform:scale(${(.3 + 1.3 * E.out(ring)).toFixed(3)})`;
    const z = kf(f, [[364, 1], [380, 1.5, E.inOut], [398, 1.5], [414, 1, E.inOut]]);
    el.pvImg.style.transformOrigin = `${px(px0 - 34)} ${px(py0 - 22)}`;
    el.pvImg.style.transform = `scale(${z.toFixed(4)})`;
    chips[1].style.background = rgb(lerpV(hex('#6457F0'), hex('#8b80ff'), kf(f, [[364, 0], [368, 1], [398, 1], [404, 0]])));
  }

  // ----- segundo prompt -----
  const barOn = SEGUNDO_ATO && f >= 200 && f < 294;
  vis(el.bar, barOn);
  if (barOn) {
    const bh2 = kf(f, [[249, 112], [258, 206, E.out]]);
    const rise = kf(f, [[204, 220], [228, 0, E.out4]]);
    const absorb = kf(f, [[276, 0], [292, 1, E.in]]);
    const bw2 = 820, bx2 = 960 - bw2 / 2, by2 = 1036 - bh2 + rise - absorb * 300;
    const pr2 = kf(f, [[270, 0], [273, 1, E.out], [278, 0, E.inOut]]);
    el.bar.style.cssText = `width:${px(bw2)};height:${px(bh2)};transform:translate(${px(bx2)},${px(by2)}) scale(${(1 - .45 * absorb).toFixed(4)});opacity:${(1 - absorb).toFixed(3)}`;
    const fl2 = kf(f, [[270, 0], [272, 1, E.out], [276, 1], [282, 0, E.inOut]]);
    el.bsend.style.background = rgb(lerpV(hex('#111111'), hex('#D97757'), fl2));
    el.bsend.style.transform = `scale(${(1 + .12 * pr2).toFixed(4)})`;
    const l2 = typeInto(chars2, typedAt2, f);
    if (l2 >= 0) { const chr = chars2[l2]; el.bcaret.style.left = px(30 + chr.offsetLeft + chr.offsetWidth + 2); el.bcaret.style.top = px(26 + chr.offsetTop + 3); }
    else { el.bcaret.style.left = '30px'; el.bcaret.style.top = '29px'; }
    vis(el.bcaret, f < 268 && ((l2 >= 0 && f - typedAt2[l2] < 6) || Math.floor(f / 16) % 2 === 0));
  }

  // ----- sobreposições -----
  field(f < 60 ? f : -1);
  const handlesOn = f < 48;
  vis(el.handles, handlesOn);
  if (handlesOn) {
    const [x, y, w, h] = BOX(f);
    const corners = [[x, y], [x + w, y], [x, y + h], [x + w, y + h]].map(([a, b]) => toScreen(c, a, b));
    const frame = [[44, 44], [W - 44, 44], [44, H - 44], [W - 44, H - 44]];
    const fly = kf(f, [[29, 0], [40, 1, E.out4]]);
    const op = kf(f, [[0, 0], [3, 1], [38, 1], [47, 0, E.inOut]]);
    handles.forEach((hd, i) => { const p = lerpV(corners[i], frame[i], fly); hd.style.left = px(p[0]); hd.style.top = px(p[1]); hd.style.opacity = op; });
  }
  el.wash.style.opacity = kf(f, [[29, 0], [36, .85, E.out], [54, 0, E.inOut]]);
  const zoomAmt = cam ? clamp((c.s - 1.03) / 2.16) : 0;
  el.pink.style.opacity = zoomAmt.toFixed(3);
  vis(el.grain, f < 148);
  if (f < 148) grain(f, kf(f, [[100, .07], [130, .04]]));
  // desfoque de movimento proporcional à velocidade da câmera
  const ds = cam ? Math.abs(camera(f + 1).s - camera(f - 1).s) / 2 : 0;
  const blur = Math.min(7, ds * 16);
  el.world.style.filter = blur > .05 ? `blur(${blur.toFixed(2)}px)` : 'none';
  el.veil.style.opacity = 0;

  // ----- ponteiro do mouse -----
  let cur = null;
  const squash = (a) => 1 - .1 * kf(f, [[a, 0], [a + 2, 1, E.out], [a + 7, 0, E.inOut]]);
  if (f >= 55 && f < 100) {
    const p0 = [1455, 595];
    const bt = toScreen(c, SEND_W[0] + 6, SEND_W[1] + 10);
    const g = E.inOut(clamp((f - 62) / 18));
    const [x, y] = lerpV(p0, bt, g);
    const grow0 = kf(f, [[55, .35], [62, 1, E.back]]);
    cur = { x, y, s: grow0 * mix(1, 1.25, zoomAmt), r: kf(f, [[62, 0], [70, -8, E.sine], [80, 0, E.sine]]), sq: squash(80),
      o: kf(f, [[88, 1], [99, 0, E.in]]) };
  } else if (SEGUNDO_ATO && f >= 256 && f < 292) {
    const bt = [960 + 410 - 20 - 28 + 6, 1036 - 20 - 28 + 10];
    const [x, y] = kf(f, [[256, [1980, 1120]], [270, bt, E.out4]]);
    cur = { x, y, s: .8, r: kf(f, [[256, 22], [270, 0, E.out]]), sq: squash(270), o: kf(f, [[280, 1], [290, 0, E.in]]) };
  }
  vis(el.cursor, !!cur);
  if (cur) {
    el.cursor.style.opacity = cur.o ?? 1;
    el.cursor.style.transform = `translate(${px(cur.x - 112 * .156)},${px(cur.y - 112 * .109)}) rotate(${cur.r.toFixed(2)}deg) scale(${(cur.s * cur.sq).toFixed(4)},${(cur.s * (2 - cur.sq) * cur.sq).toFixed(4)})`;
  }

  vis(el.black, f >= FRAMES - 1);
}

window.seek = seek;
window.FRAMES = FRAMES;
window.deixas = { typedAt, prompt: PROMPT, typedAt2, prompt2: PROMPT2, chips: CHIP_AT, segundoAto: SEGUNDO_ATO, frames: FRAMES };
await document.fonts.ready;
await Promise.all([...document.images].map(i => i.decode().catch(() => {})));
seek(+(new URLSearchParams(location.search).get('f') ?? 0));
window.pronto = true;
