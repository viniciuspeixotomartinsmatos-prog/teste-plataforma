"""Mixa a trilha do filme a partir de audio/trilha.json: a música cortada nos graves, os passa-baixas antes de cada
clique, os efeitos de audio/sfx/ em cada deixa e o master em -14 LUFS / -1 dBTP.

Precisa de: python 3 com numpy, scipy e soundfile (pip install numpy scipy soundfile) e o ffmpeg no PATH.
A música não vem no pacote: baixe a "Voxscape" (Eugenio Mininni) na Mixkit e salve em audio/voxscape.mp3,
ou aponte outra faixa em trilha.json ("musica.arquivo") e acerte os "trechos" nos graves dela.

Uso: python tools/mix.py [--dur segundos] [--saida audio/trilha.wav] [--deixas audio/deixas.json]
Depois de trocar o texto digitado em conteudo.js: node tools/deixas.mjs > audio/deixas.json e passe --deixas.
"""
import argparse, json, subprocess
from pathlib import Path
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parent.parent
SR = 48000

ap = argparse.ArgumentParser()
ap.add_argument('--dur', type=float, help='duração em segundos (o filme curto, sem o 2º ato: 7.733)')
ap.add_argument('--saida', default='audio/trilha.wav')
ap.add_argument('--deixas', help='audio/deixas.json: refaz as teclas para o texto atual dos pedidos')
args = ap.parse_args()

plano = json.load(open(ROOT / 'audio' / 'trilha.json'))
DUR = args.dur or plano['duracao_s']
N = int(round(DUR * SR))
mus = plano['musica']


def decode(path, ss, t):
    b = subprocess.run(['ffmpeg', '-v', 'error', '-ss', f'{max(0, ss)}', '-t', f'{t}', '-i', str(path), '-ac', '2', '-ar', str(SR),
                        '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(b, np.float32).reshape(-1, 2).copy()


# ---------- música: trechos emendados com um cruzamento curto ----------
src = ROOT / mus['arquivo']
if not src.exists():
    raise SystemExit(f'falta a música em {src}: baixe a faixa ({mus["url"]}) e salve com esse nome')
XF = mus['emenda_s']
segs = [(s['inicio_s'], s['fonte_s']) for s in mus['trechos'] if s['inicio_s'] < DUR]
music = np.zeros((N, 2), np.float32)
nx = int(XF * SR)
fade = np.linspace(0, 1, nx, dtype=np.float32)[:, None]
for k, (t0, s0) in enumerate(segs):
    t1 = segs[k + 1][0] if k + 1 < len(segs) else DUR
    i0 = max(0, int(t0 * SR) - (nx if k else 0))
    i1 = min(N, int(t1 * SR))
    x = decode(src, s0 - (XF if k else 0), (i1 - i0) / SR + 0.01)[:i1 - i0]
    w = np.ones((len(x), 1), np.float32)
    if k: w[:nx] = fade
    if k + 1 < len(segs): w[-nx:] = 1 - fade
    music[i0:i0 + len(x)] += x * w

# passa-baixas variável (SVF de 2 polos): fecha antes de cada clique e reabre no grave
keys = [tuple(k) for k in mus['passa_baixas']] + [(99, 18000)]


def cutoff(t):
    for (t0, c0), (t1, c1) in zip(keys, keys[1:]):
        if t0 <= t <= t1:
            u = (t - t0) / (t1 - t0) if t1 > t0 else 1
            return float(np.exp(np.log(c0) + (np.log(c1) - np.log(c0)) * u))
    return 18000.0


def svf_lowpass(x):
    y = np.empty_like(x)
    ic1 = np.zeros(2); ic2 = np.zeros(2); k = 1 / 0.75
    for i in range(len(x)):
        if i % 32 == 0:
            g = np.tan(np.pi * min(cutoff(i / SR), 20000) / SR)
            a1 = 1 / (1 + g * (g + k)); a2 = g * a1; a3 = g * a2
        v3 = x[i] - ic2
        v1 = a1 * ic1 + a2 * v3
        v2 = ic2 + a2 * ic1 + a3 * v3
        ic1 = 2 * v1 - ic1; ic2 = 2 * v2 - ic2
        y[i] = v2
    return y


music = svf_lowpass(music.astype(np.float64)).astype(np.float32)
t = np.arange(N) / SR
music *= np.clip((DUR - 0.05 - t) / mus['saida_s'], 0, 1)[:, None] ** 1.5
music *= 10 ** (mus['ganho_db'] / 20)

# ---------- teclas: refeitas a partir do texto atual (node tools/deixas.mjs > audio/deixas.json) ----------
efeitos = plano['efeitos']
segundo_ato = DUR > 8
if args.deixas:
    segundo_ato = json.load(open(ROOT / args.deixas)).get('segundoAto', True) and DUR > 8
if not segundo_ato:  # filme curto: nada do 2º ato toca
    efeitos = [c for c in efeitos if c.get('ato', 1) == 1]
if args.deixas:
    d = json.load(open(ROOT / args.deixas))
    velhas = [c for c in efeitos if c['papel'] in ('key', 'key.space')]
    efeitos = [c for c in efeitos if c['papel'] not in ('key', 'key.space')]
    def molde(papel):
        cs = [c for c in velhas if c['papel'] == papel]
        return (sorted({c['som'] for c in cs}), float(np.median([c['ganho_db'] for c in cs])),
                float(np.median([c['inicio_s'] - c['deixa_s'] for c in cs])))
    sons = {p: molde(p) for p in ('key', 'key.space')}
    uso = {'key': 0, 'key.space': 0}
    def tecla(papel, t, extra=0.0):
        arqs, g, lead = sons[papel]; i = uso[papel]; uso[papel] += 1
        efeitos.append({'som': arqs[i % len(arqs)], 'papel': papel, 'deixa_s': t, 'inicio_s': t + lead, 'ganho_db': g + extra})
    def digitacao(at, texto, n, rajada):
        por_quadro = {}
        for i in range(min(n, len(texto))): por_quadro.setdefault(at[i], []).append(i)
        for f, idx in sorted(por_quadro.items()):
            for j, i in enumerate(idx): tecla('key.space' if texto[i] == ' ' else 'key', f / plano['fps'] + j * 0.042)
        ts = np.arange(rajada[0] / plano['fps'], (rajada[1] + .6) / plano['fps'], 0.05)
        for k, t0 in enumerate(ts): tecla('key', float(t0), -2.0 - 3.0 * k / len(ts))
    digitacao(d['typedAt'], d['prompt'], 30, (40, 48))
    if segundo_ato: digitacao(d['typedAt2'], d['prompt2'], 24, (250, 256))

# ---------- efeitos: cada som no seu início, com o seu ganho ----------
sfx = np.zeros((N, 2), np.float32)
cache = {}
for c in efeitos:
    if c['deixa_s'] >= DUR: continue
    if c['som'] not in cache:
        x, _ = sf.read(str(ROOT / 'audio' / 'sfx' / c['som']), dtype='float32', always_2d=True)
        cache[c['som']] = x.mean(1)
    x = cache[c['som']] * 10 ** (c['ganho_db'] / 20)
    i0 = int(round(c['inicio_s'] * SR)); j0 = 0
    if i0 < 0: j0 = -i0; i0 = 0
    n = min(len(x) - j0, N - i0)
    if n > 0: sfx[i0:i0 + n] += x[j0:j0 + n, None]

# ---------- master: -14 LUFS integrado, pico verdadeiro -1 dBTP ----------
cru = ROOT / 'audio' / 'mix-cru.wav'
sf.write(str(cru), music + sfx, SR, subtype='FLOAT')
m = subprocess.run(['ffmpeg', '-v', 'info', '-i', str(cru), '-af', 'loudnorm=I=-14:TP=-1:LRA=11:print_format=json', '-f', 'null', '-'],
                   capture_output=True, text=True).stderr
j = json.loads(m[m.rindex('{'):m.rindex('}') + 1])
af = (f"loudnorm=I=-14:TP=-1:LRA=11:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}"
      f":measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(cru), '-af', af + ',alimiter=limit=0.85:level=false', '-ar', str(SR),
                '-c:a', 'pcm_s24le', str(ROOT / args.saida)], check=True)
print('ok', ROOT / args.saida)
