// Tira quadros soltos do filme. Uso: node tools/quadros.mjs <pasta> 20 82 125 200
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { launch } from './browser.mjs';
import { servidor } from './servidor.mjs';

const [dir, ...fs] = process.argv.slice(2);
mkdirSync(dir, { recursive: true });
const s = await servidor();
const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1920, height: 1080 } })).newPage();
page.on('pageerror', e => console.error('pageerror', e.message));
page.on('console', m => m.type() === 'error' && console.error(m.text()));
await page.goto(`${s.url}/index.html`);
await page.waitForFunction(() => window.pronto, null, { timeout: 60000 });
for (const f of fs) {
  await page.evaluate(f => window.seek(f), +f);
  await page.screenshot({ path: join(dir, `f${String(f).padStart(3, '0')}.png`) });
}
console.log('ok', fs.join(' '));
await b.close(); s.fechar();
