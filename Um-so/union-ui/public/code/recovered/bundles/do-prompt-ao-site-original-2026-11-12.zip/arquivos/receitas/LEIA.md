# Receitas das imagens

O filme usa duas imagens recortadas (PNG com fundo transparente):

- `assets/salto.png`: o assunto do fundo da cena do prompt, à direita da caixa (na demo, a lontra saltando com um print na mão).
- `assets/hero.png`: o assunto da página que o card vira, à direita do título (na demo, a lontra segurando os prints).

Você pode usar qualquer imagem sua no lugar: foto do produto, mascote, pessoa, objeto. O que importa é estar recortada,
nítida e opaca. Assunto meio transparente ou esfumado no céu parece fantasma.

## Gerar uma imagem nova

1. Escreva o estilo em um parágrafo, como em `estilo.txt`: o personagem ou produto, as cores com o código, o material e a
   luz. Peça um fundo cinza liso, sem chão e sem sombra, com o assunto inteiro dentro do quadro e margem nos lados.
2. Escreva a pose ou o ângulo, como em `assunto-do-fundo.txt` (paisagem, 1536×1024) e `assunto-da-pagina.txt` (retrato,
   1024×1536, cortado no peito embaixo).
3. Gere em qualquer gerador de imagem que aceite imagem de referência (ChatGPT, Gemini, Midjourney, Ideogram).
   Mande junto o logo ou uma foto do produto, para a imagem sair com a cara da marca. Cada imagem custa centavos, ou
   sai de graça no plano gratuito.

## Recortar

- No Mac: `swift tools/recorta.swift entrada.png saida.png` usa o recorte de assunto do próprio macOS.
- Em qualquer sistema: um removedor de fundo (remove.bg, Photoshop, o "copiar assunto" do iPhone).
- Depois, corte as sobras transparentes em volta. Na imagem da página, deixe o corte reto de baixo rente à borda: ela fica
  ancorada no pé da tela.

## Sem imagem nenhuma

- Cena do prompt: apague o `<img id="subject">` no `index.html`. Ficam o céu, as linhas finas e o brilho de arco-íris.
- Página: troque o `#hero` por um fundo de cor ou um print do seu produto (`<img>` cobrindo a primeira tela).
