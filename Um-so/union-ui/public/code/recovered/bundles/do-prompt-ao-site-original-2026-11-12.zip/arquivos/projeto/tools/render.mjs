// Render do filme: um screenshot por quadro (seek(f) desenha o quadro f), direto para o ffmpeg em H.264 a 30 fps.
// Uso: node tools/render.mjs [--out out/mudo.mp4]
import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { launch } from './browser.mjs';
import { servidor } from './servidor.mjs';

const args = process.argv.slice(2);
const out = args.includes('--out') ? args[args.indexOf('--out') + 1] : join(import.meta.dirname, '..', 'out', 'mudo.mp4');
mkdirSync(dirname(out), { recursive: true });
const s = await servidor();
const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1920, height: 1080 } })).newPage();
page.on('pageerror', e => console.error('pageerror', e.message));
await page.goto(`${s.url}/index.html`);
await page.waitForFunction(() => window.pronto, null, { timeout: 60000 });
const n = await page.evaluate(() => window.FRAMES);

const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-c:v', 'png', '-framerate', '30', '-i', '-',
  '-c:v', 'libx264', '-preset', 'slow', '-crf', '14', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
const escreve = buf => new Promise(r => ff.stdin.write(buf) ? r() : ff.stdin.once('drain', r));
const t0 = Date.now();
for (let f = 0; f < n; f++) {
  await page.evaluate(f => window.seek(f), f);
  await escreve(await page.screenshot({ type: 'png' }));
  if (f % 30 === 0) process.stdout.write(`\r${f}/${n}`);
}
ff.stdin.end();
await new Promise(r => ff.on('close', r));
console.log(`\n${out} (${n} quadros) em ${((Date.now() - t0) / 1000).toFixed(0)} s`);
await b.close(); s.fechar();
