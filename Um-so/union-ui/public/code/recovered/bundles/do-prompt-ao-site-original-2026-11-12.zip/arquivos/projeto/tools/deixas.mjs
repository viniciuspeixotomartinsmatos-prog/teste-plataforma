// Exporta os quadros em que cada letra do prompt chega (para o mixer pôr as teclas). Uso: node tools/deixas.mjs > audio/deixas.json
import { launch } from './browser.mjs';
import { servidor } from './servidor.mjs';
const s = await servidor();
const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1920, height: 1080 } })).newPage();
await page.goto(`${s.url}/index.html`);
await page.waitForFunction(() => window.pronto, null, { timeout: 60000 });
console.log(JSON.stringify(await page.evaluate(() => window.deixas)));
await b.close(); s.fechar();
