// As seis entradas de texto e de bloco do site, cada uma com o seu par de saída e o seu estado inicial:
//   a      script: cada letra nasce deitada (80° no eixo X, presa pelo pé) oito colunas à direita e levanta chegando
//   h      títulos: cada letra nasce quase de perfil (80° no eixo Y), 40% da altura abaixo, e vira de frente subindo
//   p      parágrafos: cada linha sobe de dentro da própria máscara
//   ctn    blocos (botões, símbolo, abas): sobem um pouco e acendem
//   linha  fios verticais: descem de cima para baixo
//   slide  fotos: entram por uma diagonal da direita para a esquerda, a foto de dentro desinflando
// Entrada longa (1,3 s, s-out), saída curta (0,45 s, s-in). Peças do mesmo grupo entram escalonadas.
import { gsap, SplitText, DUR, PASSO, ATRASO, desktop } from './ease.js';

const CLASSES = { charsClass: 'sp-letra', wordsClass: 'sp-palavra', linesClass: 'sp-linha', tag: 'span', aria: 'auto' };
const CORTE = { a: { type: 'chars', smartWrap: true }, h: { type: 'words,chars', smartWrap: true }, p: { type: 'lines,words', mask: 'lines' } };
const partidos = new Set();

function partir(el, tipo) {
  if (!el._sp) {
    el._sp = SplitText.create(el, { ...CORTE[tipo], ...CLASSES });
    el._tipo = tipo;
    partidos.add(el);
  }
  return el._sp;
}

const visivel = (els) => gsap.set(els, { visibility: 'visible' });

function letrasA(alvos, modo, atraso) {
  gsap.utils.toArray(alvos).forEach((el, i) => {
    if (!el.textContent.trim()) return;
    const { chars } = partir(el, 'a');
    visivel(el);
    el._estado = modo === 'mostra' ? 'visivel' : 'oculto';
    if (modo === 'mostra') {
      gsap.fromTo(chars,
        { opacity: 0, rotateX: 80, x: '8vw', transformOrigin: 'center bottom' },
        { opacity: 1, rotateX: 0, x: 0, duration: DUR.l, delay: (atraso ?? ATRASO) + i * PASSO, stagger: PASSO, ease: 's-out', overwrite: true });
    } else if (modo === 'esconde') {
      gsap.to(chars, { opacity: 0, rotateX: -80, x: '-8vw', transformOrigin: 'center top', duration: DUR.s, delay: atraso ?? 0, stagger: PASSO * 0.6, ease: 's-in', overwrite: true });
    } else {
      gsap.set(chars, { opacity: 0, rotateX: -80, x: '-8vw', transformOrigin: 'center top' });
    }
  });
}

function letrasH(alvos, modo, atraso) {
  gsap.utils.toArray(alvos).forEach((el, i) => {
    if (!el.textContent.trim()) return;
    const { chars } = partir(el, 'h');
    visivel(el);
    el._estado = modo === 'mostra' ? 'visivel' : 'oculto';
    if (modo === 'mostra') {
      gsap.fromTo(chars,
        { opacity: 0, yPercent: 40, rotateY: 80 },
        { opacity: 1, yPercent: 0, rotateY: 0, duration: DUR.l, delay: (atraso ?? ATRASO) + i * PASSO, stagger: PASSO * 0.55, ease: 's-out', overwrite: true });
    } else if (modo === 'esconde') {
      gsap.to(chars, { opacity: 0, yPercent: -40, rotateY: -80, duration: DUR.s, delay: atraso ?? 0, stagger: PASSO * 0.3, ease: 's-in', overwrite: true });
    } else {
      gsap.set(chars, { opacity: 0, yPercent: 40, rotateY: 80 });
    }
  });
}

function linhasP(alvos, modo, atraso) {
  gsap.utils.toArray(alvos).forEach((el, i) => {
    if (!el.textContent.trim()) return;
    const { lines } = partir(el, 'p');
    visivel(el);
    el._estado = modo === 'mostra' ? 'visivel' : 'oculto';
    if (modo === 'mostra') {
      gsap.fromTo(lines, { yPercent: 112 }, { yPercent: 0, duration: DUR.l, delay: (atraso ?? ATRASO) + i * PASSO, stagger: PASSO, ease: 's-out', overwrite: true });
    } else if (modo === 'esconde') {
      gsap.to(lines, { yPercent: -112, duration: DUR.s, delay: atraso ?? 0, stagger: PASSO * 0.6, ease: 's-in', overwrite: true });
    } else {
      gsap.set(lines, { yPercent: 112 });
    }
  });
}

function blocos(alvos, modo, atraso) {
  const els = gsap.utils.toArray(alvos);
  if (!els.length) return;
  const y = desktop() ? '3vw' : '10vw';
  visivel(els);
  if (modo === 'mostra') {
    gsap.fromTo(els, { opacity: 0, y }, { opacity: 1, y: 0, duration: DUR.l, delay: atraso ?? ATRASO, stagger: PASSO, ease: 's-out', overwrite: true });
  } else if (modo === 'esconde') {
    gsap.to(els, { opacity: 0, y: 0, duration: DUR.s, delay: atraso ?? 0, stagger: PASSO * 0.6, ease: 's-in', overwrite: true });
  } else {
    gsap.set(els, { opacity: 0, y });
  }
}

function fios(alvos, modo, atraso) {
  const els = gsap.utils.toArray(alvos);
  if (!els.length) return;
  visivel(els);
  if (modo === 'mostra') {
    gsap.fromTo(els, { clipPath: 'inset(0% 0% 100% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: DUR.l, delay: atraso ?? ATRASO, stagger: PASSO, ease: 's-out', overwrite: true });
  } else if (modo === 'esconde') {
    gsap.to(els, { clipPath: 'inset(100% 0% 0% 0%)', duration: DUR.s, delay: atraso ?? 0, stagger: PASSO * 0.6, ease: 's-in', overwrite: true });
  } else {
    gsap.set(els, { clipPath: 'inset(0% 0% 100% 0%)' });
  }
}

function fotos(alvos, modo, atraso) {
  const els = gsap.utils.toArray(alvos);
  if (!els.length) return;
  const dentro = els.map((el) => el.firstElementChild).filter(Boolean);
  visivel(els);
  if (modo === 'mostra') {
    gsap.fromTo(els,
      { clipPath: 'polygon(100% 0%, 100% 0%, 102% 100%, 122% 100%)' },
      { clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)', duration: DUR.l, delay: atraso ?? ATRASO, ease: 's-io', overwrite: true });
    gsap.fromTo(dentro, { scale: 1.4, xPercent: 22 }, { scale: 1, xPercent: 0, duration: DUR.l, delay: atraso ?? ATRASO, ease: 's-io', overwrite: true });
  } else if (modo === 'esconde') {
    gsap.fromTo(els,
      { clipPath: 'polygon(0% 0%, 100% 0%, 122% 100%, 0% 100%)' },
      { clipPath: 'polygon(0% 0%, 0% 0%, 0% 100%, 0% 100%)', duration: DUR.l, delay: atraso ?? 0, ease: 's-io', overwrite: true });
    gsap.to(dentro, { scale: 1.4, xPercent: -22, duration: DUR.l, delay: atraso ?? 0, ease: 's-io', overwrite: true });
  } else {
    gsap.set(els, { clipPath: 'inset(100% 0% 0% 0%)' });
    gsap.set(dentro, { scale: 1.4, xPercent: 22 });
  }
}

export const anima = { a: letrasA, h: letrasH, p: linhasP, ctn: blocos, linha: fios, slide: fotos };

/** Título que não quebra sozinho (o nome do hero e da abertura, as linhas do trilho): se a linha mais larga não cabe
 *  na largura livre da caixa, o corpo encolhe na proporção até caber; nunca cresce. Refaz quando a largura da janela
 *  muda. Assim um nome comprido de outro empreendimento nunca vaza para o lado, nem no celular. */
export function cabe(el, caixa) {
  if (!el || !caixa) return;
  const livre = () => {
    const cs = getComputedStyle(caixa);
    return caixa.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
  };
  const mede = () => {
    el.style.fontSize = '';
    el.style.width = 'max-content';
    const largura = el.offsetWidth;
    el.style.width = '';
    const espaco = livre();
    if (espaco > 0 && largura > espaco) el.style.fontSize = `${(parseFloat(getComputedStyle(el).fontSize) * espaco) / largura}px`;
  };
  mede();
  let w = innerWidth;
  let t = 0;
  addEventListener('resize', () => {
    if (innerWidth === w) return;
    w = innerWidth;
    clearTimeout(t);
    t = setTimeout(mede, 80);
  });
}

/** anima cada peça visível na tela (troca de estado rápida, como o menu) */
export function animaVisiveis(raiz, modo) {
  for (const tipo of Object.keys(anima)) {
    raiz.querySelectorAll(`[data-revela="${tipo}"], [data-parte="${tipo}"]`).forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.top < innerHeight && r.bottom > 0) anima[tipo](el, modo, 0);
    });
  }
}

// Mudou a largura: as linhas partidas dos parágrafos já não batem com a quebra nova. O que já entrou volta a ser
// texto corrido; o que ainda espera a vez é partido de novo, escondido.
let largura = innerWidth;
let espera = 0;
addEventListener('resize', () => {
  clearTimeout(espera);
  espera = setTimeout(() => {
    if (innerWidth === largura) return;
    largura = innerWidth;
    for (const el of partidos) {
      if (el._tipo !== 'p' || !el._sp) continue;
      const estado = el._estado;
      gsap.killTweensOf(el._sp.lines);
      el._sp.revert();
      el._sp = null;
      partidos.delete(el);
      if (estado === 'oculto') linhasP(el, 'inicial');
    }
  }, 120);
});
