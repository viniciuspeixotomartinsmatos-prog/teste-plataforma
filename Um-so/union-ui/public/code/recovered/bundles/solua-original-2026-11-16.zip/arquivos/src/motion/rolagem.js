// Rolagem suave: o Lenis em modo de duração (cada gesto vira uma corrida de 1,25 s com saída exponencial), no relógio
// do GSAP, com o ScrollTrigger lendo a mesma posição. Sem Lenis com movimento reduzido.
// Teto: o alvo da roda nunca fica mais que TETO telas à frente da página, para um gesto violento não atravessar
// as cenas presas de uma vez. No toque a rolagem é a nativa (o filtro devolve true: cancelar o touchend mataria o
// clique de todos os botões no celular).
import Lenis from 'lenis';
import { gsap, ScrollTrigger, REDUZIDO } from './ease.js';

const TETO = 1.25;
let lenis = null;

export function criarRolagem() {
  ScrollTrigger.config({ ignoreMobileResize: true });
  if (REDUZIDO) return null;
  lenis = new Lenis({
    duration: 1.25,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: true,
    touchMultiplier: 2,
  });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((t) => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);

  lenis.options.virtualScroll = (data) => {
    const { deltaY, event } = data;
    if (event.type.includes('touch') || event.ctrlKey || !deltaY) return true;
    const alvo = lenis.targetScroll;
    const dir = Math.sign(deltaY);
    const lim = lenis.animatedScroll + dir * TETO * innerHeight;
    const novo = dir > 0 ? Math.max(alvo, Math.min(alvo + deltaY, lim)) : Math.min(alvo, Math.max(alvo + deltaY, lim));
    data.deltaY = novo - alvo;
    if (Math.abs(data.deltaY) < 0.5) {
      if (event.cancelable) event.preventDefault();
      return false;
    }
    return true;
  };
  return lenis;
}

export const rolagem = () => lenis;

export function trava() {
  document.documentElement.classList.add('travado');
  lenis?.stop();
}
export function solta() {
  document.documentElement.classList.remove('travado');
  lenis?.start();
}
export function topo() {
  scrollTo(0, 0);
  lenis?.scrollTo(0, { immediate: true, force: true });
}
