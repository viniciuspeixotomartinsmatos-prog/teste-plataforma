// O litoral: a foto aérea assenta de 1,12 para 1 (presa pelo pé) enquanto a seção entra, até o pé dela encostar
// no pé da tela. Os tipos de residência usam o slider da casa.
import { gsap } from './ease.js';
import { slider } from './slider.js';

export function local() {
  const sec = document.querySelector('.local');
  const foto = sec?.querySelector('[data-local-foto]');
  // as nuvens só correm com a seção na tela (fora dela, a animação infinita só gastaria quadro)
  if (sec) new IntersectionObserver(([e]) => sec.classList.toggle('is-visivel', e.isIntersecting), { rootMargin: '20% 0px' }).observe(sec);
  if (foto) {
    gsap.from(foto, { scale: 1.12, transformOrigin: '50% 100%', ease: 's-ease', scrollTrigger: { trigger: sec, start: 'top bottom', end: 'bottom bottom', scrub: 0.3 } });
  }
  const tipos = document.querySelector('.tipos__slider');
  if (tipos) slider(tipos);
}
