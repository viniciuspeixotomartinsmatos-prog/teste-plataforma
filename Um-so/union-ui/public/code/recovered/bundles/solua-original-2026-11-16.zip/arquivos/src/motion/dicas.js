// Cartões dos pinos. No computador: passando o mouse num pino, o cartão aparece ao lado do cursor (escala 0,8 → 1,
// em CSS) e segue o cursor com 2,2 s de atraso. Perto da borda direita ele passa para a esquerda do cursor,
// deslizando (0,85 s); perto do pé ou do topo da tela ele não vira: o centro dele para a 16 px da borda,
// e o cartão desliza junto (a virada para cima era um salto de meio cartão).
// Foco do teclado abre o cartão ao lado do pino. No celular: o toque abre o cartão como uma folha que sobe de baixo.
import { gsap, DUR, QUEBRA } from './ease.js';
import { trava, solta } from './rolagem.js';

export function dicas() {
  const caixa = document.querySelector('[data-dicas]');
  if (!caixa) return;
  const fundo = caixa.querySelector('[data-dicas-fundo]');
  const mapa = new Map([...caixa.querySelectorAll('[data-dica]')].map((d) => [d.dataset.dica, d]));
  const ativas = new Set();
  let folha = null;

  // tamanho de layout (offsetWidth/Height): a escala de entrada (0,8) não entra na conta, senão o cartão "cabia" ao
  // abrir e deixava de caber no movimento seguinte
  const lado = (dica, x) => {
    const esq = dica.classList.contains('is-esquerda');
    const passa = x + dica.firstElementChild.offsetWidth + 48 > innerWidth - (esq ? 40 : 0); // 40 px de folga para não ir e voltar
    if (passa !== esq) dica.classList.toggle('is-esquerda', passa);
  };
  const altura = (dica, y) => {
    const meio = dica.firstElementChild.offsetHeight / 2 + 16;
    return meio * 2 > innerHeight ? innerHeight / 2 : gsap.utils.clamp(meio, innerHeight - meio, y);
  };
  const mostra = (dica, x, y) => {
    const cartao = dica.firstElementChild;
    cartao.style.transitionProperty = 'scale, opacity'; // o lado certo já na abertura, sem deslizar até ele
    lado(dica, x);
    void cartao.offsetWidth;
    cartao.style.transitionProperty = '';
    gsap.set(dica, { x, y: altura(dica, y) });
    dica.classList.add('is-ativa');
    ativas.add(dica);
  };
  // o lado fica como está: o cartão some onde estava
  const esconde = (dica) => {
    dica.classList.remove('is-ativa');
    ativas.delete(dica);
  };

  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse') return;
    ativas.forEach((dica) => {
      lado(dica, e.clientX);
      gsap.to(dica, { x: e.clientX, y: altura(dica, e.clientY), duration: 2.2, ease: 's-out', overwrite: true });
    });
  }, { passive: true });

  const abreFolha = (dica, botao) => {
    folha = { dica, botao };
    caixa.classList.add('is-folha');
    dica.classList.add('is-folha');
    botao.classList.add('is-aberto');
    gsap.set([fundo, dica], { display: 'block' });
    gsap.fromTo(dica.firstElementChild, { yPercent: 125 }, { yPercent: 0, duration: DUR.l, ease: 's-out', overwrite: true });
    gsap.fromTo(fundo, { opacity: 0 }, { opacity: 1, duration: DUR.l, ease: 's-out', overwrite: true });
    trava();
    dica.querySelector('[data-dica-fecha]')?.focus({ preventScroll: true });
  };
  const fechaFolha = () => {
    if (!folha) return;
    const { dica, botao } = folha;
    folha = null;
    botao.classList.remove('is-aberto');
    gsap.to(dica.firstElementChild, { yPercent: 125, duration: DUR.m, ease: 's-in', overwrite: true });
    gsap.to(fundo, {
      opacity: 0, duration: DUR.m, ease: 's-in', overwrite: true,
      onComplete: () => { gsap.set([fundo, dica], { clearProps: 'display' }); dica.classList.remove('is-folha'); caixa.classList.remove('is-folha'); },
    });
    solta();
    botao.focus({ preventScroll: true });
  };
  fundo.addEventListener('click', fechaFolha);
  caixa.querySelectorAll('[data-dica-fecha]').forEach((b) => b.addEventListener('click', fechaFolha));
  addEventListener('keydown', (e) => { if (e.key === 'Escape') fechaFolha(); });

  document.querySelectorAll('[data-pino]').forEach((botao) => {
    const dica = mapa.get(botao.dataset.pino);
    if (!dica) return;
    botao.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse' && innerWidth >= QUEBRA) mostra(dica, e.clientX, e.clientY); });
    botao.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') esconde(dica); });
    botao.addEventListener('focus', () => {
      if (innerWidth < QUEBRA || !botao.matches(':focus-visible')) return;
      const r = botao.getBoundingClientRect();
      mostra(dica, r.right, r.top + r.height / 2);
    });
    botao.addEventListener('blur', () => esconde(dica));
    botao.addEventListener('click', () => { if (innerWidth < QUEBRA) abreFolha(dica, botao); });
  });
}
