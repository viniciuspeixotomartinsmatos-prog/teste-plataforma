// Comodidades. Preso à rolagem pela área inteira: as fotos crescem até 1,9x e o conteúdo apaga (s-in, devagar no
// começo), enquanto a seção em arco seguinte sobe por cima. As abas: a foto nova entra pela diagonal por cima da
// antiga, os textos antigos saem e os novos entram 0,85 s depois; o fio de destaque desliza até a aba (0,85 s, s-io).
import { gsap, ScrollTrigger, DUR } from './ease.js';
import { anima } from './texto.js';

export function comodidades() {
  const area = document.querySelector('[data-comod-area]');
  if (!area) return;
  const conteudo = area.querySelector('[data-comod-conteudo]');
  const fotos = area.querySelector('[data-comod-fotos]');
  gsap.timeline({ scrollTrigger: { trigger: area, start: 'top top', end: 'bottom bottom', scrub: true } })
    .fromTo(fotos, { scale: 1 }, { scale: 1.9, ease: 's-in' })
    .fromTo(conteudo, { opacity: 1 }, { opacity: 0, ease: 's-in' }, '<');

  const gatilhos = [...area.querySelectorAll('[data-aba-gatilho]')];
  const destaque = area.querySelector('[data-destaque]');
  const pecas = (chave) => area.querySelectorAll(`[data-aba-conteudo="${chave}"]`);
  const de = (els, t) => [...els].flatMap((el) => [...el.querySelectorAll(`[data-a="${t}"]`)]);
  let atual = gatilhos[0]?.dataset.abaGatilho;
  let ocupado = false;

  gatilhos.slice(1).forEach((g) => {
    const p = pecas(g.dataset.abaGatilho);
    anima.p(de(p, 'p'), 'inicial');
    anima.slide(de(p, 'slide'), 'inicial');
  });

  const move = () => setTimeout(() => {
    const ativo = area.querySelector('[data-aba-gatilho].is-ativa');
    if (!ativo || !destaque) return;
    gsap.to(destaque, { y: ativo.offsetTop, height: ativo.offsetHeight, duration: DUR.m, ease: 's-io' });
  }, 40);
  move();
  addEventListener('resize', move);

  gatilhos.forEach((g) => g.addEventListener('click', () => {
    const chave = g.dataset.abaGatilho;
    if (chave === atual || ocupado) return;
    const velhas = pecas(atual);
    const novas = pecas(chave);
    ocupado = true;
    gatilhos.forEach((x) => { const on = x === g; x.classList.toggle('is-ativa', on); x.setAttribute('aria-selected', on); });
    move();
    gsap.timeline({ onComplete: () => { ocupado = false; } })
      .add(() => {
        velhas.forEach((v) => { v.classList.remove('is-ativa'); v.classList.add('is-saindo'); });
        novas.forEach((n) => n.classList.add('is-ativa'));
        anima.p(de(novas, 'p'), 'inicial');
        anima.slide(de(novas, 'slide'), 'inicial');
        ScrollTrigger.refresh();
      })
      .add(() => {
        anima.p(de(velhas, 'p'), 'esconde', 0);
        anima.slide(de(velhas, 'slide'), 'esconde', 0);
        anima.slide(de(novas, 'slide'), 'mostra', 0);
      })
      .to({}, { duration: DUR.m })
      .add(() => anima.p(de(novas, 'p'), 'mostra', 0))
      .to({}, { duration: DUR.s })
      .add(() => velhas.forEach((v) => v.classList.remove('is-saindo')));
    atual = chave;
  }));
}
