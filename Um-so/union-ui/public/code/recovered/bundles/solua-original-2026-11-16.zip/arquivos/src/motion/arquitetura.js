// Arquitetura (computador). Uma timeline presa à rolagem, do momento em que a tela entra até 1,9 tela depois:
//   0 → 0,45  as duas janelas (mesmo tamanho, em alturas diferentes) sobem e se alinham no meio;
//   0,45 → 0,57elas se esticam até se encostar no centro: viram uma janela só;
//   0,57 → 1  a moldura cresce 1,9x (s-io) até sumir pelas bordas, as flores abrem para os lados e a foto de trás
//             desinfla de 0,8 para 1 pelo topo.
// Com 31% da área, "Arquitetura" entra ocupando a largura (título de perfil); a frase e o botão entram a 44%.
// A foto é 10% mais alta que a tela (sobra embaixo): com a tela presa, ela sobe devagar 8% da tela; quando a tela
// solta e sai, ela fica 25% da tela para trás (o vão que abre em cima fica sempre acima da janela). Nunca desça a
// foto com a tela parada: abriria uma faixa da cor do fundo no topo. No celular: a foto com o texto, entrando ao
// aparecer.
import { gsap, ScrollTrigger, DUR, QUEBRA } from './ease.js';
import { anima } from './texto.js';

// polígono do painel com um furo retangular [x1, x2] × [y1, y2] (em %), aberto por uma fresta no pé
const furo = (x1, x2, y1, y2) =>
  `polygon(0% 0%, 0% 100%, ${x1}% 100%, ${x1}% ${y1}%, ${x2}% ${y1}%, ${x2}% ${y2}%, ${x1}% ${y2}%, ${x1}% 100%, 100% 100%, 100% 0%)`;

function ajusta(el) {
  const caixa = el.parentElement;
  const mede = () => {
    el.style.fontSize = '';
    el.style.width = 'max-content';
    const atual = parseFloat(getComputedStyle(el).fontSize);
    const w = el.offsetWidth;
    el.style.width = '';
    if (w) el.style.fontSize = `${atual * (caixa.clientWidth / w)}px`;
  };
  mede();
  let t = 0;
  new ResizeObserver(() => { clearTimeout(t); t = setTimeout(mede, 60); }).observe(caixa);
}

const DERIVA = 0.08; // quanto a foto sobe com a tela presa (fração da tela; a foto sobra 10% embaixo)
const SAIDA = 0.25; // quanto ela fica para trás enquanto a tela sai

export function arquitetura() {
  const area = document.querySelector('[data-arq]');
  if (!area) return;
  const titulo = area.querySelector('[data-ajusta]');
  if (titulo) ajusta(titulo);
  const tela = area.querySelector('.arq__tela');
  const palco = area.querySelector('[data-arq-palco]');
  const foto = area.querySelector('[data-arq-foto]');
  const texto = (t) => area.querySelectorAll(`[data-arq-texto="${t}"]`);
  const parte = (t) => area.querySelectorAll(`[data-parte="${t}"]`);
  anima.h(texto('h'), 'inicial');
  anima.p(texto('p'), 'inicial');
  anima.p(parte('p'), 'inicial');
  anima.ctn(parte('ctn'), 'inicial');
  const entraTopo = () => { anima.h(texto('h'), 'mostra', 0); anima.p(texto('p'), 'mostra', DUR.s); };
  const saiTopo = () => { anima.h(texto('h'), 'esconde', 0); anima.p(texto('p'), 'esconde', 0); };
  const entraPe = () => { anima.p(parte('p'), 'mostra', 0); anima.ctn(parte('ctn'), 'mostra', DUR.s); };
  const saiPe = () => { anima.p(parte('p'), 'esconde', 0); anima.ctn(parte('ctn'), 'esconde', 0); };

  gsap.matchMedia().add(`(min-width: ${QUEBRA}px)`, () => {
    const e = area.querySelector('[data-arq-e]');
    const d = area.querySelector('[data-arq-d]');
    // gatilho na área, não na tela presa: medida com a tela grudada (um resize no meio da seção), a posição saía errada
    gsap.timeline({ scrollTrigger: { trigger: area, start: 'top bottom', end: 'top -190%', scrub: true } })
      .fromTo(e, { clipPath: furo(44, 98.4, 38, 98) }, { clipPath: furo(44, 98.4, 20, 80), ease: 'none', duration: 0.45 })
      .fromTo(d, { clipPath: furo(1.6, 56, 2, 62) }, { clipPath: furo(1.6, 56, 20, 80), ease: 'none', duration: 0.45 }, '<')
      .to(e, { clipPath: furo(44, 100, 20, 80), ease: 'none', duration: 0.12 })
      .to(d, { clipPath: furo(0, 56, 20, 80), ease: 'none', duration: 0.12 }, '<')
      .fromTo(area.querySelector('[data-arq-janelas]'), { scale: 1 }, { scale: 1.9, ease: 's-io', duration: 0.43 })
      .to(area.querySelector('[data-arq-flor-e]'), { scale: 1.7, xPercent: -42, ease: 's-io', duration: 0.43 }, '<')
      .to(area.querySelector('[data-arq-flor-d]'), { scale: 1.7, xPercent: 42, ease: 's-io', duration: 0.43 }, '<')
      .fromTo(palco, { scale: 0.8, transformOrigin: '50% 0%' }, { scale: 1, ease: 's-io', duration: 0.43 }, '<');
    ScrollTrigger.create({ trigger: area, start: '31% top', onEnter: entraTopo, onLeaveBack: saiTopo });
    ScrollTrigger.create({ trigger: area, start: '44% top', onEnter: entraPe, onLeaveBack: saiPe });
    const alt = () => tela.offsetHeight;
    const presa = (1 - 0.54) * (area.offsetHeight / alt()) - 1; // telas rolando de 54% da área até a tela soltar
    gsap.timeline({ scrollTrigger: { trigger: area, start: '54% top', end: 'bottom top', scrub: true, invalidateOnRefresh: true } })
      .fromTo(foto, { y: 0 }, { y: () => -DERIVA * alt(), ease: 'none', duration: presa })
      .to(foto, { y: () => (SAIDA - DERIVA) * alt(), ease: 'none', duration: 1 });
  });
  gsap.matchMedia().add(`(max-width: ${QUEBRA - 1}px)`, () => {
    ScrollTrigger.create({ trigger: area, start: 'top 60%', once: true, onEnter: () => { entraTopo(); entraPe(); } });
  });
}
