# Receitas das imagens da Solua

As 27 imagens do site foram geradas por IA a partir dos prompts desta pasta (`prompts/`, em inglês, que é como os
geradores de imagem respondem melhor). Servem para refazer uma imagem, gerar mais uma no mesmo estilo ou preencher o
que faltar no empreendimento da pessoa. Qualquer gerador de imagem que aceite texto e imagem de referência serve (o do
ChatGPT, o Gemini, o Midjourney, o Ideogram); nenhum passo depende de uma conta específica.

**Num lançamento de verdade, o melhor material são as perspectivas oficiais do empreendimento** (os renders que o
escritório de arquitetura ou a incorporadora já têm) e as fotos do decorado. Use essas primeiro, nos formatos da tabela
abaixo; gere só o que faltar, mandando um render oficial como referência para a arquitetura sair a mesma.

## Ordem

1. **O estilo** (`estilo.txt`): o parágrafo de arquitetura, jardim e luz que todas as cenas externas repetem. Mantenha
   esse parágrafo em qualquer imagem nova: é ele que deixa a série coerente. Para outro empreendimento, troque a
   descrição da arquitetura nele e use o mesmo texto em todas as imagens.
2. **O hero de dia** (`hero-dia`): a peça principal, vem primeiro. Formato 10:9, a câmera na ponta da piscina, **os 45%
   de cima só de céu azul limpo** (o nome "Solua Residencial" fica ali), palmeiras entrando pelas bordas, os prédios na
   faixa do meio e o deck com as espreguiçadeiras embaixo. Se o céu sair com nuvem ou sol no meio, gere de novo.
3. **O hero de noite** (`hero-noite`): o mesmo enquadramento à noite. Mande o hero de dia junto como referência e peça
   o mesmo quadro: as abas "de dia / de noite" trocam uma pela outra no lugar, então a piscina, os prédios e as
   palmeiras têm de cair no mesmo ponto (o script acerta o tamanho; o enquadramento é com o gerador).
4. **Com o hero de dia como referência** (a mesma arquitetura vista de outros pontos): `razoes-1`, `razoes-2`,
   `razoes-3`, `citacao`, `comod-1` a `comod-5` e `arquitetura`.
5. **Sem referência**: `aerea` (o litoral visto do alto), `terraco`, `interior-1`, `galeria-1` a `galeria-4`, `tipo-1`
   a `tipo-3` e `cta`.
6. **Recortes**: as flores (`flor-1` a `flor-3`) saem em **fundo branco liso** e as nuvens (`nuvens`) em **fundo preto
   liso**; o script de conversão recorta as duas sozinho.
7. **Converter**: salve cada PNG com o nome do prompt em `arquivos/fonte/bruto/` (por exemplo
   `arquivos/fonte/bruto/hero-dia.png`) e rode, da raiz do projeto:
   `npm install -D -E sharp@0.35.5` (uma vez) e depois `node arquivos/fonte/imagens.mjs` (ou só os nomes que mudaram:
   `node arquivos/fonte/imagens.mjs hero-dia hero-noite`). Ele grava o WebP no tamanho do site, em duas larguras, direto
   em `public/img/`. O recorte das flores usa o recorte de objeto do macOS (`recorta.swift`); em outro sistema, tire o
   fundo branco em qualquer removedor de fundo e salve como `arquivos/fonte/bruto/flor-1-recorte.png` (PNG com
   transparência) antes de rodar.

## Tamanhos no site

| imagem | formato | no site |
|---|---|---|
| `hero-dia`, `hero-noite` | 10:9 | 960 e 1440 px de largura (1440 × 1296); as duas no mesmo enquadramento |
| `citacao` | 4:3 | 960 e 1440 px |
| `aerea` | 8:7 | 960 e 1440 px |
| `comod-1` a `comod-5`, `cta` | 16:9 | 960 e 1440 px |
| `arquitetura` | 16:10 | 960 e 1440 px (a seção mostra a foto alta: o assunto no meio) |
| `galeria-1` a `galeria-4` | 16:9 | 900 e 1400 px |
| `razoes-1` a `razoes-3` | 2:1 | 600 e 1000 px |
| `tipo-1` a `tipo-3`, `terraco` | 3:4, em pé | 600 e 800 px (`terraco`: 600 e 900) |
| `interior-1` | 4:5, em pé | 600 e 800 px |
| `nuvens` | 3:1 | 1800 px, com transparência |
| `flor-1`, `flor-2`, `flor-3` | 1:1, 1:1 e 3:4 | 800 px, com transparência |

Mande pelo menos 1440 px de largura nas de tela cheia; acima disso só pesa.

## Custo e alternativas

Cada imagem leva de 1 a 3 minutos; a série inteira cabe numa tarde e, nos planos de assinatura dos geradores, não
custa nada além da mensalidade. As perspectivas oficiais e as fotos do decorado funcionam melhor que qualquer imagem
gerada: respeite os formatos e, no hero, o céu limpo em cima. Foto real tirada de dia serve em todas; só a do hero de
noite precisa do mesmo enquadramento da de dia (sem ela, dá para tirar as abas "de dia / de noite" e deixar só a de
dia: o guia explica).

## Adaptando para outro empreendimento

- **Prédio na cidade ou casa na serra**: troque a arquitetura no `estilo.txt` (e no começo de cada prompt), e o mar e
  as palmeiras pela paisagem do lugar; mantenha o parágrafo de luz se quiser a mesma linguagem.
- **As flores** são de flamboyant; troque pela árvore que combina com a região (ipê, buganvília, jacarandá), sempre um
  galho sozinho em fundo branco.
- **As nuvens** servem para qualquer lugar: não precisam mudar.
