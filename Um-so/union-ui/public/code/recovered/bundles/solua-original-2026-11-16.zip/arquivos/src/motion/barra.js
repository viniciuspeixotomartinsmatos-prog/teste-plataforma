// A barra de rolagem própria (só no computador): o fio enche com a página e o número no pegador conta 00 → 100.
// O pegador arrasta (a página persegue com 3 s de folga, macia) e um clique no fio leva até ali.
import { ScrollTrigger, QUEBRA } from './ease.js';

export function barra(lenis) {
  const trilho = document.querySelector('[data-barra]');
  if (!trilho) return;
  const pegador = trilho.querySelector('[data-barra-pegador]');
  const num = trilho.querySelector('[data-barra-num]');
  const caixa = trilho.closest('.barra');
  ScrollTrigger.create({
    start: 0,
    end: 'max',
    onUpdate: (st) => {
      trilho.style.setProperty('--progresso', `${st.progress * 100}%`);
      num.textContent = String(Math.round(st.progress * 100)).padStart(2, '0');
    },
  });
  const ir = (clientY, duration) => {
    if (innerWidth < QUEBRA) return;
    const r = trilho.getBoundingClientRect();
    const f = Math.max(0, Math.min(1, (clientY - r.top) / r.height));
    const alvo = f * (document.documentElement.scrollHeight - innerHeight);
    lenis ? lenis.scrollTo(alvo, { duration }) : scrollTo({ top: alvo, behavior: 'smooth' });
  };
  let arrastando = false;
  pegador.addEventListener('pointerdown', (e) => {
    arrastando = true;
    pegador.setPointerCapture(e.pointerId);
    caixa.classList.add('is-arrastando');
    e.preventDefault();
  });
  pegador.addEventListener('pointermove', (e) => { if (arrastando) ir(e.clientY, 3); });
  const solta = () => { arrastando = false; caixa.classList.remove('is-arrastando'); };
  pegador.addEventListener('pointerup', solta);
  pegador.addEventListener('pointercancel', solta);
  trilho.addEventListener('click', (e) => { if (e.target !== pegador && !pegador.contains(e.target)) ir(e.clientY, 1.6); });
}
