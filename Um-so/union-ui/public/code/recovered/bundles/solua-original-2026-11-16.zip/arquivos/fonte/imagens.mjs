// Converte as imagens geradas (ou as fotos e renders da pessoa) em WebP no tamanho do site, em duas larguras por foto
// (o srcset do HTML escolhe a do aparelho), direto em public/img/. Rode da raiz do projeto:
//   npm install -D -E sharp@0.35.5          (uma vez; só serve para refazer as fotos)
//   node arquivos/fonte/imagens.mjs [nomes...]   (sem nomes, converte tudo o que estiver em arquivos/fonte/bruto/)
// Cada PNG vai em arquivos/fonte/bruto/<nome>.png, com o nome da receita (hero-dia, comod-1, flor-2...).
//   foto    → public/img/<nome>-<largura>.webp, uma por largura
//   nuvens  → recorte pela luminância (geradas em fundo preto)
//   flores  → recorte do galho (geradas em fundo branco): no Mac, o recorte de objeto do sistema (recorta.swift); em
//             outro sistema, recorte o fundo em qualquer removedor e salve como bruto/flor-N-recorte.png (PNG com alfa)
import sharp from 'sharp';
import { existsSync, readdirSync, rmSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';

const aqui = import.meta.dirname; // arquivos/fonte
const raiz = resolve(aqui, '../..'); // a raiz do projeto
const bruto = (n) => resolve(aqui, 'bruto', `${n}.png`);
const saida = (n) => resolve(raiz, 'public/img', `${n}.webp`);
const Q = 72; // qualidade das fotos

// nome: [larguras, altura forçada da maior (para a noite casar pixel a pixel com o dia)]
const CHEIA = [960, 1440]; // fotos de tela cheia (mande pelo menos 1440 px de largura: acima disso só pesa)
const FOTOS = {
  'hero-dia': [CHEIA], 'hero-noite': [CHEIA, 1296],
  citacao: [CHEIA], aerea: [CHEIA], arquitetura: [CHEIA], cta: [CHEIA],
  'comod-1': [CHEIA], 'comod-2': [CHEIA], 'comod-3': [CHEIA], 'comod-4': [CHEIA], 'comod-5': [CHEIA],
  'razoes-1': [[600, 1000]], 'razoes-2': [[600, 1000]], 'razoes-3': [[600, 1000]],
  terraco: [[600, 900]], 'interior-1': [[600, 800]],
  'tipo-1': [[600, 800]], 'tipo-2': [[600, 800]], 'tipo-3': [[600, 800]],
  'galeria-1': [[900, 1400]], 'galeria-2': [[900, 1400]], 'galeria-3': [[900, 1400]], 'galeria-4': [[900, 1400]],
};

const pedidos = process.argv.slice(2);
const quer = (n) => !pedidos.length || pedidos.includes(n);

// tira as versões antigas de uma imagem (outras larguras, ou o arquivo sem largura)
function limpa(nome) {
  for (const f of readdirSync(resolve(raiz, 'public/img'))) {
    if (f === `${nome}.webp` || new RegExp(`^${nome}-\\d+\\.webp$`).test(f)) rmSync(resolve(raiz, 'public/img', f));
  }
}

for (const [nome, [larguras, alturaMaior]] of Object.entries(FOTOS)) {
  if (!quer(nome)) continue;
  if (!existsSync(bruto(nome))) { console.log('falta', nome); continue; }
  limpa(nome);
  const { width } = await sharp(bruto(nome)).metadata();
  const linha = [];
  for (const l of larguras) {
    const maior = l === larguras.at(-1);
    let p = sharp(bruto(nome)).resize({
      width: l,
      height: maior && alturaMaior ? alturaMaior : undefined,
      fit: maior && alturaMaior ? 'fill' : 'cover',
      kernel: 'lanczos3',
    });
    if (l > width) p = p.sharpen({ sigma: 0.6, m1: 0.6, m2: 1.2 });
    const info = await p.webp({ quality: Q, effort: 6 }).toFile(saida(`${nome}-${l}`));
    linha.push(`${l}w ${Math.round(info.size / 1024)} KB`);
  }
  console.log(nome, linha.join(' · '));
}

// a noite tem de ter a mesma proporção do dia nas duas larguras
if (quer('hero-noite') && existsSync(bruto('hero-noite'))) {
  const dia = await sharp(saida('hero-dia-960')).metadata().catch(() => null);
  if (dia) {
    const info = await sharp(bruto('hero-noite')).resize({ width: dia.width, height: dia.height, fit: 'fill', kernel: 'lanczos3' })
      .webp({ quality: Q, effort: 6 }).toFile(saida('hero-noite-960'));
    console.log('hero-noite 960w acertada para', `${info.width}x${info.height}`);
  }
}

// Nuvens: geradas em fundo preto; a luminância vira o alfa (e a cor é desfeita da mistura com o preto), para a
// nuvem passar por cima do linho e do céu da foto como recorte de verdade.
if (quer('nuvens') && existsSync(bruto('nuvens'))) {
  limpa('nuvens');
  const { data, info } = await sharp(bruto('nuvens')).resize({ width: 1800, kernel: 'lanczos3' }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const out = Buffer.alloc(info.width * info.height * 4);
  for (let i = 0, j = 0; i < data.length; i += 3, j += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const l = Math.max(r, g, b);
    let a = Math.min(1, Math.max(0, (l - 14) / 200));
    a = a * a * (3 - 2 * a);
    const k = a > 0.01 ? 1 / Math.max(a, l / 255) : 1;
    out[j] = Math.min(255, r * k); out[j + 1] = Math.min(255, g * k); out[j + 2] = Math.min(255, b * k);
    out[j + 3] = Math.round(a * 255);
  }
  const res = await sharp(out, { raw: { width: info.width, height: info.height, channels: 4 } }).trim({ threshold: 2 })
    .webp({ quality: 76, alphaQuality: 85, effort: 6 }).toFile(saida('nuvens'));
  console.log('nuvens', `${res.width}x${res.height}`, `${Math.round(res.size / 1024)} KB`);
}

// Flores: geradas em fundo branco; o recorte de objeto do macOS (recorta.swift) separa o galho.
for (const n of ['flor-1', 'flor-2', 'flor-3']) {
  if (!quer(n) || (!existsSync(bruto(n)) && !existsSync(resolve(aqui, 'bruto', `${n}-recorte.png`)))) continue;
  limpa(n);
  const rec = resolve(aqui, 'bruto', `${n}-recorte.png`);
  if (!existsSync(rec)) {
    if (process.platform !== 'darwin') { console.log(`${n}: recorte o fundo branco e salve como arquivos/fonte/bruto/${n}-recorte.png`); continue; }
    execFileSync('swift', [resolve(aqui, 'recorta.swift'), bruto(n), rec], { stdio: 'inherit' });
  }
  const res = await sharp(rec).trim({ threshold: 1 }).resize({ width: 800, kernel: 'lanczos3' })
    .webp({ quality: 76, alphaQuality: 82, effort: 6 }).toFile(saida(n));
  console.log(n, `${res.width}x${res.height}`, `${Math.round(res.size / 1024)} KB`);
}
