// Paralaxe das fotos e dos blocos, presa à rolagem (scrub com 0,6 s de folga):
//   foto    a foto atravessa a moldura de -12% a 12% enquanto a moldura passa pela tela;
//   sai     parada até o pé da moldura chegar ao pé da tela, depois desce 18% enquanto ela sai;
//   entra   desce de -18% a 0 enquanto a moldura entra, assentando quando o pé dela chega ao pé da tela;
//   desce / sobe  o bloco anda 18% para baixo / para cima enquanto atravessa a tela (com folga de 20% nas pontas).
// data-sem-cel / data-sem-desk desligam no celular / no computador.
import { gsap, QUEBRA } from './ease.js';

export function paralaxe(raiz = document) {
  const cel = innerWidth < QUEBRA;
  const desliga = (el) => (cel && el.closest('[data-sem-cel]')) || (!cel && el.closest('[data-sem-desk]'));
  raiz.querySelectorAll('[data-paralaxe]').forEach((el) => {
    if (desliga(el)) return;
    const w = el.closest('[data-paralaxe-w]') || el.parentElement;
    const tipo = el.dataset.paralaxe;
    if (tipo === 'foto') {
      gsap.fromTo(el, { yPercent: -12 }, { yPercent: 12, ease: 'none', force3D: true, scrollTrigger: { trigger: w, start: 'top bottom', end: 'bottom top', scrub: 0.6 } });
    } else if (tipo === 'sai') {
      gsap.fromTo(el, { yPercent: 0 }, { yPercent: 18, ease: 'none', force3D: true, scrollTrigger: { trigger: w, start: 'bottom bottom', end: 'bottom top', scrub: 0.6 } });
    } else if (tipo === 'entra') {
      gsap.fromTo(el, { yPercent: -18 }, { yPercent: 0, ease: 'none', force3D: true, scrollTrigger: { trigger: w, start: 'top bottom', end: 'bottom bottom', scrub: true } });
    } else if (tipo === 'desce' || tipo === 'sobe') {
      const s = tipo === 'desce' ? 1 : -1;
      gsap.fromTo(el, { yPercent: -9 * s }, { yPercent: 9 * s, ease: 'none', force3D: true, scrollTrigger: { trigger: el, start: 'top 120%', end: 'bottom -20%', scrub: 0.6 } });
    }
  });
}
