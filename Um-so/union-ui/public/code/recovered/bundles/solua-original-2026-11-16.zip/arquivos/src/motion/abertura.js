// Abertura = pré-carregamento: um círculo (o sol) nasce no pé da tela, sobe e mergulha, abrindo a página.
// Ela não reage à rolagem nem a gesto nenhum: a página está travada até a abertura terminar.
// Primeira visita da sessão (abertura longa):
//   o nome entra entre "Sol" e "Lua"; 1,3 s depois a moldura e a foto fantasma acendem e a linha vertical começa a
//   encher com o progresso real do carregamento (precarga.js), nunca mais rápido que a curva s-carga em 2,4 s (para
//   ler como carga e não piscar); cheia e tudo baixado, 0,35 s parada e então os dois tempos:
//   1) o sol nasce: o furo redondo sobe do pé da tela até o topo dele ficar a 14% da altura, crescendo de 2/3 até o
//      tamanho cheio (1,55 s, s-io);
//   2) o mergulho: a 88% da subida, o círculo dispara para cima e cresce até cobrir a tela (2,5 s, s-mergulho, que
//      espera e depois corre); ao mesmo tempo a foto do hero desinfla de 0,78 para 1 pelo topo.
// Na volta (sessão já visitada), os arquivos estão no cache: só os dois tempos, depois de no máximo 1,5 s de espera.
// Se a rede travar, a abertura segue depois de 15 s e o resto continua baixando por trás.
import { gsap, DUR, desktop } from './ease.js';
import { anima } from './texto.js';
import { trava, solta, topo } from './rolagem.js';

const MIN_BARRA = 2.4; // s: a linha nunca enche mais rápido que isso
const TETO_REDE = 15; // s: depois disso a abertura segue mesmo sem tudo baixado
const ESPERA_VOLTA = 1.5; // s: na volta, quanto espera o cache antes de abrir

export function abertura({ carga, aoMergulhar, aoTerminar } = {}) {
  const html = document.documentElement;
  const el = document.querySelector('.abertura');
  window.__aberturaViva = true;
  if (!el || !html.classList.contains('abertura-on')) {
    aoMergulhar?.();
    aoTerminar?.();
    return;
  }
  try { sessionStorage.setItem('solua-visitou', '1'); } catch (e) {}
  history.scrollRestoration = 'manual';

  const longa = html.classList.contains('abertura-longa');
  const foto = el.querySelector('.abertura__foto');
  const moldura = el.querySelector('.abertura__moldura');
  const barra = el.querySelector('.abertura__barra');
  const aneis = [...el.querySelectorAll('[data-anel]')];
  const heroImagem = document.querySelector('[data-hero-imagem]');

  const W = innerWidth;
  const H = innerHeight;
  const d = desktop();
  const D1 = Math.min(d ? 0.4 * W : 0.78 * W, 0.7 * H); // diâmetro no fim da subida
  const R2 = (1.08 * ((W / 2) ** 2 + 4 * H * H)) / (4 * H); // raio que cobre a tela com o topo a -1 tela
  const c = { topo: 1.05 * H, r: D1 / 3 }; // nasce com 2/3 do diâmetro, logo abaixo do pé da tela
  const escala = d ? 0.78 : 1.12;

  const aplica = () => {
    const cy = c.topo + c.r;
    el.style.setProperty('--cy', `${cy}px`);
    el.style.setProperty('--r', `${c.r}px`);
    for (const a of aneis) {
      a.setAttribute('cy', cy);
      a.setAttribute('r', c.r * Number(a.dataset.anel));
    }
  };

  topo();
  trava();
  // a barra nasce vazia pelo CSS (translateY -100%); o GSAP lê isso como y em px e somaria o yPercent por cima
  gsap.set(barra, { y: 0, yPercent: -100 });
  if (heroImagem) gsap.set(heroImagem, { scale: escala, transformOrigin: 'center top' });
  aplica();

  const acende = () => {
    gsap.fromTo(foto, { opacity: 0 }, { opacity: 0.06, duration: DUR.l, ease: 's-out' });
    gsap.fromTo(moldura, { opacity: 0 }, { opacity: 1, duration: DUR.l, ease: 's-out' });
  };

  // os dois tempos do círculo
  const abre = () => gsap.timeline()
    .to(c, { topo: 0.14 * H, r: D1 / 2, duration: 1.55, ease: 's-io', onUpdate: aplica })
    .to(c, { topo: -H, r: R2, duration: 2.5, ease: 's-mergulho', onUpdate: aplica }, '<88%')
    .add(() => {
      if (heroImagem) gsap.fromTo(heroImagem, { scale: escala }, { scale: 1, duration: 1.55, ease: 's-io' });
      aoMergulhar?.();
    }, '<')
    .add(() => {
      solta();
      el.remove();
      html.classList.remove('abertura-on', 'abertura-longa', 'abertura-curta');
      html.classList.add('abertura-fim');
      aoTerminar?.();
    });

  if (!longa) {
    acende();
    let foi = false;
    const vez = () => { if (!foi) { foi = true; abre(); } };
    gsap.delayedCall(ESPERA_VOLTA, vez);
    carga?.pronto.then(vez);
    return;
  }

  const parte = (t) => el.querySelectorAll(`[data-parte="${t}"]`);
  anima.a(parte('a'), 'mostra');
  anima.h(parte('h'), 'mostra');
  anima.p(parte('p'), 'mostra');
  anima.ctn(parte('ctn'), 'mostra');
  anima.linha(parte('linha'), 'mostra');

  gsap.delayedCall(DUR.l, () => {
    acende();
    // a linha enche com o progresso real, limitada pela curva da carga (nunca pisca de vazia a cheia)
    const curva = gsap.parseEase('s-carga');
    const vai = gsap.quickTo(barra, 'yPercent', { duration: 0.6, ease: 's-out' });
    const inicio = performance.now();
    let mostrado = 0;
    const passo = () => {
      const t = (performance.now() - inicio) / 1000;
      const real = t > TETO_REDE ? 1 : carga ? carga.progresso() : 1;
      mostrado = Math.max(mostrado, Math.min(real, curva(Math.min(1, t / MIN_BARRA))));
      vai(-100 + 100 * mostrado);
      if (mostrado >= 0.999) {
        gsap.ticker.remove(passo);
        gsap.delayedCall(0.6 + 0.35, abre);
      }
    };
    gsap.ticker.add(passo);
  });
}
