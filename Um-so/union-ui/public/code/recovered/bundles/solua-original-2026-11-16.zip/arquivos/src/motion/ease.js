// Curvas e tempos da casa. Três durações (curta, média, longa), um escalonamento e um atraso de entrada; todo o
// movimento do site sai daqui, para tudo ter a mesma assinatura.
import gsap from 'gsap';
import { CustomEase } from 'gsap/CustomEase';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { SplitText } from 'gsap/SplitText';

gsap.registerPlugin(CustomEase, ScrollTrigger, SplitText);

export const DUR = { s: 0.45, m: 0.85, l: 1.3 };
export const PASSO = 0.09; // escalonamento entre peças
export const ATRASO = 0.25; // atraso de entrada quando a peça aparece na tela
export const QUEBRA = 992; // abaixo disso, o layout do celular

export const desktop = () => innerWidth >= QUEBRA;
export const REDUZIDO = matchMedia('(prefers-reduced-motion: reduce)').matches;

CustomEase.create('s-io', '0.76,0,0.24,1'); // vai e volta (easeInOutQuart): troca de estado, máscara, fotos
CustomEase.create('s-out', '0.25,1,0.5,1'); // saída longa (easeOutQuart): tudo que entra
CustomEase.create('s-in', '0.5,0,0.75,0'); // entrada (easeInQuart): tudo que sai
CustomEase.create('s-ease', '0.25,0.1,0.25,1'); // a curva padrão do CSS: hover de texto, encaixe
CustomEase.create('s-mergulho', '0.64,0,0.06,1'); // a abertura mergulhando na foto
CustomEase.create('s-lateral', '0.37,0,0.63,1'); // o trilho lateral (easeInOutSine)
// a barra de carga da abertura: arranca, quase para no meio (como quem espera a rede) e corre para o fim
CustomEase.create('s-carga', 'M0,0 C0.06,0.22 0.14,0.38 0.24,0.44 0.34,0.5 0.44,0.52 0.54,0.56 0.66,0.61 0.76,0.78 0.86,0.9 0.92,0.96 0.97,1 1,1');

export { gsap, ScrollTrigger, SplitText };
