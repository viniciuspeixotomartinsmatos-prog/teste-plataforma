// Entradas presas à rolagem: cada peça marcada com data-revela="tipo" entra uma vez, quando o topo dela (ou do grupo
// data-revela-grupo em volta) cruza o pé da tela. Peças do mesmo grupo entram escalonadas, na ordem do HTML.
// Dentro do trilho lateral, a entrada conta pela posição horizontal (quando a peça entra pela direita).
// Peças dentro de data-revela-manual ficam por conta da seção (sliders, abas, trilho).
import { ScrollTrigger } from './ease.js';
import { anima } from './texto.js';

export function revelacoes(raiz = document) {
  for (const tipo of Object.keys(anima)) {
    const grupos = new Map();
    raiz.querySelectorAll(`[data-revela="${tipo}"]`).forEach((el) => {
      if (el.closest('[data-revela-manual]')) return;
      const g = el.closest('[data-revela-grupo]') || el;
      if (!grupos.has(g)) grupos.set(g, []);
      grupos.get(g).push(el);
    });
    grupos.forEach((itens, gatilho) => {
      anima[tipo](itens, 'inicial');
      const faixa = gatilho.closest('[data-horizontal]')?._tween;
      ScrollTrigger.create({
        trigger: gatilho,
        containerAnimation: faixa,
        start: faixa ? 'left right' : 'top bottom',
        once: true,
        onEnter: () => anima[tipo](itens, 'mostra'),
      });
    });
  }
}
