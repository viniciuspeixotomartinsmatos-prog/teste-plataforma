// Sanfona: um item aberto por vez. Abrir: a altura corre até o conteúdo (1,3 s, s-out), o + gira 45° e vira x, o
// texto sobe da máscara e o fio acende. Fechar: tudo ao contrário, o x gira até virar + de novo.
import { gsap, ScrollTrigger, DUR } from './ease.js';
import { anima } from './texto.js';

export function sanfona() {
  let aberto = null;
  document.querySelectorAll('[data-item]').forEach((item) => {
    const botao = item.querySelector('[data-item-botao]');
    const conteudo = item.querySelector('[data-item-conteudo]');
    const icone = item.querySelector('[data-item-icone]');
    const p = item.querySelectorAll('[data-item-p]');
    const fio = item.querySelectorAll('[data-item-ctn]');
    gsap.set(conteudo, { height: 0, overflow: 'hidden' });
    anima.p(p, 'inicial');
    anima.ctn(fio, 'inicial');
    const abre = () => {
      item.classList.add('is-aberto');
      botao.setAttribute('aria-expanded', 'true');
      gsap.to(conteudo, { height: 'auto', duration: DUR.l, ease: 's-out', overwrite: true, onComplete: () => ScrollTrigger.refresh() });
      gsap.fromTo(icone, { rotate: 0 }, { rotate: -45, duration: DUR.m, ease: 's-io', overwrite: true });
      anima.p(p, 'mostra');
      anima.ctn(fio, 'mostra');
    };
    const fecha = () => {
      item.classList.remove('is-aberto');
      botao.setAttribute('aria-expanded', 'false');
      gsap.to(conteudo, { height: 0, duration: DUR.l, ease: 's-out', overwrite: true, onComplete: () => ScrollTrigger.refresh() });
      gsap.to(icone, { rotate: -90, duration: DUR.m, ease: 's-io', overwrite: true });
      anima.p(p, 'esconde', 0);
      anima.ctn(fio, 'esconde', 0);
    };
    item._fecha = fecha;
    botao.addEventListener('click', () => {
      if (aberto && aberto !== item) aberto._fecha();
      if (aberto !== item) { abre(); aberto = item; } else { fecha(); aberto = null; }
    });
  });
}
