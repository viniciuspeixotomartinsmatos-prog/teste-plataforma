// Hero preso à rolagem (uma timeline com scrub, de ponta a ponta da área):
//   0 → 0,58 o texto sobe mais rápido que a foto (1,22x a altura dela), a foto sobe até o pé encostar no pé da tela;
//   0,36 → 1 a foto cresce até 1,9x pela beira da piscina (74% da altura), acelerando, enquanto o semicírculo sobe.
// No celular, só o crescimento. As abas trocam a foto do dia pela da noite; os pinos pulsam sem parar.
import { gsap, DUR, desktop } from './ease.js';

export function hero() {
  const area = document.querySelector('[data-hero]');
  if (!area) return;
  const texto = area.querySelector('[data-hero-texto]');
  const fundo = area.querySelector('[data-hero-fundo]');
  const foto = fundo.querySelector('img');

  const montar = () => {
    const tl = gsap.timeline({
      scrollTrigger: { trigger: area, start: 'top top', end: 'bottom bottom', scrub: true, invalidateOnRefresh: true },
    });
    const d = desktop();
    if (d) {
      tl.fromTo(texto, { y: 0 }, { y: () => -(1.22 * fundo.offsetHeight - innerHeight), ease: 's-ease', duration: 0.58 })
        .fromTo(fundo, { y: 0 }, { y: () => -(fundo.offsetHeight - innerHeight), ease: 's-ease', duration: 0.58 }, '<');
    }
    tl.fromTo(fundo, { scale: 1, z: 1, transformOrigin: '50% 74%' }, { scale: 1.9, z: 1, ease: 's-in', duration: 0.58 }, d ? '-=0.22' : '>');
    // os pinos saem quando a foto começa a crescer (crescidos, cairiam em cima do menu); sem pinos, nada a fazer
    const pinos = area.querySelector('.pinos');
    if (pinos) tl.to(pinos, { autoAlpha: 0, ease: 'none', duration: 0.08 }, '<');
  };
  if (foto.complete && foto.naturalWidth) montar();
  else foto.addEventListener('load', montar, { once: true });

  abas(area);
  pulsos(area);
}

function abas(area) {
  const botoes = [...area.querySelectorAll('[data-aba]')];
  const noite = area.querySelector('[data-foto-noite]');
  const divisor = area.querySelector('[data-divisor]');
  let atual = 'dia';
  botoes.forEach((b) => b.addEventListener('click', () => {
    const qual = b.dataset.aba;
    if (qual === atual) return;
    atual = qual;
    botoes.forEach((x) => {
      const on = x === b;
      x.classList.toggle('is-ativa', on);
      x.setAttribute('aria-selected', on);
    });
    divisor.classList.toggle('is-dia', qual === 'dia');
    divisor.classList.toggle('is-noite', qual === 'noite');
    gsap.set(noite, { visibility: 'visible' });
    gsap.to(noite, { opacity: qual === 'noite' ? 1 : 0, duration: DUR.m, ease: 's-io', overwrite: true });
  }));
}

function pulsos(area) {
  const tweens = [...area.querySelectorAll('.pino__botao')].map((b) => gsap.fromTo(b.querySelectorAll('.pino__pulso'),
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 1.55, duration: DUR.l, ease: 's-in', stagger: 0.18, repeat: -1 }));
  // o pulso só roda com os pinos na tela
  const pinos = area.querySelector('.pinos');
  if (pinos) new IntersectionObserver(([e]) => tweens.forEach((t) => (e.isIntersecting ? t.play() : t.pause()))).observe(pinos);
}
