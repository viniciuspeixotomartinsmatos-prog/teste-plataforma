// Modal de visita e menu do celular.
// Modal: o cartão cai do alto girando em perspectiva (escala 0 → 1, -80° → 0 no eixo X, -20° → 0 no plano; 1,3 s,
// s-out) e sai caindo para baixo (0,85 s, s-in). Trava a rolagem, prende o Tab dentro e devolve o foco ao fechar.
// Formulário: rótulo que sobe no foco, linha que acende, erro por campo, "Enviando..." e a mensagem de recebido.
// Seletor próprio (não o nativo): abre com escala e subida, teclado com setas, Enter e Esc.
import { gsap, DUR } from './ease.js';
import { anima } from './texto.js';
import { trava, solta } from './rolagem.js';

const focaveis = 'a[href], button:not([disabled]), input:not([type="hidden"]), [tabindex]:not([tabindex="-1"])';

export function modal() {
  const el = document.querySelector('[data-modal="visita"]');
  if (!el) return;
  const caixa = el.querySelector('[data-modal-caixa]');
  const fundo = el.querySelector('[data-modal-fundo]');
  let aberto = false;
  let quem = null;
  gsap.set(caixa, { transformPerspective: 1000 });

  const abre = (origem) => {
    if (aberto) return;
    aberto = true;
    quem = origem;
    el.hidden = false;
    gsap.fromTo(caixa, { scale: 0, rotateX: -80, yPercent: -90, rotate: -20 }, { scale: 1, rotateX: 0, yPercent: 0, rotate: 0, duration: DUR.l, ease: 's-out', overwrite: true });
    gsap.fromTo(fundo, { opacity: 0 }, { opacity: 1, duration: DUR.l, ease: 's-out', overwrite: true });
    trava();
    setTimeout(() => el.querySelector('input')?.focus({ preventScroll: true }), 450);
  };
  const fecha = () => {
    if (!aberto) return;
    aberto = false;
    gsap.to(caixa, { scale: 1, rotateX: 80, yPercent: 180, rotate: 20, duration: DUR.m, ease: 's-in', overwrite: true, onComplete: () => { el.hidden = true; } });
    gsap.to(fundo, { opacity: 0, duration: DUR.m, ease: 's-in', overwrite: true });
    solta();
    quem?.focus?.({ preventScroll: true });
  };
  document.querySelectorAll('[data-abre-modal="visita"]').forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); abre(b); }));
  el.querySelectorAll('[data-fecha-modal]').forEach((b) => b.addEventListener('click', fecha));
  addEventListener('keydown', (e) => {
    if (!aberto) return;
    if (e.key === 'Escape' && !el.querySelector('.campo--escolha.is-aberto')) fecha();
    if (e.key === 'Tab') {
      const lista = [...caixa.querySelectorAll(focaveis)].filter((x) => x.offsetParent);
      const i = lista.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); lista.at(-1).focus(); }
      else if (!e.shiftKey && i === lista.length - 1) { e.preventDefault(); lista[0].focus(); }
    }
  });
  formulario(el);
  escolha(el);
}

function formulario(raiz) {
  const form = raiz.querySelector('[data-form]');
  if (!form) return;
  const campos = [...form.querySelectorAll('[data-campo]')];
  campos.forEach((c) => {
    const i = c.querySelector('input');
    i.addEventListener('focus', () => c.classList.add('is-focado'));
    i.addEventListener('blur', () => { c.classList.remove('is-focado'); c.classList.toggle('is-cheio', !!i.value.trim()); });
    i.addEventListener('input', () => { c.classList.remove('is-erro'); if (i.name === 'whatsapp') i.value = i.value.replace(/[^\d+()\-\s]/g, ''); });
  });
  const valido = (i) => {
    const v = i.value.trim();
    if (i.name === 'whatsapp') return v.replace(/\D/g, '').length >= 10;
    if (i.type === 'email') return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
    return v.length > 1;
  };
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let primeiro = null;
    campos.forEach((c) => {
      const i = c.querySelector('input');
      const ok = valido(i);
      c.classList.toggle('is-erro', !ok);
      if (!ok && !primeiro) primeiro = i;
    });
    if (primeiro) { primeiro.focus(); return; }
    const botao = form.querySelector('[data-enviar]');
    const rotulo = form.querySelectorAll('.form__enviar .nav-item__txt');
    botao.disabled = true;
    rotulo.forEach((r) => { r.dataset.antes = r.textContent; r.textContent = 'Enviando...'; });
    // a template não envia de verdade: aqui entra o serviço de formulário ou o WhatsApp do cliente
    setTimeout(() => {
      form.classList.add('is-enviado');
      const ok = form.querySelector('[data-form-ok]');
      ok.hidden = false;
      anima.p(ok.querySelectorAll('p'), 'mostra', 0);
    }, 900);
  });
}

function escolha(raiz) {
  const caixa = raiz.querySelector('[data-escolha]');
  if (!caixa) return;
  const botao = caixa.querySelector('[data-escolha-botao]');
  const lista = caixa.querySelector('[data-escolha-lista]');
  const valor = caixa.querySelector('[data-escolha-valor]');
  const campo = caixa.querySelector('[data-escolha-campo]');
  const ops = [...lista.querySelectorAll('[role="option"]')];
  let foco = 0;
  const marca = (i) => { foco = (i + ops.length) % ops.length; ops.forEach((o, j) => o.classList.toggle('is-foco', j === foco)); };
  const abre = () => { caixa.classList.add('is-aberto'); botao.setAttribute('aria-expanded', 'true'); marca(ops.findIndex((o) => o.classList.contains('is-ativa'))); };
  const fecha = () => { caixa.classList.remove('is-aberto'); botao.setAttribute('aria-expanded', 'false'); ops.forEach((o) => o.classList.remove('is-foco')); };
  const escolhe = (o) => {
    ops.forEach((x) => { const on = x === o; x.classList.toggle('is-ativa', on); x.setAttribute('aria-selected', on); });
    valor.textContent = o.dataset.valor;
    campo.value = o.dataset.valor;
    fecha();
    botao.focus({ preventScroll: true });
  };
  botao.addEventListener('click', () => (caixa.classList.contains('is-aberto') ? fecha() : abre()));
  ops.forEach((o, i) => {
    o.addEventListener('click', () => escolhe(o));
    o.addEventListener('pointermove', () => marca(i));
  });
  botao.addEventListener('keydown', (e) => {
    const on = caixa.classList.contains('is-aberto');
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!on) abre(); else marca(foco + (e.key === 'ArrowDown' ? 1 : -1)); }
    else if ((e.key === 'Enter' || e.key === ' ') && on) { e.preventDefault(); escolhe(ops[foco]); }
    else if (e.key === 'Escape' && on) { e.preventDefault(); fecha(); }
    else if (e.key === 'Tab' && on) fecha();
  });
  document.addEventListener('pointerdown', (e) => { if (!caixa.contains(e.target)) fecha(); });
}

export function menuCelular() {
  const botao = document.querySelector('[data-menu-cel]');
  const painel = document.getElementById('menu-cel');
  if (!botao || !painel) return;
  const fundo = painel.querySelector('[data-menu-fundo]');
  const rotulo = botao.querySelector('[data-menu-rotulo]');
  const [l1, l2] = botao.querySelectorAll('.menu__icone i');
  const parte = (t) => painel.querySelectorAll(`[data-parte="${t}"]`);
  let aberto = false;
  const abre = () => {
    aberto = true;
    painel.hidden = false;
    botao.setAttribute('aria-expanded', 'true');
    rotulo.textContent = 'Fechar';
    document.querySelector('.menu')?.classList.add('t-escuro');
    gsap.fromTo(fundo, { opacity: 0 }, { opacity: 1, duration: DUR.m, ease: 's-out' });
    gsap.to(l1, { y: 0, rotate: -45, duration: DUR.m, ease: 's-io' });
    gsap.to(l2, { y: 0, rotate: 45, duration: DUR.m, ease: 's-io' });
    anima.a(parte('a'), 'mostra');
    anima.h(parte('h'), 'mostra');
    anima.ctn(parte('ctn'), 'mostra');
    trava();
  };
  const fecha = () => {
    aberto = false;
    botao.setAttribute('aria-expanded', 'false');
    rotulo.textContent = 'Menu';
    gsap.to(l1, { y: -3, rotate: 0, duration: DUR.m, ease: 's-io' });
    gsap.to(l2, { y: 3, rotate: 0, duration: DUR.m, ease: 's-io' });
    anima.a(parte('a'), 'esconde');
    anima.h(parte('h'), 'esconde');
    anima.ctn(parte('ctn'), 'esconde');
    gsap.to(fundo, { opacity: 0, duration: DUR.m, ease: 's-in', onComplete: () => { painel.hidden = true; document.querySelector('.menu')?.classList.remove('t-escuro'); } });
    solta();
  };
  botao.addEventListener('click', () => (aberto ? fecha() : abre()));
  painel.querySelectorAll('[data-fecha-menu]').forEach((a) => a.addEventListener('click', () => { if (aberto) fecha(); }));
}
