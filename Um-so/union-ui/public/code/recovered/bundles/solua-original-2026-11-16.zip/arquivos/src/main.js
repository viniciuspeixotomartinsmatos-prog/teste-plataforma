// Solua Residencial: monta a rolagem, as cenas presas e as interações; a abertura solta as entradas de texto no
// momento do mergulho (como a página que nasce de dentro do círculo).
import { ScrollTrigger } from './motion/ease.js';
import { criarRolagem } from './motion/rolagem.js';
import { abertura } from './motion/abertura.js';
import { revelacoes } from './motion/revela.js';
import { hero } from './motion/hero.js';
import { interacoes } from './motion/interacoes.js';
import { selo } from './motion/selo.js';
import { barra } from './motion/barra.js';
import { tema } from './motion/tema.js';
import { dicas } from './motion/dicas.js';
import { paralaxe } from './motion/paralaxe.js';
import { arcos, razoes } from './motion/razoes.js';
import { trilho } from './motion/trilho.js';
import { local } from './motion/local.js';
import { comodidades } from './motion/comodidades.js';
import { slider } from './motion/slider.js';
import { arquitetura } from './motion/arquitetura.js';
import { sanfona } from './motion/sanfona.js';
import { fecho } from './motion/fecho.js';
import { modal, menuCelular } from './motion/modal.js';
import { encaixe } from './motion/encaixe.js';
import { ancoras } from './motion/ancoras.js';
import { precarga } from './motion/precarga.js';
import { cabe } from './motion/texto.js';
import './motion/rolando.js';

const html = document.documentElement;

// --vh: a altura da janela em px, fixa enquanto a barra do navegador do celular sobe e desce
let altura = 0;
let largura = 0;
const medeTela = () => {
  const mudouLargura = innerWidth !== largura;
  if (!mudouLargura && Math.abs(innerHeight - altura) < 120 && altura) return;
  altura = innerHeight;
  largura = innerWidth;
  html.style.setProperty('--vh', `${altura}px`);
};
medeTela();
addEventListener('resize', () => {
  medeTela();
  clearTimeout(medeTela.t);
  medeTela.t = setTimeout(() => ScrollTrigger.refresh(true), 60);
});

// sem transição no primeiro quadro (a trava sai depois de dois quadros)
requestAnimationFrame(() => requestAnimationFrame(() => html.classList.add('assentou')));

const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const fotoHero = document.querySelector('.hero__foto');

// a página inteira começa a baixar já: a abertura é o pré-carregamento (a linha vertical mostra o progresso)
const carga = precarga();

async function iniciar() {
  const lenis = criarRolagem();
  // as letras só se partem com a fonte certa na tela; a abertura só sobe com a foto decodificada
  await Promise.race([Promise.all([document.fonts.ready, fotoHero?.decode?.().catch(() => {})]), espera(2500)]);

  // títulos que não quebram sozinhos encolhem se o nome não couber (com a fonte certa já na tela)
  const nome = document.querySelector('#hero-titulo');
  cabe(nome, nome?.closest('.cont'));
  cabe(document.querySelector('.abertura__logo .h3'), document.querySelector('.abertura__logo'));
  const entre = document.querySelector('.trilho__titulo');
  cabe(entre, entre?.closest('.trilho__painel'));

  // as cenas que mexem na altura da página vêm antes (trilho, hero), as entradas depois (contam com elas)
  hero();
  trilho();
  arcos();
  razoes();
  local();
  comodidades();
  const galeria = document.querySelector('.galeria');
  if (galeria) slider(galeria);
  arquitetura();
  sanfona();
  fecho();
  paralaxe();
  interacoes();
  selo(lenis);
  barra(lenis);
  tema();
  dicas();
  modal();
  menuCelular();
  ancoras();
  encaixe(lenis);

  abertura({
    carga,
    aoMergulhar: () => revelacoes(),
    aoTerminar: () => ScrollTrigger.refresh(),
  });
}

iniciar();
