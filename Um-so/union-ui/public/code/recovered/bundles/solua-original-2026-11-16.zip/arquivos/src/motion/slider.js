// Slider da casa (razões, tipos de residência, galeria). Troca sozinho a cada 6,5 s enquanto está na tela, com a barra
// enchendo; setas voltam e avançam (e reiniciam a contagem). Uma troca:
//   a foto nova entra pela diagonal por cima da antiga, que sai pela mesma diagonal (1,3 s, s-io);
//   os textos antigos saem (0,45 s); 0,85 s depois entram os novos (títulos de perfil, linhas da máscara, botão por último).
// Os elementos de cada slide: data-s="h|p|ctn|slide". Só o primeiro slide entra pela rolagem (data-revela).
import { gsap, ScrollTrigger, DUR } from './ease.js';
import { anima } from './texto.js';

const AUTO = 6.5;

export function slider(raiz, { aoTrocar } = {}) {
  const slides = [...raiz.querySelectorAll('[data-slide]')];
  if (slides.length < 2) return null;
  const progresso = raiz.querySelector('[data-progresso]');
  const numAtual = raiz.querySelector('[data-num-atual]');
  const numProx = raiz.querySelector('[data-num-prox]');
  const pecas = (s, t) => s.querySelectorAll(`[data-s="${t}"]`);
  const dois = (n) => String(n).padStart(2, '0');
  const st = { atual: 0, anterior: null, ocupado: false, relogio: 0, visivel: false };

  slides.forEach((s, i) => {
    s.classList.toggle('is-atual', i === 0);
    if (i > 0) {
      anima.h(pecas(s, 'h'), 'inicial');
      anima.p(pecas(s, 'p'), 'inicial');
      anima.ctn(pecas(s, 'ctn'), 'inicial');
      anima.slide(pecas(s, 'slide'), 'inicial');
    }
  });

  const numeros = () => {
    if (numAtual) numAtual.textContent = dois(st.atual + 1);
    if (numProx) numProx.textContent = dois(st.atual === slides.length - 1 ? 1 : st.atual + 2);
  };

  const troca = () => {
    const velho = slides[st.anterior];
    const novo = slides[st.atual];
    gsap.killTweensOf([velho, novo]);
    st.ocupado = true;
    gsap.timeline({ onComplete: () => { st.ocupado = false; } })
      .add(() => {
        velho.classList.remove('is-atual');
        velho.classList.add('is-saindo');
        novo.classList.add('is-atual');
        anima.h(pecas(novo, 'h'), 'inicial');
        anima.p(pecas(novo, 'p'), 'inicial');
        anima.ctn(pecas(novo, 'ctn'), 'inicial');
        anima.slide(pecas(novo, 'slide'), 'inicial');
        aoTrocar?.(st.atual);
      })
      .add(() => {
        anima.h(pecas(velho, 'h'), 'esconde', 0);
        anima.p(pecas(velho, 'p'), 'esconde', 0);
        anima.ctn(pecas(velho, 'ctn'), 'esconde', 0);
        anima.slide(pecas(velho, 'slide'), 'esconde', 0);
        anima.slide(pecas(novo, 'slide'), 'mostra', 0);
      })
      .to({}, { duration: DUR.m })
      .add(() => {
        anima.h(pecas(novo, 'h'), 'mostra', 0);
        anima.p(pecas(novo, 'p'), 'mostra', 0);
        anima.ctn(pecas(novo, 'ctn'), 'mostra', DUR.s);
      })
      .to({}, { duration: DUR.s })
      .add(() => velho.classList.remove('is-saindo'));
  };

  const vai = (passo) => {
    if (st.ocupado) return;
    st.anterior = st.atual;
    st.atual = (st.atual + passo + slides.length) % slides.length;
    numeros();
    troca();
  };

  const enche = () => progresso && gsap.fromTo(progresso, { width: '0%' }, { width: '100%', duration: AUTO, ease: 'none' });
  const zera = () => { if (progresso) { gsap.killTweensOf(progresso); gsap.set(progresso, { width: '0%' }); } };
  const para = () => { clearInterval(st.relogio); zera(); };
  const roda = () => { para(); enche(); st.relogio = setInterval(() => { vai(1); enche(); }, AUTO * 1000); };

  new IntersectionObserver(([e]) => { st.visivel = e.isIntersecting; st.visivel && !document.hidden ? roda() : para(); }, { threshold: 0.2 }).observe(raiz);
  document.addEventListener('visibilitychange', () => (document.hidden || !st.visivel ? para() : roda()));
  raiz.querySelector('[data-ant]')?.addEventListener('click', () => { if (!st.ocupado) { vai(-1); roda(); } });
  raiz.querySelector('[data-prox]')?.addEventListener('click', () => { if (!st.ocupado) { vai(1); roda(); } });
  numeros();
  ScrollTrigger.refresh();
  return st;
}
