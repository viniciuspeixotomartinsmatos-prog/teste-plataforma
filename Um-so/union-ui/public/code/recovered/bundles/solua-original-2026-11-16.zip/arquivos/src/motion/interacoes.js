// Hovers da casa, todos com o mesmo relógio (0,85 s) e as curvas do motion:
//   nav-item  as letras rolam para cima e a cópia sobe por baixo, numa onda da esquerda para a direita (0,16 s);
//   link      as letras viram de perfil e saem para a direita, a cópia vira de frente vindo da esquerda, e o traço
//             embaixo some pela direita (volta pela esquerda);
//   círculo   os dois arcos crescem até fechar o círculo;
//   magnético o botão redondo persegue o cursor e volta com mola quando ele sai.
// No toque não há hover: o toque dá a mesma resposta e desfaz sozinho. Foco do teclado conta como hover.
import { gsap, SplitText, DUR, PASSO, QUEBRA } from './ease.js';
import { rolando } from './rolando.js';

const toque = matchMedia('(hover: none)').matches;
if (toque) document.documentElement.classList.add('toque');

// liga entrar/sair num gatilho: mouse (fora da rolagem), foco do teclado e um toque que acende e apaga sozinho
function gatilho(el, entra, sai) {
  let dentro = false;
  const on = () => { if (!dentro) { dentro = true; entra(); } };
  const off = () => { if (dentro) { dentro = false; sai(); } };
  el.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse' && !rolando.on) on(); });
  el.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') off(); });
  el.addEventListener('focusin', () => { if (el.matches(':has(:focus-visible), :focus-visible')) on(); });
  el.addEventListener('focusout', off);
  el.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse') return;
    on();
    setTimeout(off, 650);
  });
  // a rolagem passou o item por baixo do cursor parado: só acende quando o mouse mexer de verdade
  el.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' && !rolando.on) on(); });
}

// onda pela posição horizontal: a letra mais à esquerda sai primeiro, a mais à direita 'total' segundos depois
const onda = (total) => (i, alvo, lista) => {
  const xs = lista.map((l) => l.getBoundingClientRect().left);
  const min = Math.min(...xs);
  const faixa = Math.max(...xs) - min || 1;
  return ((xs[i] - min) / faixa) * total;
};

export function navItems(raiz = document) {
  raiz.querySelectorAll('[data-nav-item]').forEach((item) => {
    if (item._nav) return;
    const [t1, t2] = item.querySelectorAll('.nav-item__txt');
    if (!t1 || !t2) return;
    const opc = { type: 'words,chars', tag: 'span', smartWrap: true, mask: 'words', wordsClass: 'sp-palavra', charsClass: 'sp-letra', aria: 'none' };
    const a = SplitText.create(t1, opc);
    const b = SplitText.create(t2, opc);
    item._nav = true;
    gsap.set(b.chars, { yPercent: 100, opacity: 0 });
    const base = { duration: DUR.m, ease: 's-ease', stagger: onda(1.8 * PASSO), overwrite: true, force3D: true };
    const entra = () => {
      gsap.fromTo(a.chars, { opacity: 1, yPercent: 0 }, { opacity: 0, yPercent: -100, ...base });
      gsap.fromTo(b.chars, { opacity: 0, yPercent: 100 }, { opacity: 1, yPercent: 0, ...base });
    };
    const sai = () => {
      gsap.to(a.chars, { opacity: 1, yPercent: 0, ...base });
      gsap.to(b.chars, { opacity: 0, yPercent: 100, ...base });
    };
    gatilho(item.closest('[data-gatilho], [data-circulo]') || item, entra, sai);
  });
}

export function links(raiz = document) {
  raiz.querySelectorAll('[data-link]').forEach((link) => {
    if (link._link) return;
    const [t1, t2] = link.querySelectorAll('.link__txt');
    if (!t1 || !t2) return;
    link._link = true;
    const a = SplitText.create(t1, { type: 'lines,words,chars', tag: 'span', smartWrap: true, linesClass: 'sp-linha', wordsClass: 'sp-palavra', charsClass: 'sp-letra', aria: 'none' });
    const b = SplitText.create(t2, { type: 'words,chars', tag: 'span', smartWrap: true, wordsClass: 'sp-palavra', charsClass: 'sp-letra', aria: 'none' });
    const tracos = a.lines.map((linha) => {
      const t = document.createElement('span');
      t.className = 'link__traco';
      linha.appendChild(t);
      return t;
    });
    gsap.set(tracos, { scaleX: 1, transformOrigin: 'right center' });
    gsap.set(b.chars, { opacity: 0, x: '-0.35em', yPercent: 20, rotateY: 80 });
    const entra = () => {
      gsap.fromTo(a.chars, { opacity: 1, x: 0, yPercent: 0, rotateY: 0 },
        { opacity: 0, x: '0.35em', yPercent: -20, rotateY: -80, duration: DUR.m, ease: 's-out', stagger: PASSO * 0.3, overwrite: true, force3D: true });
      gsap.fromTo(b.chars, { opacity: 0, x: '-0.35em', yPercent: 20, rotateY: 80 },
        { opacity: 1, x: 0, yPercent: 0, rotateY: 0, duration: DUR.m, ease: 's-out', delay: 0.18, stagger: PASSO * 0.3, overwrite: true, force3D: true });
      gsap.fromTo(tracos, { scaleX: 1, transformOrigin: 'right center' }, { scaleX: 0, duration: DUR.m, ease: 's-out', stagger: PASSO, overwrite: true });
    };
    const sai = () => {
      gsap.to(a.chars, { opacity: 1, x: 0, yPercent: 0, rotateY: 0, duration: DUR.m, ease: 's-out', delay: 0.18, stagger: PASSO * 0.3, overwrite: true, force3D: true });
      gsap.to(b.chars, { opacity: 0, x: '-0.35em', yPercent: 20, rotateY: 80, duration: DUR.m, ease: 's-out', stagger: PASSO * 0.3, overwrite: true, force3D: true });
      gsap.to(tracos, { scaleX: 1, transformOrigin: 'left center', duration: DUR.m, ease: 's-out', stagger: PASSO, overwrite: true });
    };
    gatilho(link, entra, sai);
  });
}

export function circulos(raiz = document) {
  const C = 2 * Math.PI * 103.5;
  const curto = 0.0417 * C;
  raiz.querySelectorAll('[data-circulo]').forEach((c) => {
    if (c._circ) return;
    c._circ = true;
    c.setAttribute('data-gatilho', '');
    const arcos = c.querySelectorAll('[data-arco]');
    gsap.set(arcos, { strokeDasharray: `${curto} ${C}` });
    const tl = gsap.timeline({ paused: true }).to(arcos, { strokeDasharray: `${C / 2} ${C}`, duration: DUR.m, ease: 's-io' });
    gatilho(c, () => tl.play(), () => tl.reverse());
  });
}

export function magneticos(raiz = document) {
  if (toque) return;
  raiz.querySelectorAll('[data-magnetico]').forEach((el) => {
    if (el._mag) return;
    el._mag = true;
    const forca = Number(el.dataset.magnetico) || 25;
    const dentro = el.querySelectorAll('[data-magnetico-dentro]');
    const volta = (alvos, imediato) => {
      gsap.killTweensOf(alvos);
      (imediato ? gsap.set : gsap.to)(alvos, { x: 0, y: 0, force3D: true, ...(imediato ? {} : { ease: 'elastic.out(1, 0.35)', duration: 1.5 }) });
    };
    el.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse' && innerWidth >= QUEBRA) { volta(el, true); volta(dentro, true); } });
    el.addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse' || innerWidth < QUEBRA || rolando.on) return;
      const r = el.getBoundingClientRect();
      const fx = (e.clientX - r.left) / r.width - 0.5;
      const fy = (e.clientY - r.top) / r.height - 0.5;
      gsap.to(el, { x: `${fx * (forca / 16)}em`, y: `${fy * (forca / 16)}em`, force3D: true, ease: 'power4.out', duration: 1.5 });
      gsap.to(dentro, { x: `${fx * (forca / 16)}em`, y: `${fy * (forca / 16)}em`, force3D: true, ease: 'power4.out', duration: 1.9 });
    });
    el.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') { volta(el, false); volta(dentro, false); } });
  });
}

export function interacoes(raiz = document) {
  navItems(raiz);
  links(raiz);
  circulos(raiz);
  magneticos(raiz);
}
