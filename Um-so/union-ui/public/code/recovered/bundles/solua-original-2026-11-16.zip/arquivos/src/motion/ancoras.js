// Links de âncora (#residencias, #contato, #topo): a página desliza até lá com a rolagem suave (1,8 s, s-io), sem
// salto. O modal e o menu têm os próprios ouvintes.
import { gsap } from './ease.js';
import { rolagem } from './rolagem.js';

const toque = matchMedia('(hover: none)').matches;

export function ancoras() {
  const curva = gsap.parseEase('s-io');
  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    if (a.hasAttribute('data-abre-modal')) return;
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if (id === '#') { e.preventDefault(); return; }
      const alvo = id === '#topo' ? 0 : document.querySelector(id);
      if (alvo === null) return;
      e.preventDefault();
      // no toque o Lenis não conduz a rolagem (ela é a nativa): ali vai a rolagem suave do próprio navegador
      const lenis = toque ? null : rolagem();
      if (lenis) lenis.scrollTo(alvo, { duration: 1.8, easing: curva });
      else (alvo === 0 ? scrollTo({ top: 0, behavior: 'smooth' }) : alvo.scrollIntoView({ behavior: 'smooth' }));
    });
  });
}
