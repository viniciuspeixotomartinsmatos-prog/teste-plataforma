// Fecho: do topo do rodapé a 32% da tela até o fim da página (scrub com 0,6 s de folga), a foto do convite se
// recolhe numa moldura e o rodapé cresce de 0,8 e acende; os textos do rodapé entram por tempo ao começar e saem
// se a rolagem voltar. O "Role" do topo apaga enquanto o rodapé entra.
import { gsap, desktop } from './ease.js';
import { anima } from './texto.js';

export function fecho() {
  const rodape = document.querySelector('[data-rodape]');
  const cta = document.querySelector('[data-fecho-recorte]');
  if (!rodape || !cta) return;
  const corpo = rodape.querySelector('[data-rodape-corpo]');
  const r = (t) => rodape.querySelectorAll(`[data-r="${t}"]`);
  anima.h(r('h'), 'inicial');
  anima.p(r('p'), 'inicial');
  anima.ctn(r('ctn'), 'inicial');
  gsap.timeline({
    scrollTrigger: {
      trigger: rodape, start: 'top 32%', end: 'bottom bottom', scrub: 0.6,
      onEnter: () => { anima.h(r('h'), 'mostra', 0.1); anima.p(r('p'), 'mostra', 0.1); anima.ctn(r('ctn'), 'mostra', 0.1); },
      onLeaveBack: () => { anima.h(r('h'), 'esconde', 0); anima.p(r('p'), 'esconde', 0); anima.ctn(r('ctn'), 'esconde', 0); },
    },
  })
    .fromTo(cta, { clipPath: 'inset(0% 0% 0% 0%)' }, { clipPath: desktop() ? 'inset(9% 24% 9% 24%)' : 'inset(5% 30% 5% 30%)', ease: 'none' }, 0)
    .fromTo(corpo, { opacity: 0, scale: 0.8 }, { opacity: 1, scale: 1, ease: 'none' }, 0);

  const rolar = document.querySelector('.rolar');
  if (rolar) gsap.to(rolar, { opacity: 0, ease: 's-io', scrollTrigger: { trigger: rodape, start: 'top bottom', end: 'center bottom', scrub: true } });
}
