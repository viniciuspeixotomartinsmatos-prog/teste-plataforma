// Três razões: as palavras do título se afastam pela borda do semicírculo enquanto ele atravessa a tela (do pé
// entrando ao topo saindo, preso à rolagem). O slider abaixo usa o motor da casa; a paginação fica logo abaixo da foto.
import { gsap } from './ease.js';
import { slider } from './slider.js';

export function arcos() {
  document.querySelectorAll('.arco').forEach((arco) => {
    // o espaço final é 10% da largura do viewBox de cada versão (1600 no computador, 400 no celular)
    arco.querySelectorAll('[data-palavras]').forEach((texto) => {
      gsap.fromTo(texto, { wordSpacing: 0 }, {
        wordSpacing: Number(texto.dataset.espaco) || 150,
        ease: 'none',
        scrollTrigger: { trigger: arco, start: 'top bottom', end: 'bottom top', scrub: true },
      });
    });
  });
}

export function razoes() {
  const raiz = document.querySelector('.razoes__slider');
  if (!raiz) return;
  const pag = raiz.querySelector('[data-pag]');
  // a paginação acompanha o pé da foto do slide da vez
  const posiciona = () => {
    const foto = raiz.querySelector('.slide.is-atual [data-s-foto]');
    if (!foto || !pag) return;
    const r = foto.getBoundingClientRect();
    const base = raiz.getBoundingClientRect();
    pag.style.top = `${r.bottom - base.top + 16}px`;
  };
  slider(raiz, { aoTrocar: () => requestAnimationFrame(posiciona) });
  posiciona();
  addEventListener('resize', posiciona);
}
