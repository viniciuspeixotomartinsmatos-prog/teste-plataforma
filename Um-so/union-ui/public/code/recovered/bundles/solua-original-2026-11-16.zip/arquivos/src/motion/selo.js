// O selo do topo gira sozinho a 28°/s. Rolando, acelera com a velocidade da rolagem (28 + 9x a velocidade) e gira
// para o lado do gesto; 0,12 s depois de a rolagem parar, volta a 28°/s em 1,3 s, mantendo o lado do último gesto.
import { gsap, DUR } from './ease.js';

export function selo(lenis) {
  const giro = document.querySelector('.selo__giro');
  if (!giro) return;
  const v = { graus: 28 };
  let angulo = 0;
  let lado = 1;
  let espera = 0;
  let mexeu = false;
  addEventListener('wheel', () => { mexeu = true; }, { once: true, passive: true });
  addEventListener('touchmove', () => { mexeu = true; }, { once: true, passive: true });
  gsap.ticker.add((t, dt) => {
    angulo += v.graus * (Math.min(dt, 100) / 1000);
    gsap.set(giro, { rotation: angulo, transformOrigin: '50% 50%' });
  });
  lenis?.on('scroll', ({ velocity }) => {
    if (!mexeu) return;
    if (velocity !== 0) lado = velocity > 0 ? 1 : -1;
    gsap.to(v, { graus: lado * (28 + 9 * Math.abs(velocity)), duration: 0.35, ease: 's-out', overwrite: true });
    clearTimeout(espera);
    espera = setTimeout(() => gsap.to(v, { graus: 28 * lado, duration: DUR.l, ease: 's-out' }), 120);
  });
}
