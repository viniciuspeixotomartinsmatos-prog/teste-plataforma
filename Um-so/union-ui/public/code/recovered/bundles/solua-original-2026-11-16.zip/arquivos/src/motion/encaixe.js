// Encaixe (só no computador): 60 ms depois de a rolagem parar, se uma seção data-encaixe ocupa mais da metade da
// tela, a página desliza até ela em 1,3 s. Qualquer gesto novo interrompe o deslize (o Lenis troca o alvo).
import { gsap, QUEBRA, DUR } from './ease.js';

export function encaixe(lenis) {
  if (!lenis) return;
  const secoes = [...document.querySelectorAll('[data-encaixe]')];
  if (!secoes.length) return;
  const curva = gsap.parseEase('s-ease');
  let espera = 0;
  let encaixando = false;
  lenis.on('scroll', () => {
    if (innerWidth < QUEBRA || encaixando) return;
    clearTimeout(espera);
    espera = setTimeout(() => {
      const H = innerHeight;
      let melhor = null;
      let fracao = 0;
      for (const s of secoes) {
        const r = s.getBoundingClientRect();
        const f = (Math.min(r.bottom, H) - Math.max(r.top, 0)) / Math.min(s.offsetHeight, H);
        if (f > 0.5 && f > fracao) { fracao = f; melhor = s; }
      }
      if (!melhor || Math.abs(melhor.getBoundingClientRect().top) < 2) return;
      encaixando = true;
      lenis.scrollTo(melhor, { duration: DUR.l, easing: curva, onComplete: () => { encaixando = false; } });
      setTimeout(() => { encaixando = false; }, DUR.l * 1000 + 100);
    }, 60);
  });
}
