// O topo fixo (selo, menu, barra, "Role") troca de cor pela área que passa atrás de cada peça. As áreas são os
// elementos com data-fundo="foto|claro|escuro|secao"; para cada peça, conta só a área que cobre o meio dela na
// horizontal, a partir do momento em que a borda de cima da área cruza o meio dela na vertical.
// Área com topo em semicírculo (data-fundo-arco): a borda de cima desce nas laterais, e a troca espera a curva
// chegar à altura da peça.
import { ScrollTrigger } from './ease.js';

const TEMAS = ['t-foto', 't-claro', 't-escuro', 't-secao'];

export function tema() {
  const pecas = [...document.querySelectorAll('[data-tema-peca]')];
  const areas = [...document.querySelectorAll('[data-fundo]')];
  for (const peca of pecas) {
    const aplica = (fundo) => {
      peca.classList.remove(...TEMAS);
      peca.classList.add(`t-${fundo}`);
    };
    for (const area of areas) {
      const meio = () => {
        const r = peca.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      };
      const cobre = () => {
        const a = area.getBoundingClientRect();
        const { x } = meio();
        return a.width > 0 && x >= a.left && x <= a.right;
      };
      if (!cobre()) continue;
      const curva = () => {
        if (!area.hasAttribute('data-fundo-arco')) return 0;
        const a = area.getBoundingClientRect();
        const R = a.width / 2;
        const dx = meio().x - (a.left + R);
        return Math.abs(dx) >= R ? R : R - Math.sqrt(R * R - dx * dx);
      };
      ScrollTrigger.create({
        trigger: area,
        start: () => `top+=${curva()} top+=${meio().y}`,
        end: () => `bottom top+=${meio().y}`,
        onEnter: () => aplica(area.dataset.fundo),
        onEnterBack: () => aplica(area.dataset.fundo),
      });
    }
  }
}
