// Pré-carregamento de verdade: enquanto a abertura está na tela, a página inteira baixa (todas as fotos, na largura
// que o srcset escolheu para o aparelho, e as três fontes) e a linha vertical da abertura mostra quanto já chegou.
// Quando tudo chega, as fotos são decodificadas uma a uma no tempo livre do navegador: a rolagem não paga download
// nem decodificação no meio do movimento.
export function precarga() {
  const imgs = [...document.images];
  const fontes = ['400 1em "Imbue Variable"', '400 1em "Imperial Script"', '700 1em "Archivo Variable"', '400 1em "Archivo Variable"'];
  const total = imgs.length + 1;
  let feitos = 0;
  const conta = () => { feitos = Math.min(total, feitos + 1); };

  const promessas = imgs.map((img) => {
    if (img.getAttribute('loading') === 'lazy') img.loading = 'eager';
    if (img.complete && img.currentSrc) { conta(); return Promise.resolve(); }
    return new Promise((ok) => {
      const fim = () => { conta(); ok(); };
      img.addEventListener('load', fim, { once: true });
      img.addEventListener('error', fim, { once: true });
    });
  });
  promessas.push(Promise.all(fontes.map((f) => document.fonts.load(f).catch(() => {}))).then(conta));

  const pronto = Promise.all(promessas);
  pronto.then(() => decodificaAosPoucos(imgs));
  return { pronto, progresso: () => feitos / total };
}

function decodificaAosPoucos(imgs) {
  const fila = imgs.filter((i) => i.naturalWidth && typeof i.decode === 'function');
  const espera = (f) => (window.requestIdleCallback ? requestIdleCallback(f, { timeout: 400 }) : setTimeout(f, 30));
  const proxima = () => {
    const img = fila.shift();
    if (!img) return;
    img.decode().catch(() => {}).finally(() => espera(proxima));
  };
  espera(proxima);
}
