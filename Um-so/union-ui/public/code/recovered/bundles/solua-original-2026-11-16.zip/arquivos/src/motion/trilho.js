// Trilho lateral (só no computador): a área tem a altura da largura da faixa; presa à rolagem, a faixa anda para a
// esquerda do 3% ao 97% da área (s-lateral, scrub 0,3). As entradas dos painéis contam pela posição horizontal.
//   conceito  ao entrar (topo da área a 32% da tela), cresce de 0,8 e acende preso à rolagem; os textos entram por
//             tempo e saem se a rolagem voltar;
//   entre     as três linhas do título deslizam em sentidos opostos pela área toda;
//   mapa      o traço se desenha da esquerda para a direita (2,6 s) quando o painel entra.
import { gsap, ScrollTrigger, DUR, QUEBRA } from './ease.js';
import { anima } from './texto.js';

export function trilho() {
  const area = document.querySelector('[data-horizontal]');
  if (!area) return;
  const faixa = area.querySelector('[data-faixa]');
  const conceito = area.querySelector('[data-conceito]');
  const corpo = area.querySelector('[data-conceito-corpo]');
  const partes = (t) => conceito.querySelectorAll(`[data-parte="${t}"]`);
  const traco = area.querySelector('[data-mapa-traco]');
  pontosNoTraco(area);

  // o conceito entra igual nos dois tamanhos: textos por tempo, ao topo da área chegar a 32% da tela
  anima.p(partes('p'), 'inicial');
  anima.ctn(partes('ctn'), 'inicial');

  gsap.matchMedia().add(`(min-width: ${QUEBRA}px)`, () => {
    const ajusta = () => { area.style.height = `${faixa.scrollWidth}px`; };
    ajusta();
    const tween = gsap.to(faixa, {
      x: () => -(faixa.scrollWidth - innerWidth),
      ease: 's-lateral',
      scrollTrigger: { trigger: area, start: '3% top', end: '97% bottom', scrub: 0.3, invalidateOnRefresh: true, onRefreshInit: ajusta },
    });
    area._tween = tween;

    gsap.timeline({
      scrollTrigger: {
        trigger: conceito, start: 'top 32%', end: 'bottom bottom', scrub: 0.6,
        onEnter: () => { anima.p(partes('p'), 'mostra', 0.1); anima.ctn(partes('ctn'), 'mostra', 0.1); },
        onLeaveBack: () => { anima.p(partes('p'), 'esconde', 0); anima.ctn(partes('ctn'), 'esconde', 0); },
      },
    }).fromTo(corpo, { opacity: 0, scale: 0.8 }, { opacity: 1, scale: 1, ease: 'none' }, 0);

    gsap.fromTo(area.querySelectorAll('[data-linha]'),
      { xPercent: gsap.utils.wrap([-6, 22, -14]) },
      { xPercent: gsap.utils.wrap([6, -22, 22]), ease: 'none', scrollTrigger: { trigger: area, start: 'top top', end: 'bottom bottom', scrub: 0.3 } });
    gsap.fromTo(area.querySelector('.flor--entre'), { xPercent: 0 }, { xPercent: -22, ease: 'none', scrollTrigger: { trigger: area, start: 'top top', end: 'bottom bottom', scrub: 0.3 } });
    gsap.fromTo(area.querySelector('[data-flor-mapa]'), { yPercent: 0 }, { yPercent: 22, ease: 'none', scrollTrigger: { trigger: area, start: 'bottom bottom', end: 'bottom top', scrub: 0.3 } });

    gsap.fromTo(traco, { clipPath: 'inset(0% 100% 0% 0%)' }, {
      clipPath: 'inset(0% 0% 0% 0%)', duration: 2 * DUR.l, delay: DUR.m, ease: 's-out',
      scrollTrigger: { trigger: traco, containerAnimation: tween, start: 'left right', once: true },
    });
    return () => { area.style.height = ''; delete area._tween; };
  });

  gsap.matchMedia().add(`(max-width: ${QUEBRA - 1}px)`, () => {
    ScrollTrigger.create({
      trigger: conceito, start: 'top 70%', once: true,
      onEnter: () => { anima.p(partes('p'), 'mostra', 0.1); anima.ctn(partes('ctn'), 'mostra', 0.1); },
    });
    gsap.fromTo(traco, { clipPath: 'inset(0% 100% 0% 0%)' }, {
      clipPath: 'inset(0% 0% 0% 0%)', duration: 2 * DUR.l, delay: DUR.s, ease: 's-out',
      scrollTrigger: { trigger: traco, start: 'top 85%', once: true },
    });
    // o mapa é mais largo que a tela: começa centrado na casa
    const rolo = area.querySelector('.trilho__mapa-pe');
    requestAnimationFrame(() => { rolo.scrollLeft = (rolo.scrollWidth - rolo.clientWidth) / 2; });
  });
}

// cada ponto do mapa (posição horizontal em --x) desce até o traço: acha a altura do caminho naquele x
function pontosNoTraco(area) {
  const svg = area.querySelector('[data-mapa-traco]');
  const path = svg?.querySelector('path');
  if (!path) return;
  const vb = svg.viewBox.baseVal;
  const total = path.getTotalLength();
  const yEm = (x) => {
    let a = 0;
    let b = total;
    for (let i = 0; i < 30; i++) {
      const m = (a + b) / 2;
      if (path.getPointAtLength(m).x < x) a = m; else b = m;
    }
    return path.getPointAtLength((a + b) / 2).y;
  };
  area.querySelectorAll('.mapa__ponto').forEach((p) => {
    const x = (parseFloat(p.style.getPropertyValue('--x')) / 100) * vb.width;
    p.style.setProperty('--y', `${(yEm(x) / vb.height) * 100}%`);
  });
}
