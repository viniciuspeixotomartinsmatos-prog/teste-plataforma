# Guia do projeto — Sobrevoo

Filme de 1440×1152 (5:4) a 60 fps, 14,5 s, de uma landing page qualquer. A página é capturada em 1440 px de largura e deitada num piso de estúdio. Uma câmera de drone rasante a percorre do topo ao rodapé enquanto as peças descolam e inclinam para a câmera; depois a câmera sobe até ver a página de cima, mergulha no hero, que pousa como um cartão, e o título entra palavra por palavra.

## Como funciona

1. **Captura** (`tools/captura.mjs sites/<marca>.json` → `captura/<marca>/`): abre a página no Chromium headless em 1440 px (2× de resolução), rola até o fim para disparar as animações de entrada, congela tudo e grava:
   - a página sem as peças, em faixas (`pagina-N.png`);
   - cada peça sozinha com fundo transparente, com os cantos arredondados recortados e o mapa de sombra (`el/eN.png`, `el/eN-sombra.png`);
   - o logo em 8×, a cor de fundo da página e a altura do hero;
   - o `layout.json` com tudo isso. O `conferencia.jpg` é a página inteira pequena, para conferir.
   - Imagem fundida no fundo escuro (`mix-blend-mode: lighten/screen`) ganha o alfa pela luminância. Uma peça dentro de outra vira filha: sobe presa ao plano do pai.
2. **Motor** (`engine/sobrevoo.js`, Three.js): uma cena WebGL só, com o tempo buscável. `sv.frame(t, sub)` desenha o instante `t` com `sub` subquadros de motion blur e profundidade de campo. Nada depende do relógio: o mesmo `t` sai sempre igual. `node tools/servidor.mjs 5180` e abra `http://127.0.0.1:5180/engine/?site=<marca>` para ver com uma barra de tempo.
3. **Quadros, render, deixas, trilha:** `tools/quadros.mjs` (quadros soltos e uma folha), `tools/render.mjs` (o filme mudo, cru para o ffmpeg; `--fps 30 --sub 8` para um rascunho rápido), `tools/deixas.mjs` (os momentos de cada som, tirados do motor), `tools/mix.py` (a trilha).

## O config: `sites/<marca>.json`

| Chave | O quê |
|---|---|
| `url` | O endereço da página (público ou servidor local) |
| `marca` | O nome no selo do fim |
| `logo` | Seletor do símbolo da marca no menu. Logo inteiro (símbolo + nome): o ladrilho usa o quadrado da esquerda; símbolo mais alto que largo: completa os lados até o quadrado |
| `hero` | Seletor da primeira seção: vira o cartão que pousa no fim |
| `esconder` | Seletores que somem na captura (cookies, chat, pop-up, barra de aviso, seções autorizadas) |
| `css` | CSS extra injetado na captura: força o estado final das animações de entrada (texto, fotos reveladas por `clip-path`) |
| `inclinacao` | Graus que as peças viram para a câmera no voo (padrão 9; a demonstração usa 22) |
| `alturaCartao` | Altura máxima do cartão do fim, em px de página (padrão 880). Objeto no centro do hero que o corte pegaria: a altura do hero inteiro |
| `titulo.frase`, `titulo.cauda` | O título do fim: a frase em Geist 500 e a cauda em Instrument Serif itálico |
| `flutuantes` | Uma linha por grupo: `sel` (seletor CSS), `lift` (px que sobe), `inclina` (multiplica a inclinação; 0 = sobe reta), `raio` (força o raio dos cantos), `espalha` (abre a linha para os lados: 0,3 a 0,5) |

Toda mudança no config pede captura nova: `node tools/captura.mjs sites/<marca>.json`.

## Escolher as peças

É o que decide se o filme fica bom. O efeito é o contraste entre o papel, que fica, e os objetos, que sobem.

- **Sobem:** cards, prints e mockups do produto, fotos em moldura, avatares e depoimentos em card, widgets, campos de formulário, botões.
- **Ficam no papel:** texto, títulos, faixas e seções de largura inteira, fundos, o menu inteiro, o rodapé, qualquer coisa com mais de ~1300 px.
- **Quanto:** de 6 a 12 grupos, de 15 a 35 peças. Seção só de texto fica no papel.
- **Alturas:** grandes abaixo do hero, 150 a 220; fotos, 150 a 200; filhos dentro de um card que sobe, 60 a 90; campos e botões, 40 a 60.
- **Hero:** as peças dele sobem por tempo (0,25 a 2,1 s) e pouco: o print do produto, 40 a 60; chips, selos e botões, 15 a 30. Recorte de largura inteira sobre a imagem do hero: `"inclina": 0` e um `lift` um pouco maior que o da peça que ele cobre. Se o recorte é opaco de ponta a ponta (morros, uma foto), `"raio": 24` (o do cartão); se tem partes transparentes (um canvas com um objeto 3D, uma pessoa recortada), `"raio": 0`, para a sombra seguir o contorno e não escurecer o hero inteiro.
- **Leque:** uma linha de 4 ou mais peças pequenas com `"espalha"`. Primeiro a linha sobe junta; depois que termina de subir, abre para os lados.
- `node tools/elementos.mjs <url>` lista as candidatas com posição, tamanho e raio.

Problemas comuns:
- **Peça transparente ou vazia:** o seletor pegou um contêiner sem fundo. Use o elemento de dentro, o que tem o fundo ou a imagem.
- **Borda branca ou canto sujo:** o raio não foi lido (cantos feitos por um filho ou por `clip-path`). Force `"raio"`.
- **Fresta embaixo de um recorte do hero:** o recorte sobe mais que a peça que ele cobre. Deixe o `lift` dele só um pouco maior.
- **Peça atravessando outra:** duas peças vizinhas com alturas muito diferentes. Aproxime os `lift` ou tire uma delas.
- **Peças empilhadas** (uma logo acima da outra, menos de ~150 px entre elas): inclinadas, cada uma cobre a de cima. `lift` de ~100 e `"inclina": 0.4`.
- **Peça só com borda** (sem fundo, como linhas de FAQ): sobe como um borrão cinza translúcido. Deixe no papel.
- **Campo de formulário:** suba o contêiner do campo (rótulo + caixa), não o `input` sozinho, que vira uma pílula branca vazia; force o `raio` se precisar.
- **Seções em branco na captura:** animações de entrada que voltaram ao estado escondido. Force o estado final no `css`.
- **Animação parada no meio, vídeo preto, cena 3D vazia:** a captura congela a página. Force o estado final no `css`, tire o elemento dos `flutuantes` ou esconda. O que só existe em movimento não entra no filme.

## Mapa do tempo

| Segundos | O que acontece |
|---|---|
| 0,0 | O hero inteiro no quadro, a página deitada; o título do hero legível |
| 0,25–2,1 | As peças do hero descolam por tempo, enquanto a câmera arranca |
| 0–7,6 | O voo: a câmera desce a página do topo ao rodapé, devagar, rápida no meio, devagar no fim. Cada peça descola quando entra pela borda de baixo e termina de subir pouco depois do meio do quadro |
| 7,35–9,25 | A subida: a câmera recua e vira até ver a página inteira de cima, numa faixa |
| 9,45–9,7 | O resto da página afunda e some; o pé do hero some junto (o cartão fica com `alturaCartao`) |
| 9,47–9,97 | O mergulho no hero, que sobe e vira o cartão |
| **9,97** | **O cartão pousa: a entrada da música** |
| 10,0–10,7 | O selo da marca, a frase e a cauda, palavra por palavra |
| 10,7–14,5 | O fim parado; a música se resolve até o silêncio |

A câmera e os números (em `engine/sobrevoo.js`): 24° acima do plano, 1150 px de altura, lente de 40° no voo e 34° de cima; o voo usa uma curva com pico de velocidade em 56% do trecho; a subida e o mergulho mantêm um ponto fixo na tela enquanto o zoom muda. Não mude sem a pessoa pedir.

## Personalizar

Antes de mudar, três perguntas: de qual página é o filme, qual o título do fim e qual a música. Depois:

| O quê | Onde | Precisa de material novo? |
|---|---|---|
| A página | `sites/<marca>.json` (`url`) + captura | O endereço ou a pasta do projeto |
| As peças que sobem | `flutuantes` + captura | Não |
| O título do fim e o nome no selo | `titulo`, `marca` | Não |
| O logo do selo e dos ladrilhos | `logo` (seletor) | Não: vem da página |
| A altura do cartão do fim | `alturaCartao` | Não |
| Música | `audio/trilha.json` (`musica`) | Um MP3 |

**Regras ao trocar**
- A página é filmada como está, em 1440 px. Não reescreva o site da pessoa para o filme.
- Frase do título com até ~20 caracteres e cauda com até ~14: o título inteiro em no máximo 2 linhas, nada cortado.
- Página com mais de ~8.000 px passa rápido no voo. Esconder seções inteiras (`esconder`) encurta, mas só com a autorização da pessoa.
- Nada de número, depoimento ou cliente inventado: o filme mostra a página como ela é.
- No fim, liste o que ainda é da demonstração.

**O que não se edita por texto:** a página é a da pessoa. Para mudar o que aparece nela (textos, fotos, cores), mude o site e capture de novo.

## Som

`tools/deixas.mjs <marca>` lê o motor e grava `out/<marca>/cues.json`: uma deixa por linha de peças que descolam (o peso cresce com a área, e o pan acompanha a posição), a subida e o mergulho da câmera no pico da velocidade, o pouso (9,97 s), o selo e uma deixa por palavra do título. `tools/mix.py <marca>` executa o `audio/trilha.json`:

- **Efeitos** (`audio/sfx/`, gravações reais, tratadas e graves): batida de asa e tremor de pano nas peças, sopros na subida e no mergulho, alfaia e bumbo no pouso, batidas de madeira no selo e nas palavras. Cada regra liga um tipo de deixa a um grupo de sons, com `ganho_db`, `peso_db` (dB a mais por dobro do peso da peça) e `alinha` (o ataque ou o pico do som na deixa).
- **Música:** em `musica.trechos`, cada trecho toca a faixa de `fonte_de` a `fonte_ate`, a partir de `inicio_s` no filme. O terceiro trecho começa na entrada forte da faixa, em 9,97 s. `automacao_db` abaixa a música sob os sopros e as palavras.
- **Outra faixa:** ache a entrada forte dela (onde o baixo e o acorde entram juntos, depois de uma parte calma) e acerte `fonte_de` do trecho de 9,97 s nesse ponto. Os trechos de antes tocam a parte calma, que vem antes. Termine a faixa até 14,5 s com `cauda_s`.
- **Master:** -14 LUFS, pico abaixo de -1 dBTP.
- **Créditos:** `CREDITS.md`. Os créditos CC BY vão na descrição do vídeo.

## Conferir

- `node tools/quadros.mjs <marca> 0 1.5 3 4.5 6 7.3 9.3 11` e abrir a folha. Para o filme inteiro: `ffmpeg -i out/<marca>/sobrevoo-60.mp4 -vf "fps=2,scale=360:-1,tile=6x5" -frames:v 1 folha.jpg`.
- Compare com o `referencia.mp4` nos mesmos tempos: composição, ritmo, nada cortado, nenhuma peça com borda suja.
- Juntar o som: `ffmpeg -i out/<marca>/sobrevoo-60.mp4 -i out/<marca>/trilha.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -shortest -movflags +faststart out/<marca>/sobrevoo.mp4`.
- O render usa a GPU (Metal no Mac). Sem GPU, roda em software: funciona, mas devagar; use `--fps 30 --sub 8` nos rascunhos.
