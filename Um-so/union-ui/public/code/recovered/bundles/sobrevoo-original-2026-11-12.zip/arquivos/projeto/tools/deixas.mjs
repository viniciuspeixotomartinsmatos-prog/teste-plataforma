// Deixas do som tiradas do motor: node tools/deixas.mjs <site> → out/<site>/cues.json (lido por tools/mix.py)
// Peças descolando (meio da subida, por grupo e linha), velocidade máxima da subida e do mergulho, batida do cartão, palavras.
import { writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { launch } from './browser.mjs';
import { servidor } from './servidor.mjs';
const site = process.argv[2] || 'prado';
const root = join(import.meta.dirname, '..');
const L = JSON.parse(readFileSync(join(root, 'captura', site, 'layout.json')));
const cfg = JSON.parse(readFileSync(join(root, 'sites', site + '.json')));
const s = await servidor(); const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1440, height: 1152 } })).newPage();
await page.goto(`${s.url}/engine/?site=${site}&render`);
await page.waitForFunction(() => window.sv?.pronto, null, { timeout: 120000 });
const FPS = 60, DT = 1 / FPS;
const TT = await page.evaluate(() => sv.T), VOO = await page.evaluate(() => sv.voo);
const amostras = await page.evaluate(({ DT }) => { const r = []; for (let t = 0; t <= sv.DUR + 1e-6; t += DT) { const p = sv.pose(t); r.push([t, p.y, p.d, p.el]); } return r; }, { DT });
await b.close(); s.fechar();
const ALT = VOO.alt, EL = VOO.el * Math.PI / 180, pe = y => y + ALT / Math.tan(EL);   // y da página sob a câmera no voo
// a peça está no meio da subida quando o pé da câmera passa a0 + metade da janela (com espalha, a subida é a 1ª metade)
const tLift = (y, espalha) => { const alvo = y + VOO.a0 + (espalha ? 0.25 : 0.5) * (VOO.a1 - VOO.a0); const a = amostras.find(([t, py]) => t < TT.vooFim && pe(py) >= alvo); return a ? a[0] : null; };
const ev = [];
// peças (sem filhos), uma deixa por linha de peças: as que descolam juntas (< 0,12 s) viram uma deixa só
const pecas = L.elementos.filter(e => !e.pai && e.y + e.h / 2 >= L.hero.h).map(e => ({ e, t: tLift(e.y, e.espalha) })).filter(p => p.t != null && p.t > 0.3).sort((a, b) => a.t - b.t);
let grupo = null; const grupos = [];
for (const p of pecas) { if (grupo && p.t - grupo.t < 0.12) grupo.itens.push(p); else grupos.push(grupo = { t: p.t, itens: [p] }); }
grupos.forEach((g, i) => {
  const area = g.itens.reduce((s, p) => s + p.e.w * p.e.h, 0);
  const pan = g.itens.reduce((s, p) => s + ((p.e.x + p.e.w / 2) / 720 - 1) * p.e.w * p.e.h, 0) / area;
  ev.push({ f: +(g.t * FPS).toFixed(2), kind: 'lift', id: `voo:peca:${i}`, weight: +Math.min(2, 0.5 + Math.sqrt(area) / 600).toFixed(2), pan: +pan.toFixed(2), n: g.itens.length });
});
// velocidade da câmera (distância + altura) para achar os picos da subida e do mergulho
const vel = amostras.map(([t, y, d, el], i) => { if (!i) return [t, 0]; const [, y0, d0, el0] = amostras[i - 1];
  return [t, Math.abs(Math.log(d / d0)) / DT + Math.abs(el - el0) / 90 / DT + Math.abs(y - y0) / 3000 / DT]; });
const pico = (a, b) => vel.filter(([t]) => t >= a && t <= b).reduce((m, v) => v[1] > m[1] ? v : m, [0, -1])[0];
const tSobe = pico(TT.sobeIni, TT.sobeFim), tMerg = pico(9.47, 9.97);
ev.push({ f: +(tSobe * FPS).toFixed(2), kind: 'whoosh', id: 'sobe:camera', weight: 1, pan: 0, dur: Math.round(1.1 * FPS), apexFrac: 0.5 });
ev.push({ f: +(tMerg * FPS).toFixed(2), kind: 'whoosh', id: 'mergulho:camera', weight: 1.2, pan: 0, dur: Math.round(0.5 * FPS), apexFrac: 0.5 });
ev.push({ f: 9.97 * FPS, kind: 'hit', id: 'cartao:pousa', weight: 1.6, pan: 0 });
// título: selo e palavras, no meio da entrada (saída do desfoque)
ev.push({ f: +((10.0 + 0.06) * FPS).toFixed(2), kind: 'tick', id: 'titulo:selo', weight: 0.7, pan: 0 });
const frase = cfg.titulo.frase.split(/\s+/), cauda = cfg.titulo.cauda.split(/\s+/);
frase.forEach((w, i) => ev.push({ f: +((10.1 + i * 0.08 + 0.06) * FPS).toFixed(2), kind: 'key', id: `titulo:frase:${i}`, weight: 0.8, pan: +((i - (frase.length - 1) / 2) * 0.12).toFixed(2), variant: w }));
const c0 = 10.1 + frase.length * 0.08 + 0.04;
cauda.forEach((w, i) => ev.push({ f: +((c0 + i * 0.065 + 0.06) * FPS).toFixed(2), kind: 'key', id: `titulo:cauda:${i}`, weight: 0.6, pan: +((i - (cauda.length - 1) / 2) * 0.1).toFixed(2), variant: w }));
ev.sort((a, b) => a.f - b.f);
const out = { fps: FPS, bpm: 120, total: Math.round(14.5 * FPS),
  acts: { voo: { from: 0, dur: Math.round(TT.sobeIni * FPS) }, sobe: { from: Math.round(TT.sobeIni * FPS), dur: Math.round((9.97 - TT.sobeIni) * FPS) }, titulo: { from: Math.round(9.97 * FPS), dur: Math.round(4.53 * FPS) } },
  cue: { sobe: Math.round(tSobe * FPS), mergulho: Math.round(tMerg * FPS), reveal: Math.round(9.97 * FPS) }, events: ev };
mkdirSync(join(root, 'out', site), { recursive: true });
writeFileSync(join(root, 'out', site, 'cues.json'), JSON.stringify(out, null, 1));
for (const e of ev) console.log((e.f / FPS).toFixed(2), e.kind, e.id, e.weight, e.pan, e.n ?? e.variant ?? '');
