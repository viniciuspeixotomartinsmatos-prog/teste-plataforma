// lista os candidatos a elemento flutuante (para escolher os seletores do config): tag, classe, caixa
import { launch, goto } from './browser.mjs';
const [url] = process.argv.slice(2);
const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
await goto(page, url);
const H = await page.evaluate(() => document.documentElement.scrollHeight);
for (let y = 0; y < H; y += 300) { await page.evaluate(y => scrollTo(0, y), y); await page.waitForTimeout(100); }
await page.evaluate(() => scrollTo(0, 0)); await page.waitForTimeout(600);
const list = await page.evaluate(() => {
  const out = [];
  for (const el of document.querySelectorAll('body *')) {
    const r = el.getBoundingClientRect(), cs = getComputedStyle(el);
    if (r.width < 40 || r.height < 24 || r.width > 1300) continue;
    const media = /^(IMG|PICTURE|VIDEO|CANVAS|svg)$/i.test(el.tagName);
    const boxed = parseFloat(cs.borderTopLeftRadius) > 0 && (cs.boxShadow !== 'none' || cs.backgroundColor !== 'rgba(0, 0, 0, 0)' || parseFloat(cs.borderTopWidth) > 0 || cs.backgroundImage !== 'none');
    if (!media && !boxed && el.tagName !== 'BUTTON' && el.tagName !== 'A') continue;
    out.push(`${el.tagName.toLowerCase()}.${[...el.classList].join('.')} [${Math.round(r.x)},${Math.round(r.y + scrollY)} ${Math.round(r.width)}x${Math.round(r.height)}] r=${cs.borderTopLeftRadius}`);
  }
  return out;
});
console.log(list.join('\n'));
await b.close();
