// Quadros parados para aprovação: node tools/quadros.mjs <site> [t...] → quadros/<site>/t-<t>.png (e uma folha)
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import sharp from 'sharp';
import { launch } from './browser.mjs';
import { servidor } from './servidor.mjs';
const [site = 'prado', ...ts] = process.argv.slice(2);
const tempos = (ts.length ? ts : ['0', '1.6', '2.5', '5', '6.5', '9.3', '11']).map(Number);
const out = join(import.meta.dirname, '..', 'quadros', site);
mkdirSync(out, { recursive: true });
const s = await servidor();
const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1440, height: 1152 }, deviceScaleFactor: 1 })).newPage();
const erros = [];
page.on('console', m => m.type() === 'error' && erros.push(m.text()));
page.on('pageerror', e => erros.push(e.message));
await page.goto(`${s.url}/engine/?site=${site}&render`);
await page.waitForFunction(() => window.sv?.pronto, null, { timeout: 120000 }).catch(() => { console.log(erros.join('\n')); process.exit(1); });
const files = [];
for (const t of tempos) {
  const ms = await page.evaluate(t => { const a = performance.now(); sv.frame(t, 16); return performance.now() - a; }, t);
  const f = join(out, `t-${t.toFixed(2)}.png`);
  await page.locator('canvas').screenshot({ path: f });
  files.push(f);
  console.log(`t=${t}s ${ms.toFixed(0)} ms → ${f}`);
}
// folha com todos, pequenos
const cw = 480, ch = 384, cols = Math.min(4, files.length), rows = Math.ceil(files.length / cols);
const tiles = await Promise.all(files.map(f => sharp(f).resize(cw, ch).toBuffer()));
await sharp({ create: { width: cols * cw, height: rows * ch, channels: 3, background: '#222' } })
  .composite(tiles.map((input, i) => ({ input, left: (i % cols) * cw, top: Math.floor(i / cols) * ch }))).jpeg({ quality: 88 }).toFile(join(out, 'folha.jpg'));
if (erros.length) console.log('erros:\n' + erros.join('\n'));
await b.close(); s.fechar();
