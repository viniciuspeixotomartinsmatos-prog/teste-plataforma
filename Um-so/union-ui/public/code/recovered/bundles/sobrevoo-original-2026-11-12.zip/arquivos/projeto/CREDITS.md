# Credits

All credits live here and in the video description (CC BY credits are required there).

## Music

- 'Tears In Rain' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au (https://creativecommons.org/licenses/by/4.0/).
  Edited for the film: cut and rearranged at bar lines to fit the picture, levels adjusted, a fade at the end.

## Sound effects and ambience

Real recordings from Freesound.org and Mixkit, trimmed, layered, level-adjusted, equalised and pitch-shifted by resampling for the film. Nothing in the soundtrack is synthesized.


### CC BY 4.0

- "Wood Hand Knock" by Daniel Poggioli (Dpoggioli) (https://freesound.org/people/Dpoggioli/sounds/263539/), licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
- "Banging Hands on Bottom of Wardrobe Slowly.wav" by F.M.Audio (https://freesound.org/people/F.M.Audio/sounds/564183/), licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
- "foley cloth flapping flutter fast bassy" by jerry.berumen (https://freesound.org/people/jerry.berumen/sounds/769396/), licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)

### CC BY 3.0

- "deep-air-woosh.wav" by CosmicEmbers (https://freesound.org/people/CosmicEmbers/sounds/160757/), licensed under CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)

### CC0 1.0 (public domain dedication)

- "Huge wing flaps for bird, dragon, dinosaur." by 2create (https://freesound.org/people/2create/sounds/670509/), licensed under CC0 1.0 (public domain dedication) (https://creativecommons.org/publicdomain/zero/1.0/)
- "Bass Kick drum Soft Hit.wav" by captain k man (https://freesound.org/people/captain%20k%20man/sounds/124998/), licensed under CC0 1.0 (public domain dedication) (https://creativecommons.org/publicdomain/zero/1.0/)
- "Alfaia Hit" by Sassaby (https://freesound.org/people/Sassaby/sounds/509528/), licensed under CC0 1.0 (public domain dedication) (https://creativecommons.org/publicdomain/zero/1.0/)

### Mixkit Sound Effects Free License

- "Ghostly whoosh passing" by Mixkit (https://mixkit.co/free-sound-effects/whoosh/), licensed under Mixkit Sound Effects Free License (https://mixkit.co/license/#sfxFree)

## Tools

Edited, mixed and mastered with tools/mix.py (ffmpeg, NumPy, SciPy).
