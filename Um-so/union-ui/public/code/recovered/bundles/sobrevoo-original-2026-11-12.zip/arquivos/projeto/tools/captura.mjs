// Captura da página para o sobrevoo: a página inteira em 2x sem os elementos flutuantes (em faixas que cabem numa
// textura), cada flutuante recortado com fundo transparente, o logo e o layout.json com as posições.
// Uso: node tools/captura.mjs sites/<site>.json  →  captura/<site>/
import { readFileSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { basename, join } from 'node:path';
import sharp from 'sharp';
import { launch, goto } from './browser.mjs';

const cfgPath = process.argv[2];
const cfg = JSON.parse(readFileSync(cfgPath, 'utf8'));
const site = basename(cfgPath, '.json');
const out = join(import.meta.dirname, '..', 'captura', site);
rmSync(out, { recursive: true, force: true });
mkdirSync(join(out, 'el'), { recursive: true });

const W = 1440, DPR = 2, FAIXA = 2048; // faixa em px CSS: 4096 px de textura
const b = await launch();
const ctx = await b.newContext({ viewport: { width: W, height: 900 }, deviceScaleFactor: DPR });
const page = await ctx.newPage();
await goto(page, cfg.url);
await page.evaluate(() => document.fonts.ready);

// rola tudo devagar para disparar as entradas (reveal, lazy load) e volta ao topo
let H = await page.evaluate(() => document.documentElement.scrollHeight);
for (let y = 0; y < H; y += 250) { await page.evaluate(y => scrollTo(0, y), y); await page.waitForTimeout(140); }
await page.evaluate(h => scrollTo(0, h), H); await page.waitForTimeout(600);
await page.evaluate(() => scrollTo(0, 0)); await page.waitForTimeout(1200);

// trava o layout: congela animações e transições, pausa vídeos, some com a barra de rolagem e fixa a altura
await page.addStyleTag({ content: `
  *, *::before, *::after { animation-play-state: paused !important; transition: none !important; caret-color: transparent !important; }
  html { scrollbar-width: none !important; } ::-webkit-scrollbar { display: none !important; }
  ${(cfg.esconder ?? []).join(', ') || '.__nada'} { display: none !important; }
  ${cfg.css ?? ''}` });
await page.evaluate(() => document.querySelectorAll('video').forEach(v => v.pause()));
await page.waitForTimeout(300);
H = await page.evaluate(() => Math.ceil(document.documentElement.scrollHeight));
// a cor de fundo da página (o vão que fica embaixo de uma peça que sobe)
const fundo = await page.evaluate(() => {
  for (const el of [document.body, document.documentElement]) { const c = getComputedStyle(el).backgroundColor; if (!/rgba\(0, 0, 0, 0\)|transparent/.test(c)) return c; }
  return 'rgb(255, 255, 255)';
});
await page.evaluate(h => { document.documentElement.style.height = h + 'px'; document.documentElement.style.overflow = 'hidden'; }, H);

// marca os flutuantes: id, caixa na página (cortada na largura), cantos, pai (o flutuante que o contém)
const els = await page.evaluate(({ grupos, W }) => {
  const out = [];
  grupos.forEach((g, gi) => document.querySelectorAll(g.sel).forEach(el => {
    if (el.dataset.sv) return;
    const r = el.getBoundingClientRect();
    if (r.width < 8 || r.height < 8 || getComputedStyle(el).visibility === 'hidden') return;
    const x0 = Math.max(0, r.left), x1 = Math.min(W, r.right);
    const id = `e${out.length}`;
    el.dataset.sv = id;
    out.push({ id, grupo: gi, x: x0, y: r.top + scrollY, w: x1 - x0, h: r.height,
      raio: g.raio ?? (parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0), lift: g.lift, inclina: g.inclina ?? 1, espalha: g.espalha ?? 0, alfa: 'normal' });
    // imagem fundida no fundo escuro (lighten/screen): o alfa sai da luminância
    for (let a = el; a && a !== document.body; a = a.parentElement)
      if (/lighten|screen|plus-lighter/.test(getComputedStyle(a).mixBlendMode)) { out.at(-1).alfa = 'luma'; break; }
  }));
  for (const e of out) {
    const pai = document.querySelector(`[data-sv="${e.id}"]`).parentElement?.closest('[data-sv]');
    e.pai = pai ? pai.dataset.sv : null;
    e.raio = Math.min(e.raio, e.w / 2, e.h / 2);
  }
  return out;
}, { grupos: cfg.flutuantes, W });

const style = async css => page.evaluate(css => {
  let s = document.getElementById('sv-style');
  if (!s) { s = document.createElement('style'); s.id = 'sv-style'; document.head.append(s); }
  s.textContent = css;
}, css);

// a página sem os flutuantes
await style('[data-sv] { visibility: hidden !important; }');
// em faixas recortadas (clip): um print só da página inteira passa do limite do Chromium (16.384 px de textura) em
// páginas com mais de ~8.000 px e repete o topo no fim
const faixas = [];
for (let y = 0; y < H; y += FAIXA) {
  const h = Math.min(FAIXA, H - y), file = `pagina-${faixas.length}.png`;
  await page.screenshot({ path: join(out, file), fullPage: true, type: 'png', clip: { x: 0, y, width: W, height: h } });
  faixas.push({ y, h, file });
}
// a página inteira com tudo no lugar, pequena, para conferência
await style('');
const conf = [];
for (let y = 0; y < H; y += FAIXA) {
  const h = Math.min(FAIXA, H - y);
  conf.push({ input: await sharp(await page.screenshot({ fullPage: true, clip: { x: 0, y, width: W, height: h } })).resize(720, Math.round(h / 2), { fit: 'fill' }).toBuffer(), left: 0, top: Math.round(y / 2) });
}
await sharp({ create: { width: 720, height: Math.round(H / 2), channels: 3, background: '#fff' } }).composite(conf).jpeg({ quality: 80 }).toFile(join(out, 'conferencia.jpg'));

// cada flutuante sozinho, com fundo transparente; os filhos dele ficam escondidos (sobem por conta própria)
const transparente = 'html, body { background: transparent !important; } body * { visibility: hidden !important; }';
for (const e of els) {
  await style(`${transparente} [data-sv="${e.id}"], [data-sv="${e.id}"] * { visibility: visible !important; }
    [data-sv="${e.id}"] [data-sv], [data-sv="${e.id}"] [data-sv] * { visibility: hidden !important; }`);
  e.file = `el/${e.id}.png`;
  await page.screenshot({ path: join(out, e.file), fullPage: true, omitBackground: true, clip: { x: e.x, y: e.y, width: e.w, height: e.h } });
}

// pós: alfa pela luminância onde precisa e o mapa de sombra (R = sombra de contato, G = sombra larga), em 1x com
// SOMBRA px de margem, para a sombra suave seguir o contorno da peça
const SOMBRA = 48;
// desfoque gaussiano aproximado: três passadas de caixa em cada eixo
function desfoca(src, w, h, sigma) {
  const r = Math.max(1, Math.round(Math.sqrt(12 * sigma * sigma / 3 + 1) / 2));
  let a = Float32Array.from(src), b = new Float32Array(src.length);
  for (let it = 0; it < 3; it++) {
    for (let y = 0; y < h; y++) { let acc = 0; const o = y * w;
      for (let x = -r; x <= r; x++) acc += a[o + Math.min(w - 1, Math.max(0, x))];
      for (let x = 0; x < w; x++) { b[o + x] = acc / (2 * r + 1); acc += a[o + Math.min(w - 1, x + r + 1)] - a[o + Math.max(0, x - r)]; } }
    for (let x = 0; x < w; x++) { let acc = 0;
      for (let y = -r; y <= r; y++) acc += b[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (let y = 0; y < h; y++) { a[y * w + x] = acc / (2 * r + 1); acc += b[Math.min(h - 1, y + r + 1) * w + x] - b[Math.max(0, y - r) * w + x]; } }
  }
  return a;
}
for (const e of els) {
  const p = join(out, e.file);
  if (e.alfa === 'luma' || e.raio > 0) {
    const { data, info } = await sharp(p).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
    const { width: iw, height: ih } = info, n = iw * ih;
    if (e.alfa === 'luma') {
      // foto sobre fundo preto: o fundo é o preto ligado à borda; o resto fica opaco, inclusive as partes escuras de
      // dentro (sombra da caneta, reflexo da tela). O preenchimento não passa por frestas estreitas (a peça é engordada
      // em R px antes), e depois o fundo volta a crescer R px, só sobre pixels escuros.
      const lum = new Float32Array(n), fila = new Int32Array(n);
      for (let i = 0; i < n; i++) lum[i] = Math.max(data[i * 4], data[i * 4 + 1], data[i * 4 + 2]) / 255;
      const LIM = 0.08, R = 8;
      const dilata = (m, r) => { // quadrado r: separável
        const t = new Uint8Array(n), o = new Uint8Array(n);
        for (let y = 0; y < ih; y++) { let c = 0; const l = y * iw;
          for (let x = -r; x < iw + r; x++) { if (x + r < iw && x + r >= 0 && m[l + x + r]) c++; if (x - r - 1 >= 0 && x - r - 1 < iw && m[l + x - r - 1]) c--; if (x >= 0 && x < iw) t[l + x] = c > 0; } }
        for (let x = 0; x < iw; x++) { let c = 0;
          for (let y = -r; y < ih + r; y++) { if (y + r < ih && y + r >= 0 && t[(y + r) * iw + x]) c++; if (y - r - 1 >= 0 && y - r - 1 < ih && t[(y - r - 1) * iw + x]) c--; if (y >= 0 && y < ih) o[y * iw + x] = c > 0; } }
        return o; };
      const peca = new Uint8Array(n); for (let i = 0; i < n; i++) peca[i] = lum[i] >= LIM;
      const gorda = dilata(peca, R), semente = new Uint8Array(n);
      let ini = 0, fim = 0;
      const poe = i => { if (!semente[i] && !gorda[i]) { semente[i] = 1; fila[fim++] = i; } };
      for (let x = 0; x < iw; x++) { poe(x); poe((ih - 1) * iw + x); }
      for (let y = 0; y < ih; y++) { poe(y * iw); poe(y * iw + iw - 1); }
      while (ini < fim) { const i = fila[ini++], x = i % iw;
        if (x > 0) poe(i - 1); if (x < iw - 1) poe(i + 1); if (i >= iw) poe(i - iw); if (i < n - iw) poe(i + iw); }
      const fundo = dilata(semente, R + 1);
      for (let i = 0; i < n; i++) {
        let a = 1;   // sem dividir a cor pelo alfa: a franja não clareia
        if (fundo[i] && !peca[i]) { const k = Math.min(1, Math.max(0, (lum[i] - 0.02) / (LIM - 0.02))); a = k * k * (3 - 2 * k); }
        data[i * 4 + 3] = Math.round(a * data[i * 4 + 3]);
      }
    }
    if (e.raio > 0) {
      // cantos arredondados recortados no alfa (o print pega o retângulo; o canto vazio sujava a peça e a sombra)
      const sx = iw / e.w, sy = ih / e.h, bx = e.w / 2, by = e.h / 2, r = e.raio;
      for (let y = 0; y < ih; y++) for (let x = 0; x < iw; x++) {
        const qx = Math.abs((x + 0.5) / sx - bx) - bx + r, qy = Math.abs((y + 0.5) / sy - by) - by + r;
        const d = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
        const cob = Math.min(1, Math.max(0, 0.5 - d * sx));
        const i = (y * iw + x) * 4 + 3; data[i] = Math.round(data[i] * cob);
      }
    }
    await sharp(data, { raw: info }).png().toFile(p + '.tmp');
    (await import('node:fs')).renameSync(p + '.tmp', p);
  }
  const W1 = Math.max(1, Math.round(e.w)), H1 = Math.max(1, Math.round(e.h));
  const { data: px } = await sharp(p).resize(W1, H1, { fit: 'fill' }).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const sw = W1 + 2 * SOMBRA, sh = H1 + 2 * SOMBRA;
  const alfa = new Float32Array(sw * sh);
  for (let y = 0; y < H1; y++) for (let x = 0; x < W1; x++) alfa[(y + SOMBRA) * sw + x + SOMBRA] = px[(y * W1 + x) * 4 + 3] / 255;
  const r = desfoca(alfa, sw, sh, 3), g = desfoca(alfa, sw, sh, 14);
  const rgb = Buffer.alloc(sw * sh * 3);
  for (let i = 0; i < sw * sh; i++) { rgb[i * 3] = Math.round(r[i] * 255); rgb[i * 3 + 1] = Math.round(g[i] * 255); }
  const sz = { width: sw, height: sh };
  e.sombra = `el/${e.id}-sombra.png`;
  await sharp(rgb, { raw: { ...sz, channels: 3 } }).png().toFile(join(out, e.sombra));
}

// o logo da marca
let logo = null;
if (cfg.logo) {
  const r = await page.evaluate(sel => { const el = document.querySelector(sel); el.dataset.svLogo = 1; const r = el.getBoundingClientRect(); return { x: r.left, y: r.top + scrollY, w: r.width, h: r.height }; }, cfg.logo);
  await style(`${transparente} [data-sv-logo], [data-sv-logo] * { visibility: visible !important; }`);
  await ctx.close();
  // o logo sai em 8x para o ladrilho do fim, que fica grande na tela
  const c2 = await b.newContext({ viewport: { width: W, height: 900 }, deviceScaleFactor: 8 });
  const p2 = await c2.newPage();
  await goto(p2, cfg.url);
  await p2.addStyleTag({ content: `html, body { background: transparent !important; } body * { visibility: hidden !important; } ${cfg.logo}, ${cfg.logo} * { visibility: visible !important; }` });
  await p2.waitForTimeout(800);
  await p2.screenshot({ path: join(out, 'logo.png'), omitBackground: true, clip: { x: r.x, y: r.y, width: r.w, height: r.h } });
  logo = { file: 'logo.png', w: r.w, h: r.h, marca: 'logo-marca.png' };
  // o símbolo: o quadrado da esquerda do logo (o logo com nome é mais largo que alto)
  const L = await sharp(join(out, 'logo.png')).metadata();
  // símbolo mais alto que largo (só o símbolo no seletor): completa os lados até o quadrado, sem esticar
  if (L.width < L.height) { const d = L.height - L.width;
    await sharp(join(out, 'logo.png')).extend({ left: Math.floor(d / 2), right: Math.ceil(d / 2), background: { r: 0, g: 0, b: 0, alpha: 0 } }).toFile(join(out, 'logo-marca.png')); }
  else await sharp(join(out, 'logo.png')).extract({ left: 0, top: 0, width: Math.min(L.width, L.height), height: L.height }).toFile(join(out, 'logo-marca.png'));
}

const hero = cfg.hero ? { y: 0, h: Math.round(await (async () => {
  const c = await b.newContext({ viewport: { width: W, height: 900 } }); const p = await c.newPage(); await goto(p, cfg.url);
  const h = await p.evaluate(sel => document.querySelector(sel).getBoundingClientRect().bottom + scrollY, cfg.hero); await c.close(); return h;
})()) } : { y: 0, h: 900 };

writeFileSync(join(out, 'layout.json'), JSON.stringify({ url: cfg.url, marca: cfg.marca, largura: W, altura: H, dpr: DPR,
  fundo, sombraMargem: SOMBRA, faixas, hero, logo, elementos: els }, null, 2));
console.log(`${site}: ${W}×${H}, ${faixas.length} faixas, ${els.length} flutuantes, hero ${hero.h}px`);
await b.close();
