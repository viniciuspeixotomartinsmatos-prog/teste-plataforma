// Chromium headless com a GPU ligada (o WebGL do motor fica rápido). No Mac usa o Metal; nos outros, o padrão do sistema.
import { chromium } from 'playwright';
const GPU = process.platform === 'darwin' ? ['--use-angle=metal'] : [];
export const launch = () => chromium.launch({ channel: 'chromium', headless: true, args: [...GPU, '--enable-gpu', '--ignore-gpu-blocklist'] });

/** espera a rede parar; sites com WebGL ou vídeo nunca param, então desiste em 15 s e fica com o load */
export async function goto(page, url) {
  await page.goto(url, { waitUntil: 'networkidle', timeout: 15000 })
    .catch(() => page.goto(url, { waitUntil: 'load', timeout: 60000 }));
}
