// Render do sobrevoo: cada quadro sai do motor (tempo buscável) e vai cru para o ffmpeg, que codifica em H.264 na GPU
// (VideoToolbox no Mac; libx264 nos outros sistemas). Uso: node tools/render.mjs <site> [--fps 60] [--sub 16] [--ini s] [--fim s] [--out arquivo.mp4]
import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { launch } from './browser.mjs';
import { servidor } from './servidor.mjs';

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const site = args.find(a => !a.startsWith('--') && !args[args.indexOf(a) - 1]?.startsWith('--')) || 'prado';
const fps = +opt('fps', 60), sub = +opt('sub', 16), ini = +opt('ini', 0);
const out = opt('out', join(import.meta.dirname, '..', 'out', site, `sobrevoo-${fps}.mp4`));
mkdirSync(dirname(out), { recursive: true });

const s = await servidor();
const b = await launch();
const page = await (await b.newContext({ viewport: { width: 1440, height: 1152 } })).newPage();
page.on('pageerror', e => console.error(e.message));
await page.goto(`${s.url}/engine/?site=${site}&render`);
await page.waitForFunction(() => window.sv?.pronto, null, { timeout: 120000 });
const { W, H, DUR } = await page.evaluate(() => ({ W: sv.W, H: sv.H, DUR: sv.DUR }));
const fim = +opt('fim', DUR);
const n = Math.round((fim - ini) * fps);

const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${W}x${H}`, '-r', String(fps), '-i', '-',
  '-vf', 'vflip,format=yuv420p', ...(process.platform === 'darwin'
    ? ['-c:v', 'h264_videotoolbox', '-b:v', fps >= 60 ? '40M' : '16M'] : ['-c:v', 'libx264', '-preset', 'medium', '-crf', '14']), '-profile:v', 'high',
  '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
const escreve = buf => new Promise(r => ff.stdin.write(buf) ? r() : ff.stdin.once('drain', r));

const t0 = Date.now();
for (let i = 0; i < n; i++) {
  const t = ini + i / fps;
  const b64 = await page.evaluate(async ([t, sub]) => {
    sv.frame(t, sub);
    const blob = new Blob([sv.pixels()]);
    return await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result.slice(fr.result.indexOf(',') + 1)); fr.readAsDataURL(blob); });
  }, [t, sub]);
  await escreve(Buffer.from(b64, 'base64'));
  if (i % 60 === 0) process.stdout.write(`\r${i}/${n} quadros, ${((Date.now() - t0) / 1000).toFixed(0)} s`);
}
ff.stdin.end();
await new Promise(r => ff.on('close', r));
console.log(`\n${out} (${n} quadros, ${fps} fps, ${sub} subquadros) em ${((Date.now() - t0) / 1000).toFixed(0)} s`);
await b.close(); s.fechar();
