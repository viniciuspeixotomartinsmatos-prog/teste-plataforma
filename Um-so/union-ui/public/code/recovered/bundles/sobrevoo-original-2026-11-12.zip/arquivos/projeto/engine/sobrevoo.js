// Sobrevoo: a landing page deitada num piso de estúdio. A câmera rasante desce a página inteira, sobe até ver a página
// de cima numa faixa só, mergulha de volta no hero, que vira um cartão flutuante, e o título entra palavra por palavra.
// Uma cena WebGL2 só, com o tempo buscável: frame(t) desenha o instante t (16 subquadros de motion blur, profundidade de
// campo por subquadro) e nada depende do relógio. Câmera, tempos e composição medidos quadro a quadro.
import * as THREE from 'three';

const Q = new URLSearchParams(location.search);
const SITE = Q.get('site') || 'prado';
const BASE = `/captura/${SITE}/`;
export const W = 1440, H = 1152, FPS = 60, DUR = 14.5;

const L = await (await fetch(BASE + 'layout.json')).json();
const CFG = await (await fetch(`/sites/${SITE}.json`)).json();
await Promise.all([document.fonts.load('500 80px Geist'), document.fonts.load('italic 400 80px "Instrument Serif"')]);

// ---------------------------------------------------------------- tempo
export const T = {
  vooFim: 7.6,         // o voo freia até parar aqui
  sobeIni: 7.35, sobeFim: 9.25,   // a subida começa antes do voo parar: nada de ficar parado no rodapé
  mergulhoIni: 9.47, mergulhoFim: 9.97,
};

const clamp01 = x => Math.min(1, Math.max(0, x));
const smooth = x => { x = clamp01(x); return x * x * (3 - 2 * x); };
const inOutSine = x => 0.5 - 0.5 * Math.cos(Math.PI * clamp01(x));
const outCubic = x => 1 - Math.pow(1 - clamp01(x), 3);
const lerp = (a, b, k) => a + (b - a) * k;

// curva monótona por pontos (Fritsch–Carlson), com velocidade zero nas pontas
const curva = pts => {
  const n = pts.length, d = [], m = new Array(n).fill(0);
  for (let i = 0; i < n - 1; i++) d.push((pts[i + 1][1] - pts[i][1]) / (pts[i + 1][0] - pts[i][0]));
  for (let i = 1; i < n - 1; i++) m[i] = d[i - 1] * d[i] <= 0 ? 0 : 2 / (1 / d[i - 1] + 1 / d[i]);
  return t => {
    if (t <= pts[0][0]) return pts[0][1];
    if (t >= pts[n - 1][0]) return pts[n - 1][1];
    let i = 0; while (t > pts[i + 1][0]) i++;
    const h = pts[i + 1][0] - pts[i][0], s = (t - pts[i][0]) / h;
    const h00 = 2 * s ** 3 - 3 * s ** 2 + 1, h10 = s ** 3 - 2 * s ** 2 + s, h01 = -2 * s ** 3 + 3 * s ** 2, h11 = s ** 3 - s ** 2;
    return h00 * pts[i][1] + h10 * h * m[i] + h01 * pts[i + 1][1] + h11 * h * m[i + 1];
  };
};

// voo: começa devagar, acelera até o meio e freia no fim (seno), uma curva só do primeiro ao último quadro
// curva com o pico de velocidade fora do meio: velocidade sen(π·u^q), integrada (q põe o pico em u = pico)
const curvaPico = pico => {
  const q = Math.log(0.5) / Math.log(pico), n = 2000, s = new Float64Array(n + 1);
  for (let i = 1; i <= n; i++) s[i] = s[i - 1] + Math.sin(Math.PI * ((i - 0.5) / n) ** q);
  for (let i = 0; i <= n; i++) s[i] /= s[n];
  return u => { const x = clamp01(u) * n, i = Math.min(n - 1, Math.floor(x)); return lerp(s[i], s[i + 1], x - i); };
};
const VOO = (c => t => c(t / T.vooFim))(curvaPico(0.56));   // freia mais curto que acelera
const SOBE = curvaPico(0.4);                                // a subida arranca logo e assenta devagar

// ---------------------------------------------------------------- mundo
// 1 unidade = 1 px CSS da página. A página deita no plano z = 0: x centrado, Y = -(y da página).
const PW = L.largura, PH = L.altura, HERO = L.hero.h;
const wx = x => x - PW / 2, wy = y => -y;
const FOV = 34;                                   // vertical, medido pelo horizonte e pela escala do hero
const F = (H / 2) / Math.tan(THREE.MathUtils.degToRad(FOV / 2)); // distância focal em px

const renderer = new THREE.WebGLRenderer({ antialias: false, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(1);
renderer.setSize(W, H);
renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
renderer.autoClear = false;
document.body.prepend(renderer.domElement);
const ANISO = renderer.capabilities.getMaxAnisotropy();

const scene = new THREE.Scene();      // tudo que passa pela profundidade de campo
const sobre = new THREE.Scene();      // ladrilhos de perto: já desenhados desfocados, por cima do resultado
const camera = new THREE.PerspectiveCamera(FOV, W / H, 20, 200000);
camera.up.set(0, 1, 0);

const loader = new THREE.TextureLoader();
const prep = (t, cor = true) => {
  t.colorSpace = cor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = ANISO; t.minFilter = THREE.LinearMipmapLinearFilter; t.generateMipmaps = true;
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
};
const tex = async (url, cor = true) => prep(await loader.loadAsync(url), cor);
const canvasTex = cv => prep(new THREE.CanvasTexture(cv));
const lin = hex => new THREE.Color(hex);
const parseRgb = s => { const m = s.match(/[\d.]+/g).map(Number); return new THREE.Color().setRGB(m[0] / 255, m[1] / 255, m[2] / 255, THREE.SRGBColorSpace); };

const SDF = /* glsl */`
  float sdRound(vec2 p, vec2 b, float r) { vec2 q = abs(p) - b + r; return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r; }
  float erfApprox(float x) { return tanh(1.2027 * x + 0.0745 * x * x * x); }
`;

// camadas: a ordem de desenho é a pintura; o teste de profundidade fica ligado com "sempre passa" só para gravar a
// profundidade que a profundidade de campo lê (com o teste desligado o WebGL não grava)
const camada = (mesh, ordem, escreve = true, alvo = scene) => {
  mesh.renderOrder = ordem;
  Object.assign(mesh.material, { depthTest: true, depthFunc: THREE.AlwaysDepth, depthWrite: escreve, transparent: true });
  mesh.frustumCulled = false;
  alvo.add(mesh);
  return mesh;
};
const VS = `varying vec2 vUv; varying vec2 vP; varying vec3 vW; uniform vec2 uSize;
  void main() { vUv = uv; vP = (uv - 0.5) * uSize; vW = (modelMatrix * vec4(position, 1.0)).xyz; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;

// ---- piso: degradê da tela (#f9fbfb no centro, #f2f3f6 nos cantos), fundo infinito de estúdio
camada(new THREE.Mesh(new THREE.PlaneGeometry(1e6, 1e6), new THREE.ShaderMaterial({
  uniforms: { uRes: { value: new THREE.Vector2(W, H) }, uC: { value: lin('#f9fbfb') }, uE: { value: lin('#f2f3f6') } },
  vertexShader: `void main() { gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: `uniform vec2 uRes; uniform vec3 uC, uE;
    void main() { vec2 q = gl_FragCoord.xy / uRes - 0.5; q.x *= uRes.x / uRes.y;
      float r = length(q) / length(vec2(0.5 * uRes.x / uRes.y, 0.5));
      gl_FragColor = vec4(mix(uC, uE, smoothstep(0.1, 1.0, r)), 1.0); }`,
})), 0).position.z = -2;

// ---- sombra de retângulo arredondado (analítica): contato + sombra larga + ambiente, caindo para baixo da tela
// corte do cartão do hero no fim (mais baixo que o hero): o que fica fora do retângulo arredondado some com a página
const CORTE = /* glsl */`varying vec3 vW; uniform float uCorteK; uniform vec2 uCorte;
  float corte() { if (uCorteK <= 0.0) return 1.0;
    float d = sdRound(vW.xy - vec2(0.0, -uCorte.y * 0.5), uCorte * 0.5, 24.0);
    return mix(1.0, 1.0 - smoothstep(-fwidth(d), fwidth(d), d), uCorteK); }`;
const corteU = () => ({ uCorteK: { value: 0 }, uCorte: { value: new THREE.Vector2(1, 1) } });
const sombraRet = ({ w, h, raio, ordem, forca = 1 }) => {
  const M = 520;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w + 2 * M, h + 2 * M), new THREE.ShaderMaterial({
    uniforms: { uSize: { value: new THREE.Vector2(w + 2 * M, h + 2 * M) }, uBox: { value: new THREE.Vector2(w, h) }, uR: { value: raio },
      uAlt: { value: 0 }, uForca: { value: forca }, uOp: { value: 1 }, ...corteU() },
    vertexShader: VS,
    fragmentShader: `${SDF} ${CORTE} varying vec2 vP; uniform vec2 uBox; uniform float uR, uAlt, uForca, uOp;
      float camada(vec2 off, float sigma, float spread) {
        float d = sdRound(vP - off, uBox * 0.5 + spread, uR + spread);
        return 0.5 - 0.5 * erfApprox(d / (sigma * 1.4142)); }
      void main() {
        float a = uAlt;
        float contato = camada(vec2(0.0, -1.0 - a * 0.1), 2.0 + a * 0.08, -1.0) * 0.20 * (1.0 - smoothstep(0.0, 120.0, a));
        float larga = camada(vec2(0.0, -8.0 - a * 0.45), 12.0 + a * 0.32, -4.0) * mix(0.20, 0.13, smoothstep(0.0, 250.0, a));
        float amb = camada(vec2(0.0, -4.0 - a * 0.2), 40.0 + a * 0.5, 6.0) * 0.07;
        gl_FragColor = vec4(0.0, 0.0, 0.0, (contato + larga + amb) * uForca * uOp * corte()); }`,
  }));
  return camada(m, ordem, false);
};

// ---- sombra pelo mapa da peça (R contato, G larga): segue o contorno de imagens recortadas
const sombraMapa = ({ map, w, h, ordem }) => {
  const M = L.sombraMargem;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w + 2 * M, h + 2 * M), new THREE.ShaderMaterial({
    uniforms: { map: { value: map }, uSize: { value: new THREE.Vector2(w, h) }, uAlt: { value: 0 }, uOp: { value: 1 }, ...corteU() },
    vertexShader: VS,
    fragmentShader: `${SDF} ${CORTE} varying vec2 vUv; uniform sampler2D map; uniform float uAlt, uOp;
      void main() { vec2 s = texture2D(map, vUv).rg; float k = smoothstep(0.0, 60.0, uAlt);
        float a = (mix(s.r * 0.32, s.g * 0.24, k) + s.g * 0.06) * 60.0 / (60.0 + max(uAlt - 60.0, 0.0));
        gl_FragColor = vec4(0.0, 0.0, 0.0, a * uOp * corte()); }`,
  }));
  return camada(m, ordem, false);
};

// ---- plano com textura; uBlur desfoca pela mipmap (entrada das palavras, ladrilhos de perto)
const FS_PLANO = `${SDF} ${CORTE} varying vec2 vUv; varying vec2 vP; uniform sampler2D map; uniform vec4 uUv; uniform vec2 uSize;
  uniform float uR, uOp, uBlur, uTexPx;
  void main() { vec2 uv = mix(uUv.xy, uUv.zw, vUv); vec4 c;
    if (uBlur > 0.3) { // desfoque: nível de mipmap do tamanho do borrão + um anel de 8 amostras para tirar o quadriculado
      float lod = log2(max(1.0, uBlur * uTexPx * 0.6)); vec2 px = uBlur * 0.6 / uSize * (uUv.zw - uUv.xy);
      c = textureLod(map, uv, lod) * 0.2;
      for (int i = 0; i < 8; i++) { float a = float(i) * 0.7854 + 0.39; c += textureLod(map, uv + vec2(cos(a), sin(a)) * px, lod) * 0.1; }
    } else c = texture2D(map, uv);
    if (uR > 0.0) { float d = sdRound(vP, uSize * 0.5, uR); c.a *= 1.0 - smoothstep(-fwidth(d), fwidth(d), d); }
    c.a *= uOp * corte(); if (c.a < 0.02) discard; gl_FragColor = c; }`;
const plano = ({ map, w, h, ordem, uv = [0, 0, 1, 1], raio = 0, alvo = scene, texPx = 1 }) => {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.ShaderMaterial({
    uniforms: { map: { value: map }, uUv: { value: new THREE.Vector4(...uv) }, uSize: { value: new THREE.Vector2(w, h) },
      uR: { value: raio }, uOp: { value: 1 }, uBlur: { value: 0 }, uTexPx: { value: texPx },
      ...corteU() },
    vertexShader: VS, fragmentShader: FS_PLANO,
  }));
  return camada(m, ordem, true, alvo);
};

// ---------------------------------------------------------------- a página
const fundo = parseRgb(L.fundo);
const paginaSombra = sombraRet({ w: PW, h: PH, raio: 24, ordem: 1 });
paginaSombra.position.set(0, -PH / 2, -1);
const faixas = [];
for (const f of L.faixas) {
  const map = await tex(BASE + f.file);
  const m = new THREE.Mesh(new THREE.PlaneGeometry(PW, f.h), new THREE.ShaderMaterial({
    uniforms: { map: { value: map }, uRect: { value: new THREE.Vector4(0, f.y, PW, f.h) }, uPage: { value: new THREE.Vector2(PW, PH) },
      uHero: { value: HERO }, uFundo: { value: fundo }, uOp: { value: 1 } },
    vertexShader: `varying vec2 vUv; varying vec2 vPg; uniform vec4 uRect;
      void main() { vUv = uv; vPg = vec2(uRect.x + uv.x * uRect.z, uRect.y + (1.0 - uv.y) * uRect.w);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `${SDF} varying vec2 vUv; varying vec2 vPg; uniform sampler2D map; uniform vec2 uPage; uniform float uHero, uOp; uniform vec3 uFundo;
      void main() { vec4 c = texture2D(map, vUv);
        if (vPg.y < uHero) c.rgb = uFundo; // o vão do hero: o cartão do hero fica por cima e sai dali no mergulho
        float d = sdRound(vPg - uPage * 0.5, uPage * 0.5, 24.0);
        gl_FragColor = vec4(c.rgb, (1.0 - smoothstep(-fwidth(d), fwidth(d), d)) * uOp); }`,
  }));
  camada(m, 2).position.set(0, -(f.y + f.h / 2), 0);
  faixas.push(m);
}

// ---- peças flutuantes: sobem conforme entram no quadro pela parte de baixo (a câmera passando por elas)
const pecas = [], porId = {};
// ordem de desenho das peças a cada quadro: da mais longe da câmera para a mais perto (a de perto cobre a de longe);
// os filhos vêm logo depois do pai, cada um com a sombra dele por baixo. As sombras no chão ficam antes de todas.
const raizes = () => pecas.filter(p => !p.filho);
function ordenaPecas() {
  const v = new THREE.Vector3(), m = camera.matrixWorldInverse;   // profundidade no eixo da câmera, não distância ao centro
  const lista = raizes().map(p => ({ p, d: -v.copy(p.mesh.position).applyMatrix4(m).z })).sort((a, b) => b.d - a.d);
  lista.forEach(({ p }, i) => {
    const o = 100 + i * 20;
    p.mesh.renderOrder = o; p.sombra.renderOrder = 10;
    pecas.filter(c => c.filho && c.e.pai === p.e.id).forEach((c, j) => { c.sombra.renderOrder = o + 1 + 2 * j; c.mesh.renderOrder = o + 2 + 2 * j; });
  });
}
for (const e of L.elementos) {
  const noHero = e.y + e.h / 2 < HERO, filho = !!e.pai, base = noHero ? 30 : 10;
  const map = await tex(BASE + e.file), mapS = await tex(BASE + e.sombra, false);
  const p = { e, noHero, filho, cx: wx(e.x + e.w / 2), cy: wy(e.y + e.h / 2),
    // caixa arredondada (botão, card, foto): sombra analítica, que abre e esmaece com a altura sem bater na borda do
    // quadro; recorte (foto fundida, colinas): a sombra pelo contorno
    sombra: e.alfa === 'normal' && e.raio > 0
      ? sombraRet({ w: e.w, h: e.h, raio: e.raio, ordem: base + (filho ? 3 : 1) })
      : sombraMapa({ map: mapS, w: e.w, h: e.h, ordem: base + (filho ? 3 : 1) }),
    mesh: plano({ map, w: e.w, h: e.h, ordem: base + (filho ? 4 : 2), raio: e.raio }) };
  pecas.push(p); porId[e.id] = p;
}

// ---- cartão do hero: o recorte do hero na primeira faixa; as peças do hero sobem junto com ele
const faixa0 = L.faixas[0];
const heroMap = await tex(BASE + faixa0.file);
// no fim o cartão é mais baixo que o hero (no máximo 880 px de página, quase 16:10): o pé do hero some com a página
const HERO_FIM = Math.min(HERO, CFG.alturaCartao ?? 880);
const heroSombra = sombraRet({ w: PW, h: HERO, raio: 24, ordem: 3 });
const heroCartao = plano({ map: heroMap, w: PW, h: HERO, ordem: 4, raio: 24, uv: [0, 1 - HERO / faixa0.h, 1, 1] });

// ---------------------------------------------------------------- composição final (medida no último quadro)
// câmera de cima, parada; o cartão aparece com 1040 px de largura (escala 0,722) e o topo em y = 277
const ESC_FIM = 1040 / 1440;
const Z_CARTAO = 120;
const D_FIM = F / ESC_FIM;                                  // da câmera ao plano do cartão
const LOOK_FIM_Y = (576 - 277) / ESC_FIM;                   // y da página que fica no centro do quadro
const CAM_FIM_Z = Z_CARTAO + D_FIM;
// tela → mundo para um objeto na altura z, com a câmera final
// com o cartão mais baixo, o conjunto (selo, título, cartão) desce para ficar no meio do quadro: a câmera sobe
// DESCE_FIM px de tela no plano do cartão; o que está noutra altura recebe a correção da paralaxe na hora de posicionar
const DESCE_FIM = (1152 - 277 - Math.min(L.hero.h, CFG.alturaCartao ?? 880) * ESC_FIM - 40) / 2;
const paralaxe = z => DESCE_FIM * D_FIM / (CAM_FIM_Z - z);   // quanto um ponto na altura z desce na tela
const tela = (sx, sy, z) => { const k = (CAM_FIM_Z - z) / F; return { x: (sx - W / 2) * k, y: wy(LOOK_FIM_Y) - (sy - H / 2) * k, k }; };

// ladrilhos do logo: branco arredondado com o símbolo; dois na altura do cartão (cantos de cima), dois perto da câmera
const marcaImg = (await tex(BASE + (L.logo.marca || L.logo.file))).image;
const S_LAD = 256, P_LAD = 200;
const ladCanvas = (() => {
  const cv = document.createElement('canvas'); cv.width = cv.height = S_LAD + 2 * P_LAD;
  const g = cv.getContext('2d'), r = S_LAD * 0.225, o = P_LAD;
  g.beginPath(); g.roundRect(o, o, S_LAD, S_LAD, r); g.fillStyle = '#ffffff'; g.fill();
  g.strokeStyle = 'rgba(20,22,28,0.07)'; g.lineWidth = 2; g.stroke();
  const ic = S_LAD * 0.5, io = o + (S_LAD - ic) / 2;
  g.save(); g.beginPath(); g.roundRect(io, io, ic, ic, ic * 0.225); g.clip(); g.drawImage(marcaImg, io, io, ic, ic); g.restore();
  return cv;
})();
const ladMap = canvasTex(ladCanvas);
const LAD = [
  // canto de cima à direita: nítido, quase no plano do cartão
  { sx: 1236, sy: 283, px: 128, z: Z_CARTAO + 40, perto: false },
  // canto de cima à esquerda: um pouco mais alto, levemente desfocado
  { sx: 201, sy: 282, px: 134, z: Z_CARTAO + 420, perto: false },
  // dois perto da câmera, nos cantos de baixo, muito desfocados; sobem um pouco no fim
  { sx: 70, sy: 1080, px: 330, z: CAM_FIM_Z - 1000, perto: true, sobe: 150 },
  { sx: 1390, sy: 1030, px: 320, z: CAM_FIM_Z - 1050, perto: true, sobe: 130 },
].map(l => {
  const p = tela(l.sx, l.sy + (l.perto ? 0 : DESCE_FIM) - paralaxe(l.z), l.z), tam = l.px * p.k, total = tam * (S_LAD + 2 * P_LAD) / S_LAD;
  const mesh = plano({ map: ladMap, w: total, h: total, ordem: l.perto ? 90 : 2061, alvo: l.perto ? sobre : scene });
  const sombra = l.perto ? null : sombraRet({ w: tam, h: tam, raio: tam * 0.225, ordem: 2060 });
  return { ...l, x: p.x, y: p.y, tam, mesh, sombra };
});

// título: selo da marca, a frase em Geist Medium e a cauda em Instrument Serif itálico, palavra por palavra
const ESC = 3;
const titulo = [];
const kT = (CAM_FIM_Z - Z_CARTAO) / F;       // mundo por px de tela no plano do cartão
const desenhaTexto = (texto, fonte, cor, px, spacing = 0) => {
  const cv = document.createElement('canvas'), g = cv.getContext('2d');
  const set = () => { g.font = fonte.replace('{px}', px * ESC); if (spacing) g.letterSpacing = `${spacing * px * ESC}px`; };
  set(); const m = g.measureText(texto), pad = Math.ceil(px * 0.45 * ESC);
  cv.width = Math.ceil(m.width + pad * 2); cv.height = Math.ceil(px * 1.7 * ESC);
  set(); g.fillStyle = cor; g.textBaseline = 'alphabetic'; g.fillText(texto, pad, px * 1.18 * ESC);
  return { cv, w: cv.width / ESC, h: cv.height / ESC, adv: m.width / ESC, pad: pad / ESC, base: px * 1.18 };
};
{
  // tamanhos em px de tela, convertidos para o mundo no plano do cartão
  const nome = CFG.marca || L.marca;
  const fs = 20, alt = 42, icon = 22, padX = 14, gap = 8;
  const g0 = document.createElement('canvas').getContext('2d'); g0.font = `500 ${fs}px Geist`;
  const larg = Math.ceil(padX + icon + gap + g0.measureText(nome).width + padX);
  const cv = document.createElement('canvas'); const B = 24; cv.width = (larg + 2 * B) * ESC; cv.height = (alt + 2 * B) * ESC;
  const g = cv.getContext('2d'); g.scale(ESC, ESC); g.translate(B, B);
  g.beginPath(); g.roundRect(0.5, 0.5, larg - 1, alt - 1, alt / 2); g.fillStyle = '#ffffff'; g.fill();
  g.strokeStyle = 'rgba(16,18,22,0.08)'; g.lineWidth = 1; g.stroke();
  g.save(); g.beginPath(); g.roundRect(padX, (alt - icon) / 2, icon, icon, icon * 0.225); g.clip(); g.drawImage(marcaImg, padX, (alt - icon) / 2, icon, icon); g.restore();
  g.font = `500 ${fs}px Geist`; g.fillStyle = '#121418'; g.textBaseline = 'middle'; g.fillText(nome, padX + icon + gap, alt / 2 + 1);
  const w = (larg + 2 * B) * kT, h = (alt + 2 * B) * kT;
  titulo.push({ x: 0, y: wy(LOOK_FIM_Y) - (64 - H / 2) * kT, z: Z_CARTAO, ini: 10.0, dur: 0.3,
    sombra: sombraRet({ w: larg * kT, h: alt * kT, raio: alt / 2 * kT, ordem: 2070, forca: 0.5 }),
    mesh: plano({ map: canvasTex(cv), w, h, ordem: 2071, texPx: ESC / kT }) });

  const linha = (texto, fonte, cor, px, spacing, base, ini, passo) => {
    const partes = texto.split(' ').map(p => desenhaTexto(p, fonte, cor, px, spacing));
    const um = desenhaTexto('a', fonte, cor, px, spacing).adv, dois = desenhaTexto('a a', fonte, cor, px, spacing).adv;
    const espaco = dois - 2 * um;
    const total = partes.reduce((s, p) => s + p.adv, 0) + espaco * (partes.length - 1);
    let x = W / 2 - total / 2;
    partes.forEach((p, i) => {
      const cx = x - p.pad + p.w / 2, cy = base - p.base + p.h / 2; // centro da palavra em px de tela
      titulo.push({ x: (cx - W / 2) * kT, y: wy(LOOK_FIM_Y) - (cy - H / 2) * kT, z: Z_CARTAO, ini: ini + i * passo, dur: 0.32,
        mesh: plano({ map: canvasTex(p.cv), w: p.w * kT, h: p.h * kT, ordem: 2072, texPx: ESC / kT }) });
      x += p.adv + espaco;
    });
    return partes.length;
  };
  const n = linha(CFG.titulo.frase, '500 {px}px Geist', '#131417', 76, -0.022, 170, 10.1, 0.08);
  linha(CFG.titulo.cauda, 'italic 400 {px}px "Instrument Serif"', '#73767d', 88, -0.01, 250, 10.1 + n * 0.08 + 0.04, 0.065);
}

// ---------------------------------------------------------------- câmera
// pose = ponto olhado no plano (x, y da página, z), distância até ele e elevação (graus acima do plano; 90 = de cima).
// A câmera fica do lado do fim da página olhando para o topo: o topo no alto do quadro, o texto de pé.
// voo de drone rasante: 24° acima do plano (olhando mais para o horizonte), 1150 px de altura e lente de 40°
const EL_VOO = 24, ALT_VOO = 1150, FOV_VOO = 40;
const F_VOO = (H / 2) / Math.tan(THREE.MathUtils.degToRad(FOV_VOO / 2));
const D_VOO = ALT_VOO / Math.sin(THREE.MathUtils.degToRad(EL_VOO));
// y da página que fica no centro do quadro quando um ponto do chão aparece na linha sy da tela
const lookPara = (yPagina, sy) => {
  const a = THREE.MathUtils.degToRad(EL_VOO) + Math.atan((sy - H / 2) / F_VOO);
  return yPagina + (ALT_VOO / Math.tan(a) - ALT_VOO / Math.tan(THREE.MathUtils.degToRad(EL_VOO)));
};
const VOO_Y0 = lookPara(0, 470);          // começo: o topo da página na linha 470 (o piso aparece acima)
const VOO_Y1 = lookPara(PH, 590);         // fim: o pé da página para na linha 590
const D_CIMA = F / (1080 / PH);           // de cima: a página inteira em 1080 px de altura
const poseVoo = t => ({ x: 0, y: lerp(VOO_Y0, VOO_Y1, VOO(t)), z: 0, d: D_VOO, el: EL_VOO, fov: FOV_VOO });
const poseCima = { x: 0, y: PH / 2, z: 0, d: D_CIMA, el: 90, fov: FOV };
const poseFim = { x: 0, y: LOOK_FIM_Y - DESCE_FIM / ESC_FIM, z: Z_CARTAO, d: D_FIM, el: 90, fov: FOV };
export const pose = t => {
  if (t < T.sobeIni) return poseVoo(t);
  if (t < T.mergulhoIni) return zoom(poseVoo(t), poseCima, SOBE((t - T.sobeIni) / (T.sobeFim - T.sobeIni)));
  return zoom(poseCima, poseFim, inOutSine((t - T.mergulhoIni) / (T.mergulhoFim - T.mergulhoIni)));
};
// subida e mergulho = um zoom só cada, em torno do ponto da página que fica parado na tela entre os dois enquadramentos.
// A escala vertical da página na tela (F·sen(elevação)/distância) anda exponencial com uma curva só, e o ponto olhado
// anda junto, na mesma proporção: nada de recuar, virar e centralizar em tempos separados. A elevação, a lente e a
// altura do ponto olhado (o cartão subindo no mergulho) seguem a mesma curva.
const focal = fov => (H / 2) / Math.tan(THREE.MathUtils.degToRad(fov / 2));
const escalaY = p => focal(p.fov) * Math.sin(THREE.MathUtils.degToRad(p.el)) / p.d;
function zoom(a, b, e) {
  const sa = escalaY(a), sb = escalaY(b), P = (a.y * sa - b.y * sb) / (sa - sb);
  const s = Math.exp(lerp(Math.log(sa), Math.log(sb), e));
  const el = lerp(a.el, b.el, e), fov = lerp(a.fov, b.fov, e);
  return { x: 0, y: P - (P - a.y) * sa / s, z: lerp(a.z, b.z, e), d: focal(fov) * Math.sin(THREE.MathUtils.degToRad(el)) / s, el, fov };
}
const alvo = new THREE.Vector3();
const posCamera = (t, jx = 0, jy = 0) => {
  const p = pose(t), a = THREE.MathUtils.degToRad(p.el);
  alvo.set(p.x, wy(p.y), p.z);
  camera.position.set(p.x, wy(p.y) - p.d * Math.cos(a), p.z + p.d * Math.sin(a));
  camera.lookAt(alvo);
  if (camera.fov !== p.fov) { camera.fov = p.fov; camera.updateProjectionMatrix(); }
  camera.setViewOffset(W, H, jx, jy, W, H);
  camera.updateMatrixWorld();
  return p;
};
// profundidade (no eixo da câmera) do ponto do chão que aparece na linha sy da tela
const ray = new THREE.Raycaster(), chao = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0), tmp = new THREE.Vector3();
const profLinha = sy => {
  ray.setFromCamera(new THREE.Vector2(0, -(sy / H) * 2 + 1), camera);
  if (!ray.ray.intersectPlane(chao, tmp)) return 1e5;
  return -tmp.applyMatrix4(camera.matrixWorldInverse).z;
};

// ---------------------------------------------------------------- estado da cena no instante t
const heroLift = t => Z_CARTAO * inOutSine((t - T.mergulhoIni) / (T.mergulhoFim - T.mergulhoIni));
const paginaSome = t => smooth((t - 9.45) / 0.25);       // o resto da página afunda e some no mergulho
const INCLINA = CFG.inclinacao ?? 9;                     // graus que a peça gira para a câmera, no rasante
// centro de cada grupo de peças (para as que se afastam umas das outras ao subir: "espalha" no config)
const centroGrupo = {};
for (const e of L.elementos) (centroGrupo[e.grupo] ??= []).push(e.x + e.w / 2);
for (const g in centroGrupo) centroGrupo[g] = wx(centroGrupo[g].reduce((a, b) => a + b, 0) / centroGrupo[g].length);
// quanto a peça já descolou (0..1): a câmera recua sobre a página, então a peça descola quando sai de baixo dela.
// O hero já está no quadro no começo: as peças dele começam coladas (o título aparece) e descolam por tempo, enquanto
// a câmera arranca. Fora do hero a peça já começa um pouco levantada (0,3).
let tAgora = 0;
// a janela de descolar segue o quadro, não a altura: começa logo abaixo da borda de baixo e termina pouco depois do
// centro. Peças com espalha primeiro sobem (primeira metade) e só depois abrem para os lados (segunda metade).
const ATAN = d => ALT_VOO / Math.tan(THREE.MathUtils.degToRad(d));
const DESC_A0 = 0.86 * ATAN(EL_VOO + FOV_VOO / 2), DESC_A1 = 1.11 * ATAN(EL_VOO);
const avanco = (p, pePagina) => (pePagina - DESC_A0 - p.e.y) / (DESC_A1 - DESC_A0);
const descola = (p, pePagina) => p.noHero ? smooth((tAgora - 0.25) / 1.9)
  : p.e.espalha ? smooth(avanco(p, pePagina) / 0.5) : smooth(avanco(p, pePagina));
const abre = (p, pePagina) => p.e.espalha ? smooth((avanco(p, pePagina) - 0.5) / 0.5) : 0;
const fator = (p, pePagina) => p.noHero ? descola(p, pePagina) : lerp(0.3, 1, descola(p, pePagina));
export const setTime = t => {
  tAgora = t;
  const pv = poseVoo(Math.min(t, T.vooFim));
  const pe = pv.y + D_VOO * Math.cos(THREE.MathUtils.degToRad(EL_VOO));   // y da página sob a câmera
  const hl = heroLift(t), some = paginaSome(t), zPag = -320 * some * some;

  // a página abaixo do hero afunda e esmaece; a sombra dela vai junto
  for (const m of faixas) { m.material.uniforms.uOp.value = 1 - some; m.position.z = zPag; }
  paginaSombra.material.uniforms.uOp.value = 1 - some;
  paginaSombra.position.z = zPag - 1;

  heroCartao.position.set(0, -HERO / 2, hl);
  const hC = lerp(HERO, HERO_FIM, some);
  heroCartao.material.uniforms.uCorteK.value = some;
  heroCartao.material.uniforms.uCorte.value.set(PW, HERO_FIM);
  for (const p of pecas) if (p.noHero) for (const m of [p.mesh, p.sombra]) {
    m.material.uniforms.uCorteK.value = some; m.material.uniforms.uCorte.value.set(PW, HERO_FIM); }
  heroSombra.material.uniforms.uBox.value.set(PW, hC);
  heroSombra.position.set(0, -hC / 2 - hl * 0.05, Math.min(0, zPag) + 0.5);
  heroSombra.material.uniforms.uAlt.value = hl - zPag;
  heroSombra.material.uniforms.uForca.value = smooth(hl / 8);

  // cada peça sobe e inclina para a câmera, girando pela borda de baixo (a de cima levanta); a inclinação some
  // conforme a câmera fica de cima (lá a peça já está de frente). Os filhos vão presos no plano do pai.
  const elCam = pose(t).el, viraMax = THREE.MathUtils.degToRad(INCLINA) * clamp01((90 - elCam) / (90 - EL_VOO));
  const pos = new Map();
  for (const p of pecas) {
    const f = fator(p, pe);
    const base = p.noHero ? hl : zPag;
    const alt = p.e.lift * f;
    const op = p.noHero ? 1 : 1 - some;
    const k = descola(p, pe);
    let x, y, z, th;
    if (p.filho) {
      const pai = pos.get(p.e.pai), ca = Math.cos(pai.th), sa = Math.sin(pai.th);
      const dy = p.cy - porId[p.e.pai].cy;
      x = p.cx + pai.dx;
      th = pai.th; y = pai.y + dy * ca - alt * sa; z = pai.z + dy * sa + alt * ca;
    } else {
      x = p.cx + (p.cx - centroGrupo[p.e.grupo]) * (p.e.espalha ?? 0) * abre(p, pe);
      th = viraMax * (p.e.inclina ?? 1) * k;
      const h2 = p.e.h / 2;
      y = p.cy - h2 + h2 * Math.cos(th); z = base + alt + h2 * Math.sin(th);
    }
    pos.set(p.e.id, { y, z, th, dx: x - p.cx });
    p.mesh.position.set(x, y, z);
    p.mesh.rotation.x = th;
    p.mesh.material.uniforms.uOp.value = op;
    if (p.filho) {   // a sombra do filho cai no pai, no plano inclinado dele
      const pai = pos.get(p.e.pai), ca = Math.cos(th), sa = Math.sin(th), dy = p.cy - porId[p.e.pai].cy - alt * 0.4;
      p.sombra.position.set(x, pai.y + dy * ca - 0.3 * sa, pai.z + dy * sa + 0.3 * ca);
      p.sombra.rotation.x = th;
      p.sombra.material.uniforms.uAlt.value = alt;
    } else {
      const altMedia = z - base;
      p.sombra.position.set(x, p.cy - altMedia * 0.4, base + 0.3);
      p.sombra.material.uniforms.uAlt.value = altMedia;
    }
    p.sombra.material.uniforms.uOp.value = op;
  }
  ordenaPecas();

  for (const l of LAD) {
    const sobe = l.sobe ? (1 - outCubic((t - 9.9) / 0.9)) * l.sobe * (CAM_FIM_Z - l.z) / F : 0;
    l.mesh.position.set(l.x, l.y - sobe, l.z);
    if (l.perto) l.mesh.material.uniforms.uOp.value = smooth((t - 9.5) / 0.35);   // perto da câmera final: só no mergulho (no voo, de lado, viram uma barra)
    if (l.sombra) {
      const sobreCartao = Math.abs(l.x) < PW / 2 - 10 && l.y < 0 && l.y > -HERO;
      const zr = sobreCartao ? hl : Math.min(0, zPag);
      l.sombra.position.set(l.x, l.y - (l.z - zr) * 0.12, zr + 0.6);
      l.sombra.material.uniforms.uAlt.value = l.z - zr;
    }
  }

  for (const it of titulo) {
    const k = clamp01((t - it.ini) / it.dur), e = outCubic(k);
    it.mesh.material.uniforms.uOp.value = smooth(k * 1.4);
    it.mesh.material.uniforms.uBlur.value = (1 - e) * 16;
    it.mesh.position.set(it.x, it.y, it.z);
    if (it.sombra) { it.sombra.position.set(it.x, it.y, it.z - 2); it.sombra.material.uniforms.uAlt.value = 6; it.sombra.material.uniforms.uOp.value = e; }
  }
};

// ---------------------------------------------------------------- pós: profundidade de campo e acúmulo do motion blur
const rt = (depth = false) => new THREE.WebGLRenderTarget(W, H, {
  type: THREE.HalfFloatType, format: THREE.RGBAFormat, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
  depthBuffer: true, ...(depth && { depthTexture: new THREE.DepthTexture(W, H, THREE.FloatType) }),
});
const rtCena = rt(true), rtDof = rt(), rtAcc = rt();
const quad = mat => { const s = new THREE.Scene(); s.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), mat)); return s; };
const camQ = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
const vsQ = `varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

const dofMat = new THREE.ShaderMaterial({
  uniforms: { tCor: { value: rtCena.texture }, tProf: { value: rtCena.depthTexture }, uRes: { value: new THREE.Vector2(W, H) },
    uNear: { value: camera.near }, uFar: { value: camera.far }, uFoco: { value: 1000 }, uK: { value: 25 }, uMax: { value: 28 },
    uPasso: { value: 2 }, uAng: { value: 0 } },
  vertexShader: vsQ,
  fragmentShader: /* glsl */`
    #include <packing>
    varying vec2 vUv; uniform sampler2D tCor, tProf; uniform vec2 uRes; uniform float uNear, uFar, uFoco, uK, uMax, uPasso, uAng;
    float prof(vec2 uv) { return -perspectiveDepthToViewZ(texture2D(tProf, uv).x, uNear, uFar); }
    float coc(float z) { return clamp(uK * abs(z - uFoco) / z, 0.0, uMax); }
    void main() {
      float zc = prof(vUv), cc = coc(zc);
      vec3 cor = texture2D(tCor, vUv).rgb; float tot = 1.0;
      float r = uPasso * 0.5; float ang = uAng;
      for (int i = 0; i < 220; i++) {
        if (r >= uMax) break;
        vec2 tc = vUv + vec2(cos(ang), sin(ang)) * r / uRes;
        vec3 sc = texture2D(tCor, tc).rgb; float zs = prof(tc); float cs = coc(zs);
        if (zs > zc) cs = clamp(cs, 0.0, cc * 2.0);
        float m = smoothstep(r - uPasso * 0.5, r + uPasso * 0.5, cs);
        cor += mix(cor / tot, sc, m); tot += 1.0;
        r += uPasso / r; ang += 2.39996323;
      }
      gl_FragColor = vec4(cor / tot, 1.0);
    }`,
  depthTest: false, depthWrite: false,
});
const accMat = new THREE.ShaderMaterial({
  uniforms: { t: { value: rtDof.texture }, uPeso: { value: 1 / 16 } }, vertexShader: vsQ,
  fragmentShader: `varying vec2 vUv; uniform sampler2D t; uniform float uPeso; void main() { gl_FragColor = vec4(texture2D(t, vUv).rgb * uPeso, 1.0); }`,
  blending: THREE.CustomBlending, blendEquation: THREE.AddEquation, blendSrc: THREE.OneFactor, blendDst: THREE.OneFactor,
  depthTest: false, depthWrite: false,
});
const fimMat = new THREE.ShaderMaterial({
  uniforms: { t: { value: rtAcc.texture }, uSeed: { value: 0 } }, vertexShader: vsQ,
  fragmentShader: `varying vec2 vUv; uniform sampler2D t; uniform float uSeed;
    vec3 srgb(vec3 c) { return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }
    float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233)) + uSeed) * 43758.5453); }
    void main() { vec3 c = srgb(max(texture2D(t, vUv).rgb, 0.0)); c += (hash(gl_FragCoord.xy) - 0.5) / 255.0; gl_FragColor = vec4(c, 1.0); }`,
  depthTest: false, depthWrite: false,
});
const qDof = quad(dofMat), qAcc = quad(accMat), qFim = quad(fimMat);

// foco e abertura por fase. No voo, nítido no terço de cima e ~25 px de borrão embaixo; de cima, a
// página nítida; no fim, o cartão e o título nítidos e o ladrilho de cima à esquerda levemente desfocado
const focoLinha = t => lerp(700, 560, smooth(t / 1.6));   // com a câmera alta, o foco fica no meio do quadro
const K_VOO = 10;   // abertura no voo: só a borda de baixo e o horizonte borram
let op = {};
const dof = t => {
  let foco, k;
  if (t < T.sobeIni + 0.35) { foco = profLinha(focoLinha(Math.min(t, T.vooFim))); k = K_VOO; }
  else {
    foco = -alvo.clone().applyMatrix4(camera.matrixWorldInverse).z; // o plano olhado (centro do quadro)
    k = t < T.mergulhoIni ? lerp(K_VOO, 12, smooth((t - T.sobeIni - 0.35) / 0.6)) : lerp(12, 36, smooth((t - T.mergulhoIni) / 0.5));
  }
  return { foco, k: op.dof === false ? 0 : k, max: 28 };
};

// borrão dos ladrilhos de perto (desenhados por cima): o mesmo círculo de confusão, sem o teto de raio
const blurLadrilhos = (fo, k) => {
  for (const l of LAD) {
    if (!l.perto) continue;
    const z = -l.mesh.position.clone().applyMatrix4(camera.matrixWorldInverse).z;
    const pxTam = l.tam * F / Math.max(z, 1);
    // borrão grande, mas nunca maior que ~0,4 do ladrilho: o miolo colorido continua aparecendo como um brilho
    const coc = z > 0 ? Math.min(0.3 * pxTam, 110, 160 * Math.abs(z - fo) / z) : 0;
    l.mesh.material.uniforms.uBlur.value = op.dof === false ? 0 : coc;
    l.mesh.material.uniforms.uTexPx.value = S_LAD / pxTam;
    l.mesh.visible = z > 30;
  }
};

const halton = (i, b) => { let f = 1, r = 0; while (i > 0) { f /= b; r += f * (i % b); i = Math.floor(i / b); } return r; };
export function frame(t, sub = 16, opcoes = {}) {
  op = opcoes;
  const obt = 0.5 / FPS; // obturador de 180°
  renderer.setRenderTarget(rtAcc); renderer.setClearColor(0x000000, 1); renderer.clear();
  accMat.uniforms.uPeso.value = 1 / sub;
  for (let k = 0; k < sub; k++) {
    const ts = Math.min(DUR, Math.max(0, t + ((k + 0.5) / sub - 0.5) * obt));
    posCamera(ts, halton(k + 1, 2) - 0.5, halton(k + 1, 3) - 0.5);
    setTime(ts);
    const d = dof(ts);
    blurLadrilhos(d.foco, d.k);
    renderer.setRenderTarget(rtCena); renderer.setClearColor(0xf2f3f6, 1); renderer.clear();
    renderer.render(scene, camera);
    dofMat.uniforms.uFoco.value = d.foco; dofMat.uniforms.uK.value = d.k; dofMat.uniforms.uMax.value = d.max;
    dofMat.uniforms.uPasso.value = Math.max(1.6, d.max * d.max / 380);
    dofMat.uniforms.uAng.value = k * 0.7;
    renderer.setRenderTarget(rtDof); renderer.render(qDof, camQ);
    renderer.render(sobre, camera);                 // ladrilhos de perto, já desfocados, por cima
    renderer.setRenderTarget(rtAcc); renderer.render(qAcc, camQ);
  }
  fimMat.uniforms.uSeed.value = (t * 997) % 13;
  renderer.setRenderTarget(null); renderer.setClearColor(0x000000, 1); renderer.clear();
  renderer.render(qFim, camQ);
}

export function pixels() {
  const gl = renderer.getContext(), buf = new Uint8Array(W * H * 4);
  gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, buf);
  return buf;
}

// ---------------------------------------------------------------- prévia ao vivo
window.sv = { frame, pixels, pose, T, W, H, FPS, DUR, voo: { alt: ALT_VOO, el: EL_VOO, a0: DESC_A0, a1: DESC_A1 }, pronto: true };
if (Q.has('render')) document.body.classList.add('render');
else {
  const inp = document.getElementById('t'), tv = document.getElementById('tv'), btn = document.getElementById('play');
  let tocando = false, t0 = 0, tIni = 0;
  const mostra = t => { inp.value = t; tv.textContent = t.toFixed(2) + ' s'; frame(t, tocando ? 2 : 16); };
  inp.oninput = () => { tocando = false; mostra(+inp.value); };
  btn.onclick = () => { tocando = !tocando; t0 = performance.now(); tIni = +inp.value >= DUR ? 0 : +inp.value; if (tocando) requestAnimationFrame(loop); };
  const loop = now => { if (!tocando) return; const t = tIni + (now - t0) / 1000; if (t >= DUR) { tocando = false; mostra(DUR); return; } mostra(t); requestAnimationFrame(loop); };
  mostra(+(Q.get('t') || 0));
}
