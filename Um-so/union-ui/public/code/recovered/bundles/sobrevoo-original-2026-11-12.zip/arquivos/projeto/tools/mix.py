"""Mixa a trilha do Sobrevoo a partir de audio/trilha.json e das deixas do filme (out/<site>/cues.json):
a música em trechos, abaixada sob os sopros e as palavras, os efeitos graves de audio/sfx/ em cada deixa e o master
em -14 LUFS / -1 dBTP.

Precisa de: python 3 com numpy, scipy e soundfile (pip install numpy scipy soundfile) e o ffmpeg no PATH.
A música não vem no pacote: baixe "Tears In Rain" (Scott Buckley, CC BY 4.0) e salve em audio/tears-in-rain.mp3
(o endereço está em trilha.json, "musica.url"), ou aponte outra faixa e acerte os trechos (ver o guia).

Uso: python tools/mix.py [site] [--saida out/<site>/trilha.wav]
Antes: node tools/deixas.mjs <site>  (as deixas mudam com a página: cada peça que descola é uma deixa)
"""
import argparse, json, math, subprocess
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt

ROOT = Path(__file__).resolve().parent.parent
SR = 48000

ap = argparse.ArgumentParser()
ap.add_argument('site', nargs='?', default='prado')
ap.add_argument('--saida')
args = ap.parse_args()
saida = ROOT / (args.saida or f'out/{args.site}/trilha.wav')

plano = json.load(open(ROOT / 'audio' / 'trilha.json'))
deixas = json.load(open(ROOT / 'out' / args.site / 'cues.json'))
DUR = plano['duracao_s']
N = int(round(DUR * SR))
t = np.arange(N) / SR


def decode(path, ss, dur):
    b = subprocess.run(['ffmpeg', '-v', 'error', '-ss', f'{max(0, ss)}', '-t', f'{dur}', '-i', str(path), '-ac', '2',
                        '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(b, np.float32).reshape(-1, 2).copy()


def db(x):
    return 10 ** (x / 20)


# ---------- música: trechos da faixa postos no filme, com rampas curtas nas emendas ----------
mus = plano['musica']
src = ROOT / mus['arquivo']
if not src.exists():
    raise SystemExit(f'falta a música em {src}: baixe a faixa ({mus["url"]}) e salve com esse nome')
music = np.zeros((N, 2), np.float32)
for tr in mus['trechos']:
    i0 = int(round(tr['inicio_s'] * SR))
    if i0 >= N:
        continue
    x = decode(src, tr['fonte_de'], tr['fonte_ate'] - tr['fonte_de'])
    x = x[:N - i0]
    n = len(x)
    w = np.ones(n, np.float32)
    for campo, lado in (('entrada_s', 1), ('saida_s', -1)):
        k = min(n, int(tr.get(campo, 0) * SR))
        if k:
            r = np.linspace(0, 1, k, dtype=np.float32)
            if lado > 0: w[:k] *= r
            else: w[-k:] *= r[::-1]
    k = min(n, int(tr.get('cauda_s', 0) * SR))
    if k:  # cauda: a faixa some devagar até o fim do trecho
        w[-k:] *= (0.5 + 0.5 * np.cos(np.linspace(0, math.pi, k))).astype(np.float32)
    music[i0:i0 + n] += x * (w * db(tr.get('ganho_db', 0)))[:, None]
if mus.get('passa_altas_hz'):
    music = sosfilt(butter(2, mus['passa_altas_hz'], 'highpass', fs=SR, output='sos'), music, axis=0).astype(np.float32)
auto = np.array(mus.get('automacao_db', [[0, 0], [DUR, 0]]), float)
music *= db(np.interp(t, auto[:, 0], auto[:, 1])).astype(np.float32)[:, None]

# ---------- efeitos: cada regra põe um som do grupo em cada deixa que bate com ela ----------
sons = {}
for nome, s in plano['sons'].items():
    x, sr = sf.read(str(ROOT / s['arquivo']), dtype='float32', always_2d=True)
    if sr != SR:
        raise SystemExit(f'{s["arquivo"]}: precisa estar em {SR} Hz')
    sons[nome] = (np.repeat(x, 2, axis=1) if x.shape[1] == 1 else x[:, :2], s)

sfx = np.zeros((N, 2), np.float32)
fps = deixas['fps']
for r in plano['regras']:
    eventos = [e for e in deixas['events'] if (r.get('tipo') is None or e['kind'] == r['tipo']) and (r.get('id') is None or e['id'] == r['id'])]
    for k, e in enumerate(sorted(eventos, key=lambda e: e['f'])):
        x, s = sons[r['sons'][k % len(r['sons'])]]
        ganho = r.get('ganho_db', 0) + r.get('peso_db', 0) * math.log2(max(e.get('weight', 1), 1e-3))
        pan = (e.get('pan', 0) * r.get('pan_escala', 1)) if r.get('pan', 'deixa') == 'deixa' else float(r['pan'])
        a = (pan + 1) * math.pi / 4  # pan de potência constante
        lr = np.array([math.cos(a), math.sin(a)], np.float32) * math.sqrt(2) * db(ganho)
        ancora = s['pico_s'] if r.get('alinha') == 'pico' else s['ataque_s']
        i0 = int(round((e['f'] / fps + r.get('desloca_s', 0) - ancora) * SR))
        j0 = max(0, -i0); i0 = max(0, i0)
        n = min(len(x) - j0, N - i0)
        if n > 0:
            sfx[i0:i0 + n] += x[j0:j0 + n] * lr

# ---------- master: -14 LUFS integrado, pico verdadeiro -1 dBTP ----------
saida.parent.mkdir(parents=True, exist_ok=True)
cru = saida.with_name(saida.stem + '-cru.wav')
sf.write(str(cru), music + sfx, SR, subtype='FLOAT')
alvo = plano['master']
lufs, tp = alvo['lufs'], alvo['pico_dbtp']
def loudness(path):
    m = subprocess.run(['ffmpeg', '-v', 'info', '-i', str(path), '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    return float(m[m.rindex('I:'):].split()[1])   # loudness integrada (LUFS)


# ganho fixo até o alvo e um limitador só nos picos (a dinâmica da trilha fica como está); o limitador come um pouco
# de volume nos golpes, então repete o ganho até cair no alvo
ganho = lufs - loudness(cru)
for _ in range(4):
    af = f'volume={ganho:.2f}dB,alimiter=limit={db(tp - 0.5):.3f}:attack=1:release=60:level=false'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(cru), '-af', af, '-ar', str(SR), '-c:a', 'pcm_s24le', str(saida)], check=True)
    erro = lufs - loudness(saida)
    if abs(erro) < 0.2:
        break
    ganho += erro
cru.unlink()
print('ok', saida)
