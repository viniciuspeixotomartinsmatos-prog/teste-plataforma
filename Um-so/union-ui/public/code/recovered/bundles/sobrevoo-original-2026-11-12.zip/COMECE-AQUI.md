# Sobrevoo: comece aqui

1. Abra esta pasta no Claude Code, no Codex ou na sua IA de código.
2. Cole o prompt (ele está no PROMPT.md) ou escreva para a IA: "siga o PROMPT.md".
3. Responda às perguntas dela e deixe ela trabalhar até o fim. Se parar no meio, escreva "continue".

O CLAUDE.md e o AGENTS.md são o mesmo guia: a IA lê sozinha, não precisa colar.

## Passo a passo completo

1. Abra o Claude Code na pasta, cole o prompt e responda às perguntas: o endereço da sua página, o nome da marca e o título do fim
2. Deixe a IA montar a demonstração primeiro; se ela parar no meio, diga "continue"
3. Confira os quadros que ela mostra antes do filme: o hero no começo, as peças subindo, a página vista de cima e o cartão do fim
4. Assista ao filme: a câmera sobrevoa a página deitada e os cards, fotos e botões descolam do papel e sobem
5. No rodapé, a câmera sobe até ver a página inteira e mergulha no topo, que pousa como um cartão com o seu título
6. Se alguma peça subir demais, de menos ou com borda estranha, diga qual: a IA ajusta e captura de novo
7. Banner de cookies, chat ou pop-up na frente da página: peça para esconder
8. Baixe a música indicada ou mande a sua, para a entrada dela cair no pouso do cartão
9. Peça o filme final: um MP4 em 1440×1152 com som, pronto para postar
10. Ao postar, cole os créditos da música na descrição (estão no arquivo CREDITS.md)
