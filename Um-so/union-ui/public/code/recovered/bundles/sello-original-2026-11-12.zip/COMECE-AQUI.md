# Sello: comece aqui

1. Abra esta pasta no Claude Code, no Codex ou na sua IA de código.
2. Cole o prompt (ele está no PROMPT.md) ou escreva para a IA: "siga o PROMPT.md".
3. Responda às perguntas dela e deixe ela trabalhar até o fim. Se parar no meio, escreva "continue".

O CLAUDE.md e o AGENTS.md são o mesmo guia: a IA lê sozinha, não precisa colar.

## Passo a passo completo

1. Abra a pasta no Claude Code ou no Codex, cole o prompt inteiro e responda às perguntas: montar a demo, fazer o site da sua empresa ou usar só algumas peças.
2. Deixe a IA trabalhar até o fim: ela instala tudo sozinha e monta a demo primeiro. Se ela parar no meio, escreva "continue".
3. Peça "abre o site para eu ver" e abra o link que ela mostrar (algo como localhost:5350).
4. Recarregue a página: o S, a águia e o O sobem na tela preta e uma janela abre no meio até mostrar o site. Passe o mouse: a águia de cromo inclina para o cursor.
5. Role devagar: a águia fica parada enquanto o título sobe e vai pousar entre o "20" e o "05", girando no caminho.
6. Continue até as moedas: elas abrem num anel em volta da palavra REAL, passando na frente e atrás das letras, e a que sobra vai para o meio do painel.
7. Peça à IA o link para abrir no celular (na mesma rede Wi-Fi), role a página inteira e toque no menu e nos botões: nada pode escapar para o lado.
8. Peça para trocar nome, serviços, números e contatos pelos seus; a IA segue a seção "Personalizar" do guia e diz o que ainda é da demo.
9. Mande o seu logo em SVG (ou PNG sem fundo): a IA roda um comando que transforma o logo na peça de cromo e no relevo das moedas.
10. Para publicar, peça "gera a versão final" e suba a pasta dist/ na sua hospedagem (Vercel, Netlify, Hostinger ou outra).
