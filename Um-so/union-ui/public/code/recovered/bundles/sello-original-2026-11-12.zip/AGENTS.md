# Guia do projeto — Sello

(Salve como `CLAUDE.md` na raiz do projeto se você usa o Claude Code, ou como `AGENTS.md` se usa o Codex, o Cursor ou outro agente. O conteúdo é o mesmo.)

Landing page da Sello, uma corretora de cripto fictícia com cara de banco antigo (custódia, compra e venda, Pix 24 horas, crédito com garantia em bitcoin, prova de reservas e um real em token). Vite sem framework, Three.js, GSAP, Lenis e as fontes Noto Serif Display, Gloock e Geist pelo Fontsource.

**A jogada é o emblema da casa em cromo inflado, 3D de verdade, atravessando a página.** A águia heráldica fica parada no ar enquanto o hero sobe, viaja girando até pousar entre os números do ano e volta no rodapé; as moedas da casa abrem num anel em volta da palavra REAL e a que sobra vira o centro do painel do lastro. Tudo na família verde-água, preto e branco. A régua é site de premiação: se uma animação parece "ok", ainda não está pronta.

## Arquitetura

### HTML e CSS

- **O `index.html` tem todas as seções**, nesta ordem:
  1. a `.abertura` (as quatro barras e o monograma), o canvas `.palco`, o `.topo` (logo e "Entrar"), a `.barra` do pé e o `#menu`;
  2. `.hero` (`#topo`);
  3. `.casa` (`#casa`), com o `.casa__palco` preso;
  4. uma `.passagem` (degradê do branco para o preto);
  5. `.servicos` (`#servicos`), com o `.servicos__palco` preso;
  6. outra `.passagem` (do preto para o branco);
  7. `.moeda` (`#moeda`), com o `.moeda__palco` preso, e `.lastro` (`#lastro`);
  8. `.cofre` (`#cofre`) e o rodapé `.fecho` (`#fecho`).
- **Cada seção diz o tom e o nome** para a barra do pé: `data-tema="claro|escuro"` e `data-secao="Casa"`. As `.passagem` têm `data-de` e `data-para` (a barra troca de tom na metade do degradê).
- **Vagas** (`.vaga--hero`, `.vaga--ano`, `.vaga--lastro`, `.vaga--fecho`): caixas vazias do HTML que dizem ao 3D onde a águia e a moeda ficam. Mudou o layout, mudou a vaga: o 3D segue sozinho.
- **O CSS** entra por uma folha só, `src/styles/site.css`, ligada por `<link>` no `<head>` do `index.html` (as fontes e as outras folhas por `@import` dentro dela). Nunca importe CSS pelo JS: no dev do Vite ele chegaria depois dos módulos e a página apareceria crua por um instante a cada recarregamento. O fundo e a tela preta da abertura vêm inline no `<head>`, antes do link. As folhas estão em `src/styles/` e `src/sections/`:
  - `tokens.css` e `base.css`: as cores por papel e as seis paletas, as escalas, o reset, a barra de rolagem, o `.aguia` (o desenho como máscara) e a saída sem WebGL;
  - `botao.css`: o botão chanfrado;
  - `nav.css`: a barra do pé e o menu de ladrilhos;
  - `abertura.css`, `hero.css`, `casa.css`, `servicos.css`, `moeda.css` (moeda e lastro), `cofre.css`, `fecho.css`;
  - `celular.css`: a composição do celular de todas as seções, num lugar só.
- **Duas escalas** (`src/styles/tokens.css`):
  - escala de cena (`svh` e `vw`): o hero, o ano, as sílabas, o R E A L e o monograma do rodapé acompanham a tela;
  - escala de site (`--su`, 1 px a partir de 1280 de largura, só encolhe abaixo): textos, rótulos e títulos das seções, com os tokens (`--s-h2` 64, `--s-corpo` 17, `--s-rotulo` 12).
  - No celular (até 1023 px, ou tela em pé com proporção até 4:5), a escala de site parte de 390.

### O 3D (`src/gl/`)

- `palco.js`: o renderer (um canvas só, fixo, `100lvh`), a câmera, o estúdio que o cromo reflete (`estudio()`: cúpula em degradê, caixas de luz, uma faixa cinza) e o laço de desenho. O laço roda os **diretores** (`antesDoQuadro`) e depois as **peças** (`aCadaQuadro`), e só desenha quando algo mudou. `palco.mundo(x, y)` converte um ponto da tela em px para o mundo; `palco.k` é quanto mundo vale 1 px.
- `brasao.js`: carrega `public/3d/brasao.glb` (comprimido com meshopt) e aplica o material de cromo. A `pose` (centro x/y e altura h em px, giro) vem de fora; a peça soma a respiração e a mola do cursor.
- `diretor.js`: a viagem da águia. No hero ela fica parada na tela (a posição da `.vaga--hero` com a página no topo); quando o `.casa__palco` sobe de 85% da tela até o topo, ela vai até a `.vaga--ano` girando uma volta e depois anda com ela; no rodapé, segue a `.vaga--fecho`, girando meia volta até o fim da página.
- `moedas.js`: as moedas (InstancedMesh, 12 no desktop e 9 no celular, uma cor por moeda, da lista `moedas` da paleta em `src/paletas.js`; a primeira é a principal, que não troca de cor) e as letras R E A L (planos com a fonte, no lugar das letras do HTML pela linha de base). A cena anda pelo progresso da `.moeda`: 0–0,12 a moeda sozinha, 0,14–0,42 o rolo abrindo no anel, até 0,76 o anel girando, 0,76–0,9 a queda; depois a moeda vai para a `.vaga--lastro` quando o lastro entra.

### O emblema (`fonte/brasao.mjs`, `npm run brasao`)

- Transforma qualquer desenho chapado (SVG, ou PNG com fundo transparente ou branco) na peça inflada e no relevo da moeda.
- Como funciona: o desenho vira uma máscara; a borda é traçada em subpixel; dentro dela se resolve a equação de Poisson (como uma película sob pressão), o que deixa as partes finas como tubos redondos e as largas como cúpulas achatadas; a malha é densa perto da borda e espaçada no miolo; as normais saem da equação (lisas, sem facetas).
- Grava `public/3d/brasao.glb` (~230 KB) e `public/3d/moeda-relevo.webp` (aro, anel de contas e o desenho em relevo baixo).
- Os ajustes ficam no alto do script: `A` (redondeza dos tubos), `TETO` (o quanto as partes largas estufam), `PASSO_BORDA` e `PASSO_MIOLO` (densidade da malha).

### Motion (`src/motion/`)

- `main.js` (em `src/`): monta tudo na abertura; o 3D nasce com a tela ainda preta e a janela da abertura só abre quando a águia e as moedas estão prontas.
- `abertura.js`: o monograma e a janela (as variáveis `--t --b --l --r` das quatro barras).
- `secoes.js`: o movimento de cada seção. `hero()` (as linhas do título, a custódia contando), `casa()` (colunas, a frase que acende, o ano), `servicos()` (a coluna presa à rolagem, os pares por marco, a textura que embaralha, a faixa de números), `moeda()` (as letras), `lastro()` (painel e contadores), `cofre()` (escudos e saldos) e `fecho()`.
- `nav.js`: o tom e o nome da barra pelo fundo debaixo dela, os links que rolam até a seção e o menu de ladrilhos.
- `split.js`: `linhas()` (máscara de linha), `pecas()` (blocos que sobem) e `marco()` (entra e sai num ponto da tela, nos dois sentidos). `contador.js`: números que contam no formato brasileiro.
- `guia.js`: o teto de velocidade da roda. `smooth.js`: Lenis + ScrollTrigger num relógio só. `scrollbar.js`: a barra fina. `rolando.js`: a classe `.is-scrolling`. `ease.js`: as curvas e as constantes `REDUZIDO`, `CELULAR` e `TOQUE`.

## Design system

- **Cores** em `src/styles/tokens.css`, por papel, nunca soltas no CSS das seções:
  - `--hero-fundo` e `--hero-tinta`: o hero e a casa (a casa fica inteira na cor do hero e passa direto para o preto dos serviços);
  - `--destaque` (sílabas, escudinhos, um escudo, título do rodapé, foco), `--destaque-tinta` (texto em cima dele), `--destaque-hover` e `--destaque-chip` (chips do lastro);
  - `--preto #000`, `--tinta #0b0b0c` (texto), `--branco`; `--cinza-claro` e `--cinza-escuro` (rótulos), `--fio-claro` e `--fio-escuro` (fios).
- **Paletas:** seis prontas, cada uma um bloco `html[data-paleta="…"]` em `tokens.css` mais a parte do 3D em `src/paletas.js` (o estúdio que o cromo reflete, a cor do metal da águia, as moedas, o furta-cor delas, a cor da barra do navegador e se o hero é escuro): `agua` (a demo), `lavanda`, `marfim` (águia em ouro), `preto`, `vermelho` e `limao`. A escolhida vem do `data-paleta` do `<html>` (o `<head>` lê o `?paleta=` da URL); para fixar uma, escreva `data-paleta="marfim"` na tag `<html>`. `?paletas` na URL mostra as amostras para comparar (`src/teste-paletas.js`, só carrega com esse parâmetro).
- **Cores no 3D:** `estudio()` em `palco.js` monta o estúdio a partir da paleta (as três cores da cúpula, as caixas de luz e a faixa escura). Paleta nova: copie um bloco em `tokens.css` e um em `paletas.js` com o mesmo nome. Mudou a cor da marca: mude também o `favicon.svg`.
- **Tipo:**
  - Noto Serif Display variável, com `font-stretch: var(--largura-serifa)` (87,5%) nos títulos; 100% e peso 520 nas sílabas e no R E A L;
  - Gloock no ano;
  - Geist variável no texto, nos botões e na interface. `.rotulo`: caixa alta pequena com tracking largo.
- **Peças comuns:** `.botao` (`--claro`, `--linha`, `--mini`), `.link`, `.rotulo`, `.aguia` (o desenho da marca em qualquer cor e tamanho).

## Regras de motion

- **Três cenas presas** com `position: sticky` (o palco da casa, os serviços, a moeda). O que é imagem segue a rolagem (a águia, a coluna de sílabas, o anel). Texto e estados vão por marco com tempo fixo: rolando rápido, cada marco termina inteiro e nunca fica meia linha na tela. Nunca prenda texto ao scrub.
- **A roda tem teto de velocidade** (`guia.js`, ~0,9 tela por segundo); a página sempre rola presa ao gesto e nunca para sozinha. No toque, a rolagem é a nativa e nada é cancelado.
- **Uma peça 3D sai de cena:** o palco precisa redesenhar uma vez (`palco.pedir()`), senão ela fica "presa" no último quadro.
- **Mais ou menos serviços:** cada `article.servico` tem `data-lado`; os pares e o celular estão em `servicos()` (`limites`). **Mais ou menos sílabas:** um `<span>` por sílaba em `.silabas`, de 2 ou 3 letras.
- **Títulos** curtos (até três linhas no título do hero e do lastro). Nada de HUD, rótulo com traço, contador "01/04", "role para..." ou linha decorativa.
- **`prefers-reduced-motion`:** sem abertura, sem Lenis, a águia sem giro nem balanço, moedas paradas, texto só com opacidade.

## Celular (regras que nunca quebram)

O corte é `(max-width: 1023px), (max-aspect-ratio: 4/5)`. A composição (`celular.css`):

- **Abertura:** o monograma com o corpo pela largura (`min(19svh, 26vw)`), para o S · águia · O começar junto na metade da direita e ter espaço para deslizar até as bordas.
- **Hero:** em coluna: título no alto, a águia com a altura que sobra entre ele e o texto (o topo dela entra na última linha), texto e botão no pé; sem rótulos nem custódia.
- **A casa:** a cena presa é a frase centrada e o "20 · 05" com a águia, numa tela só (a frase acende quando a águia já pousou); as colunas vêm logo depois, rolando: "O que fazemos" na largura toda e as outras três lado a lado.
- **Serviços:** a coluna passa primeiro e os serviços entram um de cada vez.
- **Moeda:** 9 moedas maiores. **Lastro:** a moeda em cima e o painel empilhado. **Cofre:** escudos em 2 × 2.

Ao personalizar, estas regras continuam valendo:

1. **Nada rola para o lado**, em nenhuma altura e em nenhum momento (abertura, menu aberto). `html, body { overflow-x: clip }` é a rede de segurança.
2. **O script nunca briga com o dedo.** O Lenis fica sem `syncTouch`, e o filtro de rolagem do `guia.js` devolve `true` para todo evento de toque: nunca chame `preventDefault()` num `touchend` (isso mata o clique de todos os botões no celular) e nenhum `scrollTo` roda enquanto o dedo ou a inércia rolam.
3. **O palco não muda de tamanho rolando.** O canvas mede `100lvh` e ignora a mudança só de altura no toque: a barra do Safari indo e voltando não realoca o WebGL. As cenas presas ficam em `svh` (nunca `100vh` nem `dvh`).
4. **Leve:** o site abre com ~0,7 MB; o 3D usa no máximo 1,5× de densidade no celular (2× no desktop). Alvos de toque de 44 px (os links pequenos crescem por `::after` no toque).
5. **Cabe na tela baixa.** No Safari do iPhone, `100svh` é a tela com as barras abertas: ~660 px num iPhone comum e ~550 num SE, não os 844 do emulador. O hero e as cenas presas cabem nessa altura sem nada se cruzar: o hero é uma coluna em que a águia fica com a sobra, e a casa prende só a frase e o ano. Ao trocar textos ou tamanhos, confira a 390 × 664 e a 375 × 553.

## Como checar

1. **Abrir.** Rode `npm run dev` (porta 5350) e olhe a 1456 × 840, a 390 × 844 e a 390 × 664 (o iPhone com as barras do Safari abertas), no Chrome e no Safari. Para o celular de verdade, `npm run dev -- --host`.
2. **Comparar.** Confira cada trecho contra o print de `arquivos/conceito/` (ou o novo desenho, depois de personalizar).
3. **A abertura** (recarregue a página). S, a águia e O sobem, se espalham, a janela abre no meio e cresce. Passe o mouse: a águia inclina para o cursor e balança ao soltar.
4. **As cenas, rolando devagar.** A águia fica parada enquanto o título sobe e pousa entre "20" e "05", girando; a frase acende. Na seção preta, as sílabas sobem e os serviços entram aos pares. A moeda sobe girando, o rolo abre o anel em volta do R E A L (moedas atrás e na frente das letras), elas caem e a que sobra vai para o lastro.
5. **A roda, rolando rápido.** O teto de velocidade segura a página, cada marco termina inteiro e a águia chega pousada.
6. **Os controles.** O menu abre em ladrilhos, fecha com Esc e cada link chega na seção certa. Toque em cada botão no celular: todos respondem. O Tab mostra o foco em tudo.
7. **O resto.**
   - Com movimento reduzido, a página abre sem abertura e com a águia parada.
   - O console fica sem erros.
   - `npm run build` passa.
   - No celular, nada rola para o lado em nenhuma altura.

## Personalizar

O site chega como a demo da Sello, uma corretora inventada. Esta seção vale sempre que a pessoa pedir uma mudança, hoje ou daqui a meses: trocar o nome, o emblema, um número, uma cor, ou levar uma peça para outro site.

### Antes de mexer

- Se ainda não sabe o objetivo, pergunte qual destes é (uma pergunta por vez, em linguagem simples):
  1. **Ver a demo funcionando** como está, para trocar depois.
  2. **O site da minha empresa** (corretora ou custódia de cripto, gestora, banco digital, casa de ouro e câmbio) com esta estrutura e estas animações.
  3. **Só algumas peças** (o emblema de cromo, o ano com o emblema pousado, as sílabas da seção preta, o anel de moedas, o painel ao vivo, os escudos, a barra com ladrilhos) para um site que já existe.
- **Para o caminho 2**, pergunte o que ainda não sabe, sem pedir tudo de uma vez:
  - o nome e os serviços (quatro, para manter os pares);
  - os números que pode mostrar (ou se prefere texto sem número);
  - o ano de fundação;
  - e-mail, WhatsApp, endereço, redes, os links de "Entrar" e "Abrir conta";
  - **que material já tem**: o logo em SVG.
- **Para o caminho 3**, pergunte quais peças e onde fica o site de destino. Leia o código do destino antes.
  - O emblema é o pedaço mais fácil de levar: `palco.js` + `brasao.js` + uma vaga no HTML + um diretor mínimo que copie o retângulo da vaga para a `pose` a cada quadro (o trecho do rodapé em `diretor.js` é o exemplo mais curto).
  - Em React ou Next, crie o palco num `useEffect`, guarde-o num `ref` e descarte o renderer na saída.
- **Diga com clareza, sem rodeio:**
  - Os números da demo (custódia, circulação, emitidos, saldos dos escudos, a faixa de números) são inventados.
  - O endereço, o CNPJ e o e-mail são de exemplo.

### O que muda e onde

| o quê | onde | precisa de material novo? |
|---|---|---|
| Nome, `<title>`, `description` | `index.html`: `<title>`, meta, o `aria-label` do logo, a barra do pé ("Sello"), o aviso legal | não |
| Monograma (abertura e rodapé) | `.mono__s`/`.mono__o` (abertura) e `.fecho__s`/`.fecho__o` (rodapé) no `index.html`: a primeira e a última letra do nome | não |
| **O emblema 3D** | o desenho em `public/aguia.svg` (logo, abertura, favicon) e a peça: `npm run brasao -- caminho/do/logo.svg` (regrava `public/3d/brasao.glb` e `moeda-relevo.webp`) | o logo (abaixo) |
| Título e texto do hero | `.hero__titulo` (três `.hero__linha`), `.hero__rotulo`, `.hero__texto` | não |
| Sob custódia | `.custodia__num` (`data-ate`), a barra (`--p` de cada `<i>`) e a legenda | não |
| Colunas e frase da casa | `.casa__colunas` e `.casa__frase` | não |
| O ano | `.ano__a` e `.ano__b` (duas metades do ano), também em "Fundada em", na frase e no rótulo do hero. As metades ficam encostadas no vão da águia, então só fecha simétrico se as duas tiverem a mesma largura de tinta: 20/05 fecha; 20/14 não (o 1 é fino). Com um ano assimétrico, compense com `margin` numa das metades | não |
| Serviços | cada `article.servico`: o ícone do escudinho, o título, o texto e o "para quem"; as sílabas em `.silabas` (um `<span>` por sílaba) e o `aria-label` | não |
| Faixa de números | `itens` em `servicos()` (`src/motion/secoes.js`) | não |
| A palavra das moedas | `.moeda__letras` (uma letra por `<span>`, até ~5) e `.moeda__sub` | não |
| Painel do lastro | `.lastro__total` (`data-de`/`data-ate`), a ficha (`<dl>`), os números do dia (`data-ate`) e o título | não |
| Escudos | cada `li.escudo`: nome, `data-ate` e `data-casas` do saldo, a unidade e o ícone (SVG em traço) | não |
| Fecho e rodapé | `.fecho__titulo`, `.fecho__lado`, `.fecho__grade`, `.fecho__legal` | não |
| Menu | `#menu`: cada `li.ladrilho` com a posição (`--l` linha, `--c` coluna) | não |
| Cores | escolher uma das seis paletas (`data-paleta` no `<html>`; `?paletas` para comparar) ou criar uma nova: um bloco em `src/styles/tokens.css` e um em `src/paletas.js` com o mesmo nome; `favicon.svg` | não |
| Tirar uma seção | o `<section>` no `index.html`, a chamada dela no `src/main.js` e o link no menu; se tirar a casa, o diretor da águia perde o pouso (ajuste `diretor.js`) | não |

### Material da pessoa

**O logo vira o emblema de cromo.** Ofereça estes caminhos, do mais simples para o mais trabalhoso:

1. **O logo dela em SVG**, de uma cor só (o símbolo, sem o nome ao lado): salve em `fonte/logo.svg` e rode `npm run brasao -- fonte/logo.svg`. Copie o mesmo SVG para `public/aguia.svg` (o logo do topo, a abertura e a saída sem WebGL) e troque o desenho dentro do `public/favicon.svg`. O que funciona melhor:
   - formas cheias, com recortes finos separando as partes (como a águia: cada recorte vira uma "costura" entre dois volumes);
   - nada mais fino que ~1% da largura do desenho (some ou vira um fio);
   - símbolo mais ou menos quadrado (cabe nas vagas sem sobrar).
2. **PNG com fundo transparente** (ou escuro sobre branco): o mesmo comando aceita PNG, `npm run brasao -- logo.png`. Para o `public/aguia.svg`, vetorize antes (o `potrace` faz isso: PNG → PBM → SVG).
3. **Gerar um símbolo novo** no estilo da demo: a receita da águia está em `arquivos/receitas/` (com o `LEIA.md`). Troque o bicho ou o objeto e mantenha o resto do texto.
4. **Manter a águia** por enquanto. Ela não é marca de ninguém; antes de publicar, o nome tem de ser o dela.

Depois de trocar, olhe o hero, o ano e o rodapé: se o símbolo for bem mais largo que alto, aumente a largura das vagas (`.vaga--hero`, `.vaga--ano`, `.vaga--fecho`) e confira que ele não cobre o texto do lado.

**Números:** o que a pessoa não informou fica `[preencher]` ou vira texto sem número ("Reservas atestadas a cada hora" no lugar de "R$ 3,41 bi").

### Regras ao trocar

- Nada de número, saldo, licença, CNPJ ou endereço inventado como se fosse da pessoa: o que ela não informou fica `[preencher]` e entra na lista do fim. Corretora de verdade não publica número que não pode provar.
- Nada de cidade se a pessoa não quiser: o endereço sem cidade, como na demo, é uma saída honesta.
- Ao trocar o emblema, confira nas duas larguras e no Safari: o cromo inteiro na vaga, sem cortar asa nem pé.
- Depois de cada troca, rode o "Como checar" de novo e, no fim, liste para a pessoa o que ainda é da demo (números, textos, emblema) e o que falta ela mandar.
