// Curvas da marca e as condições do aparelho. REDUZIDO: movimento reduzido no sistema (sem Lenis, sem abertura,
// a águia parada no lugar, trocas sem animação).
import gsap from 'gsap';
import { CustomEase } from 'gsap/CustomEase';

gsap.registerPlugin(CustomEase);

CustomEase.create('se-out', '0.23, 1, 0.32, 1');
CustomEase.create('se-in', '0.6, 0, 0.84, 0.2');
CustomEase.create('se-io', '0.77, 0, 0.175, 1');

export const REDUZIDO = matchMedia('(prefers-reduced-motion: reduce)').matches;
// celular: tela estreita ou em pé (iPad em pé usa a composição do celular)
export const CELULAR = matchMedia('(max-width: 1023px), (max-aspect-ratio: 4/5)').matches;
export const TOQUE = matchMedia('(hover: none)').matches;

export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const faixa = (v, a, b) => clamp((v - a) / (b - a));
export const suave = (t) => t * t * (3 - 2 * t);
export const suave2 = (t) => t * t * t * (t * (t * 6 - 15) + 10);
