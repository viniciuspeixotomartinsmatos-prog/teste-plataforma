// Palco 3D: um canvas fixo do tamanho da tela, com a águia de cromo e as moedas. Desenha só quando alguma coisa
// mudou (pose, rolagem, mola do cursor) e nunca com o palco vazio. As peças ficam em coordenadas de tela: quem
// chama diz "centro em (x, y) px, altura h px" e o palco converte para o mundo.
import * as THREE from 'three';
import gsap from 'gsap';
import { CELULAR, TOQUE } from '../motion/ease.js';

export function criarPalco(canvas, cores) {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  } catch (e) {
    return null;
  }
  const dpr = () => Math.min(devicePixelRatio || 1, CELULAR ? 1.5 : 2);
  renderer.setPixelRatio(dpr());
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.toneMappingExposure = 1.0;

  const cena = new THREE.Scene();
  const FOV = 22, DIST = 14;
  const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 100);
  camera.position.set(0, 0, DIST);

  let ambiente = null;
  function trocarEstudio(c) {
    const pmrem = new THREE.PMREMGenerator(renderer);
    const novo = pmrem.fromScene(estudio(c), 0.025).texture;
    pmrem.dispose();
    ambiente?.dispose();
    ambiente = novo;
    cena.environment = ambiente;
    sujo = true;
  }

  // o canvas mede 100lvh (a tela com a barra do navegador recolhida): quando a barra do Safari some e volta durante a
  // rolagem, ele não muda de tamanho e não realoca nada; no toque, mudança só de altura (< 140 px) é ignorada
  let W = 1, H = 1, k = 1, Wantes = 0;
  function medir(e) {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (e && TOQUE && w === Wantes && Math.abs(h - H) < 140) return;
    Wantes = w; W = w; H = h;
    renderer.setPixelRatio(dpr());
    renderer.setSize(W, H, false);
    camera.aspect = W / H;
    camera.updateProjectionMatrix();
    k = (2 * DIST * Math.tan(THREE.MathUtils.degToRad(FOV / 2))) / H; // unidades do mundo por px (no plano z = 0)
    sujo = true;
    ouvintes.forEach((f) => f());
  }

  const ouvintes = new Set();
  const antes = new Set();  // diretores: leem a rolagem e decidem as poses (rodam primeiro)
  const quadro = new Set(); // peças: aplicam as poses (devolvem true se ainda animam)
  let sujo = true, visivel = true;

  gsap.ticker.add(() => {
    let anima = false;
    antes.forEach((f) => { if (f()) anima = true; });
    quadro.forEach((f) => { if (f()) anima = true; });
    if (!(sujo || anima)) return;
    sujo = false;
    if (!visivel) { renderer.clear(); return; }
    renderer.render(cena, camera);
  });

  addEventListener('resize', medir);
  medir();
  trocarEstudio(cores);

  return {
    THREE, renderer, cena, camera,
    get W() { return W; }, get H() { return H; }, get k() { return k; },
    /** posição no mundo (plano z = 0) de um ponto da tela em px */
    mundo(x, y, alvo = new THREE.Vector3()) { return alvo.set((x - W / 2) * k, -(y - H / 2) * k, 0); },
    pedir() { sujo = true; },
    aCadaQuadro(f) { quadro.add(f); return () => quadro.delete(f); },
    antesDoQuadro(f) { antes.add(f); return () => antes.delete(f); },
    aoMedir(f) { ouvintes.add(f); },
    trocarEstudio,
    set visivel(v) { if (v !== visivel) { visivel = v; sujo = true; } },
  };
}

// Estúdio de fotografia para o reflexo do cromo: cúpula em degradê (alto claro, horizonte verde-água, chão
// verde-petróleo), três caixas de luz e uma faixa escura na frente para desenhar o volume.
function estudio(c) {
  const cena = new THREE.Scene();
  const cupula = new THREE.Mesh(
    new THREE.SphereGeometry(40, 64, 32),
    new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false,
      uniforms: {
        alto: { value: new THREE.Color(c.alto) },
        meio: { value: new THREE.Color(c.meio) },
        baixo: { value: new THREE.Color(c.baixo) },
      },
      vertexShader: 'varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `
        uniform vec3 alto, meio, baixo; varying vec3 vP;
        void main(){
          float h = normalize(vP).y;
          vec3 c = h > 0.0 ? mix(meio, alto, smoothstep(0.0, 0.75, h)) : mix(meio, baixo, smoothstep(0.0, 0.55, -h));
          gl_FragColor = vec4(c, 1.0);
        }`,
    }),
  );
  cena.add(cupula);
  const caixa = (w, h, cor, forca, pos) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(cor).multiplyScalar(forca), side: THREE.DoubleSide }));
    m.position.set(...pos); m.lookAt(0, 0, 0); cena.add(m);
  };
  caixa(22, 12, c.luz, 7.0, [-10, 14, 16]);    // principal: alto, à esquerda, na frente (o branco estourado)
  caixa(6, 28, c.luz, 4.5, [21, 4, 7]);        // recorte à direita
  caixa(5, 22, c.borda, 3.2, [-22, -1, 6]);    // recorte à esquerda
  caixa(30, 5, c.chao, 2.6, [0, -15, 13]);     // rebatedor claro embaixo
  caixa(44, 1.8, c.faixa, 1.0, [0, -2.5, 22]); // faixa escura na frente: desenha o volume no meio das peças
  return cena;
}
