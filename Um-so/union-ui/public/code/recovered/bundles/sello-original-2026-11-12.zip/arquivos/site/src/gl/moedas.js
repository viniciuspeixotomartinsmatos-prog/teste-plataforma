// As moedas da casa (Real Sello) e as letras R E A L, no palco 3D.
// A cena da moeda (seção .moeda, presa por ~2,6 telas) anda assim, pelo progresso da rolagem:
//   0,00–0,12  uma moeda gira sozinha no meio, as letras sobem
//   0,12–0,42  as outras saem de trás dela como um rolo e abrem num anel inclinado em volta das letras
//   0,42–0,78  o anel gira (a parte de cima passa atrás das letras, a de baixo na frente)
//   0,78–0,92  as moedas caem e sobra a primeira, que cresce no meio
//   depois     ela vai para a vaga do lastro e anda com a seção
// As letras são desenhadas aqui (planos com a mesma fonte, no lugar exato das letras do HTML) para as moedas
// passarem na frente e atrás delas; o HTML fica com as letras transparentes (e visíveis sem WebGL).
import gsap from 'gsap';
import { CELULAR, REDUZIDO, clamp, faixa, lerp, suave, suave2 } from '../motion/ease.js';

const BASE = import.meta.env.BASE_URL;
const VOLTA = Math.PI * 2;
// o mesmo ângulo, na volta mais perto de ref (para uma transição nunca desenrolar voltas acumuladas)
const perto = (a, ref) => ref + ((((a - ref) % VOLTA) + VOLTA * 1.5) % VOLTA) - Math.PI;

export async function criarMoedas(palco, paleta) {
  const { THREE } = palco;
  const N = CELULAR ? 9 : 12;
  const ESP = 0.12; // espessura da moeda (raio 1)

  // ---- geometria e materiais ----
  const geo = new THREE.CylinderGeometry(1, 1, ESP, 128, 1);
  geo.rotateX(Math.PI / 2); // as faces olham para ±z
  const relevo = await new THREE.TextureLoader().loadAsync(`${BASE}3d/moeda-relevo.webp`);
  relevo.colorSpace = THREE.NoColorSpace;
  relevo.anisotropy = 8;
  const face = new THREE.MeshPhysicalMaterial({
    metalness: 1, roughness: 0.3, normalMap: relevo, normalScale: new THREE.Vector2(1.15, -1.15),
    iridescence: paleta.irid, iridescenceIOR: 1.6, iridescenceThicknessRange: [170, 330], envMapIntensity: 1.1,
  });
  const borda = new THREE.MeshPhysicalMaterial({
    metalness: 1, roughness: 0.24, normalMap: serrilha(THREE), normalScale: new THREE.Vector2(0.9, 0.9),
    iridescence: paleta.irid * 0.7, iridescenceIOR: 1.6, iridescenceThicknessRange: [170, 330], envMapIntensity: 1.1,
  });
  const moedas = new THREE.InstancedMesh(geo, [borda, face, face], N);
  moedas.frustumCulled = false;
  moedas.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  // cores das moedas: metal anodizado (roxo, azul-noite, grafite), prata e lilás
  const cores = Array.from({ length: N }, () => new THREE.Color());
  const pintar = (tons) => { for (let i = 0; i < N; i++) { cores[i].set(tons[i % tons.length]); moedas.setColorAt(i, cores[i]); } };
  pintar(paleta.moedas);
  moedas.instanceColor.setUsage(THREE.DynamicDrawUsage);
  moedas.visible = false;
  palco.cena.add(moedas);

  // ---- letras R E A L ----
  const letras = await criarLetras(palco);

  // ---- direção ----
  const secao = document.querySelector('.moeda');
  const vLastro = document.querySelector('.vaga--lastro');
  const linhaLetras = document.querySelector('.moeda__letras');
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v = new THREE.Vector3(), esc = new THREE.Vector3();
  let giroAnel = 0, ultimo = performance.now(), tempo = 0;
  // a moeda principal gira lentinho por tempo (~20° por segundo, uma volta a cada ~18 s) enquanto está sozinha e à vista, no máximo duas
  // voltas, desacelerando no fim; ryL é o ângulo dela já trazido para perto do anel (só muda com ela sozinha)
  let giroLider = 0, ryL = 0;
  // cada moeda tem um jeito de girar: umas viram de vez em quando, outras só balançam
  const jeito = Array.from({ length: N }, (_, i) => ({ vel: 0.6 + ((i * 37) % 11) / 11 * 1.4, fase: i * 1.7, vira: i % 3 === 1 }));
  // ângulo próprio das que viram inteiras: só avança com o anel formado e volta ao lugar quando elas se juntam no rolo
  const giro = new Float32Array(N);

  palco.antesDoQuadro(() => {
    const agora = performance.now(), dt = Math.min(0.05, (agora - ultimo) / 1000); ultimo = agora; tempo += dt;
    const H = innerHeight, W = innerWidth;
    const rS = secao.getBoundingClientRect(), rL = vLastro.getBoundingClientRect();
    const naTela = rS.top < H * 1.2 && rL.bottom > -H * 0.2;
    const letrasNaTela = rS.top < H && rS.bottom > 0;
    if (naTela !== moedas.visible || letrasNaTela !== letras.mostrando) palco.pedir(); // entrou ou saiu: redesenha
    moedas.visible = naTela;
    letras.visivel(letrasNaTela);
    if (!naTela) return false;
    letras.medir();

    const pre = suave(clamp(1 - rS.top / H));        // a cena subindo da passagem
    const p = clamp(-rS.top / (rS.height - H));      // a cena presa
    const rLet = linhaLetras.getBoundingClientRect();
    const k = palco.k;
    const centro = palco.mundo(W / 2, rLet.top + rLet.height * 0.55, new THREE.Vector3()); // centro do anel (anda com a cena)
    const meioTela = palco.mundo(W / 2, H * 0.47, new THREE.Vector3()); // onde a moeda que sobra espera o lastro
    const rMoeda = Math.min(H * 0.075, W * (CELULAR ? 0.08 : 0.055)) * k;   // raio da moeda no anel (mundo)
    // anel: elipse inclinada (a parte de cima vai para trás das letras, a de baixo vem para a frente)
    const rx = Math.min(W * (CELULAR ? 0.45 : 0.36), H * 0.62), ry = CELULAR ? rx * 0.92 : Math.min(H * 0.34, rx * 0.92);
    const alfa = Math.acos(clamp(ry / rx, 0.2, 1)), R = rx * k;
    const f = suave2(faixa(p, 0.14, 0.42));          // formação
    const queda = faixa(p, 0.76, 0.9);               // queda
    if (!REDUZIDO) giroAnel += dt * (0.12 + 0.16 * (1 - f));
    const base = -Math.PI / 2 + giroAnel * f;
    const cheg = suave2(clamp((H - rL.top - rL.height * 0.5) / (H * 0.55))); // ida para a vaga do lastro

    for (let i = 0; i < N; i++) {
      const jt = jeito[i];
      // no anel
      const th = base - i * ((Math.PI * 2) / N) * f;
      let x = Math.cos(th) * R + (1 - f) * i * rMoeda * 0.24; // juntas, formam um rolo deitado para a direita
      let y = Math.sin(th) * Math.cos(alfa) * R;
      let z = -Math.sin(th) * Math.sin(alfa) * R;
      let s = rMoeda;
      let ryAnel;
      if (jt.vira) {
        giro[i] = perto(giro[i] + (REDUZIDO ? 0 : dt * jt.vel * 0.5 * f), 0);
        if (f < 1) giro[i] -= giro[i] * Math.min(1, (1 - f) * dt * 3);
        ryAnel = 1.4 + giro[i];
      } else {
        ryAnel = lerp(1.4, REDUZIDO ? 0 : Math.sin(tempo * jt.vel * 0.5 + jt.fase) * 0.7, f);
      }
      let rx_ = -Math.sin(th) * 0.85 + 0.15, ry_ = ryAnel, rz_ = th * 0.12;

      if (i === 0) {
        // sozinha: grande no meio, girando lentinho (no máximo duas voltas, desacelerando no fim) e respirando de leve.
        // Depois vira a cabeça do rolo.
        const so = 1 - suave(faixa(p, 0.08, 0.24));
        if (so >= 0.999) {
          if (!REDUZIDO && pre > 0.45 && giroLider < VOLTA * 2) {
            giroLider = Math.min(VOLTA * 2, giroLider + dt * 0.35 * Math.min(1, (VOLTA * 2 - giroLider) / 1.4 + 0.1));
          }
          ryL = perto(giroLider + (REDUZIDO ? 0 : Math.sin(tempo * 0.5) * 0.1), ry_);
        }
        x = lerp(x, 0, so); y = lerp(y, 0, so); z = lerp(z, 0, so);
        s = lerp(s, Math.min(H * 0.15, W * 0.3) * k, so) * (0.35 + 0.65 * pre);
        rx_ = lerp(rx_, 0.12, so); ry_ = lerp(ry_, ryL, so); rz_ = lerp(rz_, 0, so);
        // depois da queda: volta ao meio e cresce
        const fim = suave2(queda);
        x = lerp(x, 0, fim); y = lerp(y, 0, fim); z = lerp(z, 0, fim); s = lerp(s, Math.min(H * 0.17, W * 0.32) * k, fim);
        rx_ = lerp(rx_, 0, fim); rz_ = lerp(rz_, 0, fim);
        ry_ = lerp(ry_, REDUZIDO ? 0 : Math.sin(tempo * 0.5) * 0.4, fim);
        // quando a cena começa a sair, a moeda não sobe com ela: fica no meio da tela até o lastro chegar
        x += lerp(centro.x, meioTela.x, fim); y += lerp(centro.y, meioTela.y, fim);
        if (cheg > 0) {
          const alvo = palco.mundo(rL.left + rL.width / 2, rL.top + rL.height / 2, v);
          x = lerp(x, alvo.x, cheg); y = lerp(y, alvo.y, cheg); z = lerp(z, 0, cheg);
          s = lerp(s, (rL.height / 2) * k, cheg);
          ry_ = lerp(ry_, REDUZIDO ? 0 : Math.sin(tempo * 0.45) * 0.35, cheg);
        } // a cor é a mesma do começo ao fim (a do R E A L)
      } else {
        // as outras: nascem com a formação e caem no fim
        s *= f <= 0.001 ? 0 : suave(clamp(f * 3 - (i / N) * 0.4));
        if (queda > 0) {
          const qd = clamp(queda * 1.25 - (i % 4) * 0.06);
          y -= qd * qd * H * k * 1.4; rx_ += qd * (2 + i * 0.3); rz_ += qd * (i % 2 ? 1.5 : -1.5);
        }
        if (cheg > 0.3) s = 0;
        x += centro.x; y += centro.y;
      }
      e.set(rx_, ry_, rz_); q.setFromEuler(e); esc.setScalar(Math.max(0.00001, s));
      m.compose(v.set(x, y, z), q, esc);
      moedas.setMatrixAt(i, m);
    }
    moedas.instanceMatrix.needsUpdate = true;
    return true;
  });

  return {
    letras, moedas,
    trocarTons(tons, irid) {
      pintar(tons); moedas.instanceColor.needsUpdate = true;
      face.iridescence = irid; borda.iridescence = irid * 0.7;
      palco.pedir();
    },
  };
}

// serrilha da borda: listras verticais como mapa de normais
function serrilha(THREE) {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 4;
  const x = c.getContext('2d'), img = x.createImageData(1024, 4), RISCOS = 220;
  for (let i = 0; i < 1024; i++) {
    const n = Math.sin((i / 1024) * RISCOS * Math.PI * 2);
    const r = Math.round((n * 0.55 * 0.5 + 0.5) * 255);
    for (let j = 0; j < 4; j++) { const o = (j * 1024 + i) * 4; img.data[o] = r; img.data[o + 1] = 128; img.data[o + 2] = 255; img.data[o + 3] = 255; }
  }
  x.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.NoColorSpace; t.wrapS = THREE.RepeatWrapping;
  return t;
}

// As letras R E A L num plano cada, desenhadas com a mesma fonte do HTML e no lugar exato delas (pela linha de base).
async function criarLetras(palco) {
  const { THREE } = palco;
  const spans = [...document.querySelectorAll('.moeda__letras span')];
  await document.fonts.ready;
  const grupo = new THREE.Group();
  grupo.visible = false;
  palco.cena.add(grupo);
  const itens = spans.map((span) => {
    const base = document.createElement('i');
    base.style.cssText = 'display:inline-block;width:0;height:0;vertical-align:baseline';
    span.append(base);
    const mat = new THREE.ShaderMaterial({
      uniforms: { mapa: { value: null }, cor: { value: new THREE.Color('#0b0b0c') }, sobe: { value: REDUZIDO ? 1 : 0 } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `
        uniform sampler2D mapa; uniform vec3 cor; uniform float sobe; varying vec2 vUv;
        void main(){
          vec2 uv = vUv; uv.y += (1.0 - sobe) * 1.05;
          if (uv.y > 1.0) discard;
          float a = texture2D(mapa, uv).a;
          if (a < 0.02) discard;
          gl_FragColor = vec4(cor, a);
        }`,
      alphaToCoverage: true, transparent: false, toneMapped: false,
    });
    const plano = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat);
    grupo.add(plano);
    return { span, base, plano, mat, chave: '' };
  });
  document.documentElement.classList.add('letras-gl');

  function desenhar(it) {
    const cs = getComputedStyle(it.span);
    const tam = parseFloat(cs.fontSize), res = Math.min(2, devicePixelRatio || 1);
    const fonte = `${cs.fontWeight} ${tam}px ${cs.fontFamily}`;
    const c = document.createElement('canvas'), x = c.getContext('2d');
    x.font = fonte;
    const mt = x.measureText(it.span.textContent);
    const pad = Math.ceil(tam * 0.06);
    const w = Math.ceil(mt.actualBoundingBoxLeft + mt.actualBoundingBoxRight) + pad * 2;
    const h = Math.ceil(mt.actualBoundingBoxAscent + mt.actualBoundingBoxDescent) + pad * 2;
    c.width = Math.ceil(w * res); c.height = Math.ceil(h * res);
    x.scale(res, res); x.font = fonte; x.fillStyle = '#000'; x.textBaseline = 'alphabetic';
    x.fillText(it.span.textContent, pad + mt.actualBoundingBoxLeft, pad + mt.actualBoundingBoxAscent);
    it.mat.uniforms.mapa.value?.dispose();
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
    it.mat.uniforms.mapa.value = t;
    it.w = w; it.h = h; it.pad = pad; it.mt = mt;
  }
  const v = new THREE.Vector3();
  function medir() {
    for (const it of itens) {
      const r = it.span.getBoundingClientRect(), b = it.base.getBoundingClientRect();
      const chave = `${Math.round(parseFloat(getComputedStyle(it.span).fontSize))}`;
      if (chave !== it.chave) { it.chave = chave; desenhar(it); }
      // a origem do texto é a borda esquerda da letra, na linha de base
      const x0 = r.left - it.mt.actualBoundingBoxLeft - it.pad, y0 = b.top - it.mt.actualBoundingBoxAscent - it.pad;
      palco.mundo(x0 + it.w / 2, y0 + it.h / 2, v);
      it.plano.position.copy(v);
      it.plano.scale.set(it.w * palco.k, it.h * palco.k, 1);
    }
  }
  return {
    medir,
    visivel(v) { grupo.visible = v; },
    get mostrando() { return grupo.visible; },
    entrar(atraso = 0) { itens.forEach((it, i) => gsap.to(it.mat.uniforms.sobe, { value: 1, duration: REDUZIDO ? 0 : 1.1, ease: 'se-out', delay: atraso + i * 0.07 })); },
    sair() { itens.forEach((it) => gsap.to(it.mat.uniforms.sobe, { value: 0, duration: REDUZIDO ? 0 : 0.4, ease: 'se-in' })); },
  };
}
