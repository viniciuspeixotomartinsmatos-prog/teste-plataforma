// O movimento de cada seção. Texto e estados entram por marco (tempo fixo, nos dois sentidos); o que é imagem
// (a coluna de sílabas, o 3D) anda preso à rolagem.
import gsap from 'gsap';
import { linhas, pecas, marco } from './split.js';
import { contador, brl } from './contador.js';
import { REDUZIDO, CELULAR, clamp, faixa } from './ease.js';

// ---------------------------------------------------------------- hero
export function hero() {
  // cada linha do título sobe por dentro da própria máscara (as três linhas são fixas)
  const L = [...document.querySelectorAll('.hero__linha')].map((l) => {
    const dentro = document.createElement('span');
    dentro.className = 'hero__linha-in';
    dentro.append(...l.childNodes);
    l.append(dentro);
    return dentro;
  });
  gsap.set(L, REDUZIDO ? { autoAlpha: 0 } : { yPercent: 105 });
  const lado = pecas([...document.querySelectorAll('.hero__rotulo, .hero__texto, .hero .botao, .custodia')], { y: 16 });
  const num = document.querySelector('.custodia__num');
  const barra = [...document.querySelectorAll('.custodia__barra i')];
  gsap.set(barra, { scaleX: 0 });
  const o = { v: 0 };
  return {
    entrar(atraso = 0) {
      L.forEach((l, i) => gsap.to(l, REDUZIDO ? { autoAlpha: 1, duration: 0.4 } : { yPercent: 0, duration: 1.3, ease: 'se-out', delay: atraso + i * 0.1 }));
      lado.entrar(atraso + 0.45, 0.08);
      if (REDUZIDO) { num.textContent = '3,41'; gsap.set(barra, { scaleX: 1 }); return; }
      gsap.to(o, { v: 3.41, duration: 2.2, delay: atraso + 0.6, ease: 'se-out', onUpdate: () => { num.textContent = brl(o.v, 2); } });
      gsap.to(barra, { scaleX: 1, duration: 1.4, ease: 'se-out', delay: atraso + 0.7, stagger: 0.12 });
    },
  };
}

// ---------------------------------------------------------------- a casa
export function casa() {
  const colunas = pecas([...document.querySelectorAll('.coluna')], { y: 18 });
  marco(document.querySelector('.casa__colunas'), { linha: 0.88, entrar: () => colunas.entrar(0, 0.08), sair: () => colunas.sair() });

  // a frase acende palavra por palavra (por tempo, ~1,4 s), não presa à rolagem
  const frase = document.querySelector('.casa__frase');
  const palavras = frase.textContent.trim().split(/\s+/);
  frase.innerHTML = palavras.map((p) => `<span class="palavra">${p}</span>`).join(' ');
  const P = [...frase.querySelectorAll('.palavra')];
  let tl;
  marco(frase, {
    // no celular, só quando a águia já pousou: na tela estreita ela passa por cima da frase no caminho
    linha: CELULAR ? 0.5 : 0.78,
    entrar: () => { tl?.kill(); tl = gsap.timeline(); P.forEach((p, i) => tl.add(() => p.classList.add('acesa'), REDUZIDO ? 0 : i * 0.045)); },
    sair: () => { tl?.kill(); P.forEach((p) => p.classList.remove('acesa')); },
  });

  // o ano sobe por máscara quando aparece
  const ano = [...document.querySelectorAll('.ano__a, .ano__b')];
  gsap.set(ano, { yPercent: REDUZIDO ? 0 : 30, autoAlpha: 0 });
  marco(document.querySelector('.ano'), {
    linha: 0.95,
    entrar: () => gsap.to(ano, { yPercent: 0, autoAlpha: 1, duration: 1.2, ease: 'se-out', stagger: 0.1 }),
    sair: () => gsap.to(ano, { yPercent: 30, autoAlpha: 0, duration: 0.45, ease: 'se-in' }),
  });
}

// ---------------------------------------------------------------- serviços
export function servicos({ lenis }) {
  const secao = document.querySelector('.servicos');
  const coluna = document.querySelector('.servicos__coluna');
  const textura = document.querySelector('.servicos__textura');
  const S = [...document.querySelectorAll('.servico')];

  // textura: a frase da casa repetida em coluna, com o pé embaralhando
  const base = document.querySelector('.casa__frase')?.textContent.trim() ?? '';
  textura.textContent = Array(14).fill(base).join(' ');
  const SIMB = 'abcdefghijklmnopqrstuvwxyz0123456789.,:;';
  const textoBase = textura.textContent;
  let embaralha = 0;
  function trocar() {
    // os últimos ~260 caracteres viram outros, como dado sendo lido
    const n = textoBase.length, ini = n - 260;
    let out = textoBase.slice(0, ini);
    for (let i = ini; i < n; i++) out += textoBase[i] === ' ' || Math.random() < 0.5 ? textoBase[i] : SIMB[(Math.random() * SIMB.length) | 0];
    textura.textContent = out;
  }

  // desktop: os serviços entram aos pares ([Custódia, Pix] e [Crédito, Prova de reservas]) com a coluna ainda na
  // tela; celular: um de cada vez, depois que a coluna passou. Por marco do progresso da cena, nos dois sentidos.
  const grupos = CELULAR ? S.map((s) => pecas([s], { y: 26 })) : [pecas([S[0], S[1]], { y: 26 }), pecas([S[2], S[3]], { y: 26 })];
  const limites = CELULAR ? [0.48, 0.61, 0.74, 0.87] : [0.4, 0.66];
  const fimColuna = CELULAR ? 0.46 : 1;
  const faixaNum = pecas([document.querySelector('.ticker')], { y: 12 });
  let fase = -1, faixaDentro = false;
  function quadro() {
    const r = secao.getBoundingClientRect(), H = innerHeight;
    const p = clamp(-r.top / (r.height - H));
    // a coluna sobe da base da tela até sair por cima, presa à rolagem (é desenho, não texto lido)
    const h = coluna.offsetHeight;
    const y = H * 1.02 - clamp(p / fimColuna) * (h + H * 1.15);
    coluna.style.transform = `translate3d(-50%, ${y.toFixed(1)}px, 0)`;
    let nova = -1;
    limites.forEach((l, i) => { if (p >= l) nova = i; });
    if (nova !== fase) {
      // o par novo só entra depois que o anterior saiu (a saída leva 0,32 s): os títulos nunca se sobrepõem
      if (fase >= 0) grupos[fase].sair();
      if (nova >= 0) grupos[nova].entrar(fase >= 0 ? 0.34 : 0.05, 0.12);
      fase = nova;
    }
    // a faixa de números entra quando a coluna já saiu
    const querFaixa = CELULAR ? nova >= 0 : nova === 1;
    if (querFaixa !== faixaDentro) { faixaDentro = querFaixa; querFaixa ? faixaNum.entrar(0.3) : faixaNum.sair(); }
    const perto = r.top < H && r.bottom > 0;
    if (perto && !REDUZIDO && ++embaralha % 5 === 0) trocar();
  }
  gsap.ticker.add(quadro);

  // faixa de números
  const fita = document.querySelector('.ticker__fita');
  const itens = [
    ['Reserva', '1,0000'], ['Liquidado hoje', 'R$ 5,21 bi'], ['Sob custódia', 'R$ 3,41 bi'],
    ['Real Sello em circulação', '1.204.923.520'], ['Bitcoin', 'R$ 612.408'], ['Último extrato', 'há 12 min'],
  ];
  const html = itens.map(([a, b]) => `<div class="ticker__item"><span class="rotulo">${a}</span><b>${b}</b></div>`).join('');
  fita.innerHTML = html + html.replace(/class="ticker__item"/g, 'class="ticker__item" aria-hidden="true"');
}

// ---------------------------------------------------------------- moeda e lastro
export function moeda({ letras }) {
  const sub = pecas([...document.querySelectorAll('.moeda__sub span')], { y: 10 });
  const secao = document.querySelector('.moeda');
  let dentro = false;
  gsap.ticker.add(() => {
    const r = secao.getBoundingClientRect(), H = innerHeight;
    const p = clamp(-r.top / (r.height - H));
    const v = r.top < H * 0.15 && p < 0.84; // as letras aparecem com a cena presa e somem antes da queda
    if (v === dentro) return;
    dentro = v;
    if (v) { letras?.entrar(0.05); sub.entrar(0.35, 0.05); } else { letras?.sair(); sub.sair(); }
  });
}

export function lastro() {
  const blocos = pecas([...document.querySelectorAll('.lastro__esq, .lastro__dir, .lastro__pe')], { y: 18 });
  const titulo = linhas(document.querySelector('.lastro__titulo'));
  const conts = [...document.querySelectorAll('.lastro .contador')].map((el) => contador(el, { dur: 2.2 }));
  const tracos = [...document.querySelectorAll('.lastro .tracos')];
  gsap.set(tracos, { '--s': 0 });
  marco(document.querySelector('.lastro__palco'), {
    linha: 0.55,
    entrar: () => {
      blocos.entrar(0, 0.1); titulo.entrar(0.2);
      conts.forEach((c, i) => c.correr(0.25 + i * 0.08));
      gsap.to(tracos, { '--s': 1, duration: 1.6, ease: 'se-out', delay: 0.4, stagger: 0.15 });
    },
    sair: () => { blocos.sair(); titulo.sair(); conts.forEach((c) => c.zerar()); gsap.to(tracos, { '--s': 0, duration: 0.3 }); },
  });
  // o total segue subindo devagar, como um painel ao vivo
  const total = document.querySelector('.lastro__total .contador');
  let ate = Number(total.dataset.ate);
  const palco = document.querySelector('.lastro__palco');
  setInterval(() => {
    if (REDUZIDO) return;
    const r = palco.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight) return;
    ate += Math.round(Math.random() * 400 + 60);
    if (gsap.isTweening(total)) return;
    total.textContent = brl(ate);
  }, 1400);
}

// ---------------------------------------------------------------- cofre
export function cofre() {
  const topo = linhas(document.querySelector('.cofre__titulo'));
  const lados = pecas([...document.querySelectorAll('.cofre__lado, .cofre__sub')], { y: 14 });
  marco(document.querySelector('.cofre__topo'), { linha: 0.8, entrar: () => { topo.entrar(); lados.entrar(0.25); }, sair: () => { topo.sair(); lados.sair(); } });
  const E = [...document.querySelectorAll('.escudo')];
  const conts = E.map((e) => contador(e.querySelector('.contador'), { dur: 1.9 }));
  gsap.set(E, { autoAlpha: 0, yPercent: REDUZIDO ? 0 : 14 });
  marco(document.querySelector('.escudos'), {
    linha: 0.88,
    entrar: () => {
      E.forEach((e, i) => gsap.to(e, { autoAlpha: 1, yPercent: 0, duration: 1.1, ease: 'se-out', delay: i * 0.09 }));
      conts.forEach((c, i) => c.correr(0.2 + i * 0.09));
    },
    sair: () => { gsap.to(E, { autoAlpha: 0, yPercent: 14, duration: 0.4, ease: 'se-in' }); conts.forEach((c) => c.zerar()); },
  });
}

// ---------------------------------------------------------------- fecho
export function fecho() {
  const titulo = linhas(document.querySelector('.fecho__titulo'));
  const resto = pecas([...document.querySelectorAll('.fecho__lado, .fecho__grade > div, .fecho__legal')], { y: 16 });
  marco(document.querySelector('.fecho__corpo'), { linha: 0.82, entrar: () => { titulo.entrar(); resto.entrar(0.2, 0.06); }, sair: () => { titulo.sair(); resto.sair(); } });
  const mono = [...document.querySelectorAll('.fecho__s, .fecho__o')];
  gsap.set(mono, { yPercent: 110 });
  marco(document.querySelector('.fecho__mono'), {
    linha: 0.98,
    entrar: () => gsap.to(mono, { yPercent: 14, duration: 1.2, ease: 'se-out', stagger: 0.08 }),
    sair: () => gsap.to(mono, { yPercent: 110, duration: 0.5, ease: 'se-in' }),
  });
}
