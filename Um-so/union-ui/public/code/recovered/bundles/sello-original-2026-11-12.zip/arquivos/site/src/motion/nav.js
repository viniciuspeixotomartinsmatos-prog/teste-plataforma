// Navegação: o tom (claro/escuro) segue o fundo que está debaixo da barra; o segundo bloco diz em que parte da
// página você está (o nome troca subindo); o menu de ladrilhos abre e fecha (Esc, clique fora, foco preso); os links
// rolam até a seção pelo Lenis.
import gsap from 'gsap';

export function nav({ lenis }) {
  const html = document.documentElement;
  const barra = document.querySelector('.barra');
  const botao = barra.querySelector('.barra__menu');
  const rotulo = barra.querySelector('.barra__secao');
  const menu = document.getElementById('menu');
  const secoes = [...document.querySelectorAll('main > section, main > footer, main > .passagem')];

  // ---- tom e seção ----
  let tomAtual = '', secaoAtual = rotulo.textContent.trim();
  function olhar() {
    const y = innerHeight - Math.max(14, innerHeight * 0.026) - 20; // a altura da barra
    let tom = 'claro', nome = secaoAtual;
    for (const s of secoes) {
      const r = s.getBoundingClientRect();
      if (r.top <= y && r.bottom > y) {
        if (s.classList.contains('passagem')) tom = (y - r.top) / r.height < 0.5 ? s.dataset.de : s.dataset.para;
        else {
          tom = s.dataset.temaTopo && y - r.top < innerHeight * 0.24 ? s.dataset.temaTopo : s.dataset.tema || 'claro';
          nome = s.dataset.secao || nome;
        }
        break;
      }
    }
    // o logo e o "Entrar" ficam no alto: o tom deles é o do fundo no topo da tela
    let tomTopo = 'claro';
    for (const s of secoes) {
      const r = s.getBoundingClientRect();
      if (r.top <= 30 && r.bottom > 30) {
        tomTopo = s.classList.contains('passagem') ? ((30 - r.top) / r.height < 0.5 ? s.dataset.de : s.dataset.para) : (s.dataset.tema || 'claro');
        break;
      }
    }
    if (tom !== tomAtual) { tomAtual = tom; html.classList.toggle('tema-escuro', tom === 'escuro'); }
    html.classList.toggle('topo-escuro', tomTopo === 'escuro');
    if (nome !== secaoAtual) trocarNome(nome);
  }
  function trocarNome(nome) {
    secaoAtual = nome;
    // o nome é um .rolo (rola no hover, como o botão); o novo entra subindo por baixo do velho
    const velho = rotulo.querySelector('.rolo:last-child');
    const novo = Object.assign(document.createElement('span'), { className: 'rolo', textContent: nome });
    novo.dataset.txt = nome;
    rotulo.append(novo);
    gsap.fromTo(novo, { yPercent: 0 }, { yPercent: -100, duration: 0.6, ease: 'se-out' });
    gsap.to(velho, { yPercent: -100, duration: 0.6, ease: 'se-out', onComplete: () => { velho.remove(); gsap.set(novo, { yPercent: 0 }); } });
  }
  lenis ? lenis.on('scroll', olhar) : addEventListener('scroll', olhar, { passive: true });
  addEventListener('resize', olhar);
  olhar();

  // ---- rolar até a seção ----
  function ir(id) {
    const alvo = document.querySelector(id);
    if (!alvo) return;
    const y = id === '#topo' ? 0 : alvo.getBoundingClientRect().top + (lenis ? lenis.scroll : scrollY);
    if (lenis) lenis.scrollTo(y, { duration: 1.8, easing: (t) => 1 - Math.pow(1 - t, 4), force: true });
    else scrollTo({ top: y, behavior: 'smooth' });
  }
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const id = a.getAttribute('href');
    if (id.length < 2) return;
    e.preventDefault();
    if (aberto) fechar(false);
    ir(id);
  });

  // ---- menu de ladrilhos ----
  let aberto = false;
  const links = () => [...menu.querySelectorAll('a')];
  function abrir() {
    aberto = true;
    menu.hidden = false;
    requestAnimationFrame(() => requestAnimationFrame(() => menu.classList.add('is-aberto')));
    botao.setAttribute('aria-expanded', 'true');
    lenis?.stop();
    setTimeout(() => links()[0]?.focus({ preventScroll: true }), 80);
  }
  function fechar(devolverFoco = true) {
    aberto = false;
    menu.classList.remove('is-aberto');
    botao.setAttribute('aria-expanded', 'false');
    lenis?.start();
    setTimeout(() => { if (!aberto) menu.hidden = true; }, 650);
    if (devolverFoco) botao.focus({ preventScroll: true });
  }
  botao.addEventListener('click', () => (aberto ? fechar() : abrir()));
  menu.querySelector('[data-fecha]').addEventListener('click', () => fechar());
  addEventListener('keydown', (e) => {
    if (!aberto) return;
    if (e.key === 'Escape') { fechar(); return; }
    if (e.key === 'Tab') {
      // foco preso entre os ladrilhos e o botão do menu
      const itens = [...links(), botao];
      const i = itens.indexOf(document.activeElement);
      e.preventDefault();
      itens[(i + (e.shiftKey ? -1 : 1) + itens.length) % itens.length].focus();
    }
  });
}
