// A águia de cromo: a malha inflada gerada por fonte/brasao.mjs, com material de metal polido que reflete o estúdio
// (palco.js). A pose vem de fora (diretor.js): centro e altura em px de tela, giro e opacidade. A mola do cursor
// inclina a peça na direção do mouse e passa um pouco do ponto antes de assentar.
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import { REDUZIDO, TOQUE } from '../motion/ease.js';

const URL_BRASAO = `${import.meta.env.BASE_URL}3d/brasao.glb`;

export async function criarBrasao(palco, paleta) {
  const { THREE } = palco;
  const gltf = await new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync(URL_BRASAO);
  let malha = null;
  gltf.scene.traverse((o) => { if (o.isMesh && !malha) malha = o; });
  malha.geometry.computeBoundingBox();
  const caixa = malha.geometry.boundingBox;
  const altura = caixa.max.y - caixa.min.y;

  malha.material = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(paleta.cromo),
    metalness: 1,
    roughness: 0.2,
    envMapIntensity: 1.3,
    iridescence: 0.1,
    iridescenceIOR: 1.45,
    iridescenceThicknessRange: [160, 420],
  });
  malha.frustumCulled = false;

  const piv = new THREE.Group(); // a pose (posição e escala)
  const giro = new THREE.Group(); // giro da cena + mola do cursor
  giro.add(malha);
  piv.add(giro);
  piv.visible = false;
  palco.cena.add(piv);

  // pose pedida
  const pose = { x: innerWidth / 2, y: innerHeight * 0.7, h: innerHeight * 0.5, yaw: 0, pitch: 0, roll: 0, opacidade: 1, visivel: false };
  // mola do cursor (inclinação): posição + velocidade, pouco amortecida
  const mola = { x: 0, y: 0, vx: 0, vy: 0, ax: 0, ay: 0 };
  let ultimo = performance.now(), ocioso = 0;
  if (!TOQUE && !REDUZIDO) {
    addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse') return;
      mola.ax = (e.clientX / innerWidth) * 2 - 1;
      mola.ay = (e.clientY / innerHeight) * 2 - 1;
    }, { passive: true });
  }

  const v = new THREE.Vector3();
  palco.aCadaQuadro(() => {
    const agora = performance.now(), dt = Math.min(0.05, (agora - ultimo) / 1000); ultimo = agora;
    const vis = pose.visivel && pose.opacidade > 0.01;
    if (vis !== piv.visible) { piv.visible = vis; palco.pedir(); } // sumiu ou voltou: redesenha uma vez
    if (!vis) return false;
    // mola: k 26, amortecimento 3,1 (passa do ponto e balança ~1,5 s)
    const K = 26, C = 3.1;
    mola.vx += (K * (mola.ax - mola.x) - C * mola.vx) * dt; mola.x += mola.vx * dt;
    mola.vy += (K * (mola.ay - mola.y) - C * mola.vy) * dt; mola.y += mola.vy * dt;
    // respiração de quem está parado no ar
    ocioso += dt;
    const resp = REDUZIDO ? 0 : 1;
    palco.mundo(pose.x, pose.y + Math.sin(ocioso * 0.9) * pose.h * 0.012 * resp, v);
    piv.position.copy(v);
    piv.scale.setScalar((pose.h * palco.k) / altura);
    giro.rotation.set(
      pose.pitch + mola.y * 0.16 + Math.sin(ocioso * 0.7) * 0.035 * resp,
      pose.yaw + mola.x * 0.32 + Math.sin(ocioso * 0.42) * 0.3 * resp,
      pose.roll + Math.sin(ocioso * 0.6 + 1) * 0.02 * resp,
    );
    const op = pose.opacidade;
    malha.material.transparent = op < 0.999;
    malha.material.opacity = op;
    return true; // a respiração e a mola não param enquanto a peça está na tela
  });

  return { pose, malha, altura, cor(c) { malha.material.color.set(c); palco.pedir(); } };
}
