// Abertura (~2,8 s): S · águia · O sobem no pé da tela preta, juntos à direita; se espalham (S para a esquerda, a
// águia para o meio, O fica à direita); uma janela pequena abre no meio com o hero já montado e cresce até a tela
// inteira, enquanto o monograma desce. Qualquer gesto (roda, toque, tecla, clique) acelera até o fim. Devolve uma
// promessa que resolve quando a janela começa a crescer (o hero entra junto).
import gsap from 'gsap';

export function abertura({ lenis, pronto: tudoPronto = Promise.resolve() }) {
  const html = document.documentElement;
  const el = document.querySelector('.abertura');
  if (!html.classList.contains('com-abertura') || !el) return tudoPronto.then(() => {});

  const [S, A, O] = el.querySelectorAll('.mono__peca');
  lenis?.stop();
  // a janela só abre com o 3D pronto (no máximo 6 s de espera: depois abre assim mesmo)
  let carregou = false;
  Promise.race([tudoPronto, new Promise((r) => setTimeout(r, 6000))]).then(() => { carregou = true; if (tl.paused()) tl.resume(); });
  const W = () => innerWidth;
  const margem = () => Math.max(20, innerWidth * 0.016);

  // posições: juntas à direita → espalhadas pela borda de baixo
  const lado = (e) => e.getBoundingClientRect().width;
  const juntas = () => {
    const ga = lado(A) * 0.04, total = lado(S) + lado(A) + lado(O) + ga * 2;
    const x0 = W() - margem() - total;
    return [x0, x0 + lado(S) + ga, x0 + lado(S) + lado(A) + ga * 2];
  };
  const espalhadas = () => [margem(), W() / 2 - lado(A) / 2, W() - margem() - lado(O)];

  const [js, ja, jo] = juntas();
  gsap.set(S, { x: js, yPercent: 105 });
  gsap.set(A, { x: ja, yPercent: 120 });
  gsap.set(O, { x: jo, yPercent: 105 });
  gsap.set([S, A, O], { opacity: 1 }); // nascem invisíveis no CSS: só aparecem já no lugar
  html.classList.add('abertura-viva');

  let pronto;
  const abriu = new Promise((r) => { pronto = r; });
  const [es, ea, eo] = espalhadas();
  const tl = gsap.timeline({ delay: 0.25, onComplete: fim });
  tl.to([S, A, O], { yPercent: 0, duration: 0.85, ease: 'se-out', stagger: 0.08 })
    .to(S, { x: es, duration: 1.0, ease: 'se-io' }, 0.95)
    .to(A, { x: ea, duration: 1.0, ease: 'se-io' }, 0.95)
    .to(O, { x: eo, duration: 1.0, ease: 'se-io' }, 0.95)
    .add(() => { if (!carregou) tl.pause(); }, 1.74)
    .to(el, { '--t': '46%', '--b': '46%', '--l': '46%', '--r': '46%', duration: 0.42, ease: 'se-out' }, 1.75)
    .add(() => pronto(), 2.1)
    .to(el, { '--t': '0%', '--b': '0%', '--l': '0%', '--r': '0%', duration: 1.05, ease: 'se-io' }, 2.15)
    .to([S, A, O], { yPercent: 115, duration: 0.7, ease: 'se-in', stagger: 0.04 }, 2.35);

  function acelera() { if (tl.isActive()) tl.timeScale(3.2); }
  const gestos = ['wheel', 'touchstart', 'keydown', 'pointerdown'];
  gestos.forEach((g) => addEventListener(g, acelera, { passive: true }));

  function fim() {
    gestos.forEach((g) => removeEventListener(g, acelera));
    html.classList.remove('com-abertura', 'abertura-viva');
    lenis?.start();
    pronto();
  }
  return abriu;
}
