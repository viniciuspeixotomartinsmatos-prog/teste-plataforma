# Receitas — Sello

O site tem uma imagem gerada só: o desenho da águia, que vira o logo, o emblema de cromo em 3D e o relevo das moedas. Todo o resto (o cromo, as moedas, os fios, os escudos) é código.

## A ordem

1. **O desenho** (`aguia.txt`): um gerador de imagem que aceite texto (ChatGPT/GPT Image, Midjourney, Ideogram, Flux ou outro). Peça em quadrado. Custo: uma imagem (centavos, ou dentro do plano).
   - Gere três ou quatro e escolha o de formas mais cheias, com recortes brancos separando as partes.
2. **Vetorizar** (só se for usar no logo do topo, na abertura e no favicon): o `potrace` transforma o PNG em SVG.
   - Converta o PNG para preto e branco puro (o desenho preto, o fundo branco) em formato PBM e rode `potrace desenho.pbm -s -t 40 -a 1.0 -O 0.4 -o desenho.svg`.
   - O emblema 3D não precisa do SVG: `npm run brasao` aceita o PNG direto.
3. **O emblema e as moedas:** `npm run brasao -- caminho/do/desenho.svg` (ou `.png`). Grava `public/3d/brasao.glb` e `public/3d/moeda-relevo.webp`.

## O que adaptar

- **Outro bicho ou objeto** (leão, onça, coruja, torre, chave, coroa): troque só a primeira frase do prompt e mantenha o resto (silhueta chapada, recortes brancos, nada fino demais, fundo branco, quadrado). Heráldico funciona porque já nasce em silhueta.
- **O logo da empresa no lugar do bicho:** não gere nada; use o SVG do logo (o guia, em "Material da pessoa", diz o que funciona melhor).
- **Sem 3D:** sem WebGL, o site mostra o desenho chapado com um degradê de prata nas mesmas vagas; para tirar o 3D de propósito, basta não criar o palco em `src/main.js`.
