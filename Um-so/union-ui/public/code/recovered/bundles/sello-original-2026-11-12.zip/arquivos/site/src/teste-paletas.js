// Seletor de paletas para teste (só com ?paletas na URL): uma fileira de amostras no alto da página; clicar (ou
// apertar 1 a 6) troca a paleta na hora, com o 3D junto. Não faz parte do site entregue.
import { PALETAS, aplicarPaleta, nomePaleta } from './paletas.js';

export function seletor({ palco, aguia, moedas }) {
  const nomes = Object.keys(PALETAS);
  const barra = document.createElement('div');
  barra.setAttribute('role', 'radiogroup');
  barra.setAttribute('aria-label', 'Paleta de teste');
  barra.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:95;display:flex;gap:6px;padding:6px;background:rgba(20,20,22,.82);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);font:500 12px/1 system-ui,sans-serif;color:#fff';
  const botoes = nomes.map((nome, i) => {
    const p = PALETAS[nome];
    const b = document.createElement('button');
    b.type = 'button';
    b.setAttribute('role', 'radio');
    b.innerHTML = `<i style="display:inline-block;width:14px;height:14px;margin-right:7px;vertical-align:-3px;background:${p.tema};box-shadow:inset 0 0 0 1px rgba(255,255,255,.35)"></i>${i + 1} ${p.nome}`;
    b.style.cssText = 'padding:8px 10px;color:inherit;font:inherit;cursor:pointer;background:transparent;border:0';
    b.addEventListener('click', () => trocar(nome));
    barra.append(b);
    return b;
  });
  document.body.append(barra);

  function marcar() {
    const atual = nomePaleta();
    botoes.forEach((b, i) => {
      const sim = nomes[i] === atual;
      b.setAttribute('aria-checked', String(sim));
      b.style.background = sim ? 'rgba(255,255,255,.18)' : 'transparent';
    });
  }
  function trocar(nome) {
    const p = aplicarPaleta(nome);
    palco.trocarEstudio(p.estudio);
    aguia.cor(p.cromo);
    moedas.trocarTons(p.moedas, p.irid);
    const url = new URL(location.href);
    url.searchParams.set('paleta', nome);
    history.replaceState(null, '', url);
    dispatchEvent(new Event('resize')); // a navegação recalcula o tom
    marcar();
  }
  addEventListener('keydown', (e) => {
    const n = Number(e.key);
    if (n >= 1 && n <= nomes.length && !e.metaKey && !e.ctrlKey && !e.altKey) trocar(nomes[n - 1]);
  });
  marcar();
}
