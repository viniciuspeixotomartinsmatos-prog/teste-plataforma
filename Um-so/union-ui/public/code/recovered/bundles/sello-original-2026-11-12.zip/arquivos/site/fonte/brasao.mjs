// Brasão 3D: transforma o desenho chapado da marca (SVG ou PNG) numa peça de cromo "inflada", como um balão de
// metal, e gera o relevo da face das moedas com o mesmo desenho.
//
//   npm run brasao                      usa fonte/aguia.svg
//   npm run brasao -- logo.svg          qualquer desenho chapado: SVG, ou PNG com fundo transparente ou branco
//
// Saída:
//   public/3d/brasao.glb         malha fechada (frente e verso), comprimida com meshopt (~200 KB)
//   public/3d/moeda-relevo.webp  mapa de normais da face da moeda (borda, contas e o desenho em relevo baixo)
//
// Como funciona: o desenho vira uma máscara; a borda é traçada com precisão de subpixel (marching squares); dentro
// dela resolvemos a equação de Poisson (como uma película sob pressão), o que dá uma "altura" que cresce suave da
// borda para o miolo: partes finas viram tubos redondos e partes largas viram cúpulas achatadas. A malha nasce de
// pontos densos perto da borda e espaçados no miolo, e as normais saem da própria equação (lisas, sem facetas).
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import Delaunator from 'delaunator';
import { Document, NodeIO } from '@gltf-transform/core';
import { EXTMeshoptCompression, KHRMeshQuantization } from '@gltf-transform/extensions';
import { reorder, quantize, meshopt } from '@gltf-transform/functions';
import { MeshoptEncoder } from 'meshoptimizer';

const raiz = join(dirname(fileURLToPath(import.meta.url)), '..');
const entrada = process.argv[2] ?? join(raiz, 'fonte/aguia.svg');

// ---- ajustes ---------------------------------------------------------------------------------------------------
const N = 1024;        // grade de trabalho (px); o desenho cabe em N - 2P
const P = 20;          // folga em volta
const A = 2.0;        // redondeza: ~1,41 faz das partes finas tubos de seção redonda
const TETO = 170;       // altura máxima aproximada das partes largas (px da grade): achata as cúpulas grandes
const PASSO_BORDA = 2.2; // espaço entre pontos na borda (px)
const PASSO_MIOLO = 8;   // espaço entre pontos no miolo (px)
// ----------------------------------------------------------------------------------------------------------------

async function mascara(arquivo) {
  let img;
  if (arquivo.toLowerCase().endsWith('.svg')) {
    const svg = Buffer.from((await readFile(arquivo, 'utf8')).replace(/currentColor/g, '#000'));
    const { width, height } = await sharp(svg).metadata();
    img = sharp(svg, { density: Math.min(2400, (72 * 2048) / Math.max(width, height)) });
  } else img = sharp(arquivo);
  const meta = await img.metadata();
  let base = img.ensureAlpha();
  // PNG sem transparência: o escuro é o desenho
  const { channels } = await base.clone().stats();
  const temAlfa = channels[3].min < 250;
  const quadro = N - 2 * P;
  const fundo = temAlfa ? { r: 0, g: 0, b: 0, alpha: 0 } : { r: 255, g: 255, b: 255, alpha: 1 };
  const { data } = await base
    .resize(quadro, quadro, { fit: 'contain', background: fundo, kernel: 'lanczos3' })
    .extend({ top: P, bottom: P, left: P, right: P, background: fundo })
    .raw().toBuffer({ resolveWithObject: true });
  const cob = new Float32Array(N * N);
  for (let i = 0; i < N * N; i++) {
    const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2], a = data[i * 4 + 3] / 255;
    cob[i] = temAlfa ? a : 1 - (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  }
  console.log(`desenho: ${arquivo} (${meta.width}×${meta.height}), ${temAlfa ? 'transparência' : 'escuro sobre claro'}`);
  return cob;
}

// amostra bilinear de um campo N×N
function amostra(f, x, y, n = N) {
  x = Math.min(n - 1.001, Math.max(0, x)); y = Math.min(n - 1.001, Math.max(0, y));
  const x0 = x | 0, y0 = y | 0, tx = x - x0, ty = y - y0, i = y0 * n + x0;
  return (f[i] * (1 - tx) + f[i + 1] * tx) * (1 - ty) + (f[i + n] * (1 - tx) + f[i + n + 1] * tx) * ty;
}

// borda em subpixel: marching squares na cobertura (isolinha 0,5), segmentos encadeados em laços fechados
function contornos(cob) {
  const iso = 0.5, prox = new Map(), pt = new Map();
  const v = (x, y) => cob[y * N + x];
  const ponto = (k, x0, y0, x1, y1) => {
    if (!pt.has(k)) { const a = v(x0, y0), b = v(x1, y1), t = (iso - a) / (b - a); pt.set(k, [x0 + (x1 - x0) * t, y0 + (y1 - y0) * t]); }
    return k;
  };
  for (let y = 0; y < N - 1; y++) for (let x = 0; x < N - 1; x++) {
    const a = v(x, y) > iso, b = v(x + 1, y) > iso, c = v(x + 1, y + 1) > iso, d = v(x, y + 1) > iso;
    const caso = (a ? 1 : 0) | (b ? 2 : 0) | (c ? 4 : 0) | (d ? 8 : 0);
    if (caso === 0 || caso === 15) continue;
    const T = () => ponto(`h${x},${y}`, x, y, x + 1, y);
    const R = () => ponto(`v${x + 1},${y}`, x + 1, y, x + 1, y + 1);
    const B = () => ponto(`h${x},${y + 1}`, x, y + 1, x + 1, y + 1);
    const L = () => ponto(`v${x},${y}`, x, y, x, y + 1);
    const seg = (p, q) => prox.set(p, q); // o dentro fica à esquerda de p → q
    const meio = (v(x, y) + v(x + 1, y) + v(x + 1, y + 1) + v(x, y + 1)) / 4 > iso;
    switch (caso) {
      case 1: seg(T(), L()); break;
      case 2: seg(R(), T()); break;
      case 3: seg(R(), L()); break;
      case 4: seg(B(), R()); break;
      case 5: if (meio) { seg(B(), L()); seg(T(), R()); } else { seg(T(), L()); seg(B(), R()); } break;
      case 6: seg(B(), T()); break;
      case 7: seg(B(), L()); break;
      case 8: seg(L(), B()); break;
      case 9: seg(T(), B()); break;
      case 10: if (meio) { seg(L(), T()); seg(R(), B()); } else { seg(L(), B()); seg(R(), T()); } break;
      case 11: seg(R(), B()); break;
      case 12: seg(L(), R()); break;
      case 13: seg(T(), R()); break;
      case 14: seg(L(), T()); break;
    }
  }
  const lacos = [], visto = new Set();
  for (const ini of prox.keys()) {
    if (visto.has(ini)) continue;
    const laco = []; let k = ini;
    while (k !== undefined && !visto.has(k)) { visto.add(k); laco.push(pt.get(k)); k = prox.get(k); }
    if (laco.length > 8) lacos.push(laco);
  }
  return lacos;
}

const area = (l) => { let s = 0; for (let i = 0; i < l.length; i++) { const [x0, y0] = l[i], [x1, y1] = l[(i + 1) % l.length]; s += x0 * y1 - x1 * y0; } return s / 2; };

// suaviza um pouco (tira o serrilhado da rasterização) e reamostra com passo fixo
function reamostra(l, passo) {
  let p = l.map((q) => q.slice());
  for (let it = 0; it < 2; it++) p = p.map((q, i) => { const a = p[(i - 1 + p.length) % p.length], b = p[(i + 1) % p.length]; return [q[0] * 0.5 + (a[0] + b[0]) * 0.25, q[1] * 0.5 + (a[1] + b[1]) * 0.25]; });
  const n0 = p.length, cum = new Float64Array(n0 + 1);
  for (let i = 0; i < n0; i++) { const a = p[i], b = p[(i + 1) % n0]; cum[i + 1] = cum[i] + Math.hypot(b[0] - a[0], b[1] - a[1]); }
  const total = cum[n0], n = Math.max(6, Math.round(total / passo)), out = [];
  let j = 0;
  for (let k = 0; k < n; k++) {
    const s = (k * total) / n;
    while (cum[j + 1] < s) j++;
    const a = p[j], b = p[(j + 1) % n0], seg = cum[j + 1] - cum[j], t = seg ? (s - cum[j]) / seg : 0;
    out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
  }
  return out;
}

// distância euclidiana até a borda (Felzenszwalb), em px
function distancia(dentro) {
  const INF = 1e10, f = new Float64Array(N * N);
  for (let i = 0; i < N * N; i++) f[i] = dentro[i] ? INF : 0;
  const lin = new Float64Array(N), d = new Float64Array(N), v = new Int32Array(N), z = new Float64Array(N + 1);
  const dt = () => {
    let k = 0; v[0] = 0; z[0] = -Infinity; z[1] = Infinity;
    for (let q = 1; q < N; q++) {
      let s = ((lin[q] + q * q) - (lin[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
      while (s <= z[k]) { k--; s = ((lin[q] + q * q) - (lin[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); }
      k++; v[k] = q; z[k] = s; z[k + 1] = Infinity;
    }
    k = 0;
    for (let q = 0; q < N; q++) { while (z[k + 1] < q) k++; d[q] = (q - v[k]) * (q - v[k]) + lin[v[k]]; }
  };
  for (let x = 0; x < N; x++) { for (let y = 0; y < N; y++) lin[y] = f[y * N + x]; dt(); for (let y = 0; y < N; y++) f[y * N + x] = d[y]; }
  for (let y = 0; y < N; y++) { for (let x = 0; x < N; x++) lin[x] = f[y * N + x]; dt(); for (let x = 0; x < N; x++) f[y * N + x] = d[x]; }
  const out = new Float32Array(N * N);
  for (let i = 0; i < N * N; i++) out[i] = Math.sqrt(f[i]);
  return out;
}

// Poisson (∇²φ = -1 dentro, φ = 0 fora), do grosso para o fino com SOR
function poisson(dentro) {
  const niveis = []; for (let m = N; m >= 64; m >>= 1) niveis.unshift(m);
  let phi = null, mAnt = 0;
  for (const m of niveis) {
    const h = N / m, ins = new Uint8Array(m * m);
    for (let y = 0; y < m; y++) for (let x = 0; x < m; x++) {
      let s = 0; for (let j = 0; j < h; j++) for (let i = 0; i < h; i++) s += dentro[(y * h + j) * N + x * h + i];
      ins[y * m + x] = s * 2 >= h * h ? 1 : 0;
    }
    const p = new Float32Array(m * m);
    if (phi) for (let y = 0; y < m; y++) for (let x = 0; x < m; x++) if (ins[y * m + x]) p[y * m + x] = amostra(phi, (x + 0.5) / 2 - 0.5, (y + 0.5) / 2 - 0.5, mAnt);
    const w = 1.92, it = m <= 128 ? 600 : m <= 256 ? 300 : m <= 512 ? 160 : 90, h2 = h * h;
    for (let k = 0; k < it; k++) for (let y = 1; y < m - 1; y++) for (let x = 1; x < m - 1; x++) {
      const i = y * m + x; if (!ins[i]) continue;
      const nv = (p[i - 1] + p[i + 1] + p[i - m] + p[i + m] + h2) * 0.25; p[i] += w * (nv - p[i]);
    }
    phi = p; mAnt = m;
  }
  return phi;
}

// altura a partir de φ: tubos redondos nas partes finas, cúpulas achatadas nas largas
const alturaR = (phi) => A * Math.sqrt(Math.max(phi, 0));
const altura = (phi) => { const r = alturaR(phi); return r / (1 + r / TETO); };
const dAltura = (phi) => { const r = alturaR(phi); const s = Math.sqrt(Math.max(phi, 1e-6)); return (A / (2 * s)) / ((1 + r / TETO) ** 2); };

async function main() {
  console.time('brasão');
  const cob = await mascara(entrada);
  const dentro = new Uint8Array(N * N);
  let x0 = N, x1 = 0, y0 = N, y1 = 0;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (cob[y * N + x] > 0.5) { dentro[y * N + x] = 1; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }

  const edt = distancia(dentro);
  const phi = poisson(dentro);
  // gradiente de φ (diferenças centrais)
  const gx = new Float32Array(N * N), gy = new Float32Array(N * N);
  for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) { const i = y * N + x; gx[i] = (phi[i + 1] - phi[i - 1]) / 2; gy[i] = (phi[i + N] - phi[i - N]) / 2; }

  // ---- pontos ----
  const lacos = contornos(cob).filter((l) => Math.abs(area(l)) > 12).map((l) => reamostra(l, PASSO_BORDA));
  const pts = [], ehBorda = [];
  const CEL = 2, grade = new Map();
  const chave = (x, y) => `${Math.floor(x / CEL)},${Math.floor(y / CEL)}`;
  const perto = (x, y, r) => {
    const cx = Math.floor(x / CEL), cy = Math.floor(y / CEL), k = Math.ceil(r / CEL);
    for (let j = -k; j <= k; j++) for (let i = -k; i <= k; i++) for (const q of grade.get(`${cx + i},${cy + j}`) ?? []) if ((pts[q][0] - x) ** 2 + (pts[q][1] - y) ** 2 < r * r) return true;
    return false;
  };
  const poe = (x, y, borda) => { const k = chave(x, y); if (!grade.has(k)) grade.set(k, []); grade.get(k).push(pts.length); pts.push([x, y]); ehBorda.push(borda); };
  for (const l of lacos) for (const [x, y] of l) poe(x, y, true);
  const nBorda = pts.length;
  // raio mínimo entre pontos conforme a distância até a borda (denso perto dela, onde a curva é forte)
  const raio = (d) => Math.min(PASSO_MIOLO, Math.max(1.3, 0.9 + d * 0.62));
  // anéis logo abaixo da borda, seguindo para dentro pelo gradiente de φ
  for (const dk of [0.5, 1.5, 3.2, 5.6]) {
    for (const l of lacos) for (let k = 0; k < l.length; k++) {
      const [x, y] = l[k];
      const ax = amostra(gx, x, y), ay = amostra(gy, x, y), g = Math.hypot(ax, ay) || 1;
      const px = x + (ax / g) * dk, py = y + (ay / g) * dk;
      if (amostra(cob, px, py) < 0.55 || amostra(edt, px, py) < dk * 0.6) continue;
      if (!perto(px, py, raio(dk) * 0.95)) poe(px, py, false);
    }
  }
  // miolo: grade hexagonal com tremor
  const LH = PASSO_MIOLO * 0.866;
  for (let y = y0, lin = 0; y <= y1; y += LH, lin++) for (let x = x0 + (lin % 2) * PASSO_MIOLO * 0.5; x <= x1; x += PASSO_MIOLO) {
    const d = amostra(edt, x, y);
    if (d < 7 || amostra(cob, x, y) < 0.6) continue;
    if (!perto(x, y, raio(d))) poe(x, y, false);
  }
  // reforço entre os anéis e o miolo
  for (let y = y0; y <= y1; y += 2.5) for (let x = x0; x <= x1; x += 2.5) {
    const d = amostra(edt, x, y); if (d < 2 || d > 9 || amostra(cob, x, y) < 0.6) continue;
    if (!perto(x, y, raio(d))) poe(x, y, false);
  }

  // ---- triângulos ----
  const del = Delaunator.from(pts);
  const tri = [];
  const dentroSeg = (a, b) => { for (const t of [0.2, 0.4, 0.5, 0.6, 0.8]) if (amostra(cob, a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t) < 0.4) return false; return true; };
  for (let t = 0; t < del.triangles.length; t += 3) {
    const a = del.triangles[t], b = del.triangles[t + 1], c = del.triangles[t + 2];
    const A_ = pts[a], B_ = pts[b], C_ = pts[c];
    const cx = (A_[0] + B_[0] + C_[0]) / 3, cy = (A_[1] + B_[1] + C_[1]) / 3;
    if (amostra(cob, cx, cy) < 0.5) continue;
    if (!dentroSeg(A_, B_) || !dentroSeg(B_, C_) || !dentroSeg(C_, A_)) continue;
    tri.push(a, b, c);
  }

  // ---- malha: frente (z+) e verso (z-) dividindo os pontos da borda ----
  const nI = pts.length - nBorda, nV = nBorda + 2 * nI;
  const pos = new Float32Array(nV * 3), nor = new Float32Array(nV * 3);
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, esc = 2 / Math.max(x1 - x0, y1 - y0); // cabe em [-1, 1]
  let zMax = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x, y] = pts[i];
    const ax = amostra(gx, x, y), ay = amostra(gy, x, y);
    const X = (x - cx) * esc, Y = -(y - cy) * esc;
    if (ehBorda[i]) {
      const g = Math.hypot(ax, ay) || 1;
      pos.set([X, Y, 0], i * 3); nor.set([-ax / g, ay / g, 0], i * 3);
      continue;
    }
    const f = amostra(phi, x, y), H = altura(f), dH = dAltura(f);
    zMax = Math.max(zMax, H * esc);
    let nx = -dH * ax, ny = dH * ay, nz = 1; const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
    const iF = i, iB = nI + i;
    pos.set([X, Y, H * esc], iF * 3); nor.set([nx, ny, nz], iF * 3);
    pos.set([X, Y, -H * esc], iB * 3); nor.set([nx, ny, -nz], iB * 3);
  }
  // índices: frente usa i; verso usa i + nI para pontos do miolo e i para os da borda, com a ordem invertida
  const nTri = tri.length / 3, idx = new Uint32Array(tri.length * 2);
  const vb = (i) => (i < nBorda ? i : i + nI);
  for (let t = 0; t < nTri; t++) {
    const a = tri[t * 3], b = tri[t * 3 + 1], c = tri[t * 3 + 2];
    // frente anti-horária vista de +z (no 3D o y sobe; na imagem desce)
    const [ax_, ay_] = pts[a], [bx_, by_] = pts[b], [cx_, cy_] = pts[c];
    const anti = (bx_ - ax_) * (-(cy_ - ay_)) - (-(by_ - ay_)) * (cx_ - ax_) > 0;
    if (anti) { idx.set([a, b, c], t * 3); idx.set([vb(a), vb(c), vb(b)], (nTri + t) * 3); }
    else { idx.set([a, c, b], t * 3); idx.set([vb(a), vb(b), vb(c)], (nTri + t) * 3); }
  }
  console.log(`pontos ${pts.length} (borda ${nBorda}), vértices ${nV}, triângulos ${nTri * 2}, espessura máx. ${(2 * zMax).toFixed(3)} (largura 2)`);

  // ---- glb ----
  const doc = new Document();
  const buf = doc.createBuffer();
  const prim = doc.createPrimitive()
    .setAttribute('POSITION', doc.createAccessor().setType('VEC3').setArray(pos).setBuffer(buf))
    .setAttribute('NORMAL', doc.createAccessor().setType('VEC3').setArray(nor).setBuffer(buf))
    .setIndices(doc.createAccessor().setType('SCALAR').setArray(nV < 65536 ? Uint16Array.from(idx) : idx).setBuffer(buf));
  const mesh = doc.createMesh('brasao').addPrimitive(prim);
  doc.createScene('cena').addChild(doc.createNode('brasao').setMesh(mesh));
  doc.createExtension(EXTMeshoptCompression).setRequired(true).setEncoderOptions({ method: EXTMeshoptCompression.EncoderMethod.QUANTIZE });
  await MeshoptEncoder.ready;
  await doc.transform(reorder({ encoder: MeshoptEncoder }), quantize({ quantizePosition: 14, quantizeNormal: 8 }), meshopt({ encoder: MeshoptEncoder, level: 'medium' }));
  const io = new NodeIO().registerExtensions([EXTMeshoptCompression, KHRMeshQuantization]).registerDependencies({ 'meshopt.encoder': MeshoptEncoder });
  const glb = await io.writeBinary(doc);
  await mkdir(join(raiz, 'public/3d'), { recursive: true });
  await writeFile(join(raiz, 'public/3d/brasao.glb'), glb);
  console.log(`public/3d/brasao.glb ${(glb.length / 1024).toFixed(0)} KB`);

  await moeda({ phi, gx, gy, cob, x0, x1, y0, y1 });
  console.timeEnd('brasão');
}

// ---- moeda: mapa de normais da face (borda alta, anel de contas e o desenho em relevo baixo) ----
async function moeda({ phi, cob, x0, x1, y0, y1 }) {
  const M = 1024, c = M / 2, R = M / 2 - 3;
  const h = new Float32Array(M * M);
  const lado = Math.max(x1 - x0, y1 - y0), caixa = 0.62 * 2 * R; // o desenho ocupa ~62% do diâmetro
  const s = lado / caixa, ox = (x0 + x1) / 2, oy = (y0 + y1) / 2;
  let fMax = 0; for (let i = 0; i < N * N; i++) fMax = Math.max(fMax, altura(phi[i]));
  const CONTAS = 96, rConta = 0.0135 * R, rAnel = 0.855 * R;
  for (let y = 0; y < M; y++) for (let x = 0; x < M; x++) {
    const dx = x - c, dy = y - c, r = Math.hypot(dx, dy) / R;
    let v = 0;
    if (r >= 0.925) v = Math.max(0, 1 - ((r - 0.925) / 0.075 - 0.45) ** 2 / 0.3025) * 0.95 + 0.05; // aro arredondado
    else {
      // contas
      const ang = Math.atan2(dy, dx), k = Math.round((ang / (2 * Math.PI)) * CONTAS), a = (k / CONTAS) * 2 * Math.PI;
      const bx = c + Math.cos(a) * rAnel, by = c + Math.sin(a) * rAnel, db = Math.hypot(x - bx, y - by) / rConta;
      if (db < 1) v = Math.sqrt(1 - db * db) * 0.42;
      // desenho
      const gxp = ox + dx * s, gyp = oy + dy * s;
      if (gxp > 1 && gyp > 1 && gxp < N - 2 && gyp < N - 2 && amostra(cob, gxp, gyp) > 0.02) v = Math.max(v, (altura(amostra(phi, gxp, gyp)) / fMax) * 0.55);
    }
    h[y * M + x] = v;
  }
  // suaviza um passo (tira o degrau do pixel) e calcula as normais
  const out = Buffer.alloc(M * M * 3), K = 38;
  const H = (x, y) => h[Math.min(M - 1, Math.max(0, y)) * M + Math.min(M - 1, Math.max(0, x))];
  for (let y = 0; y < M; y++) for (let x = 0; x < M; x++) {
    const dx = (H(x + 1, y - 1) + 2 * H(x + 1, y) + H(x + 1, y + 1) - H(x - 1, y - 1) - 2 * H(x - 1, y) - H(x - 1, y + 1)) / 8;
    const dy = (H(x - 1, y + 1) + 2 * H(x, y + 1) + H(x + 1, y + 1) - H(x - 1, y - 1) - 2 * H(x, y - 1) - H(x + 1, y - 1)) / 8;
    // espaço tangente do three.js: x para a direita, y para cima (a imagem tem y para baixo)
    let nx = -dx * K, ny = dy * K, nz = 1; const l = Math.hypot(nx, ny, nz);
    const i = (y * M + x) * 3; out[i] = Math.round((nx / l * 0.5 + 0.5) * 255); out[i + 1] = Math.round((ny / l * 0.5 + 0.5) * 255); out[i + 2] = Math.round((nz / l * 0.5 + 0.5) * 255);
  }
  await sharp(out, { raw: { width: M, height: M, channels: 3 } }).webp({ quality: 92 }).toFile(join(raiz, 'public/3d/moeda-relevo.webp'));
  console.log('public/3d/moeda-relevo.webp');
}

main();
