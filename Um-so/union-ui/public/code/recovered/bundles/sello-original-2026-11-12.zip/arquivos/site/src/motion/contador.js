// Números que contam até o valor, no formato brasileiro (1.204.660.000 e 18.402,51). Por tempo, nunca preso ao
// scroll: o marco dispara e o número corre ~1,6 s com a curva da marca.
import gsap from 'gsap';
import { REDUZIDO } from './ease.js';

const formatos = new Map();
export function brl(v, casas = 0) {
  if (!formatos.has(casas)) formatos.set(casas, new Intl.NumberFormat('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas }));
  return formatos.get(casas).format(v);
}

export function contador(el, { de, ate, casas, dur = 1.7 } = {}) {
  de = de ?? Number(el.dataset.de ?? 0);
  ate = ate ?? Number(el.dataset.ate ?? 0);
  casas = casas ?? Number(el.dataset.casas ?? 0);
  const o = { v: de };
  el.textContent = brl(de, casas);
  let tw;
  return {
    correr(atraso = 0) {
      tw?.kill();
      if (REDUZIDO) { el.textContent = brl(ate, casas); return; }
      o.v = de;
      tw = gsap.to(o, { v: ate, duration: dur, delay: atraso, ease: 'se-out', onUpdate: () => { el.textContent = brl(o.v, casas); } });
    },
    zerar() { tw?.kill(); o.v = de; el.textContent = brl(de, casas); },
    ja() { tw?.kill(); el.textContent = brl(ate, casas); },
  };
}
