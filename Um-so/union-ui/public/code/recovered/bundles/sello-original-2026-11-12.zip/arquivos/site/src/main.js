// O CSS não entra por aqui: vai numa folha única ligada no <head> (src/styles/site.css), para a primeira pintura
// nunca mostrar a página crua.
import { criarScroll } from './motion/smooth.js';
import { criarGuia } from './motion/guia.js';
import { scrollbar } from './motion/scrollbar.js';
import './motion/rolando.js';
import { nav } from './motion/nav.js';
import { abertura } from './motion/abertura.js';
import * as secoes from './motion/secoes.js';
import { criarPalco } from './gl/palco.js';
import { criarBrasao } from './gl/brasao.js';
import { diretorAguia } from './gl/diretor.js';
import { criarMoedas } from './gl/moedas.js';
import { aplicarPaleta, nomePaleta, paletaAtual } from './paletas.js';

document.documentElement.classList.add('js');
aplicarPaleta(nomePaleta());
history.scrollRestoration = 'manual';

async function iniciar() {
  const lenis = criarScroll();
  if (import.meta.env.DEV) window.__lenis = lenis; // auditoria headless (só no npm run dev)
  criarGuia({ lenis });
  scrollbar({ lenis });
  nav({ lenis });
  const hero = secoes.hero();
  secoes.casa();
  secoes.servicos({ lenis });
  secoes.lastro();
  secoes.cofre();
  secoes.fecho();

  // o 3D nasce já, com a tela ainda preta da abertura; a janela só abre quando a águia está pronta
  const paleta = paletaAtual();
  const palco = criarPalco(document.querySelector('.palco'), paleta.estudio);
  const pronto = palco
    ? Promise.all([criarBrasao(palco, paleta), criarMoedas(palco, paleta)]).then(([aguia, moedas]) => {
      diretorAguia({ palco, aguia });
      if (/[?&]paletas/.test(location.search)) import('./teste-paletas.js').then((m) => m.seletor({ palco, aguia, moedas }));
      if (import.meta.env.DEV) Object.assign(window, { __palco: palco, __aguia: aguia, __moedas: moedas });
      return moedas.letras;
    }).catch((e) => { console.error(e); document.documentElement.classList.add('sem-gl'); return null; })
    : (document.documentElement.classList.add('sem-gl'), Promise.resolve(null));

  const abriu = abertura({ lenis, pronto });
  pronto.then((letras) => secoes.moeda({ letras }));
  await abriu;
  hero.entrar(0.05);
}
iniciar();
