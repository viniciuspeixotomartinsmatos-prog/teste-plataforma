// Diretor da águia: lê a rolagem a cada quadro e diz ao brasão onde ficar.
// - No hero, a águia fica parada na tela (na vaga do hero) enquanto o título sobe.
// - Quando o palco da casa sobe, ela viaja até o vão entre o "20" e o "05", girando uma volta, e pousa ali; dali em
//   diante anda com o ano (sobe junto com ele e sai da tela).
// - No rodapé, ela volta no vão do monograma S · O, girando meia volta enquanto sobe com a página.
import { clamp, lerp, suave2, REDUZIDO } from '../motion/ease.js';

export function diretorAguia({ palco, aguia }) {
  const vHero = document.querySelector('.vaga--hero');
  const vAno = document.querySelector('.vaga--ano');
  const vFecho = document.querySelector('.vaga--fecho');
  const casa = document.querySelector('.casa__palco');
  const pose = aguia.pose;

  let fixo = { x: 0, y: 0, h: 0 }, fechoIni = 0, fechoFim = 1;
  function medir() {
    const r = vHero.getBoundingClientRect(), s = scrollY;
    fixo = { x: r.left + r.width / 2, y: r.top + s + r.height / 2, h: r.height };
    // o giro do rodapé começa quando a vaga entra pelo pé da tela e termina no fim da página
    const f = vFecho.getBoundingClientRect();
    fechoIni = f.top + s - innerHeight * 1.05;
    fechoFim = Math.max(fechoIni + 1, document.documentElement.scrollHeight - innerHeight);
  }
  medir();
  palco.aoMedir(medir);
  // no celular a vaga do hero é a sobra entre o título e o texto, e a página muda de altura quando as fontes chegam:
  // mede de novo quando a vaga ou a página mudam de tamanho (nunca rolando)
  const ro = new ResizeObserver(() => { medir(); palco.pedir(); });
  ro.observe(vHero);
  ro.observe(document.body);

  const centro = (r) => ({ x: r.left + r.width / 2, y: r.top + r.height / 2, h: r.height });
  palco.antesDoQuadro(() => {
    const H = innerHeight;
    const rC = casa.getBoundingClientRect();
    const rA = vAno.getBoundingClientRect();
    const rF = vFecho.getBoundingClientRect();
    if (rF.top < H * 1.1 && rF.bottom > -20) {
      const c = centro(rF), t = clamp((scrollY - fechoIni) / (fechoFim - fechoIni));
      pose.x = c.x; pose.y = c.y; pose.h = c.h;
      pose.yaw = REDUZIDO ? 0 : (1 - suave2(t)) * Math.PI; pose.pitch = 0;
      pose.visivel = true;
      return;
    }
    if (rA.bottom < -30) { pose.visivel = false; return; }
    // pouso: começa com o topo do palco da casa a 85% da tela e termina com ele no topo
    const t = clamp((0.85 * H - rC.top) / (0.85 * H));
    const e = suave2(t);
    const a = centro(rA);
    pose.x = lerp(fixo.x, a.x, e);
    pose.y = lerp(fixo.y, a.y, e);
    pose.h = lerp(fixo.h, a.h, e);
    pose.yaw = REDUZIDO ? 0 : e * Math.PI * 2;
    pose.pitch = REDUZIDO ? 0 : Math.sin(e * Math.PI) * -0.18;
    pose.visivel = true;
  });
}
