// Paletas: as cores do CSS ficam em src/styles/tokens.css (html[data-paleta]); aqui fica o que o 3D precisa de cada
// uma: o estúdio que o cromo reflete (cúpula em degradê, caixas de luz, faixa escura), a cor do metal da águia e as
// moedas (a primeira da lista é a principal, que vai do R E A L ao lastro sem trocar de cor). A escolhida vem do <html data-paleta> (posto no <head> pelo ?paleta= da URL); sem nada, verde-água.
export const PALETAS = {
  agua: {
    nome: 'Verde-água', tema: '#c1e7e8', escuro: false,
    estudio: { alto: '#ffffff', meio: '#d6eded', baixo: '#86a8a9', faixa: '#4c6769', luz: '#ffffff', borda: '#f2ffff', chao: '#eafafa' },
    irid: 0.42, // iridescência das moedas (o furta-cor puxa para roxo e azul)
    cromo: '#ffffff',
    moedas: ['#5a4a8c', '#2f3656', '#d9dde3', '#433a66', '#a99fd6', '#2a2b33', '#6c5aa3', '#cfd3da', '#3a3f63', '#8f84c4', '#262733', '#b6b9c2'],
  },
  lavanda: {
    nome: 'Lavanda', tema: '#d8d3f1', escuro: false,
    estudio: { alto: '#ffffff', meio: '#e0dcf3', baixo: '#958cb8', faixa: '#4f4870', luz: '#ffffff', borda: '#f7f5ff', chao: '#f1eefc' },
    irid: 0.42, // iridescência das moedas (o furta-cor puxa para roxo e azul)
    cromo: '#ffffff',
    moedas: ['#5a4a8c', '#2f3656', '#d9dde3', '#433a66', '#a99fd6', '#2a2b33', '#6c5aa3', '#cfd3da', '#3a3f63', '#8f84c4', '#262733', '#b6b9c2'],
  },
  marfim: {
    nome: 'Marfim e ouro', tema: '#ece5d6', escuro: false,
    estudio: { alto: '#fffaf0', meio: '#efe4cc', baixo: '#9c8660', faixa: '#5b4a2f', luz: '#fff8ea', borda: '#fff5e0', chao: '#f6eedb' },
    irid: 0.1, // iridescência das moedas (o furta-cor puxa para roxo e azul)
    cromo: '#f2cf8c', // a águia vira ouro
    moedas: ['#d9b45a', '#24211d', '#e8d3a6', '#a8743a', '#d8d6d0', '#3a352e', '#c99a5e', '#8a6a2e', '#efe2c4', '#2d2a25', '#b88a4a', '#cfcac0'],
  },
  preto: {
    nome: 'Preto e prata', tema: '#0c0c0d', escuro: true,
    estudio: { alto: '#ffffff', meio: '#a9b1b6', baixo: '#30353a', faixa: '#0e0f10', luz: '#ffffff', borda: '#ffffff', chao: '#d5dbe0' },
    irid: 0.22, // iridescência das moedas (o furta-cor puxa para roxo e azul)
    cromo: '#ffffff',
    moedas: ['#d9dde3', '#2a2b30', '#8d939b', '#18191c', '#b6b9c2', '#4a4e56', '#e6e8ec', '#36383e', '#a4a9b0', '#202125', '#c7cbd1', '#5b6068'],
  },
  vermelho: {
    nome: 'Vermelho', tema: '#f01810', escuro: false,
    estudio: { alto: '#ffffff', meio: '#efd8d5', baixo: '#a0473f', faixa: '#3d0d09', luz: '#ffffff', borda: '#fff3f1', chao: '#f8e4e1' },
    irid: 0.08, // iridescência das moedas (o furta-cor puxa para roxo e azul)
    cromo: '#ffffff',
    moedas: ['#d8231a', '#1c1a1a', '#d9dde3', '#8a1510', '#3a3a40', '#e0544c', '#cfd3da', '#5a0e0a', '#26262b', '#b81d15', '#b6b9c2', '#2e1210'],
  },
  limao: {
    nome: 'Limão', tema: '#e2f29c', escuro: false,
    estudio: { alto: '#ffffff', meio: '#e6efc6', baixo: '#8f9f5c', faixa: '#3f4a1d', luz: '#ffffff', borda: '#fbffef', chao: '#f2f8dc' },
    irid: 0.1, // iridescência das moedas (o furta-cor puxa para roxo e azul)
    cromo: '#ffffff',
    moedas: ['#1f2a14', '#c9e35a', '#d9dde3', '#3c4d1f', '#9db83a', '#2a2b30', '#e2f29c', '#5b6e2b', '#cfd3da', '#151a10', '#b2cf4a', '#3a3a40'],
  },
};

export const nomePaleta = () => (PALETAS[document.documentElement.dataset.paleta] ? document.documentElement.dataset.paleta : 'agua');
export const paletaAtual = () => PALETAS[nomePaleta()];

/** aplica a parte da página (tokens do CSS, cor da barra do navegador, tom do hero para a navegação) */
export function aplicarPaleta(nome) {
  const p = PALETAS[nome] ?? PALETAS.agua;
  document.documentElement.dataset.paleta = PALETAS[nome] ? nome : 'agua';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', p.tema);
  const hero = document.querySelector('.hero');
  if (hero) hero.dataset.tema = p.escuro ? 'escuro' : 'claro';
  const casa = document.querySelector('.casa'); // a casa fica na cor do hero
  if (casa) casa.dataset.tema = p.escuro ? 'escuro' : 'claro';
  return p;
}
