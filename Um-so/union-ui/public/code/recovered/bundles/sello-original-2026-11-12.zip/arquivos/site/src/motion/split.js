// Texto por marco: entra por máscara de linha (subindo por dentro dela) e sai no lugar, sem atravessar a máscara.
// Nunca preso ao scroll: cada seção chama entrar()/sair() num marco. Um tween por linha, com o atraso já calculado
// (um tween só com stagger + delay voltava sozinho depois de morto).
import gsap from 'gsap';
import { SplitText } from 'gsap/SplitText';
import { REDUZIDO } from './ease.js';

gsap.registerPlugin(SplitText);

export function linhas(el, { tipo = 'lines' } = {}) {
  const s = SplitText.create(el, { type: tipo, mask: tipo, linesClass: 'ln', wordsClass: 'pl' });
  const L = tipo === 'words' ? s.words : s.lines;
  let dentro = false;
  gsap.set(L, REDUZIDO ? { opacity: 0 } : { yPercent: 120, opacity: 0 });
  return {
    el,
    get dentro() { return dentro; },
    entrar(atraso = 0, dur = 1.1, passo = 0.085) {
      dentro = true;
      gsap.killTweensOf(L);
      L.forEach((l, i) => {
        const d = atraso + i * passo;
        if (REDUZIDO) { gsap.to(l, { opacity: 1, duration: 0.4, delay: d }); return; }
        gsap.set(l, { yPercent: 120, opacity: 0 });
        gsap.to(l, { opacity: 1, duration: 0.2, ease: 'none', delay: d });
        gsap.to(l, { yPercent: 0, duration: dur, ease: 'se-out', delay: d });
      });
    },
    sair(dur = 0.4) {
      dentro = false;
      gsap.killTweensOf(L);
      if (REDUZIDO) { gsap.to(L, { opacity: 0, duration: 0.25 }); return; }
      L.forEach((l, i) => gsap.to(l, {
        opacity: 0, yPercent: -10, duration: dur, ease: 'se-in', delay: i * 0.03,
        onComplete: () => { if (!dentro) gsap.set(l, { yPercent: 120, opacity: 0 }); },
      }));
    },
    ja(v) {
      dentro = v;
      gsap.killTweensOf(L);
      gsap.set(L, REDUZIDO ? { opacity: v ? 1 : 0 } : { yPercent: v ? 0 : 120, opacity: v ? 1 : 0 });
    },
  };
}

// peças que não são texto corrido (botões, blocos, cartões): sobem e aparecem. autoAlpha: escondidas, saem também
// do Tab (nada recebe foco invisível)
export function pecas(els, { y = 22 } = {}) {
  const E = els.filter(Boolean);
  gsap.set(E, REDUZIDO ? { autoAlpha: 0 } : { autoAlpha: 0, y });
  let dentro = false;
  return {
    get dentro() { return dentro; },
    entrar(atraso = 0, passo = 0.07) {
      dentro = true;
      gsap.killTweensOf(E);
      E.forEach((e, i) => gsap.to(e, REDUZIDO
        ? { autoAlpha: 1, duration: 0.4, delay: atraso + i * passo }
        : { autoAlpha: 1, y: 0, duration: 1, ease: 'se-out', delay: atraso + i * passo }));
    },
    sair() {
      dentro = false;
      gsap.killTweensOf(E);
      gsap.to(E, { autoAlpha: 0, y: REDUZIDO ? 0 : -8, duration: 0.32, ease: 'se-in' });
    },
    ja(v) { dentro = v; gsap.killTweensOf(E); gsap.set(E, { autoAlpha: v ? 1 : 0, y: 0 }); },
  };
}

/** marco: chama entrar/sair quando o elemento cruza a linha da tela (fração da altura), nos dois sentidos */
export function marco(el, { linha = 0.82, entrar, sair, uma = false }) {
  let dentro = false;
  const io = new IntersectionObserver(([e]) => {
    const v = e.isIntersecting || e.boundingClientRect.top < 0;
    if (v === dentro) return;
    if (!v && uma) return;
    dentro = v;
    v ? entrar?.() : sair?.();
  }, { rootMargin: `0px 0px ${-(1 - linha) * 100}% 0px` });
  io.observe(el);
  return io;
}
