// render.mjs — desenha o filme no Chromium headless (o palco vai a cada instante por window.seek(t) e é fotografado).
//   node tools/render.mjs <filme> linha                          a linha do tempo e os eventos de som → out/<filme>/linha.json, cues.json
//   node tools/render.mjs <filme> folha [--passo 15]             folha de contato → out/<filme>/folha.jpg (quadros de 30 por segundo)
//   node tools/render.mjs <filme> quadros 120,300-330:5          quadros soltos em 1920×1080 → out/<filme>/quadros/
//   node tools/render.mjs <filme> video [--abas 3] [--rascunho]  o vídeo sem som → out/<filme>/video.mp4 (rascunho: 960×540)
//   node tools/render.mjs <filme> compara <outro.mp4> [--passo 30]   pares lado a lado (o nosso | o outro) → out/<filme>/compara.jpg
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync, spawn } from 'node:child_process';
import { RAIZ, args, quadros, servidor, navegador, abrir, foto, pad, ffmpeg } from './comum.mjs';

const { pos, opt } = args();
const [nome, modo = 'folha', lista] = pos;
if (!nome) { console.log('uso: node tools/render.mjs <filme> linha|folha|quadros|video|compara [...]'); process.exit(1); }

const srv = await servidor(); const porta = srv.address().port;
const browser = await navegador();
const OUT = path.join(RAIZ, 'out', nome);
fs.mkdirSync(OUT, { recursive: true });
const FPS = 30;
let erros = [];
try {
  if (modo === 'linha') {
    const p = await abrir(browser, porta, nome, .25);
    const cues = await p.page.evaluate(() => window.CUES);
    fs.writeFileSync(path.join(OUT, 'linha.json'), JSON.stringify(p.linha, null, 1));
    fs.writeFileSync(path.join(OUT, 'cues.json'), JSON.stringify(cues, null, 1));
    resumo(p.linha); erros = p.erros;
  } else if (modo === 'folha' || modo === 'quadros') {
    const escala = Number(opt.escala || (modo === 'folha' ? .25 : 1));
    const p = await abrir(browser, porta, nome, escala);
    const total = p.linha.total;
    const fs_ = modo === 'folha' ? quadros(`0-${total - 1}:${opt.passo || 30}`) : quadros(lista, total);
    const dir = path.resolve(opt.saida || path.join(OUT, modo === 'folha' ? '.folha' : 'quadros'));
    fs.rmSync(dir, { recursive: modo === 'folha', force: true }); fs.mkdirSync(dir, { recursive: true });
    for (const [i, f] of fs_.entries()) await foto(p, f / FPS, path.join(dir, (modo === 'folha' ? pad(i) : pad(f)) + '.png'));
    if (modo === 'folha') {
      const cols = Number(opt.colunas || 6), out = path.join(OUT, 'folha.jpg');
      execFileSync(ffmpeg(), ['-v', 'error', '-y', '-framerate', '1', '-i', path.join(dir, '%04d.png'),
        '-vf', `scale=480:-1,tile=${cols}x${Math.ceil(fs_.length / cols)}:padding=4:color=black`, '-frames:v', '1', '-q:v', '3', out]);
      fs.rmSync(dir, { recursive: true, force: true });
      console.log(`folha: ${fs_.length} quadros, 1 a cada ${opt.passo || 30} (${((opt.passo || 30) / FPS).toFixed(2)} s), da esquerda para a direita → ${path.relative(RAIZ, out)}`);
    } else console.log(`${fs_.length} quadros → ${path.relative(RAIZ, dir)}`);
    resumo(p.linha); erros = p.erros;
  } else if (modo === 'video') {
    const escala = opt.rascunho ? .5 : 1, W = 1920 * escala, H = 1080 * escala;
    const nAbas = Number(opt.abas || 3);
    const p0 = await abrir(browser, porta, nome, escala);
    const total = p0.linha.total;
    const dst = path.resolve(opt.saida || path.join(OUT, opt.rascunho ? 'video-rascunho.mp4' : 'video.mp4'));
    // os quadros vão direto para o ffmpeg por pipe, em ordem (nada de PNG em disco)
    const ff = spawn(ffmpeg(), ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'png', '-i', '-',
      '-vf', `scale=${W}:${H}:out_color_matrix=bt709:out_range=tv:flags=accurate_rnd+full_chroma_int,format=yuv420p`,
      '-c:v', 'libx264', '-preset', opt.rascunho ? 'fast' : 'slow', '-crf', opt.rascunho ? '22' : '15', '-tune', 'film',
      '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv', '-movflags', '+faststart', dst], { stdio: ['pipe', 'inherit', 'inherit'] });
    const ffDone = new Promise((res, rej) => ff.on('close', c => c === 0 ? res() : rej(new Error('ffmpeg ' + c))));
    const pages = [p0, ...await Promise.all(Array.from({ length: nAbas - 1 }, () => abrir(browser, porta, nome, escala)))];
    const buf = new Map(); let next = 0, done = 0; const t0 = Date.now();
    const write = async () => { while (buf.has(next)) { const b = buf.get(next); buf.delete(next); next++; if (!ff.stdin.write(b)) await new Promise(r => ff.stdin.once('drain', r)); } };
    let writing = Promise.resolve();
    console.log(`${total} quadros (${(total / FPS).toFixed(2)} s) com ${nAbas} abas`);
    await Promise.all(pages.map(async (p, k) => { for (let f = k; f < total; f += nAbas) {
      while (f - next > nAbas * 12) await new Promise(r => setTimeout(r, 20));        // não deixa a fila crescer sem limite
      buf.set(f, await foto(p, f / FPS));
      writing = writing.then(write);
      if (++done % 150 === 0) console.log(`  ${done}/${total}  ${((Date.now() - t0) / done).toFixed(0)} ms/quadro`); } }));
    await writing; await write(); ff.stdin.end(); await ffDone;
    pages.forEach(p => erros.push(...p.erros));
    console.log(`vídeo: ${total} quadros em ${((Date.now() - t0) / 1000).toFixed(0)} s → ${path.relative(RAIZ, dst)}`);
  } else if (modo === 'compara') {
    const ref = path.resolve(lista || '');
    if (!fs.existsSync(ref)) throw new Error('não achei o vídeo para comparar: ' + ref);
    const p = await abrir(browser, porta, nome, .5);
    const total = p.linha.total;
    const fs_ = quadros(opt.quadros || `0-${total - 1}:${opt.passo || 30}`, total);
    const tmp = path.join(OUT, '.compara'); fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp);
    for (const [i, f] of fs_.entries()) await foto(p, f / FPS, path.join(tmp, pad(2 * i) + '.png'));
    const sel = fs_.map(f => `eq(n\\,${f})`).join('+');
    const tmpR = path.join(tmp, 'ref'); fs.mkdirSync(tmpR);
    execFileSync(ffmpeg(), ['-v', 'error', '-y', '-i', ref, '-vf', `select=${sel},scale=960:540`, '-vsync', '0', path.join(tmpR, '%04d.png')]);
    fs_.forEach((f, i) => { const a = path.join(tmpR, pad(i + 1) + '.png'); if (fs.existsSync(a)) fs.renameSync(a, path.join(tmp, pad(2 * i + 1) + '.png')); else fs.copyFileSync(path.join(tmp, pad(2 * i) + '.png'), path.join(tmp, pad(2 * i + 1) + '.png')); });
    fs.rmSync(tmpR, { recursive: true, force: true });
    const out = path.join(OUT, opt.nome || 'compara.jpg');
    execFileSync(ffmpeg(), ['-v', 'error', '-y', '-framerate', '1', '-i', path.join(tmp, '%04d.png'),
      '-vf', `scale=640:-1,tile=4x${Math.ceil(2 * fs_.length / 4)}:padding=6:color=black`, '-frames:v', '1', '-q:v', '3', out]);
    fs.rmSync(tmp, { recursive: true, force: true });
    console.log(`compara: ${fs_.length} pares (o nosso | o outro), quadros ${fs_.join(', ')} → ${path.relative(RAIZ, out)}`);
    erros = p.erros;
  } else console.log('modos: linha | folha | quadros | video | compara');
} finally {
  const u = [...new Set(erros)].filter(x => !/favicon/.test(x));
  if (u.length) console.log('avisos:\n  ' + u.join('\n  '));
  await browser.close(); srv.close();
}

function resumo(l) {
  console.log(`linha: ${l.total} quadros (${l.duracao.toFixed(2)} s); drop ${l.drop.toFixed(2)} s, parada ${l.parada.toFixed(2)} s`);
  for (const c of l.cenas) console.log(`  ${c.tipo.padEnd(10)} ${c.de.toFixed(2).padStart(6)} – ${c.ate.toFixed(2).padEnd(6)} s  (quadros ${Math.round(c.de * 30)}–${Math.round(c.ate * 30)})`);
}
