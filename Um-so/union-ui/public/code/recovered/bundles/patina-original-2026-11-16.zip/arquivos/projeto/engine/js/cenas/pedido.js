// pedido — o app: uma barra de vidro iridescente sobre o meio-tom de uma foto, o logo gigante ao fundo; a câmera entra em
// macro na digitação e acompanha o cursor de texto, volta ao plano aberto e o cursor clica em enviar.
// { tipo: "pedido", fundo?: imagem (vira meio-tom), chip?: "nome", texto: "o pedido digitado", manchas?: [3 cores] }
window.CENA_pedido = () => {
  const c = F.cena('pedido'); if (!c) return;
  const { tl, add, q, qa, cue, C, rect } = F;
  const P = c.cfg, O = c.off, bar = (i, b) => F.bar(i, b) + O;
  const t0 = c.t0, tMacro = bar(6, .4), tWide = bar(7), tClick = bar(7, 1), tEnd = c.t1;
  const s = F.scene('s5', t0, tEnd, 4);
  const world = add(`<div class="s5-world"></div>`, s);
  if (P.fundo && window.MEIOTOM) add(`<img class="s5-bg" src="${MEIOTOM}">`, world);
  K.logo(world, { fs: 600, cx: 960, cy: 470, mono: true, color: P.fundo ? 'rgba(255,255,255,.62)' : F.rgba(C.tinta, .06), z: 1, maxW: 1840 });
  const PROMPT = String(P.texto ?? 'campanha de linho, terraço, pôr do sol');
  const M = P.manchas || [F.claro(C.acento, .45), F.claro(C.acento2, .55), F.claro(C.gradiente[1], .3)];
  const chip = P.chip === '' ? '' : `<div class="s5-chip">${K.mini(4)}${F.esc(P.chip ?? 'Linho de Domingo')}</div>`;
  const barEl = add(`<div class="s5-bar" style="z-index:3">
    <i class="s5-blob b1" style="left:80px;top:-70px;width:340px;height:220px;background:${M[0]}"></i>
    <i class="s5-blob b2" style="left:470px;top:-50px;width:360px;height:200px;background:${M[1]}"></i>
    <i class="s5-blob b3" style="left:820px;top:-80px;width:340px;height:240px;background:${M[2]}"></i>
    ${chip}
    <div class="s5-input"><span class="s5-text">${F.esc(PROMPT)}</span><i class="s5-caret"></i></div>
    <i class="s5-ring"></i><div class="s5-send">${K.I.seta('#fff')}</div></div>`, world);
  F.stage.style.setProperty('--acento-sombra', F.rgba(C.acento, .35));
  const blobs = qa('.s5-blob', barEl);
  const input = q('.s5-input', barEl), txt = q('.s5-text', barEl);
  // o campo começa logo depois do chip; o texto cabe até o botão de enviar
  const barR = rect(barEl);
  const chipEl = q('.s5-chip', barEl);
  const inLeft = chipEl ? Math.round(rect(chipEl).x - barR.x + rect(chipEl).w + 18) : 30;
  input.style.left = inLeft + 'px';
  const livre = 1180 - inLeft - 20 - 56 - 26;
  const tw = rect(txt).w;
  if (tw > livre) { const k = livre / tw; input.style.fontSize = (30 * k).toFixed(2) + 'px'; if (k < .75) F.aviso(`pedido.texto longo demais (${PROMPT.length} caracteres): encurte para ~${Math.round(PROMPT.length * k / .75)}`); }
  const chars = F.charsOf(txt);
  const caret = q('.s5-caret', barEl), send = q('.s5-send', barEl), ring = q('.s5-ring', barEl);
  const inRect = rect(input);
  const xs = chars.map(ch => { const r = rect(ch); return r.x + r.w - inRect.x; });
  const dtc = Math.min(.034, 1.44 / Math.max(1, chars.length));
  const tc = i => tMacro + .06 + i * dtc;
  F.typeChars(chars, tMacro + .06, dtc, { tint: C.acento, ink: C.tintaC, blur: 2, y: 0, dur: .09 });
  gsap.set(caret, { x: 0 });
  chars.forEach((ch, i) => tl.set(caret, { x: xs[i] + 2 }, tc(i)));
  tl.to(caret, { opacity: 0, duration: .01 }, tWide + .6); tl.to(caret, { opacity: 1, duration: .01 }, tWide + .9);
  // teclas: uma a cada ~3 caracteres (≤ 12 por segundo) e sempre no começo da palavra
  chars.forEach((ch, i) => { const k = PROMPT[i]; if (k === ' ') return; if (i === 0 || PROMPT[i - 1] === ' ' || i % 3 === 0) cue(tc(i), 'key', `s5:key${i}`, { word: i === 0 || PROMPT[i - 1] === ' ' }); });
  const caretAt = t => { if (t <= tc(0)) return 0; for (let i = 1; i < xs.length; i++) if (t < tc(i)) return F.lerp(xs[i - 1], xs[i], (t - tc(i - 1)) / (tc(i) - tc(i - 1))); return xs[xs.length - 1]; };
  const bx = 370, by = 492;
  const cur = add(K.CURSOR, world);
  gsap.set(cur, { x: 1760, y: 940, opacity: 0 });
  const sendC = { x: bx + 1180 - 20 - 28, y: by + 20 + 28 };
  tl.set(cur, { opacity: 1 }, tWide + .02);
  tl.fromTo(cur, { x: 1760, y: 940 }, { x: sendC.x - 6, y: sendC.y - 4, duration: .4, ease: 'io', immediateRender: false }, tWide + .02);
  tl.to(cur, { scale: .86, duration: .06, ease: 'quick', transformOrigin: '20% 15%' }, tClick); tl.to(cur, { scale: 1, duration: .2, ease: 'out' }, tClick + .07);
  tl.to(send, { scale: .86, duration: .06, ease: 'quick' }, tClick); tl.to(send, { scale: 1, duration: .3, ease: 'out' }, tClick + .07);
  tl.fromTo(ring, { scale: 1, opacity: .9 }, { scale: 1.8, opacity: 0, duration: .5, ease: 'out', immediateRender: false }, tClick);
  gsap.set(ring, { opacity: 0 });
  tl.to(txt, { opacity: .45, duration: .2, ease: 'quick' }, tClick + .04);
  cue(tClick, 'click', 's5:send', { note: 'o clique em enviar' });
  cue(t0, 'swoosh_s', 's5:cut', { soft: true, note: 'o corte para o app' });

  const tEndCam = 13.0 + O;           // a câmera anda como no filme completo, mesmo quando a cena segura mais
  F.apply(t => {
    if (t < t0 - .05 || t > tEnd + .05) return;
    let S, fx, fy;
    if (t < tMacro) { S = F.lerp(1, 1.02, (t - t0) / (tMacro - t0)); fx = 960; fy = 520; }
    else if (t < tWide) { S = 3.0; const k = (t - tMacro) / (tWide - tMacro); fx = inRect.x + caretAt(t - .07) - (1215 - 960) / S; fy = by + 48 + F.lerp(-6, 4, k); }
    else { S = F.lerp(1.05, 1.075, (t - tWide) / (tEndCam - tWide)); fx = 985; fy = 545; }
    gsap.set(world, { x: 960 - fx * S, y: 540 - fy * S, scale: S, transformOrigin: '0 0' });
    blobs.forEach((b, i) => gsap.set(b, { x: 60 * Math.sin(t * .9 + i * 2.1), y: 14 * Math.cos(t * 1.1 + i) }));
  });
};
