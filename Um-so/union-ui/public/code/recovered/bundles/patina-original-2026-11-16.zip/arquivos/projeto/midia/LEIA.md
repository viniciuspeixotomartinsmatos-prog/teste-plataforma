A mídia de cada filme fica em midia/<nome-do-filme>/ (ver o guia, seção "As imagens").
