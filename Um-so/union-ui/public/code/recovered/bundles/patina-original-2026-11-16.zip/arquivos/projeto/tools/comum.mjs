// comum.mjs — servidor local, navegador headless e abertura do filme. Usado pelas outras ferramentas.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';

export const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function args(argv = process.argv.slice(2)) {
  const pos = [], opt = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2), v = argv[i + 1];
      if (v === undefined || v.startsWith('--')) opt[k] = true; else { opt[k] = v; i++; }
    } else pos.push(a);
  }
  return { pos, opt };
}

/** "0,10,20" | "100-140" | "100-140:4", misturáveis com vírgula (números de quadro, 30 por segundo) */
export function quadros(s, total) {
  const out = [];
  for (const part of String(s).split(',')) {
    const [range, step] = part.split(':');
    let [a, b] = range.split('-').map(Number);
    if (b === undefined || Number.isNaN(b)) b = a;
    if (total !== undefined) b = Math.min(b, total - 1);
    for (let f = a; f <= b; f += Number(step || 1)) out.push(f);
  }
  return out;
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.json': 'application/json', '.svg': 'image/svg+xml' };

/** serve a raiz do projeto (o filme abre em /engine/index.html?filme=<nome>) */
export function servidor(porta = 0) {
  return new Promise(res => {
    const srv = http.createServer((req, rsp) => {
      const p = decodeURIComponent(req.url.split('?')[0]);
      const file = path.join(RAIZ, p);
      if (!file.startsWith(RAIZ)) { rsp.writeHead(403); rsp.end(); return; }
      fs.readFile(file, (err, buf) => {
        if (err) { rsp.writeHead(404); rsp.end(); return; }
        rsp.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
        rsp.end(buf);
      });
    }).listen(porta, '127.0.0.1', () => res(srv));
  });
}

/** Chromium headless com GPU (Metal/D3D11/Vulkan); sem o Chromium completo instalado, cai no headless padrão */
export async function navegador() {
  const ANGLE = process.platform === 'win32' ? 'd3d11' : process.platform === 'darwin' ? 'metal' : 'vulkan';
  try {
    return await chromium.launch({ channel: 'chromium', headless: true, args: [`--use-angle=${ANGLE}`, '--enable-gpu', '--ignore-gpu-blocklist'] });
  } catch {
    return await chromium.launch({ headless: true, args: ['--ignore-gpu-blocklist', '--enable-unsafe-swiftshader'] });
  }
}

export function lerFilme(nome) {
  const f = path.join(RAIZ, 'filmes', nome + '.json');
  if (!fs.existsSync(f)) throw new Error(`não achei filmes/${nome}.json`);
  return JSON.parse(fs.readFileSync(f, 'utf8'));
}

/** abre o filme numa aba; escala 1 = 1920×1080, 0,5 = 960×540 */
export async function abrir(browser, porta, nome, escala = 1) {
  lerFilme(nome);
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: escala });
  const page = await ctx.newPage();
  const erros = [];
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') erros.push(m.text()); });
  page.on('pageerror', e => erros.push(e.message));
  await page.goto(`http://127.0.0.1:${porta}/engine/index.html?filme=${encodeURIComponent(nome)}`);
  await page.waitForFunction(() => document.documentElement.dataset.ready || window.erroFilme, null, { timeout: 180000 }).catch(() => {});
  const ok = await page.evaluate(() => document.documentElement.dataset.ready === '1');
  if (!ok) throw new Error('o filme não abriu:\n' + erros.join('\n'));
  // o palco fica exatamente na origem da janela
  await page.addStyleTag({ content: 'body{display:block;min-height:0} #stage{position:absolute;left:0;top:0}' });
  const linha = await page.evaluate(() => window.LINHA);
  return { ctx, page, erros, linha };
}

export async function foto(p, t, arquivo, tipo = 'png') {
  await p.page.evaluate(t => window.seek(t), t);
  const o = { type: tipo, clip: { x: 0, y: 0, width: 1920, height: 1080 } };
  if (tipo === 'jpeg') o.quality = 90;
  if (arquivo) o.path = arquivo;
  return p.page.screenshot(o);
}

export const pad = n => String(n).padStart(4, '0');

/** caminho do ffmpeg: o do pacote @ffmpeg-installer (vem com o npm install) ou o do sistema */
export function ffmpeg() {
  const plat = `${process.platform}-${process.arch}`;
  const bin = path.join(RAIZ, 'node_modules/@ffmpeg-installer', plat, process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
  if (!fs.existsSync(bin)) return 'ffmpeg';
  // o npm pode bloquear o script que dá permissão de execução ao binário: dá aqui
  try { fs.accessSync(bin, fs.constants.X_OK); } catch { try { fs.chmodSync(bin, 0o755); } catch {} }
  return bin;
}

/** o Python do projeto (.venv) ou o do sistema */
export function python() {
  for (const p of ['.venv/bin/python', '.venv/Scripts/python.exe']) if (fs.existsSync(path.join(RAIZ, p))) return path.join(RAIZ, p);
  return process.platform === 'win32' ? 'python' : 'python3';
}
