// Peças reutilizáveis: o logo da marca, ícones, cursor e o "corner pin" (homografia para o free transform).
window.K = (() => {
  const { add, CFG, C } = F;
  const MARCA = CFG.marca || {};
  const LOGO = MARCA.logo || {};
  const PESO = (MARCA.fonte && MARCA.fonte.peso) || 600;

  // ---------- logo ----------
  // Dois jeitos:
  //   símbolo + nome: o símbolo (o disco nas cores da marca, ou o SVG/PNG do config) à esquerda e o nome escrito;
  //   "haste": a primeira letra do nome é uma haste de tinta com o símbolo no lugar do bojo (p, b, d, q).
  const HASTE = !!LOGO.haste;
  const PALAVRA = LOGO.palavra ?? (HASTE ? String(MARCA.nome || '').slice(1) : String(MARCA.nome || 'marca'));
  const SIMBOLO = LOGO.simbolo && LOGO.simbolo !== 'disco' ? LOGO.simbolo : null;   // caminho da imagem, ou o disco
  const DISCO = LOGO.disco || [[0, F.claro(C.acento, .55)], [.15, F.mix(C.acento, F.claro(C.acento, .4), .5)], [.34, C.acento],
    [.5, F.mix(C.acento, C.acento2, .45)], [.66, F.claro(C.acento2, .12)], [.81, C.acento2], [1, F.escuro(C.acento2, .4)]];
  const discoCSS = `radial-gradient(circle at 30% 26%, ${DISCO.map(([p, c]) => `${c} ${Math.round(p * 100)}%`).join(', ')})`;
  const simbCor = LOGO.cor || null;                                   // símbolo de imagem: a cor (padrão: o gradiente do disco)
  function metrics(fs) {
    const cv = document.createElement('canvas').getContext('2d');
    cv.font = `${PESO} ${fs}px Logo`;
    const xh = cv.measureText('x').actualBoundingBoxAscent;
    const desc = Math.max(cv.measureText('p').actualBoundingBoxDescent, cv.measureText(PALAVRA).actualBoundingBoxDescent);
    cv.letterSpacing = `${-0.045 * fs}px`;
    const mt = cv.measureText(PALAVRA);
    return { xh, desc, ww: mt.width, fA: mt.fontBoundingBoxAscent, fD: mt.fontBoundingBoxDescent };
  }
  function proporcao() { const im = SIMBOLO && window.PRE && PRE[SIMBOLO]; return im ? im.naturalWidth / im.naturalHeight : 1; }
  function logo(parent, { fs = 200, cx = 960, cy = 540, mono = false, color = null, z = 5, maxW = null } = {}) {
    let m = metrics(fs);
    const largura = f => { const mm = metrics(f), sw = f * .13, D = mm.xh * (SIMBOLO ? (LOGO.escala || 1.25) : 1.1); const Dw = D * proporcao();
      const discL = HASTE ? sw * .2 : 0; return discL + Dw + (HASTE ? f * .018 : f * .16) + mm.ww; };
    if (maxW && largura(fs) > maxW) { fs = fs * maxW / largura(fs); m = metrics(fs); }
    const sw = Math.round(fs * .13), D = m.xh * (SIMBOLO ? (LOGO.escala || 1.25) : 1.1), Dw = D * proporcao(), gap = HASTE ? fs * .018 : fs * .16;
    const discL = HASTE ? sw * .2 : 0, wordL = discL + Dw + gap;
    const W = wordL + m.ww, H = m.xh + m.desc;
    const fundo = mono ? 'currentColor' : (SIMBOLO ? (simbCor || discoCSS) : discoCSS);
    const mask = SIMBOLO ? `-webkit-mask:url(${F.img(SIMBOLO)}) center/contain no-repeat;mask:url(${F.img(SIMBOLO)}) center/contain no-repeat;border-radius:0;` : '';
    const el = add(`<div class="logo${mono ? ' mono' : ''}" style="z-index:${z};width:${W}px;height:${H}px;${color ? `color:${color}` : ''}">
      ${HASTE ? '<i class="stem"></i>' : ''}<i class="disc" style="background:${fundo};${mask}"><i class="sheen"></i></i><div class="word" style="font-size:${fs}px">${F.esc(PALAVRA)}</div></div>`, parent);
    const base = m.xh;                                        // linha de base, a partir do topo do x-height
    const left = cx - W / 2, top = cy - m.xh / 2;            // centro óptico = meio do x-height
    gsap.set(el, { x: left, y: top });
    const stem = el.querySelector('.stem'), disc = el.querySelector('.disc'), word = el.querySelector('.word'), sheen = el.querySelector('.sheen');
    if (stem) gsap.set(stem, { left: 0, top: -fs * .004, width: sw, height: m.xh + m.desc + fs * .004 });
    gsap.set(disc, { left: discL, top: (m.xh - D) / 2, width: Dw, height: D });
    // posiciona a palavra pela linha de base: com line-height 1 a linha de base fica em (fs - (A + D)) / 2 + A
    word.style.left = wordL + 'px';
    word.style.top = (base - ((fs - (m.fA + m.fD)) / 2 + m.fA)) + 'px';
    gsap.set(sheen, { xPercent: -120 });
    return { el, stem, disc, word, sheen, m, sw, D, Dw, W, H, left, top, cx, cy, fs, haste: HASTE, discCenter: { x: left + discL + Dw / 2, y: top + m.xh / 2 } };
  }

  // ---------- ícones em traço (46 px) ----------
  // Os desenhados para o filme (paleta, sol, grao, lente, chave...) e qualquer ícone do pacote lucide (kebab-case).
  const I = {
    paleta: c => `<svg class="ic" viewBox="0 0 48 48" fill="none" stroke="${c}" stroke-width="2.6" stroke-linecap="round"><path d="M24 6a18 18 0 1 0 0 36c2.6 0 3.4-2.2 2.3-4-1.2-2 .2-4.4 2.6-4.4H34a8 8 0 0 0 8-8C42 14.2 33.9 6 24 6Z"/><circle cx="15" cy="21" r="2.4" fill="${c}"/><circle cx="21" cy="14" r="2.4" fill="${c}"/><circle cx="30" cy="15" r="2.4" fill="${c}"/></svg>`,
    sol: c => `<svg class="ic" viewBox="0 0 48 48" fill="none" stroke="${c}" stroke-width="2.6" stroke-linecap="round"><circle cx="24" cy="24" r="8"/><path d="M24 5v5M24 38v5M5 24h5M38 24h5M10.6 10.6l3.5 3.5M33.9 33.9l3.5 3.5M10.6 37.4l3.5-3.5M33.9 14.1l3.5-3.5"/></svg>`,
    grao: c => `<svg class="ic" viewBox="0 0 48 48" fill="${c}"><rect x="7" y="7" width="34" height="34" rx="7" fill="none" stroke="${c}" stroke-width="2.6"/><circle cx="17" cy="17" r="2.2"/><circle cx="24" cy="21" r="1.6"/><circle cx="31" cy="16" r="2"/><circle cx="16" cy="29" r="1.7"/><circle cx="25" cy="31" r="2.3"/><circle cx="32" cy="27" r="1.5"/></svg>`,
    lente: c => `<svg class="ic" viewBox="0 0 48 48" fill="none" stroke="${c}" stroke-width="2.6" stroke-linejoin="round"><circle cx="24" cy="24" r="17"/><path d="M24 7l7.5 13M41 24H26M31.5 38.7 24 26M17 37.8 22 24M7.5 27.5 17 17M14.4 9.9 22 21"/></svg>`,
    chave: c => `<svg class="ic" viewBox="0 0 48 48" fill="none" stroke="${c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="30" r="8"/><path d="M22 24 38 8M32 14l5 5M28 18l4 4"/></svg>`,
    check: c => `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="${c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5 10 17 19 7"/></svg>`,
    seta: c => `<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="${c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>`,
    imagem: c => `<svg viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2.2" stroke-linejoin="round"><rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6" fill="${c}"/><path d="m4.5 17 5-5 4 4 2.5-2.5 3.5 3.5"/></svg>`,
    video: c => `<svg viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2.2" stroke-linejoin="round"><rect x="3" y="6" width="13" height="12" rx="2.5"/><path d="m16 10.5 5-3v9l-5-3"/></svg>`,
    play: c => `<svg viewBox="0 0 24 24" width="18" height="18" fill="${c}"><path d="M8 5.5v13l10.5-6.5z"/></svg>`,
    chaveP: c => `<svg viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2.3" stroke-linecap="round"><circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l2.5 2.5"/></svg>`,
  };
  // ícone por nome: os do filme, senão lucide (miolo 24×24, traço afinado para casar com os do filme)
  function icone(nome, c, { cls = 'ic', sw = 1.35, size = null } = {}) {
    const st = size ? ` width="${size}" height="${size}"` : '';
    if (I[nome]) return I[nome](c).replace('<svg', `<svg${st}`).replace(/class="ic"/, `class="${cls}"`);
    const all = window.LUCIDE_ALL || {};
    let inner = all[nome];
    if (!inner) { F.aviso(`ícone desconhecido: "${nome}" (usei "sparkles"; confira o nome em engine/js/lucide.js)`); inner = all.sparkles || ''; }
    return `<svg class="${cls}"${st} viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
  }

  // ---------- cursor (seta, ponto quente na ponta) ----------
  const CURSOR = `<svg class="cursor" viewBox="0 0 32 32"><path d="M7 4.5v20.6l5.1-4.6 3.4 7.7 3.4-1.5-3.3-7.6h6.9z" fill="#111" stroke="#fff" stroke-width="1.8" stroke-linejoin="round"/></svg>`;

  // ---------- homografia: retângulo w×h → quadrilátero (corner pin, como o free transform de um editor) ----------
  function homography(w, h, q) {
    // q = [[x0,y0],[x1,y1],[x2,y2],[x3,y3]] = TL, TR, BR, BL
    const src = [[0, 0], [w, 0], [w, h], [0, h]];
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = q[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    const n = 8;                                             // eliminação de Gauss
    for (let c = 0; c < n; c++) {
      let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      [A[c], A[p]] = [A[p], A[c]]; [b[c], b[p]] = [b[p], b[c]];
      for (let r = 0; r < n; r++) { if (r === c) continue; const f = A[r][c] / A[c][c]; for (let k = c; k < n; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; }
    }
    const [a, bb, c, d, e, f, g, hh] = b.map((v, i) => v / A[i][i]);
    // matrix3d em ordem de colunas
    return `matrix3d(${a},${d},0,${g},${bb},${e},0,${hh},0,0,1,0,${c},${f},0,1)`;
  }

  // mini paleta (as bolinhas do chip)
  const mini = (n = 4) => `<span class="mini">${C.paleta.slice(0, n).map(c => `<i style="background:${c}"></i>`).join('')}</span>`;

  return { logo, I, icone, CURSOR, homography, mini, PALAVRA, HASTE };
})();
