// Efeitos desenhados em canvas, todos funções puras do tempo (ou de um parâmetro que a linha do tempo anima),
// e as imagens derivadas (meio-tom e passes de falsa cor), feitas no navegador a partir das imagens do config.
window.FX = (() => {
  const { C, clamp, lerp, rgbOf } = F;
  const hash = (a, b = 0, c = 0) => { let h = (a * 374761393 + b * 668265263 + c * 2147483647) | 0; h = (h ^ (h >>> 13)) * 1274126177; h ^= h >>> 16; return (h >>> 0) / 4294967295; };
  const hexA = (hex, a) => { const n = rgbOf(hex); return `rgba(${n[0]},${n[1]},${n[2]},${a})`; };

  // ---------- campo de gradiente (a floração e o fundo do manifesto e dos formatos) ----------
  function gradientField(parent, { z = 0 } = {}) {
    const cv = F.add(`<canvas class="gfield" width="480" height="270" style="z-index:${z}"></canvas>`, parent);
    const g = cv.getContext('2d');
    const st = { rise: 0, glow: 1, shift: 0 };
    const G = C.gradiente;
    const blobs = [
      { c: G[0], x: 470, y: 1000, r: 820, ax: 140, ay: 70, fx: .31, fy: .27, p: 0 },
      { c: G[1], x: 1480, y: 760, r: 760, ax: 150, ay: 90, fx: .23, fy: .19, p: 1.3 },
      { c: G[2], x: 1000, y: 1090, r: 680, ax: 170, ay: 50, fx: .21, fy: .33, p: 2.1 },
      { c: G[3], x: 1780, y: 1120, r: 600, ax: 100, ay: 40, fx: .29, fy: .25, p: .7 },
      { c: G[4], x: 150, y: 1150, r: 560, ax: 80, ay: 50, fx: .17, fy: .3, p: 2.8 },
    ];
    function draw(t) {
      g.setTransform(.25, 0, 0, .25, 0, 0);
      g.globalCompositeOperation = 'source-over';
      g.fillStyle = C.fundo; g.fillRect(0, 0, 1920, 1080);
      const lift = (1 - st.rise) * 820 - st.shift;
      for (const b of blobs) {
        const x = b.x + b.ax * Math.sin(b.fx * t + b.p), y = b.y + b.ay * Math.cos(b.fy * t + b.p) + lift;
        const grd = g.createRadialGradient(x, y, 0, x, y, b.r);
        grd.addColorStop(0, hexA(b.c, .95 * st.glow)); grd.addColorStop(.45, hexA(b.c, .62 * st.glow)); grd.addColorStop(1, hexA(b.c, 0));
        g.fillStyle = grd; g.beginPath(); g.arc(x, y, b.r, 0, Math.PI * 2); g.fill();
      }
    }
    return { cv, st, draw };
  }

  // ---------- wipe em pixels escalonados ----------
  function pixelWipe(parent, { cell = 24, z = 30, fill = C.fundo } = {}) {
    const cv = F.add(`<canvas class="wipe" width="1920" height="1080" style="z-index:${z}"></canvas>`, parent);
    const g = cv.getContext('2d');
    const st = { p: 0 };
    const cols = Math.ceil(1920 / cell), rows = Math.ceil(1080 / cell);
    const pal = C.pixels;
    function draw(t) {
      g.clearRect(0, 0, 1920, 1080);
      if (st.p <= 0) return;
      const front = lerp(-6, rows + 8, st.p);              // linha da frente, em células
      const step = Math.floor(t * 30 / 2);                  // os blocos coloridos trocam a cada 2 quadros
      for (let c = 0; c < cols; c++) {
        // borda em escada: soma de ondas + ruído, quantizada na célula
        const off = Math.round(2.6 * Math.sin(c * .21 + st.p * 5) + 1.8 * Math.sin(c * .53 + 1.7) + 2.2 * (hash(c, 7) - .5));
        const fr = Math.floor(front + off);
        if (fr > 0) { g.fillStyle = fill; g.fillRect(c * cell, 0, cell, Math.min(fr, rows) * cell); }
        for (let k = 0; k < 3; k++) {                        // franja de blocos coloridos logo abaixo da frente
          const r = fr + k; if (r < 0 || r >= rows) continue;
          const h = hash(c, r, step);
          if (h < [.72, .38, .14][k]) { g.fillStyle = pal[Math.floor(hash(r, c, step + 3) * pal.length)]; g.globalAlpha = [.95, .8, .6][k]; g.fillRect(c * cell, r * cell, cell, cell); g.globalAlpha = 1; }
          else if (k === 0 && h < .9) { g.fillStyle = fill; g.fillRect(c * cell, r * cell, cell, cell); }
        }
      }
    }
    return { cv, st, draw };
  }

  // ---------- matriz de pontos que monta a imagem ----------
  function dotMatrix(parent, img, { x = 680, y = 190, w = 560, h = 700, pitch = 20, z = 5, t0 = 13.0, t1 = 13.86, tc = 14.0, tEnd = 14.55 } = {}) {
    const cv = F.add(`<canvas class="dots" width="1920" height="1080" style="z-index:${z}"></canvas>`, parent);
    const g = cv.getContext('2d');
    const cols = Math.floor(w / pitch), rows = Math.floor(h / pitch);
    const ox = x + (w - cols * pitch) / 2 + pitch / 2, oy = y + (h - rows * pitch) / 2 + pitch / 2;
    // amostra a imagem na grade (média por célula)
    const off = document.createElement('canvas'); off.width = cols; off.height = rows;
    const og = off.getContext('2d');
    const s = Math.max(cols / img.naturalWidth, rows / img.naturalHeight);
    const dw = img.naturalWidth * s, dh = img.naturalHeight * s;
    og.drawImage(img, (cols - dw) / 2, (rows - dh) / 2, dw, dh);
    const px = og.getImageData(0, 0, cols, rows).data;
    // os pontos nascem nas cores da paleta da marca e passam para a cor real da imagem
    const pal = [...C.paleta, C.fundo].map(rgbOf);
    const dots = [];
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const i = (r * cols + c) * 4, rgb = [px[i], px[i + 1], px[i + 2]];
      let best = 0, bd = 1e9;
      pal.forEach((p, k) => { const d = (p[0] - rgb[0]) ** 2 + (p[1] - rgb[1]) ** 2 * 1.2 + (p[2] - rgb[2]) ** 2; if (d < bd) { bd = d; best = k; } });
      const L = (0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]) / 255;
      const u = hash(c, r, 11);
      dots.push({ cx: ox + c * pitch, cy: oy + r * pitch, rgb, pc: pal[best], L, ta: t0 + Math.pow(u, .62) * (t1 - t0), j: hash(r, c, 5) });
    }
    const st = { on: 0 };
    function draw(t) {
      g.clearRect(0, 0, 1920, 1080);
      if (t < t0 || t > tEnd) return;
      const kc = clamp((t - t1) / (tc - t1), 0, 1);           // paleta → cor real
      const fade = 1 - clamp((t - (tc + .2)) / (tEnd - tc - .2), 0, 1);
      for (const d of dots) {
        const a = clamp((t - d.ta) / .12, 0, 1); if (a <= 0) continue;
        const e = 1 - Math.pow(1 - a, 3);
        const col = d.pc.map((v, k) => Math.round(lerp(v, d.rgb[k], kc)));
        const base = pitch * .36, rad = lerp(base, pitch * (.18 + (1 - d.L) * .42) + pitch * .12, kc) * (.6 + .4 * e);
        g.globalAlpha = e * fade;
        g.fillStyle = `rgb(${col[0]},${col[1]},${col[2]})`;
        g.beginPath(); g.arc(d.cx, d.cy, rad, 0, Math.PI * 2); g.fill();
      }
      g.globalAlpha = 1;
    }
    return { cv, st, draw, dots, rect: { x, y, w, h } };
  }

  // ---------- imagens derivadas ----------
  const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  function cobrir(img, W, H, foco = [.5, .5]) {
    const c = canvas(W, H), g = c.getContext('2d');
    const s = Math.max(W / img.naturalWidth, H / img.naturalHeight), dw = img.naturalWidth * s, dh = img.naturalHeight * s;
    g.drawImage(img, (W - dw) * foco[0], (H - dh) * foco[1], dw, dh);
    return c;
  }
  // meio-tom colorido (o fundo do app no pedido): pontos na cor da própria foto, puxada para o papel
  function meioTom(img, { W = 2400, H = 1350, pitch = 10, papel = F.claro(C.fundo, .3) } = {}) {
    const src = cobrir(img, W, H).getContext('2d').getImageData(0, 0, W, H).data;
    const out = canvas(W, H), g = out.getContext('2d');
    g.fillStyle = papel; g.fillRect(0, 0, W, H);
    const p = rgbOf(papel);
    for (let y = 0; y < H; y += pitch) for (let x = 0; x < W; x += pitch) {
      let r = 0, gg = 0, b = 0, n = 0;
      for (let yy = y; yy < Math.min(H, y + pitch); yy++) for (let xx = x; xx < Math.min(W, x + pitch); xx++) { const i = (yy * W + xx) * 4; r += src[i]; gg += src[i + 1]; b += src[i + 2]; n++; }
      r /= n; gg /= n; b /= n;
      const L = (0.2126 * r + 0.7152 * gg + 0.0722 * b) / 255;
      const rad = Math.pow(1 - L, .85) * pitch * .74 + .6;
      const col = [r, gg, b].map((v, k) => Math.min(255, (v * .62 + p[k] * .38) * 1.04));
      g.fillStyle = `rgb(${col.map(v => v | 0).join(',')})`;
      g.beginPath(); g.ellipse(x + pitch / 2, y + pitch / 2, rad, rad, 0, 0, Math.PI * 2); g.fill();
    }
    const fin = canvas(W, H), fg = fin.getContext('2d'); fg.filter = 'blur(0.35px)'; fg.drawImage(out, 0, 0);
    return fin.toDataURL('image/jpeg', .92);
  }
  // passes de "falsa cor" da imagem principal (o mapa de gradiente na paleta e um passe frio de relevo)
  // paradas: ["#hex", ...] (espaçadas por igual) ou [[posição 0–1, "#hex"], ...]
  const stopsRGB = stops => stops.map((c, i) => Array.isArray(c) ? [c[0], rgbOf(c[1])] : [i / (stops.length - 1), rgbOf(c)]);
  const gmap = (L, st) => { for (let i = 1; i < st.length; i++) if (L <= st[i][0]) { const k = (L - st[i - 1][0]) / (st[i][0] - st[i - 1][0] || 1); return st[i - 1][1].map((v, j) => v + (st[i][1][j] - v) * k); } return st[st.length - 1][1]; };
  function passes(img, { a, b }) {
    const W = img.naturalWidth, H = img.naturalHeight;
    const d = cobrir(img, W, H).getContext('2d').getImageData(0, 0, W, H).data;
    const lum = new Float32Array(W * H); let mn = 1, mx = 0;
    for (let i = 0; i < W * H; i++) { const v = (0.2126 * d[i * 4] + 0.7152 * d[i * 4 + 1] + 0.0722 * d[i * 4 + 2]) / 255; lum[i] = v; if (v < mn) mn = v; if (v > mx) mx = v; }
    for (let i = 0; i < W * H; i++) lum[i] = clamp((lum[i] - mn) / (mx - mn + 1e-6), 0, 1);
    const SA = stopsRGB(a), SB = stopsRGB(b);
    const ca = canvas(W, H), ga = ca.getContext('2d'), ia = ga.createImageData(W, H);
    for (let i = 0; i < W * H; i++) { const c = gmap(lum[i], SA); ia.data[i * 4] = c[0]; ia.data[i * 4 + 1] = c[1]; ia.data[i * 4 + 2] = c[2]; ia.data[i * 4 + 3] = 255; }
    ga.putImageData(ia, 0, 0);
    const fa = canvas(W, H), fga = fa.getContext('2d'); fga.filter = 'blur(1.2px)'; fga.drawImage(ca, 0, 0);
    // relevo: gradientes locais da luminância desfocada
    const cl = canvas(W, H), gl = cl.getContext('2d'), il = gl.createImageData(W, H);
    for (let i = 0; i < W * H; i++) { const v = lum[i] * 255; il.data[i * 4] = il.data[i * 4 + 1] = il.data[i * 4 + 2] = v; il.data[i * 4 + 3] = 255; }
    gl.putImageData(il, 0, 0);
    const cb = canvas(W, H), gb = cb.getContext('2d'); gb.filter = 'blur(6px)'; gb.drawImage(cl, 0, 0);
    const bl = gb.getImageData(0, 0, W, H).data;
    const g0 = i => bl[i * 4] / 255;
    const ob = gb.createImageData(W, H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const gx = (g0(y * W + Math.min(W - 1, x + 1)) - g0(y * W + Math.max(0, x - 1))) / ((x > 0 && x < W - 1) ? 2 : 1) * 18;
      const gy = (g0(Math.min(H - 1, y + 1) * W + x) - g0(Math.max(0, y - 1) * W + x)) / ((y > 0 && y < H - 1) ? 2 : 1) * 18;
      const n = [clamp(.5 + gx, 0, 1), clamp(.5 + gy, 0, 1), .85];
      const t = gmap(lum[i], SB);
      for (let k = 0; k < 3; k++) ob.data[i * 4 + k] = clamp(n[k] * .55 + t[k] / 255 * .6, 0, 1) * 255;
      ob.data[i * 4 + 3] = 255;
    }
    const fb = canvas(W, H); fb.getContext('2d').putImageData(ob, 0, 0);
    return { a: fa.toDataURL('image/jpeg', .92), b: fb.toDataURL('image/jpeg', .92) };
  }
  // a cor média de uma imagem (para a cor que cada referência solta)
  function corMedia(img) {
    const d = cobrir(img, 16, 16).getContext('2d').getImageData(0, 0, 16, 16).data;
    let r = 0, g = 0, b = 0; for (let i = 0; i < 256; i++) { r += d[i * 4]; g += d[i * 4 + 1]; b += d[i * 4 + 2]; }
    return [r / 256, g / 256, b / 256];
  }

  return { gradientField, pixelWipe, dotMatrix, meioTom, passes, corMedia, hash, hexA };
})();
