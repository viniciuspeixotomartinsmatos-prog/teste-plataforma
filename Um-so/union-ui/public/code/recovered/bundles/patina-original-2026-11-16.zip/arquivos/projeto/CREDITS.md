# Créditos e licenças

- **Música** (`audio/trilha/laser-groove.mp3`): "Laser Groove", Kevin MacLeod (incompetech.com), licença Creative Commons Attribution 4.0 (https://creativecommons.org/licenses/by/4.0/). Uso comercial e sincronização com vídeo liberados **com crédito obrigatório**. O filme usa a faixa editada (recortada nos compassos, equalizada e mixada com efeitos). Ao postar, ponha na legenda, na descrição ou nos créditos:

  > "Laser Groove" Kevin MacLeod (incompetech.com)
  > Licensed under Creative Commons: By Attribution 4.0 License
  > http://creativecommons.org/licenses/by/4.0/
  > Editada do original (recortada e mixada com efeitos sonoros).

  Sem crédito: gere o filme com `--sem-musica` e use uma música da biblioteca do Instagram ou do TikTok.
- **Efeitos sonoros**: sintetizados em código (`tools/sfx.py`), sem amostras de terceiros. Livres.
- **Fontes**: Instrument Sans e Instrument Serif (SIL Open Font License).
- **Ícones**: lucide (ISC), em `engine/js/lucide.js`; os ícones desenhados para o filme são livres.
- **Bibliotecas**: GSAP e CustomEase (licença padrão da GreenSock, gratuita, inclusive para uso comercial), Playwright (Apache 2.0), ffmpeg pelo pacote @ffmpeg-installer (LGPL), numpy, scipy, soundfile, pyloudnorm.
- **Demonstração**: a Patina é uma marca fictícia. As imagens da demonstração (`midia/demo/`) foram geradas por IA para esta marca fictícia, com as receitas em `midia/demo/receitas/`; servem para ver a demonstração funcionando. No filme da sua marca, troque pelas suas.
