// gancho, vao e etapas: dividem o mesmo palco (a frase do gancho abre o vão; as imagens do vão viram as cores das etapas).
//
// gancho — a pergunta com chaves { } que abrem palavra a palavra e alças de seleção que pulam no tempo.
//   { tipo: "gancho", antes: "E se a IA tivesse", dentro: "o seu", destaque: "gosto", fim: "?" }
// vao — o vão entre "dentro" e "destaque" abre; imagens giram dentro dele (caça-níquel) e explodem num painel.
//   { tipo: "vao", imagens: [6 a 8], final?: [3 índices], pilula: "**8** referências", pilula_icone?: "imagem" }
// etapas — cada imagem solta a sua cor; os pontos viram a paleta e a lista de etapas entra, um item por batida.
//   { tipo: "etapas", titulo, itens: [{ icone, rotulo, valor? | cores: true | chip: "nome" }], status: ["Destilando…", "Pronta"] }
window.CENA_gancho = () => {
  const cg = F.cena('gancho'), cv = F.cena('vao'), ce = F.cena('etapas');
  const { tl, add, q, qa, cue, C, popIn, popOut, rect } = F;
  const IMG = F.img;
  const t0s = (cg || cv || ce).t0, t1s = (ce || cv || cg).t1;
  const s = F.scene('s234', cg ? Math.max(0, cg.t0 - .028) : t0s, t1s, 2);
  let tiles = null, MBv = null, mbEls = null, gapR = null;

  // ---------------- gancho ----------------
  const G = cg.cfg;
  const O = cg.off, bar = (i, b) => F.bar(i, b) + O;
  const antes = F.palavras(G.antes ?? 'E se a IA tivesse');
  const wrap = add(`<div class="s2-line"><div class="row" style="display:flex;align-items:baseline">
    ${antes.map((w, i) => `<span class="slot" data-k="a${i}"><span class="w">${F.esc(w)}</span>&nbsp;</span>`).join('')}
    <span class="slot" data-k="bl"><span class="br">{</span></span>
    <span class="slot" data-k="your"><span class="w">${F.esc(G.dentro ?? 'o seu')}</span>&nbsp;</span>
    <span class="slot" data-k="gap" style="overflow:visible"><span class="s2-gap"></span></span>
    <span class="slot" data-k="taste"><span class="w taste">${F.esc(G.destaque ?? 'gosto')}</span></span>
    <span class="slot" data-k="br"><span class="br">}</span></span>
    ${(G.fim ?? '?') ? `<span class="slot" data-k="q"><span class="w">${F.esc(G.fim ?? '?')}</span></span>` : ''}</div></div>`, s);
  const slot = {}; qa('.slot', wrap).forEach(el => slot[el.dataset.k] = el);
  const A = antes.map((_, i) => 'a' + i);
  // cabe: a frase inteira (sem o vão) em 1700 px
  const row = q('.row', wrap);
  slot.gap.style.width = '0px';
  F.caber(wrap, 1700, { nome: 'gancho', medir: row });
  const nat = {}; for (const k in slot) nat[k] = rect(slot[k]).w;
  nat.gap = 600;
  const setW = st => { for (const k in slot) slot[k].style.width = (st[k] ? nat[k] : 0) + 'px'; };
  const W = (k, t, on, { dur = .34, ease = 'out' } = {}) => slot[k] && tl.to(slot[k], { width: on ? nat[k] : 0, duration: dur, ease }, t);
  const word = k => slot[k] && (q('.w', slot[k]) || q('.br', slot[k]));

  const base = {}; A.forEach(k => base[k] = 1);
  setW({ ...base, bl: 1, your: 1, br: 1 });
  const rB1 = { x: rect(slot.bl).x, y: 0, w: rect(slot.br).x + nat.br - rect(slot.bl).x };
  const rBr2 = (() => { setW({ ...base, bl: 1, your: 1, taste: 1, br: 1 }); const a = rect(slot.bl), b = rect(slot.br); return { a, b }; })();
  const rTaste = (() => { setW({ ...base, bl: 1, your: 1, taste: 1, br: 1, q: 1 }); return rect(word('taste')); })();
  const yMid = rect(word('your'));
  const boxY = yMid.y - 8, boxH = yMid.h + 16;
  setW({ bl: 1, your: 1, gap: 1, taste: 1, br: 1 });
  gapR = rect(q('.s2-gap', wrap));
  setW(base);

  // as palavras de antes entram juntas, em cascata curta
  A.forEach((k, i) => popIn(word(k), 3.95 + O + i * Math.min(.06, .3 / A.length), { y: 16, blur: 10 }));
  const tB = bar(2, 1), tY = bar(2, 1.1), tT = bar(2, 2), tQ = bar(2, 2.5);
  W('bl', tB, 1, { dur: .3 }); W('br', tB, 1, { dur: .3 });
  popIn(word('bl'), tB, { y: 0, blur: 6, dur: .3 }); popIn(word('br'), tB, { y: 0, blur: 6, dur: .3 });
  W('your', tY, 1, { dur: .36 }); popIn(word('your'), tY + .04, { y: 12 });
  W('taste', tT, 1, { dur: .4 }); popIn(word('taste'), tT + .04, { y: 14, tint: C.brilho });
  if (slot.q) { W('q', tQ, 1, { dur: .26 }); popIn(word('q'), tQ + .03, { y: 10 }); }
  cue(tY + .05, 'pop', 's2:your', { pitch: 0 }); cue(tT + .05, 'pop', 's2:taste', { pitch: 2 });

  const H = F.handles(s, { size: 12 });
  const r1 = { x: rB1.x - 14, y: boxY - 6, w: rB1.w + 28, h: boxH + 12 };
  H.show(tB + .08, r1);
  cue(tB + .08, 'tick', 's2:handles-in');
  const r2 = { x: rBr2.a.x - 14, y: boxY - 10, w: rBr2.b.x + nat.br - rBr2.a.x + 28, h: boxH + 20 };
  H.to(tT + .06, r2); cue(tT + .06, 'tick', 's2:handles-1');
  H.to(bar(2, 3), F.pad(rTaste, 12, 6)); cue(bar(2, 3), 'tick', 's2:handles-2');
  H.hide(bar(3) - .1);
  const todas = [...A, 'bl', 'your', 'taste', 'br', ...(slot.q ? ['q'] : [])];
  if (!cv) {
    // sem o vão: a frase sai inteira no fim do compasso
    todas.forEach((k, i) => popOut(word(k), cg.t1 - .3 + i * .012, { dur: .26 }));
    return;
  }

  // ---------------- vão ----------------
  const V = cv.cfg, OV = cv.off, barV = (i, b) => F.bar(i, b) + OV;
  const REFS = (V.imagens || []).slice(0, 8);
  if (REFS.length < 3) F.aviso('vao: precisa de 3 a 8 imagens (ideal 8)');
  const t3 = barV(3);
  [...A, ...(slot.q ? ['q'] : [])].forEach((k, i) => { W(k, t3, 0, { dur: .5, ease: 'io' }); popOut(word(k), t3 - .08 + i * .015, { dur: .2 }); });
  W('gap', t3 + .14, 1, { dur: .5, ease: 'io' });
  cue(t3 + .32, 'swoosh_s', 's3:gap', { note: 'swoosh curto quando o vão abre' });
  const gap = q('.s2-gap', wrap);
  tiles = [{ w: 140, h: 176, dx: -178 }, { w: 186, h: 234, dx: 0 }, { w: 140, h: 176, dx: 178 }].map((d, i) => {
    const el = add(`<div class="s2-tile" style="width:${d.w}px;height:${d.h}px;left:calc(50% + ${d.dx - d.w / 2}px);margin-top:${-d.h / 2 - 22}px">${REFS.map(r => `<img src="${IMG(r)}">`).join('')}</div>`, gap);
    gsap.set(el, { opacity: 0 });
    popIn(el, t3 + .36 + Math.abs(i - 1) * .06, { y: 0, s: .9, blur: 10, dur: .4 });
    return { el, imgs: qa('img', el), d };
  });
  const N = REFS.length;
  const steps = 11, dt = .068, tc0 = t3 + .3;
  const finals = (V.final && V.final.length === 3 ? V.final : [1, 4, 3]).map(i => Math.min(i, N - 1));
  tiles.forEach(tile => tile.imgs.forEach(im => gsap.set(im, { opacity: 0 })));
  for (let s_ = 0; s_ <= steps; s_++) {
    const t = tc0 + s_ * dt;
    tiles.forEach((tile, ti) => {
      const idx = s_ === steps ? finals[ti] : (s_ * 3 + ti * 5) % N;
      tile.imgs.forEach((im, k) => tl.set(im, { opacity: k === idx ? 1 : 0 }, t));
    });
    if (s_ % 2 === 0 || s_ === steps) cue(t, 'tick', `s3:slot${s_}`, { soft: s_ !== steps });
  }

  // explode num painel de referências
  const tBurst = barV(3, 2.4);
  ['bl', 'your', 'taste', 'br'].forEach((k, i) => popOut(word(k), tBurst + i * .02, { dur: .3, y: 0, blur: 12 }));
  const LAY = [
    { x: 236, y: 150, w: 250, h: 312, rot: -3 }, { x: 560, y: 590, w: 228, h: 285, rot: 2.2 },
    { x: 812, y: 120, w: 250, h: 250, rot: 1.5 }, { x: 1128, y: 600, w: 260, h: 260, rot: -2.4 },
    { x: 1446, y: 140, w: 244, h: 305, rot: 2.6 }, { x: 1500, y: 560, w: 214, h: 268, rot: -1.6 },
    { x: 262, y: 620, w: 220, h: 220, rot: 3.1 }, { x: 830, y: 410, w: 330, h: 220, rot: -1.2 },
  ];
  // com menos de 8 imagens, as posições que ficam equilibradas
  const SUB = { 8: [0, 1, 2, 3, 4, 5, 6, 7], 7: [0, 1, 2, 3, 4, 5, 6], 6: [0, 1, 2, 3, 4, 6], 5: [0, 2, 3, 4, 6], 4: [0, 2, 3, 4], 3: [0, 2, 4] };
  MBv = SUB[Math.max(3, Math.min(8, N))].map((li, i) => ({ ...LAY[li], r: REFS[i], i }));
  const fromGap = {}; finals.forEach((fi, ti) => { if (!(fi in fromGap)) fromGap[fi] = ti; });
  mbEls = MBv.map((m, i) => {
    const el = add(`<div class="mb-tile" style="width:${m.w}px;height:${m.h}px"><img src="${IMG(m.r)}"></div>`, s);
    gsap.set(el, { x: m.x, y: m.y, rotation: m.rot, opacity: 0, zIndex: 4 });
    if (i in fromGap) {
      const ti = fromGap[i], d = tiles[ti].d;
      const sx = gapR.x + 300 + d.dx - d.w / 2, sy = gapR.y + gapR.h / 2 - d.h / 2 - 22;
      // nasce exatamente onde estava a imagem do vão e voa para o lugar
      tl.set(tiles[ti].el, { opacity: 0 }, tBurst);
      tl.fromTo(el, { x: sx + (d.w - m.w) / 2, y: sy + (d.h - m.h) / 2, scale: d.w / m.w, rotation: 0, opacity: 1 },
        { x: m.x, y: m.y, scale: 1, rotation: m.rot, duration: .62, ease: 'io', immediateRender: false }, tBurst);
    } else {
      const t = tBurst + .1 + i * .035;
      tl.fromTo(el, { opacity: 0, scale: .94, filter: 'blur(10px)', y: m.y + 20 }, { opacity: 1, scale: 1, filter: 'blur(0px)', y: m.y, duration: .5, ease: 'out', immediateRender: false }, t);
    }
    return el;
  });
  tiles.forEach((tile, ti) => { if (!finals.slice(0, ti).includes(finals[ti]) ) return; tl.to(tile.el, { opacity: 0, duration: .2, ease: 'exit' }, tBurst); });
  cue(tBurst + .02, 'swoosh_s', 's3:burst');
  [0, 2, 4, 6].filter(k => k < MBv.length).forEach((k, i) => cue(tBurst + .16 + k * .035, 'pop', `s3:mb${k}`, { pitch: i, pan: F.pan(MBv[k].x + MBv[k].w / 2) }));
  let pill = null;
  if (V.pilula !== '') {
    pill = add(`<div class="pill" style="position:absolute;left:0;top:0">${K.icone(V.pilula_icone || 'imagem', C.tintaC, { size: 24, cls: 'pi' })}<span>${F.rico(V.pilula ?? `**${N}** referências`)}</span></div>`, s);
    gsap.set(pill, { zIndex: 6 });
    const pr = rect(pill); gsap.set(pill, { x: 960 - pr.w / 2, y: 952 });
    popIn(pill, barV(3, 3.3), { y: 14 });
  }
  if (!ce) {
    // sem as etapas: o painel sai no fim do compasso
    mbEls.forEach((el, i) => tl.to(el, { scale: .94, opacity: 0, filter: 'blur(10px)', duration: .3, ease: 'exit' }, cv.t1 - .34 + i * .012));
    if (pill) popOut(pill, cv.t1 - .3, { dur: .25 });
    return;
  }
  F.GANCHO = { pill };
};

window.CENA_etapas = () => {
  const ce = F.cena('etapas'); if (!ce) return;
  const { tl, add, q, qa, cue, C, popIn, popOut, rect } = F;
  const s = F.q('#s234') || F.scene('s234', ce.t0, ce.t1, 2);
  const E = ce.cfg, O = ce.off, bar = (i, b) => F.bar(i, b) + O;
  const t4 = bar(4);
  const PAL = C.paleta;
  const P = PAL.length;
  const comVao = !!F.cena('vao');
  // de onde saem os pontos: das imagens do painel (cada uma solta a cor mais próxima da paleta) ou do meio da tela
  const tilesMB = comVao ? F.qa('.mb-tile', s) : [];
  const fontes = tilesMB.map(el => { const r = rect(el); return { x: r.x + r.w / 2, y: r.y + r.h / 2, img: q('img', el) }; });
  const vcfg = F.cfgDe('vao');
  let map;
  if (fontes.length) {
    map = vcfg.cores && vcfg.cores.length ? vcfg.cores.map(i => Math.min(i, P - 1)) : fontes.map(f => {
      const m = FX.corMedia(PRE[f.img.getAttribute('src').slice(1)] || f.img);
      let best = 0, bd = 1e9; PAL.map(F.rgbOf).forEach((p, k) => { const d = (p[0] - m[0]) ** 2 + (p[1] - m[1]) ** 2 * 1.2 + (p[2] - m[2]) ** 2; if (d < bd) { bd = d; best = k; } });
      return best;
    });
    for (let k = 0; k < P; k++) if (!map.includes(k)) map[k % map.length] = k;   // toda cor da paleta aparece
  } else map = PAL.map((_, k) => k);
  const pill = F.GANCHO && F.GANCHO.pill;
  if (pill) popOut(pill, t4, { dur: .25 });
  const sx = k => 960 + (k - (P - 1) / 2) * 82;
  const dots = map.map((pk, i) => {
    const d = add(`<i class="pdot" style="background:${PAL[pk]}"></i>`, s);
    const t = t4 + .02 + i * .03;
    if (fontes[i]) {
      gsap.set(d, { x: fontes[i].x, y: fontes[i].y, zIndex: 8, opacity: 0 });
      tl.fromTo(d, { opacity: 0, scale: .6 }, { opacity: 1, scale: 1, duration: .3, ease: 'out', immediateRender: false }, t);
      tl.to(tilesMB[i], { scale: .9, opacity: 0, filter: 'blur(10px)', duration: .42, ease: 'exit' }, t + .06);
    } else {
      gsap.set(d, { x: sx(pk), y: 540 + 30, zIndex: 8, opacity: 0 });
      tl.fromTo(d, { opacity: 0, scale: .6, filter: 'blur(6px)' }, { opacity: 1, scale: 1, filter: 'blur(0px)', duration: .4, ease: 'out', immediateRender: false }, t + .2 + i * .04);
    }
    return d;
  });
  cue(t4 + .1, 'swoosh_l', 's4:gather', { note: 'swoosh longo quando as cores voam' });
  const landed = {};
  dots.forEach((d, i) => {
    const t = t4 + .22 + i * .04;
    tl.to(d, { x: sx(map[i]), y: 540, duration: .62, ease: 'io' }, t);
    if (!(map[i] in landed)) landed[map[i]] = t + .5;
  });
  Object.entries(landed).sort((a, b) => a[1] - b[1]).forEach(([k, t], i) => cue(t, 'pop', `s4:swatch${k}`, { pitch: i + 1, pan: F.pan(sx(+k)) }));
  tl.to(dots, { scale: 1.25, duration: .25, ease: 'out', stagger: .02 }, t4 + .9);

  // a lista
  const itens = (E.itens || []).slice(0, 5);
  if (itens.length < 3) F.aviso('etapas: use 3 a 5 itens');
  const n = itens.length;
  const st = E.status || ['Destilando…', 'Pronta'];
  const valor = (it, i) => it.cores ? PAL.map(c => `<i class="sw" style="background:${c}"></i>`).join('')
    : it.chip ? `<span class="keychip">${K.mini(4)}${F.esc(it.chip)}</span>` : F.esc(it.valor ?? '');
  const list = add(`<div class="s4-list">
    <div class="s4-title">${F.esc(E.titulo ?? 'Destilando o seu estilo')}</div>
    <div class="s4-items"><i class="s4-rail"></i>
      ${itens.map((it, i) => `<div class="s4-item" data-i="${i}">${K.icone(it.icone || 'sparkles', i === n - 1 ? C.acento2 : C.acento)}<span class="lb">${F.esc(it.rotulo ?? '')}</span><span class="va">${valor(it, i)}</span></div>`).join('')}
    </div>
    <div class="s4-status"><span class="st1">${F.esc(st[0] ?? '')}</span><span class="st2" style="position:absolute;display:inline-flex;align-items:center;gap:8px;color:${C.acento2}">${K.I.check(C.acento2)}${F.esc(st[1] ?? '')}</span></div>
  </div>`, s);
  const items = qa('.s4-item', list), title = q('.s4-title', list), rail = q('.s4-rail', list);
  // a coluna dos rótulos e a largura: medidas, e a lista centrada (nunca sai do quadro)
  const lbw = Math.max(250, ...qa('.lb', list).map(e => { e.style.width = 'auto'; const w = rect(e).w; e.style.width = ''; return Math.ceil(w + 34); }));
  list.style.setProperty('--lbw', lbw + 'px');
  const largura = Math.max(rect(title).w ? (() => { title.style.display = 'inline-block'; const w = rect(title).w; title.style.display = ''; return w; })() : 0,
    ...items.map(it => { const a = rect(it), b = rect(q('.va', it)); return b.x + b.w - a.x + 102; }));
  const esc = Math.min(1, 1640 / largura);
  if (esc < .7) F.aviso('etapas: textos longos demais (a lista ficou em ' + Math.round(esc * 100) + '%); encurte o título ou os valores');
  const left = Math.max(140, Math.min(470, (1920 - largura * esc) / 2));
  const yTop = 214 - Math.max(0, n - 5) * 46 + (5 - n) * 46;
  gsap.set(list, { x: left - 470, y: yTop, zIndex: 7, scale: esc });
  const st2 = q('.st2', list), st1 = q('.st1', list);
  gsap.set(st2, { x: -rect(st1).w / esc, opacity: 0 });
  gsap.set(rail, { height: n * 92 - 20, scaleY: 0 });
  const tTitle = t4 + .62;
  popIn(title, tTitle, { y: 18, blur: 12, dur: .6 });
  tl.fromTo(title, { backgroundPosition: '100% 0' }, { backgroundPosition: '0% 0', duration: 2.4, ease: 'none', immediateRender: false }, tTitle);
  // os tempos dos itens: o último sempre na 4ª batida do 2º compasso; os outros uma batida antes cada
  const tItems = items.map((_, i) => { const b = 3 - (n - 1 - i); return b >= 0 ? bar(5, b) : t4 + 1.26 + (b + 1) * .15; });
  const iCores = itens.findIndex(it => it.cores);
  const tMove = tItems[Math.max(0, iCores)] - .24;
  if (iCores >= 0) {
    // a paleta voa para dentro do item das cores
    const sws = qa('.sw', items[iCores]);
    gsap.set(sws, { opacity: 0 });
    const swR = sws.map(e => { const r = rect(e); return { x: r.x + r.w / 2, y: r.y + r.h / 2 }; });
    dots.forEach((d, i) => tl.to(d, { x: swR[map[i]].x, y: swR[map[i]].y, scale: 26 * esc / 34, duration: .5, ease: 'io' }, tMove + map[i] * .03));
    tl.set(dots, { opacity: 0 }, tMove + .62); tl.set(sws, { opacity: 1 }, tMove + .62);
  } else {
    // sem item de cores: as cores voam juntas para o lugar dos ícones (seguindo a lista, que sobe devagar) e cada uma
    // vira o ícone quando a etapa entra
    const listY = t => F.kf(t, [[t4 + 1.3, yTop], [t4 + 3.7, yTop - 64, 'io']]);
    const eio = F.EASE('io');
    const voo = dots.map((d, i) => {
      const j = Math.min(i, n - 1), r = rect(q('.ic', items[j]));
      const t0 = Math.min(tMove, t4 + 1.02) + i * .03;
      return { d, j, x0: sx(map[i]), y0: 540, x1: r.x + r.w / 2, y1: r.y + r.h / 2, t0, tFim: tItems[j] + .04 };
    });
    F.apply(t => {
      if (t < ce.t0 || t > ce.t1) return;
      for (const v of voo) {
        if (t < v.t0) continue;
        const k = eio(Math.min(1, (t - v.t0) / .5));
        const dy = listY(t) - yTop;
        const sc = F.lerp(1.25, 22 * esc / 34, k);
        const op = t < v.tFim ? 1 : Math.max(0, 1 - (t - v.tFim) / .14);
        gsap.set(v.d, { x: F.lerp(v.x0, v.x1, k), y: F.lerp(v.y0, v.y1 + dy, k), scale: t < v.tFim ? sc : sc * (1 - .6 * (1 - op)), opacity: op });
      }
    });
  }
  items.forEach((it, i) => {
    const lb = q('.lb', it), va = q('.va', it), ic = q('.ic', it);
    const t = tItems[i];
    popIn(ic, t, { y: 0, x: -10, blur: 8, dur: .45 });
    popIn(lb, t + .03, { y: 0, x: -14, blur: 8, dur: .5, tint: i === n - 1 ? C.acento2 : C.acento });
    if (i !== iCores) popIn(va, t + .08, { y: 0, x: -10, blur: 8, dur: .55 });
    tl.to(rail, { scaleY: (i + 1) / n, duration: .4, ease: 'out' }, t);
    cue(t, i === n - 1 ? 'lock' : 'tick2', `s4:item${i}`, { pitch: i });
  });
  popIn(st1, Math.min(t4 + 1.3, tItems[0] + .04), { y: 0, blur: 6 });
  tl.to(st1, { opacity: 0, filter: 'blur(6px)', duration: .2, ease: 'exit' }, tItems[n - 1]);
  tl.fromTo(st2, { opacity: 0, filter: 'blur(6px)' }, { opacity: 1, filter: 'blur(0px)', duration: .35, ease: 'out', immediateRender: false }, tItems[n - 1] + .05);
  tl.to(list, { y: yTop - 64, duration: 2.4, ease: 'io' }, t4 + 1.3);
};
