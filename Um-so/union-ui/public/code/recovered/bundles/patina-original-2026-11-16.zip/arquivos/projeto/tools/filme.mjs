// filme.mjs — o filme inteiro de uma vez: linha do tempo → quadros → trilha → mixagem → MP4.
//   node tools/filme.mjs <filme> [--rascunho] [--sem-musica] [--abas 3]
// Saída: out/<filme>/<filme>.mp4 (1920×1080, 30 fps, H.264, áudio AAC). --rascunho: 960×540, para conferir rápido.
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { RAIZ, args, lerFilme, ffmpeg, python } from './comum.mjs';

const { pos, opt } = args();
const nome = pos[0];
if (!nome) { console.log('uso: node tools/filme.mjs <filme> [--rascunho] [--sem-musica] [--abas 3]'); process.exit(1); }
lerFilme(nome);
const OUT = path.join(RAIZ, 'out', nome);
const run = (cmd, a) => execFileSync(cmd, a, { stdio: 'inherit', cwd: RAIZ });
console.log('— linha do tempo e eventos de som');
run('node', ['tools/render.mjs', nome, 'linha']);
console.log('— quadros');
const video = path.join(OUT, opt.rascunho ? 'video-rascunho.mp4' : 'video.mp4');
run('node', ['tools/render.mjs', nome, 'video', '--abas', String(opt.abas || 3), ...(opt.rascunho ? ['--rascunho'] : [])]);
console.log('— trilha e mixagem');
run(python(), ['tools/trilha.py', nome]);
run(python(), ['tools/mix.py', nome, ...(opt['sem-musica'] ? ['--sem-musica'] : [])]);
console.log('— MP4');
const mp4 = path.join(OUT, `${nome}${opt.rascunho ? '-rascunho' : ''}${opt['sem-musica'] ? '-sem-musica' : ''}.mp4`);
execFileSync(ffmpeg(), ['-v', 'error', '-y', '-i', video, '-i', path.join(OUT, 'mix.wav'), '-map', '0:v', '-map', '1:a',
  '-c:v', 'copy', '-c:a', 'aac', '-b:a', '256k', '-shortest', '-movflags', '+faststart', mp4], { stdio: 'inherit' });
console.log(`pronto → ${path.relative(RAIZ, mp4)}`);
