// montagem e baralho: dividem o palco (a imagem montada é a primeira carta do baralho).
//
// montagem — pontos nas cores da paleta pipocam e montam a imagem; no drop da música ela passa por dois passes de
// "falsa cor" e resolve na foto.
//   { tipo: "montagem", imagem, foco?: "50% 50%", pilula: "Gerando com **Linho de Domingo**", passes?: { a: [...], b: [...] } }
// baralho — variações trocam no tempo e empilham num baralho 3D; quatro palavras em volta da carta da frente.
//   { tipo: "baralho", imagens: [4 a 8], palavras: ["Cada", "foto.", "Seu", "visual."] }
window.CENA_montagem = () => {
  const cm = F.cena('montagem'), cb = F.cena('baralho');
  if (!cm && !cb) return;
  const { tl, add, q, qa, cue, C, popIn, popOut, rect, kf, clamp, lerp, EASE } = F;
  const IMG = F.img;
  const Mc = cm ? cm.cfg : {}, Bc = cb ? cb.cfg : {};
  const Om = cm ? cm.off : null, Ob = cb ? cb.off : null;
  const barM = (i, b) => F.bar(i, b) + Om, barB = (i, b) => F.bar(i, b) + Ob;
  const t0 = (cm || cb).t0, tEnd = (cb || cm).t1 + .05;
  const tDrop = cm ? barM(8) : null;
  const s = F.scene('s67', t0, tEnd, 3);
  const cam = add(`<div class="s7-cam" style="z-index:2"><div class="s7-deck"></div></div>`, s);
  const deck = q('.s7-deck', cam);
  // as cartas e quando cada uma entra
  const vars = (Bc.imagens || []).slice(0, 8);
  const slotsB = cb ? [barB(9), barB(9, 2), barB(9, 3), barB(10), barB(10, 1), barB(10, 2), barB(10, 3), barB(11)] : [];
  const pick = (n, of) => n >= of ? [...Array(of).keys()] : [...Array(n).keys()].map(i => Math.round(i * (of - 1) / Math.max(1, n - 1)));
  const E = [], NAMES = [];
  if (cm) { E.push(tDrop); NAMES.push(Mc.imagem); }
  if (cb) {
    if (vars.length < 3) F.aviso('baralho: use 4 a 8 imagens');
    const idx = pick(vars.length, 8);
    if (!cm) { E.push(cb.t0 + .05); NAMES.push(vars[0]); idx.shift(); vars.shift(); }
    idx.forEach((j, i) => { if (vars[i]) { E.push(slotsB[j]); NAMES.push(vars[i]); } });
  }
  const foco = Mc.foco || '50% 50%';
  const cards = NAMES.map((n, k) => {
    const inner = k === 0 && cm
      ? `<img class="pa" src="${PASSES.a}" style="position:absolute;inset:0;object-position:${foco}"><img class="pb" src="${PASSES.b}" style="position:absolute;inset:0;object-position:${foco}"><img class="ph" src="${IMG(n)}" style="position:absolute;inset:0;object-position:${foco}">`
      : `<img src="${IMG(n)}">`;
    const c = add(`<div class="s7-card">${inner}</div>`, deck);
    gsap.set(c, { opacity: 0 });
    return c;
  });
  if (cm) {
    // pontos da paleta montam a imagem
    const dm = FX.dotMatrix(s, PRE[Mc.imagem], { z: 5, t0: 13.0 + Om + .04, t1: 13.84 + Om, tc: tDrop - .02, tEnd: tDrop + .32 });
    F.apply(t => dm.draw(t));
    cue(13.04 + Om, 'granular', 's6:dots', { dur: 1.1, note: 'ripple granular sob a matriz de pontos' });
    cue(tDrop, 'swell', 's6:riser', { note: 'swell reverso terminando no drop' });
    cue(tDrop, 'impact', 's6:drop', { note: 'a revelação no acento da música' });
    if (Mc.pilula !== '') {
      const lab = add(`<div class="pill" style="position:absolute;left:0;top:0;gap:12px"><i style="width:12px;height:12px;border-radius:50%;background:${C.acento};display:block"></i>${F.rico(Mc.pilula ?? 'Gerando com **Linho de Domingo**')}</div>`, s);
      gsap.set(lab, { zIndex: 6 }); const lr = rect(lab); gsap.set(lab, { x: 960 - lr.w / 2, y: 930 });
      popIn(lab, Math.max(cm.t0, 13.0 + Om - cm.lead) + .12, { y: 12 }); popOut(lab, tDrop - .14, { dur: .2 });
    }
    const pa = q('.pa', cards[0]), pb = q('.pb', cards[0]), ph = q('.ph', cards[0]);
    gsap.set([pb, ph], { opacity: 0 });
    tl.set(pb, { opacity: 1 }, tDrop + .067); tl.set(pb, { opacity: 0 }, tDrop + .134);
    tl.fromTo(ph, { opacity: 0 }, { opacity: 1, duration: .42, ease: 'quick', immediateRender: false }, tDrop + .134);
    const flash = add(`<i class="flash" style="z-index:9"></i>`, s); gsap.set(flash, { opacity: 0 });
    tl.fromTo(flash, { opacity: .6 }, { opacity: 0, duration: .4, ease: 'out', immediateRender: false }, tDrop);
  }

  // a saída: floração para o gradiente (manifesto/formatos) ou desfoque sobre o fundo
  const fim = (cb || cm);
  const proxGrad = ['manifesto', 'formatos'].includes(fim.prox);
  const tB = fim.t1 - .7 * F.BEAT * (cb ? 1 : 1);                 // = bar(11, 3.3) no filme completo
  const bl = { b: 0 };
  // baralho 3D (função pura do tempo)
  const eo = EASE('out'), eio = EASE('io');
  const camStart = cb ? barB(9) : tDrop + F.BAR, camEnd = cb ? barB(11) + .8 : tDrop + F.BAR + .8;
  F.apply(t => {
    if (t < t0 || t > tEnd) return;
    const camX = cb ? kf(t, [[camStart, 0], [camEnd, 170, 'io']]) : 0;
    cards.forEach((c, k) => {
      if (t < E[k]) { gsap.set(c, { opacity: 0 }); return; }
      const first = k === 0 && cm;
      const a = first ? 1 : eo(clamp((t - E[k]) / .52, 0, 1));
      let d = 0; for (let j = k + 1; j < cards.length; j++) d += eio(clamp((t - E[j]) / .55, 0, 1));
      const age = t - E[k];
      const push = Math.min(age, 1.8) * 24 * (1 - Math.min(d, 1));
      const x = -d * 86 + (1 - a) * 170 + camX;
      const y = d * 9 - (1 - a) * 10;
      const z = -d * 150 + (1 - a) * 200 + push;
      const ry = (first ? kf(t, [[tDrop, 0], [tDrop + F.BAR, -6, 'io']]) : lerp(-14, -6, a)) - Math.min(d, 1.6) * 13;
      const far = clamp((d - 5) / 2.5, 0, 1);
      const bb = bl.b;
      gsap.set(c, { x, y, z: z + bb * 120, rotationY: ry, opacity: (first ? 1 : a) * (1 - far) * (1 - bb * (proxGrad ? .35 : 1)),
        filter: `brightness(${(1 - Math.min(d, 6) * .045 + bb * .12).toFixed(3)}) saturate(${(1 + bb * .4).toFixed(2)}) blur(${(bb * 26).toFixed(1)}px)`, zIndex: k });
    });
  });
  for (let k = 1; k < E.length; k++) cue(E[k] + .03, 'swoosh_s', `s7:card${k}`, { soft: true, pitch: k % 3 });

  if (cb) {
    // palavras em volta da carta da frente
    const P4 = Bc.palavras || ['Cada', 'foto.', 'Seu', 'visual.'];
    const word = (txt, x, y, cls = '') => { const w = add(`<div class="s7-word ${cls}">${F.esc(txt)}</div>`, s); gsap.set(w, { x, y, zIndex: 10 }); return w; };
    const wEvery = word(P4[0] || '', 560, 70), wShot = word(P4[1] || '', 1180, 900);
    const wYour = word(P4[2] || '', 1488, 330), wLook = word(P4[3] || '', 1494, 420, 'serif');
    // cabe: as da direita até 1860 px; a de cima antes da carta (≤ 1240); a de baixo até 1860
    const fit = (w, maxR) => { const r = rect(w); if (r.x + r.w > maxR) { const k = Math.max(.6, (maxR - r.x) / r.w); w.style.setProperty('--k', k); if (k === .6) F.aviso(`baralho: a palavra "${w.textContent}" é longa demais`); } };
    fit(wEvery, 1860); fit(wShot, 1860); fit(wYour, 1860); fit(wLook, 1860);
    // as duas da direita com o mesmo corpo
    const kR = Math.min(+(wYour.style.getPropertyValue('--k') || 1), +(wLook.style.getPropertyValue('--k') || 1));
    wYour.style.setProperty('--k', kR); wLook.style.setProperty('--k', kR);
    gsap.set(wLook, { color: C.acento });
    popIn(wEvery, barB(9, 1), { y: 20, blur: 12 }); popIn(wShot, barB(9, 2), { y: 20, blur: 12 });
    popOut(wEvery, barB(10) + .02, { dur: .26 }); popOut(wShot, barB(10) + .06, { dur: .26 });
    popIn(wYour, barB(10, 1), { y: 20, blur: 12 }); popIn(wLook, barB(10, 2), { y: 22, blur: 12, tint: C.brilho });
    popOut(wYour, barB(11, 3.6), { dur: .3 }); popOut(wLook, barB(11, 3.65), { dur: .3 });
    cue(barB(9, 1), 'pop', 's7:every', { pitch: 0 }); cue(barB(9, 2), 'pop', 's7:shot', { pitch: 1 });
    cue(barB(10, 1), 'pop', 's7:your', { pitch: 2 }); cue(barB(10, 2), 'pop', 's7:look', { pitch: 3 });
  }

  // floração: o baralho desfoca (e o gradiente sobe, na cena seguinte); sem gradiente depois, só some no fundo
  tl.fromTo(bl, { b: 0 }, { b: 1, duration: .8, ease: 'quick', immediateRender: false }, tB);
  cue(tB + .45, 'swoosh_l', 's7:bloom', { note: 'swoosh longo para o gradiente' });
  if (proxGrad) cue(fim.t1, 'sub', 's8:section', { note: 'grave na troca de seção' });
  F.BLOOM = proxGrad ? tB : null;
};
