// Monta o filme depois que fontes e imagens estão prontas; expõe window.seek(t), window.CUES e window.LINHA para o render.
window.PRE = {};
(async () => {
  try {
    const { CFG, C } = F;
    // ---- fontes: "Inst" (texto), "Serif" (destaque), "Logo" (o nome da marca); sem nada no config, Instrument Sans/Serif ----
    const FT = CFG.fontes || {};
    const texto = FT.texto || { arquivos: [{ arquivo: 'engine/fontes/InstrumentSans-var.woff2', peso: '400 700' }, { arquivo: 'engine/fontes/InstrumentSans-italic-var.woff2', peso: '400 700', estilo: 'italic' }] };
    const dest = FT.destaque || { arquivos: [{ arquivo: 'engine/fontes/InstrumentSerif-Italic.woff2', estilo: 'italic' }, { arquivo: 'engine/fontes/InstrumentSerif-Regular.woff2' }] };
    const logoF = (CFG.marca && CFG.marca.fonte) || texto;
    const faces = [];
    const reg = (fam, def) => (def.arquivos || []).forEach(a => faces.push(new FontFace(fam, `url(${F.img(a.arquivo)})`, { weight: String(a.peso || 400), style: a.estilo || 'normal', display: 'block' })));
    reg('Inst', texto); reg('Serif', dest); reg('Logo', logoF);
    await Promise.all(faces.map(f => f.load().then(x => document.fonts.add(x)).catch(e => F.aviso('fonte não carregou: ' + e.message))));
    if (dest.italico === false || !(dest.arquivos || []).some(a => a.estilo === 'italic')) document.documentElement.style.setProperty('--serif-estilo', 'normal');
    if (CFG.marca && CFG.marca.fonte && CFG.marca.fonte.peso) document.documentElement.style.setProperty('--logo-peso', CFG.marca.fonte.peso);
    await document.fonts.ready;

    // ---- imagens: todo caminho de imagem do config é pré-carregado (PRE[caminho]) ----
    const caminhos = new Set();
    const anda = v => { if (typeof v === 'string') { if (/\.(jpe?g|png|webp|svg)$/i.test(v)) caminhos.add(v); } else if (v && typeof v === 'object') Object.values(v).forEach(anda); };
    anda(CFG.cenas); anda(CFG.marca);
    await Promise.all([...caminhos].map(p => new Promise(res => {
      const im = new Image();
      im.onload = () => im.decode().then(() => { PRE[p] = im; res(); }, () => { PRE[p] = im; res(); });
      im.onerror = () => { F.aviso('imagem não encontrada: ' + p); res(); };
      im.src = F.img(p);
    })));
    // ---- imagens derivadas: o meio-tom do pedido e os passes de falsa cor da montagem ----
    const ped = F.cfgDe('pedido');
    if (F.cena('pedido') && ped.fundo && PRE[ped.fundo]) window.MEIOTOM = FX.meioTom(PRE[ped.fundo], { papel: ped.papel || F.claro(C.fundo, .3) });
    const mon = F.cfgDe('montagem');
    if (F.cena('montagem')) {
      if (!PRE[mon.imagem]) throw new Error('montagem: a imagem "' + mon.imagem + '" não carregou');
      const ps = mon.passes || {};
      window.PASSES = FX.passes(PRE[mon.imagem], {
        a: ps.a || [[0, F.escuro(C.acento2, .72)], [.22, F.escuro(C.acento2, .35)], [.42, C.acento2], [.6, F.claro(C.acento2, .6)], [.74, C.brilho], [.88, C.acento], [1, F.claro(C.brilho, .7)]],
        b: ps.b || [F.escuro(C.gradiente[1], .45), F.escuro(C.gradiente[1], .1), F.claro(C.gradiente[1], .7)],
      });
    }

    // ---- as cenas, na ordem ----
    CENA_abertura(); CENA_gancho(); CENA_etapas(); CENA_pedido(); CENA_montagem(); CENA_manifesto(); CENA_chamada();
    // todas as <img> do palco decodificadas (as cenas criaram novas)
    await Promise.all([...document.images].map(im => im.decode().catch(() => null)));
    window.seek = F.seek;
    window.CUES = { fps: F.FPS, duration: F.DUR, bar: F.BAR, beat: F.BEAT, t0: F.T0, drop: F.DROP, parada: F.PARADA, events: F.CUES.slice().sort((a, b) => a.t - b.t) };
    window.LINHA = { filme: F.FILME_ID, fps: F.FPS, total: Math.round(F.DUR * F.FPS), duracao: F.DUR, drop: F.DROP, parada: F.PARADA,
      cenas: F.ATIVAS.map(t => ({ tipo: t, de: F.CENAS[t].t0, ate: F.CENAS[t].t1 })), avisos: F.AVISOS };
    F.seek(0);
    document.documentElement.dataset.ready = '1';
    if (location.search.includes('play')) {
      const st = performance.now() - (parseFloat(new URLSearchParams(location.search).get('t') || '0') * 1000);
      const loop = () => { F.seek(((performance.now() - st) / 1000) % F.DUR); requestAnimationFrame(loop); };
      loop();
    } else if (location.search.includes('t=')) F.seek(parseFloat(new URLSearchParams(location.search).get('t')));
  } catch (e) {
    console.error(e); window.erroFilme = e.message + '\n' + (e.stack || ''); document.documentElement.dataset.ready = 'error';
  }
})();
