// manifesto e formatos, sobre o campo de gradiente.
//
// manifesto — a frase entra palavra a palavra, com o espaçamento relaxando e as alças crescendo com o texto; a frase abre
// e o cartão do produto sai do vão em perspectiva (free transform).
//   { tipo: "manifesto", antes: "O estúdio de IA que aprende", destaque: "o seu visual.",
//     cartao: { icone, titulo, subtitulo, cores: true, linhas: [[rótulo, valor] × até 3], miniaturas: [até 6 imagens] } }
// formatos — o cartão vira um nó ligado por fios a 3 ou 4 saídas (4:5, 16:9 em vídeo, 1:1, 9:16); a câmera corre pelos fios.
//   { tipo: "formatos", saidas: [{ imagem, foco?, texto?, fraco?, chips: [3] }], legenda: ["Uma chave.", "Todo formato."] }
window.CENA_manifesto = () => {
  const cm = F.cena('manifesto'), cf = F.cena('formatos');
  if (!cm && !cf) return;
  const { tl, add, q, qa, cue, C, popIn, popOut, rect, clamp, lerp, EASE } = F;
  const IMG = F.img;
  const t0 = (cm || cf).t0, tEnd = (cf || cm).t1;

  // ---------- o gradiente de fundo ----------
  const tB = F.BLOOM;
  const sg = F.scene('sgrad', tB != null ? tB - .02 : t0, tEnd, 4);
  const gf = FX.gradientField(sg, { z: 0 });
  gsap.set(gf.cv, { opacity: 0 });
  const tG = tB != null ? tB : t0;
  tl.fromTo(gf.cv, { opacity: 0 }, { opacity: 1, duration: .62, ease: 'quick', immediateRender: false }, tG);
  tl.fromTo(gf.st, { rise: 0 }, { rise: 1, duration: 1.3, ease: 'out', immediateRender: false }, tG);
  if (cf) tl.to(gf.st, { shift: 140, duration: 3.6, ease: 'io' }, F.bar(16) + cf.off);
  F.apply(t => { if (t >= tG - .05 && t <= tEnd + .05) gf.draw(t); });
  add(`<div class="grain"></div>`, sg);
  if (tB == null) cue(t0, 'swoosh_l', 's8:rise', { soft: true, note: 'o gradiente sobe' });

  const s = F.scene('s89', t0, tEnd, 5);
  const world = add(`<div class="abs" style="width:1920px;height:1080px;transform-origin:0 0;z-index:1"></div>`, s);
  const M = cm ? cm.cfg : {}, Fc = cf ? cf.cfg : {};
  const CA = M.cartao || Fc.cartao || {};
  const Om = cm ? cm.off : null, Of = cf ? cf.off : null;
  const barM = (i, b) => F.bar(i, b) + Om, barF = (i, b) => F.bar(i, b) + Of;

  // ---------- o cartão do produto (o mesmo elemento vai do corner pin para o grafo) ----------
  const KW = 520, KR = { x: 700, y: 370 };
  const linhas = (CA.linhas || []).slice(0, 3), minis = (CA.miniaturas || []).slice(0, 6);
  const key = add(`<div class="node keynode" style="left:0;top:0;width:${KW}px;transform-origin:0 0">
    <div class="hd2">${K.icone(CA.icone || 'chaveP', C.tintaC, { size: 24, cls: 'ki', sw: 2 })}${F.esc(CA.titulo ?? 'Chave de Estilo')} ${CA.subtitulo ? `<span>· ${F.esc(CA.subtitulo)}</span>` : ''}</div>
    ${CA.cores !== false ? `<div class="sws">${C.paleta.map(c => `<i style="background:${c}"></i>`).join('')}</div>` : ''}
    ${linhas.length ? `<div class="attrs">${linhas.map(([a, b]) => `<div><b>${F.esc(a)}</b>${F.esc(b)}</div>`).join('')}</div>` : ''}
    ${minis.length ? `<div class="thumbs">${minis.map(r => `<i style="background-image:url(${IMG(r)})"></i>`).join('')}</div>` : '<div class="fim"></div>'}</div>`, world);
  const atw = Math.max(92, ...qa('.attrs b', key).map(b => { b.style.width = 'auto'; const w = rect(b).w; b.style.width = ''; return Math.ceil(w + 16); }));
  key.style.setProperty('--atw', atw + 'px');
  const KH = Math.round(rect(key).h);
  gsap.set(key, { opacity: 0 });

  if (cm) {
    // ---------- manifesto ----------
    const antes = F.palavras(M.antes ?? 'O estúdio de IA que aprende'), dest = F.palavras(M.destaque ?? 'o seu visual.');
    const NW = antes.length + dest.length;
    const line = add(`<div class="s8-line"><div class="row" style="display:flex;align-items:baseline">
      ${antes.map((w, i) => `<span class="slot" data-k="${i}"><span class="w">${F.esc(w)}</span>&nbsp;</span>`).join('')}
      <span class="slot" data-k="gap" style="width:0"></span>
      ${dest.map((w, j) => `<span class="slot" data-k="${antes.length + j}"><span class="w serif">${F.esc(w)}</span>${j < dest.length - 1 ? '&nbsp;' : ''}</span>`).join('')}</div></div>`, s);
    gsap.set(line, { zIndex: 4, y: -40 });
    // cabe: a frase com o vão aberto (640 px) dentro de 1800 px
    const rowEl = q('.row', line);
    line.style.setProperty('--k', 1);
    const wl = rect(rowEl).w, k = Math.min(1, (1800 - 640) / wl);
    if (k < .6) F.aviso('manifesto: frase longa demais; encurte');
    line.style.setProperty('--k', Math.max(.6, k).toFixed(4));
    const slots = qa('.slot', line), wds = qa('.w', line);
    const slotOf = k_ => slots.find(e => e.dataset.k === String(k_));
    const nat = {}; slots.forEach(e => nat[e.dataset.k] = rect(e).w);
    nat.gap = 640;
    const wordR = rect(wds[0]);
    const last = NW - 1, nA = antes.length;
    const setW = n => slots.forEach(e => { const k_ = e.dataset.k; e.style.width = (k_ !== 'gap' && +k_ <= n ? nat[k_] : 0) + 'px'; });
    const lineRect = n => { setW(n); const a = rect(slotOf(0)), b = rect(slotOf(n)); return { x: a.x, y: wordR.y - 2, w: b.x + nat[n] - a.x - (n < last ? 14 * (+line.style.getPropertyValue('--k')) : 0), h: wordR.h + 8 }; };
    const rects = [...Array(NW).keys()].map(lineRect);
    slots.forEach(e => e.style.width = nat[e.dataset.k] + 'px');
    const gR = rect(slotOf('gap')); const gx = gR.x + gR.w / 2;
    setW(-1);
    const H = F.handles(s, { size: 12, z: 12 });
    const passo = Math.min(.5, 3 / Math.max(1, NW - 1));
    const times = [...Array(NW).keys()].map(i => barM(12, .5 + i * passo));
    wds.forEach((w, i) => {
      const t = times[i], k_ = String(i);
      tl.to(slotOf(k_), { width: nat[k_], duration: .34, ease: 'out' }, t);
      const fs = parseFloat(getComputedStyle(w).fontSize);
      tl.fromTo(w, { opacity: 0, letterSpacing: -.17 * fs, filter: 'blur(8px)' }, { opacity: 1, letterSpacing: (i >= nA ? -.01 : -.025) * fs, filter: 'blur(0px)', duration: .62, ease: 'out', immediateRender: false }, t);
      gsap.set(w, { opacity: 0 });
      if (i === 0) H.show(t + .04, F.pad(rects[0], 14, 8)); else H.to(t + .05, F.pad(rects[i], 14, 8));
      cue(t + .02, 'liquid', `s8:w${i}`, { pitch: Math.min(i, 8), soft: true });
    });
    const tSplit = barM(13, 1);
    H.hide(tSplit - .06);
    tl.to(slotOf('gap'), { width: nat.gap, duration: .55, ease: 'io' }, tSplit);
    cue(tSplit + .2, 'whoosh', 's8:split', { note: 'whoosh quando o cartão sai do texto' });
    tl.to(wds.slice(0, nA), { x: -120, opacity: 0, filter: 'blur(12px)', duration: .45, ease: 'exit', stagger: .03 }, tSplit + .72);
    tl.to(wds.slice(nA), { x: 120, opacity: 0, filter: 'blur(12px)', duration: .45, ease: 'exit', stagger: .03 }, tSplit + .72);

    const H2 = F.handles(s, { size: 12, z: 13 });
    const ease = EASE('io');
    const quad = (x, y, w, h) => [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
    const ky = v => 540 + (v - 540) * KH / 340;
    const Q = [
      { t: tSplit + .1, q: [[gx - 26, 536], [gx + 22, 530], [gx + 26, 546], [gx - 20, 552]] },
      { t: tSplit + .5, q: [[gx - 214, ky(404)], [gx + 236, ky(366)], [gx + 262, ky(700)], [gx - 186, ky(660)]] },
      { t: tSplit + .9, q: quad(gx - KW / 2, 540 - KH / 2, KW, KH) },
    ];
    // vai para o canto do grafo (formatos) ou volta para o centro da tela e fica
    if (cf) Q.push({ t: barM(14) - .02, q: quad(KR.x, KR.y, KW, KH) });
    else Q.push({ t: barM(14), q: quad(960 - KW / 2, 540 - KH / 2, KW, KH) });
    const qAt = t => {
      if (t <= Q[0].t) return Q[0].q;
      for (let i = 1; i < Q.length; i++) if (t <= Q[i].t) { const k_ = ease((t - Q[i - 1].t) / (Q[i].t - Q[i - 1].t)); return Q[i].q.map((p, j) => [lerp(Q[i - 1].q[j][0], p[0], k_), lerp(Q[i - 1].q[j][1], p[1], k_)]); }
      return Q[Q.length - 1].q;
    };
    F.apply(t => {
      if (t < t0 || t > tEnd) return;
      if (t < Q[0].t) { gsap.set(key, { opacity: 0 }); return; }
      const qq = qAt(t);
      key.style.transform = K.homography(KW, KH, qq);
      gsap.set(key, { opacity: clamp((t - Q[0].t) / .08, 0, 1) });
      const ord = [qq[0], qq[1], qq[3], qq[2]];
      if (t < Q[2].t + .25) H2.sq.forEach((sq, i) => gsap.set(sq, { x: ord[i][0] - 6, y: ord[i][1] - 6 }));
    });
    H2.sq.forEach(sq => { gsap.set(sq, { opacity: 0 }); tl.set(sq, { opacity: 1 }, Q[0].t + .02); tl.to(sq, { opacity: 0, duration: .2, ease: 'exit' }, Q[2].t + .12); });
    cue(Q[1].t, 'tick', 's8:pin1'); cue(Q[2].t, 'liquid', 's8:pin2', { pitch: 3 });
    if (!cf) { tl.to(world, { filter: 'blur(14px)', opacity: 0, duration: .32, ease: 'exit' }, tEnd - .32); return; }
  } else {
    // sem o manifesto: o cartão entra no lugar dele no grafo
    key.style.transform = `translate(${KR.x}px, ${KR.y}px)`;
    tl.fromTo(key, { opacity: 0, filter: 'blur(12px)', scale: .96 }, { opacity: 1, filter: 'blur(0px)', scale: 1, duration: .6, ease: 'out', immediateRender: false }, barF(14) + .1);
    cue(barF(14) + .1, 'liquid', 's9:key', { pitch: 2 });
  }

  // ---------- formatos: o grafo ----------
  const svgNS = 'http://www.w3.org/2000/svg';
  const wires = add(`<svg class="wires" width="2600" height="1500" viewBox="0 0 2600 1500" style="z-index:0"></svg>`, world);
  const outPort = { x: KR.x + KW, y: KR.y + KH / 2 };
  const port = (x, y, bg, icon) => add(`<div class="port" style="left:${x}px;top:${y}px;background:${bg}">${icon}</div>`, world);
  const pKey = port(outPort.x, outPort.y, C.acento, K.I.chaveP('#fff'));
  gsap.set(pKey, { opacity: 0 });
  popIn(pKey, barF(14, .3), { y: 0, s: .7, blur: 4, dur: .35 });
  const icImg = F.escuro(C.porta, .8), icVid = F.escuro(C.porta2, .7);
  const SLOTS = [
    { x: 1490, y: 120, w: 400, mh: 500, pc: C.porta, icon: K.I.imagem(icImg) },
    { x: 1540, y: 850, w: 440, mh: 248, pc: C.porta2, icon: K.I.video(icVid), video: true },
    { x: 2060, y: 210, w: 330, mh: 330, pc: C.porta, icon: K.I.imagem(icImg) },
    { x: 2090, y: 650, w: 270, mh: 480, pc: C.porta, icon: K.I.imagem(icImg) },
  ];
  const saidas = (Fc.saidas || []).slice(0, 4);
  if (saidas.length < 3) F.aviso('formatos: use 3 ou 4 saídas (4:5, 16:9, 1:1, 9:16)');
  const node = (o, sd) => {
    const media = o.video
      ? `<img src="${IMG(sd.imagem)}" class="vid" style="object-position:${sd.foco || '50% 50%'}"><div class="play">${K.I.play(C.tintaC)}</div><div class="prog"><i></i></div>`
      : `<img src="${IMG(sd.imagem)}" style="object-position:${sd.foco || '50% 50%'}">`;
    const txt = sd.texto ? `<div class="txt">${F.esc(sd.texto)}${sd.fraco ? ` <span class="fade">· ${F.esc(sd.fraco)}</span>` : ''}</div>` : '';
    const el = add(`<div class="node" style="left:${o.x}px;top:${o.y}px;width:${o.w}px"><div class="media" style="height:${o.mh}px">${media}</div>${txt}</div>`, world);
    const chips = add(`<div class="node chips" style="left:${o.x}px;width:${o.w}px;top:0">${(sd.chips || []).slice(0, 3).map(c => `<span>${F.esc(c)}</span>`).join('')}</div>`, world);
    const h = rect(el).h; gsap.set(chips, { top: o.y + h + 10 });
    const pin = port(o.x, o.y + o.mh / 2, o.pc, o.icon);
    return { el, chips, pin, h, o };
  };
  const OUT = saidas.map((sd, i) => node(SLOTS[i], sd));
  const wireTimes = [barF(14, 1), barF(15), barF(16, .25), barF(16, .6)];
  OUT.forEach((n, i) => {
    const ip = { x: n.o.x, y: n.o.y + n.o.mh / 2 };
    const dx = Math.max(140, (ip.x - outPort.x) * .5);
    const p = document.createElementNS(svgNS, 'path');
    p.setAttribute('d', `M${outPort.x},${outPort.y} C${outPort.x + dx},${outPort.y} ${ip.x - dx},${ip.y} ${ip.x},${ip.y}`);
    p.setAttribute('fill', 'none'); p.setAttribute('stroke', 'rgba(255,255,255,.92)'); p.setAttribute('stroke-width', '3'); p.setAttribute('stroke-linecap', 'round');
    wires.appendChild(p);
    const L = p.getTotalLength(); p.style.strokeDasharray = L; p.style.strokeDashoffset = L;
    const t = wireTimes[i];
    tl.fromTo(p, { strokeDashoffset: L }, { strokeDashoffset: 0, duration: .5, ease: 'io', immediateRender: false }, t);
    const tn = t + .42;
    [n.el, n.chips].forEach((e, j) => { gsap.set(e, { opacity: 0 }); popIn(e, tn + j * .12, { y: 18, blur: 12, s: .97, dur: .55 }); });
    gsap.set(n.pin, { opacity: 0 }); popIn(n.pin, tn - .06, { y: 0, s: .7, blur: 4, dur: .3 });
    const media = q('.media img', n.el);
    tl.fromTo(media, { scale: 1.08, filter: 'blur(14px)' }, { scale: 1, filter: 'blur(0px)', duration: .7, ease: 'out', immediateRender: false }, tn);
    cue(tn, 'liquid', `s9:node${i}`, { pitch: i, pan: i < 2 ? .2 : .4 });
    cue(tn + .12, 'tick', `s9:chips${i}`, { soft: true });
  });
  // a saída em vídeo anda
  if (OUT[1]) {
    const vid = q('.vid', OUT[1].el), prog = q('.prog i', OUT[1].el);
    tl.fromTo(vid, { scale: 1 }, { scale: 1.1, duration: 4.4, ease: 'none', immediateRender: false }, wireTimes[1] + .9);
    tl.fromTo(prog, { scaleX: 0 }, { scaleX: 1, duration: 4.4, ease: 'none', immediateRender: false }, wireTimes[1] + .9);
    gsap.set(prog, { scaleX: 0 });
  }
  // legenda
  const leg = Fc.legenda || ['Uma chave.', 'Todo formato.'];
  const cap = add(`<div class="s9-cap"><span class="medir">${F.palavras(leg[0]).map(w => `<span class="w">${F.esc(w)}</span>`).join(' ')} ${F.palavras(leg[1] || '').map(w => `<span class="w serif">${F.esc(w)}</span>`).join(' ')}</span></div>`, s);
  gsap.set(cap, { zIndex: 6 });
  F.caber(cap, 1700, { nome: 'formatos.legenda', medir: q('.medir', cap) });
  const cw = qa('.w', cap);
  cw.forEach((w, i) => popIn(w, barF(16, 1.9) + i * Math.min(.11, .45 / cw.length), { y: 18, blur: 10 }));
  cue(barF(16, 1.9) + .22, 'pop', 's9:caption', { pitch: 2 });
  // brilho passando por cada saída, como se o cartão as atualizasse
  OUT.forEach((n, i) => {
    const sh = add(`<i style="position:absolute;inset:0;background:linear-gradient(110deg,rgba(255,255,255,0) 35%,rgba(255,255,255,.55) 50%,rgba(255,255,255,0) 65%);z-index:2"></i>`, q('.media', n.el));
    tl.fromTo(sh, { xPercent: -120 }, { xPercent: 120, duration: .7, ease: 'io', immediateRender: false }, barF(17) + i * .16);
    gsap.set(sh, { xPercent: -120 });
  });
  cue(barF(17), 'granular', 's9:sync', { soft: true, dur: .9 });
  // câmera
  const ease = EASE('io');
  const cam = [
    [barF(14), 960, 540, 1], [barF(14, 1), 960, 540, 1], [barF(14, 1) + .85, 1290, 470, .93],
    [barF(15), 1290, 470, .93], [barF(15) + .85, 1390, 690, .9],
    [barF(16), 1400, 690, .9], [barF(16) + .95, 1548, 590, .79], [barF(18), 1548, 600, .815],
  ];
  const camAt = (t, j) => { if (t <= cam[0][0]) return cam[0][j]; for (let i = 1; i < cam.length; i++) if (t <= cam[i][0]) { const k = (t - cam[i - 1][0]) / (cam[i][0] - cam[i - 1][0]); return lerp(cam[i - 1][j], cam[i][j], (i === cam.length - 1 ? EASE('quick') : ease)(k)); } return cam[cam.length - 1][j]; };
  F.apply(t => {
    if (t < t0 - .05 || t > tEnd + .05) return;
    const fx = camAt(t, 1), fy = camAt(t, 2), S = camAt(t, 3);
    gsap.set(world, { x: 960 - fx * S, y: 540 - fy * S, scale: S });
  });
  cue(barF(14, 1) + .4, 'swoosh_s', 's9:cam1', { soft: true }); cue(barF(15) + .4, 'swoosh_s', 's9:cam2', { soft: true });
  cue(barF(16) + .45, 'whoosh', 's9:zoomout');
  // saída
  tl.to(world, { filter: 'blur(14px)', opacity: 0, duration: .32, ease: 'exit' }, tEnd - .32);
  popOut(cap, tEnd - .3, { dur: .26 });
};
