"""sfx.py — os efeitos sonoros do filme, sintetizados em código (numpy, sementes fixas): nada gravado de terceiros.

Cada tipo de evento que o filme registra (out/<filme>/cues.json, "kind") tem uma função aqui. A função devolve
(estéreo float64 a 48 kHz, normalizado no pico, e o ponto de alinhamento em segundos: o ataque ou o pico do som, que cai
no instante do evento). Os níveis de cada tipo ficam em PAPEIS (dB), na mesma ordem de grandeza da mixagem do filme.
"""
import numpy as np

SR = 48000


def _rng(seed):
    return np.random.default_rng(seed)


def _norm(y):
    return y / (np.abs(y).max() + 1e-12)


def _env_exp(n, tau):
    return np.exp(-np.arange(n) / SR / tau)


def _bandnoise(n, fc, q, seed, blk=1024):
    """ruído branco por um passa-banda gaussiano que muda no tempo (fc, q: curvas por amostra ou escalares)"""
    fc = np.broadcast_to(np.asarray(fc, float), (n,)); q = np.broadcast_to(np.asarray(q, float), (n,))
    x = _rng(seed).standard_normal(n + blk)
    hop = blk // 4; win = np.hanning(blk)
    out = np.zeros(n + blk); ws = np.zeros(n + blk); fq = np.fft.rfftfreq(blk, 1 / SR)
    for s in range(0, n, hop):
        c = min(s + blk // 2, n - 1)
        X = np.fft.rfft(x[s:s + blk] * win) * np.exp(-0.5 * ((fq - fc[c]) / (fc[c] / q[c])) ** 2)
        out[s:s + blk] += np.fft.irfft(X) * win; ws[s:s + blk] += win ** 2
    return _norm(out[:n] / np.maximum(ws[:n], 1e-3))


def _lp(y, fc):
    """passa-baixa suave (1 polo duplo) por FFT"""
    n = len(y); fq = np.fft.rfftfreq(n, 1 / SR)
    return np.fft.irfft(np.fft.rfft(y) / (1 + (fq / fc) ** 2), n)


def _hp(y, fc):
    n = len(y); fq = np.fft.rfftfreq(n, 1 / SR)
    return np.fft.irfft(np.fft.rfft(y) * (fq / fc) ** 2 / (1 + (fq / fc) ** 2), n)


def _verb(y, dur=1.2, mix=.25, seed=9):
    """cauda curta de ruído decaindo (um "quarto" leve), estéreo"""
    n = int(dur * SR); r = _rng(seed)
    out = []
    for ch in range(2):
        ir = r.standard_normal(n) * _env_exp(n, dur / 6.5)
        ir = _lp(ir, 6000); ir[0] = 0
        d = np.concatenate([y, np.zeros(n)])
        w = np.convolve(y, ir)[:len(d)] * mix / (np.abs(ir).sum() ** .5 + 1e-9) * 6
        w = np.pad(w, (0, len(d) - len(w)))
        out.append(d + w)
    return np.stack(out, 1)


def _st(y, pan=0.0):
    a = (pan + 1) * np.pi / 4
    return np.stack([y * np.cos(a), y * np.sin(a)], 1) * np.sqrt(2)


def _pitch(y, st):
    """troca de altura junto com a duração (como fita): reamostragem linear"""
    if abs(st) < 1e-6: return y
    r = 2 ** (st / 12); n = int(len(y) / r)
    idx = np.arange(n) * r
    return np.interp(idx, np.arange(len(y)), y) if y.ndim == 1 else np.stack([np.interp(idx, np.arange(len(y)), y[:, c]) for c in range(y.shape[1])], 1)


# ---------------- os sons ----------------

def swell(seed=1, dur=1.05):
    """swell reverso (prato ao contrário): ruído agudo crescendo até o pico no fim"""
    n = int(dur * SR); u = np.arange(n) / n
    y = _bandnoise(n, 2500 + 6500 * u ** 1.5, 1.2, seed) * u ** 3.2
    y += _bandnoise(n, 900 + 1500 * u, 1.0, seed + 1) * u ** 4 * .35
    k = int(.012 * SR); y[-k:] *= np.linspace(1, 0, k)
    y = _verb(_norm(y), .9, .18, seed)
    return _norm(y), dur * .985


def whoosh(seed=2, dur=2.4, peak=.43, fc0=500, fc1=3200, q=1.4):
    """whoosh de ar: sobe até o pico e desce, com o filtro acompanhando"""
    n = int(dur * SR); u = np.arange(n) / n
    env = np.where(u < peak, (u / peak) ** 2.4, np.exp(-((u - peak) / (1 - peak)) * 4.2))
    fc = np.where(u < peak, fc0 * (fc1 / fc0) ** (u / peak), fc1 * (fc0 * 1.4 / fc1) ** ((u - peak) / (1 - peak)))
    y = _bandnoise(n, fc, q, seed) * env + _bandnoise(n, 260, 1.0, seed + 1) * env * .3
    L = _bandnoise(n, fc * 1.05, q, seed + 2) * env; R = _bandnoise(n, fc * .95, q, seed + 3) * env
    st = np.stack([y * .7 + L * .3, y * .7 + R * .3], 1)
    return _norm(st), dur * peak


def swoosh_s(seed=3):
    return whoosh(seed, 1.1, .45, 700, 4200, 1.8)


def swoosh_l(seed=4):
    return whoosh(seed, 1.5, .3, 400, 2600, 1.3)


def swoosh_c(seed=5):
    """swoosh frio: mais agudo e mais estreito, descendo"""
    y, p = whoosh(seed, 1.4, .3, 1800, 7000, 2.4)
    return y, p


def pop(seed=6):
    """pop de tampinha: um sopro grave que sobe rápido + estalo"""
    n = int(.22 * SR); t = np.arange(n) / SR
    f = 260 + 900 * (1 - np.exp(-t / .012))
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .03)
    cl = _rng(seed).standard_normal(n) * np.exp(-t / .0015)
    y = _norm(y) + _norm(_hp(cl, 2500)) * .35
    return _st(_norm(y)), .004


def tick(seed=7):
    """tique de vidro: clique curto com dois parciais agudos"""
    n = int(.12 * SR); t = np.arange(n) / SR
    y = (np.sin(2 * np.pi * 3150 * t) + .6 * np.sin(2 * np.pi * 5230 * t + 1) + .3 * np.sin(2 * np.pi * 7900 * t)) * np.exp(-t / .016)
    cl = _hp(_rng(seed).standard_normal(n) * np.exp(-t / .0008), 4000)
    return _st(_norm(_norm(y) + .6 * _norm(cl))), 0.0


def tick2(seed=8):
    """clique "sci-fi": um blip que desce de altura, com um tique por cima"""
    n = int(.26 * SR); t = np.arange(n) / SR
    f = 1900 * np.exp(-t / .03) + 700
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .045)
    tk = tick(seed)[0][:, 0]; tk = np.pad(tk, (0, max(0, n - len(tk))))[:n]
    y = _norm(y) * .8 + _norm(tk) * .4
    return _st(_norm(y)), .002


def liquid(seed=9):
    """clique líquido: gota (seno que sobe de altura rápido) com corpo macio"""
    n = int(.16 * SR); t = np.arange(n) / SR
    f = 520 + 1500 * (t / .05) ** .8
    f = np.minimum(f, 2300)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * np.clip(t / .06, 0, 1)) ** 1.5 * np.exp(-np.maximum(t - .03, 0) / .025)
    y += .25 * _hp(_rng(seed).standard_normal(n) * np.exp(-t / .002), 3000)
    return _st(_norm(y)), .0


def key(seed=10):
    """tecla: estalo + "thock" grave, cada uma um pouco diferente"""
    r = _rng(100 + seed); n = int(.09 * SR); t = np.arange(n) / SR
    cl = _norm(_bandnoise(n, r.uniform(2800, 4200), 1.6, 100 + seed)) * np.exp(-t / .0018)
    fb = r.uniform(240, 330)
    body = np.sin(2 * np.pi * fb * t * (1 - .15 * t / .09)) * np.exp(-t / .016) + .3 * np.sin(2 * np.pi * 2.7 * fb * t) * np.exp(-t / .007)
    return _st(_norm(cl * .7 + body * .6) * r.uniform(.8, 1.0)), .004


def click(seed=11):
    """clique moderno: transiente seco + corpo curto + um "tok" tonal"""
    n = int(.2 * SR); t = np.arange(n) / SR
    tr = _hp(_rng(seed).standard_normal(n) * np.exp(-t / .0012), 1800)
    body = np.sin(2 * np.pi * 180 * t) * np.exp(-t / .02)
    tok = np.sin(2 * np.pi * 1250 * t) * np.exp(-t / .009)
    y = _norm(tr) * .8 + body * .55 + tok * .5
    return _st(_norm(y)), .0


def lock(seed=12):
    y, a = click(seed)
    n = len(y); t = np.arange(n) / SR
    y = y + _st(np.sin(2 * np.pi * 2480 * t) * np.exp(-t / .05) * .35)
    return _norm(y), a


def granular(seed=13, dur=1.0):
    """ondulação granular: dezenas de grãos curtos (blips e chiados) espalhados, abrindo no estéreo"""
    r = _rng(seed); n = int(dur * SR); out = np.zeros((n + SR // 10, 2))
    k = int(70 * dur) + 8
    for i in range(k):
        t0 = r.uniform(0, dur) ** 1.15 / dur ** .15
        gl = int(r.uniform(.008, .03) * SR); tt = np.arange(gl) / SR
        if r.random() < .55:
            g = np.sin(2 * np.pi * r.uniform(900, 5200) * tt)
        else:
            g = _hp(r.standard_normal(gl), 2500)
        g *= np.hanning(gl) * r.uniform(.3, 1)
        p = r.uniform(-.8, .8); i0 = int(t0 * SR)
        out[i0:i0 + gl] += _st(g, p)[:len(out) - i0]
    env = np.minimum(1, np.arange(len(out)) / (.04 * SR)) * np.exp(-np.maximum(0, np.arange(len(out)) / SR - dur * .6) / (dur * .25))
    return _norm(out * env[:, None]), 0.0


def impact(seed=14):
    """impacto distante: grave que cai + ruído escuro + cauda"""
    n = int(1.8 * SR); t = np.arange(n) / SR
    f = 38 + 70 * np.exp(-t / .05)
    boom = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .35)
    nz = _lp(_rng(seed).standard_normal(n) * np.exp(-t / .12), 700)
    tr = _lp(_rng(seed + 1).standard_normal(n) * np.exp(-t / .006), 2500)
    y = _norm(boom) + _norm(nz) * .45 + _norm(tr) * .5
    return _norm(_verb(y, 1.6, .3, seed)), .0


def sub(seed=15):
    """grave na troca de seção"""
    n = int(1.3 * SR); t = np.arange(n) / SR
    f = 42 + 30 * np.exp(-t / .06)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .3) * np.minimum(1, t / .004)
    return _st(_norm(y)), .01


def shimmer(seed=16, dur=3.0):
    """brilho do logo: parciais agudos em cascata que se apagam devagar"""
    r = _rng(seed); n = int(dur * SR); t = np.arange(n) / SR
    out = np.zeros((n, 2))
    base = [1318.5, 1760.0, 1975.5, 2637.0, 3520.0, 3951.1, 5274.0]
    for k in range(18):
        f = base[k % len(base)] * (2 if k > 10 else 1) * r.uniform(.997, 1.003)
        d = r.uniform(0, .4); tau = r.uniform(.4, 1.2)
        e = np.clip((t - d) / .006, 0, 1) * np.exp(-np.maximum(t - d, 0) / tau)
        out += _st(np.sin(2 * np.pi * f * t + r.uniform(0, 6)) * e * r.uniform(.3, 1), r.uniform(-.7, .7))
    return _norm(_verb(out[:, 0], 1.5, .35, seed) * .5 + np.pad(out, ((0, int(1.5 * SR)), (0, 0))) * .7), .1


def logo(seed=17):
    """o sting do logo: swell que termina na trava + brilho + impacto distante"""
    sw, psw = swell(seed, 1.05)
    sh, psh = shimmer(seed + 1)
    im, pim = impact(seed + 2)
    pre = int(psw * SR); n = pre + max(len(sh), len(im)) + SR
    out = np.zeros((n, 2))
    out[:len(sw)] += sw * 10 ** (-5 / 20)
    i0 = pre - int(psh * SR); out[i0:i0 + len(sh)] += sh
    i1 = pre - int(pim * SR); out[i1:i1 + len(im)] += im * 10 ** (-2 / 20)
    return _norm(out), psw


GERA = {'swell': swell, 'whoosh': whoosh, 'swoosh_s': swoosh_s, 'swoosh_l': swoosh_l, 'swoosh_c': swoosh_c, 'pop': pop,
        'tick': tick, 'tick2': tick2, 'liquid': liquid, 'key': key, 'click': click, 'lock': lock, 'granular': granular,
        'impact': impact, 'sub': sub, 'logo': logo}

# nível (dB), nível a mais nos eventos "soft", passo de altura por "pitch" do evento (semitons) e variação por repetição
PAPEIS = {
    'swell': {'db': -9}, 'whoosh': {'db': -13}, 'swoosh_s': {'db': -5, 'soft': -7, 'ciclo': [0, -1, 1]}, 'swoosh_l': {'db': -11},
    'swoosh_c': {'db': -8}, 'pop': {'db': -17, 'soft': -5, 'passo': 1.5}, 'tick': {'db': -11, 'soft': -7}, 'tick2': {'db': -13, 'passo': 1.0},
    'liquid': {'db': -14, 'soft': -4, 'passo': .7, 'ciclo': [0, .3, -.2]}, 'key': {'db': -19, 'palavra': 2.5}, 'lock': {'db': -9},
    'click': {'db': -8}, 'granular': {'db': -12, 'soft': -8}, 'impact': {'db': -6}, 'sub': {'db': -5}, 'logo': {'db': -11},
}
POR_ID = {'s6:riser': {'db': -6}, 's11:lock': {'db': -12}, 's10:h1': {'db': -7}}


def evento(ev, k):
    """o som de um evento (k = quantas vezes esse tipo já tocou): (estéreo, segundos do alinhamento)"""
    kind = ev['kind']
    if kind not in GERA: return None, 0
    papel = dict(PAPEIS.get(kind, {}), **POR_ID.get(ev.get('id', ''), {}))
    seed = 1000 + k * 7 + sum(map(ord, kind))
    if kind == 'granular': y, a = granular(seed, ev.get('dur', 1.0))
    else: y, a = GERA[kind](seed)
    st = papel.get('passo', 0) * (ev.get('pitch') or 0) + (papel.get('ciclo', [0])[k % len(papel.get('ciclo', [0]))])
    if st: r = 2 ** (st / 12); y = _pitch(y, st); a = a / r
    g = papel.get('db', -12) + (papel.get('soft', 0) if ev.get('soft') else 0) + (papel.get('palavra', 0) if ev.get('word') else 0)
    pan = (ev.get('pan') or 0) * .5
    if pan: y = y * np.array([np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)]) * np.sqrt(2)
    return y * 10 ** (g / 20), a
