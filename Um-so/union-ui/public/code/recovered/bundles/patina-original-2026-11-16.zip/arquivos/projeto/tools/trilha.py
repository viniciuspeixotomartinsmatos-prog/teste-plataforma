"""trilha.py <filme> [outra.mp3 --drop <s> --fim <s>] — corta a música na linha do tempo do filme → out/<filme>/trilha.wav

A trilha da demo é "Laser Groove" (Kevin MacLeod, incompetech.com, CC BY 4.0: o crédito é obrigatório, ver CREDITS.md),
140 BPM, a mesma grade do filme (1 compasso = 1,714 s). O corte, em compassos:
  introdução  a faixa até o drop dela (13,75 s), recuada para o drop cair no drop do filme (linha.drop: a revelação
              da montagem). Sem as cenas do começo, a faixa entra no meio da introdução, com uma entrada curta.
  groove      segue a faixa do drop em diante até um compasso antes da parada (linha.parada: a trava do logo).
  final       o último compasso da faixa e a batida final dela: a batida cai na trava do logo, e a cauda some no fecho.
Outra faixa a 140 BPM serve se tiver um drop marcado e um final seco: passe --drop (o segundo do drop na faixa) e --fim
(o segundo da batida final). Faixa em outro andamento não casa com o filme.
"""
import json, os, sys, shutil, platform, subprocess
import numpy as np, soundfile as sf

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 48000
BAR = 60 / 140 * 4
nome = sys.argv[1]
args = sys.argv[2:]
opt = lambda k, d: float(args[args.index('--' + k) + 1]) if '--' + k in args else d
src_path = next((a for a in args if a.lower().endswith(('.mp3', '.wav', '.m4a', '.ogg'))), os.path.join(RAIZ, 'audio/trilha/laser-groove.mp3'))
L = json.load(open(os.path.join(RAIZ, 'out', nome, 'linha.json')))

plat = {'darwin': 'darwin', 'linux': 'linux', 'win32': 'win32'}.get(sys.platform, sys.platform) + '-' + \
    {'arm64': 'arm64', 'aarch64': 'arm64', 'x86_64': 'x64', 'AMD64': 'x64'}.get(platform.machine(), 'x64')
ff = os.path.join(RAIZ, 'node_modules/@ffmpeg-installer', plat, 'ffmpeg.exe' if sys.platform == 'win32' else 'ffmpeg')
if not os.path.exists(ff): ff = shutil.which('ffmpeg') or 'ffmpeg'
raw = subprocess.run([ff, '-v', 'error', '-i', src_path, '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
src = np.frombuffer(raw, np.float32).reshape(-1, 2).astype(np.float64)

DROP_SRC = opt('drop', 13.750)            # o drop da faixa (compasso 8 da Laser Groove)
FIM_SRC = opt('fim', 164.607)             # a batida final da faixa
total = L['duracao']; drop = L['drop']; parada = L['parada']
N = int(round(total * SR))
music = np.zeros((N, 2))
XF = int(.012 * SR)


def trecho(o0, o1, s0, entrada=0.0, saida=True):
    """copia a faixa a partir de s0 (segundos da faixa) para [o0, o1) da saída, com fusões curtas nas pontas"""
    i0, i1 = int(round(o0 * SR)), min(N, int(round(o1 * SR)))
    j0 = int(round(s0 * SR))
    if j0 < 0: i0 -= j0; j0 = 0
    n = min(i1 - i0, len(src) - j0)
    if n <= 0: return
    seg = src[j0:j0 + n].copy()
    fi = max(XF, int(entrada * SR))
    w = np.ones(n); k = np.arange(min(fi, n)); w[:len(k)] = np.sin(.5 * np.pi * (k + .5) / fi)
    if saida: k = np.arange(min(XF, n)); w[n - len(k):] *= np.cos(.5 * np.pi * (k + .5) / XF)
    music[i0:i0 + n] += seg * w[:, None]


shift = DROP_SRC - drop                   # segundo da faixa = segundo do filme + shift
fim0 = parada - BAR                       # onde entra o compasso final
s_ini = 0.0 + shift
trecho(0.0, fim0 + XF / SR, s_ini, entrada=(.08 if s_ini > .05 else 0))
trecho(fim0, total, FIM_SRC - BAR, saida=False)

# níveis: os da faixa; o fim some nos últimos 2 s
t = np.arange(N) / SR
g = np.zeros(N)
g += np.interp(t, [0, total - 2.0, total], [0, 0, -40])
music *= (10 ** (g / 20))[:, None]
music *= 10 ** (-3 / 20) / (np.abs(music).max() + 1e-12)
dst = os.path.join(RAIZ, 'out', nome, 'trilha.wav')
sf.write(dst, music.astype(np.float32), SR, subtype='FLOAT')
print(f"trilha → out/{nome}/trilha.wav  {total:.2f} s; drop em {drop:.2f} s (faixa {DROP_SRC:.2f} s); final da faixa na trava, {parada:.2f} s")
