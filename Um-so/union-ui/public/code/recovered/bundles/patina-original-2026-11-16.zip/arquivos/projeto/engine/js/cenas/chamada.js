// chamada e fecho.
// chamada — a frase final grande, a palavra de destaque em gradiente; as alças pulam nela; um cisalhamento recolhe a
// frase num ponto.   { tipo: "chamada", antes: "Deixe com a sua", destaque: "cara." }
// fecho — o símbolo cai grande, encolhe para o lugar, o nome sai de trás com máscara e desfoque; o groove para e o logo
// trava no silêncio; o slogan.   { tipo: "fecho", slogan: "Estilo, destilado." }
window.CENA_chamada = () => {
  const c = F.cena('chamada'), cf = F.cena('fecho');
  const { tl, add, q, qa, cue, C, popIn, rect } = F;
  const A = c.cfg, O = c.off, bar = (i, b) => F.bar(i, b) + O;
  const Of = cf.off, barF = (i, b) => F.bar(i, b) + Of;
  const t0 = c.t0, tLogo = barF(20), tLock = barF(21);
  const s = F.scene('s1011', t0, F.DUR + 1, 6);
  gsap.set(s, { background: C.fundo });
  F.stage.style.setProperty('--destaque-grad', `linear-gradient(95deg, ${C.acento} 10%, ${F.mix(C.acento, C.brilho, .45)} 40%, ${C.acento2} 95%)`);
  const antes = F.palavras(A.antes ?? 'Deixe com a sua'), dest = F.palavras(A.destaque ?? 'cara.');
  const line = add(`<div class="s10-line"><div class="row" style="display:flex;align-items:baseline">
    ${antes.map(w => `<span class="w">${F.esc(w)}</span>`).join('&nbsp;')}&nbsp;${dest.map(w => `<span class="w serif">${F.esc(w)}</span>`).join('&nbsp;')}</div></div>`, s);
  F.caber(line, 1640, { nome: 'chamada', medir: q('.row', line), min: .5 });
  const wds = qa('.w', line);
  const n = wds.length, passo = Math.min(.5, 2 / Math.max(1, n - 1));
  const tw = wds.map((_, i) => bar(18, 2 - (n - 1 - i) * passo));
  const nA = antes.length;
  wds.forEach((w, i) => popIn(w, tw[i], { y: i >= nA ? 30 : 24, blur: 12, dur: i >= nA ? .7 : .55 }));
  cue(tw[0], 'pop', 's10:make', { pitch: 0, soft: true });
  if (n > 2) cue(tw[Math.floor((n - 1) / 2)], 'pop', 's10:look', { pitch: 1, soft: true });
  cue(tw[nA] ?? tw[n - 1], 'pop', 's10:you', { pitch: 3 });
  const H = F.handles(s, { size: 13, z: 12 });
  const rd = wds.slice(nA).map(rect);
  const rYou = F.pad({ x: rd[0].x, y: Math.min(...rd.map(r => r.y)), w: rd[rd.length - 1].x + rd[rd.length - 1].w - rd[0].x, h: Math.max(...rd.map(r => r.h)) }, 10, 0);
  const rRow = F.pad(rect(q('.row', line)), 18, 6);
  H.show(bar(18, 2.6), rYou); cue(bar(18, 2.6), 'tick', 's10:h1');
  H.to(bar(19), rRow, { dur: .2 }); cue(bar(19), 'tick', 's10:h2');
  H.to(bar(19, 2), rYou, { dur: .2 }); cue(bar(19, 2), 'tick', 's10:h3');
  // cisalhamento recolhe a frase num ponto
  tl.to(line, { skewX: -38, scaleX: .04, scaleY: .3, opacity: 0, filter: 'blur(4px)', duration: .46, ease: 'io', transformOrigin: '50% 50%' }, tLogo);
  H.to(tLogo + .02, { x: 954, y: 534, w: 12, h: 12 }, { dur: .4, ease: 'io' }); H.hide(tLogo + .26, { dur: .12 });
  cue(tLogo + .22, 'swoosh_c', 's11:collapse', { note: 'a frase dobra para dentro do logo' });

  // ---------------- fecho: o logo ----------------
  const L = K.logo(s, { fs: 214, cx: 960, cy: 500, z: 8, maxW: 1500 });
  const big = 250 / Math.max(L.D, L.Dw);
  const dx = 960 - L.discCenter.x, dy = 540 - L.discCenter.y;
  gsap.set(L.disc, { opacity: 0 }); if (L.stem) gsap.set(L.stem, { scaleY: 0 });
  tl.fromTo(L.disc, { x: dx, y: dy, scale: big * .9, opacity: 0, filter: 'blur(16px)' }, { scale: big, opacity: 1, filter: 'blur(0px)', duration: .5, ease: 'out', immediateRender: false }, barF(20, 1));
  tl.to(L.disc, { x: 0, y: 0, scale: 1, duration: .48, ease: 'io' }, barF(20, 2));
  if (L.stem) tl.fromTo(L.stem, { scaleY: 0 }, { scaleY: 1, duration: .3, ease: 'out', immediateRender: false }, barF(20, 2) + .36);
  tl.fromTo(L.word, { '--m': '-25%', x: -36, filter: 'blur(12px)' }, { '--m': '125%', x: 0, filter: 'blur(0px)', duration: .62, ease: 'out', immediateRender: false }, barF(20, 3));
  gsap.set(L.word, { '--m': '-25%' });
  cue(barF(20, 1), 'granular', 's11:disc', { soft: true, dur: .7 });
  cue(barF(20, 2) + .4, 'tick2', 's11:stem', { pitch: 2 });
  cue(barF(20, 3) + .05, 'swoosh_s', 's11:word', { soft: true });
  // trava no silêncio
  tl.fromTo(L.el, { scale: 1.014 }, { scale: 1, duration: .6, ease: 'out', immediateRender: false, transformOrigin: '50% 50%' }, tLock);
  tl.fromTo(L.sheen, { xPercent: -120 }, { xPercent: 120, duration: .75, ease: 'io', immediateRender: false }, tLock + .04);
  const H3 = F.handles(s, { size: 12, z: 12 });
  const top = Math.min(L.top - L.m.xh * .55, L.top + (L.m.xh - L.D) / 2) - 18;
  const lr = { x: L.left - 26, y: top, w: L.W + 52, h: (L.top + L.m.xh + L.m.desc + 18) - top };
  H3.show(tLock + .02, lr, { dur: .25 }); H3.hide(tLock + .95, { dur: .3 });
  cue(tLock, 'click', 's11:lock', { note: 'o clique na trava' });
  cue(tLock, 'logo', 's11:sting', { note: 'o sting do logo no silêncio depois do groove' });
  const sl = cf.cfg.slogan ?? 'Estilo, destilado.';
  if (sl) {
    const tag = add(`<div class="s11-tag serif"><span class="medir">${F.esc(sl)}</span></div>`, s);
    F.caber(tag, 1500, { nome: 'fecho.slogan', medir: q('.medir', tag) });
    gsap.set(tag, { y: 680, zIndex: 8 });
    popIn(tag, tLock + .8, { y: 14, blur: 10, dur: .7 });
  }
};
