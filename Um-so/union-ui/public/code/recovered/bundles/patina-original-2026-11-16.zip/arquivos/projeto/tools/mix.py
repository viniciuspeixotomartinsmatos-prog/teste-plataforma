"""mix.py <filme> [--sem-musica] — trilha + efeitos → out/<filme>/mix.wav, a -14 LUFS e pico verdadeiro ≤ -2 dBTP (o AAC não estoura).

Lê out/<filme>/cues.json (os eventos de som que o próprio filme registra, no quadro em que a imagem anima: tools/render.mjs
linha) e out/<filme>/trilha.wav (tools/trilha.py). Os efeitos são sintetizados em tools/sfx.py.
--sem-musica: só os efeitos, para postar com uma música da biblioteca do Instagram ou do TikTok.
"""
import json, os, sys
import numpy as np, soundfile as sf, pyloudnorm as pyln
from scipy.signal import resample_poly
from scipy.ndimage import minimum_filter1d, uniform_filter1d

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
import sfx  # noqa: E402

SR = 48000
nome = sys.argv[1]
SEM_MUSICA = '--sem-musica' in sys.argv
cues = json.load(open(os.path.join(RAIZ, 'out', nome, 'cues.json')))
total = cues['duration']
N = int(round(total * SR)) + SR


def db(x): return 10 ** (x / 20)


def place(bus, x, t):
    i = int(round(t * SR))
    if i < 0: x = x[-i:]; i = 0
    j = min(len(bus), i + len(x))
    if j > i: bus[i:j] += x[:j - i]


music = np.zeros((N, 2))
if not SEM_MUSICA:
    m, _ = sf.read(os.path.join(RAIZ, 'out', nome, 'trilha.wav'), dtype='float64')
    place(music, m, 0)
fx = np.zeros((N, 2)); cont = {}; n = 0
for ev in cues['events']:
    k = cont.get(ev['kind'], 0)
    y, a = sfx.evento(ev, k)
    if y is None: continue
    place(fx, y, ev['t'] - a); cont[ev['kind']] = k + 1; n += 1
def shelf(x, fc, g_db):
    """prateleira suave acima de fc (g_db negativo = mais escuro)"""
    n = len(x); fq = np.fft.rfftfreq(n, 1 / SR)
    h = 1 + (db(g_db) - 1) * (fq / fc) ** 2 / (1 + (fq / fc) ** 2)
    return np.fft.irfft(np.fft.rfft(x, axis=0) * h[:, None], n, axis=0)


# a música um pouco mais escura (os sintetizadores da faixa são brilhantes) e os efeitos sem aspereza no agudo
music = shelf(music, 2500, -4.0)
fq_ = np.fft.rfftfreq(len(music), 1 / SR); bell = 1 + (db(-2.0) - 1) * np.exp(-0.5 * (np.log2((fq_ + 1) / 1800) / .7) ** 2)
music = np.fft.irfft(np.fft.rfft(music, axis=0) * bell[:, None], len(music), axis=0)   # os médios (1-3 kHz) 2 dB abaixo
fx = shelf(fx, 5000, -3.0)
# a música abre espaço para os efeitos fortes (um "ducking" leve, 30 ms de ataque)
env = uniform_filter1d(np.abs(fx).max(1), int(.03 * SR))
music *= (1 - .35 * np.clip(env / db(-12), 0, 1))[:, None]
mix = music * db(-3) + fx
mix = mix[:int(round(total * SR))]
# fecha os últimos 40 ms
k = int(.04 * SR); mix[-k:] *= np.linspace(1, 0, k)[:, None]

meter = pyln.Meter(SR)


def true_peak(x): return np.abs(resample_poly(x, 4, 1, axis=0)).max()


def limit(x, ceil, look=.003):
    up = np.abs(resample_poly(x, 4, 1, axis=0)).max(1)
    pk = up[:len(x) * 4].reshape(-1, 4).max(1)[:len(x)]
    g = np.minimum(1.0, ceil / np.maximum(pk, 1e-9)); w = int(look * SR) | 1
    return x * uniform_filter1d(minimum_filter1d(g, 2 * w + 1), 2 * w + 1)[:, None]


for _ in range(6):
    mix *= db(-14 - meter.integrated_loudness(mix)); mix = limit(mix, db(-2.6))
    if true_peak(mix) <= db(-2.2) and abs(meter.integrated_loudness(mix) + 14) < .15: break
dst = os.path.join(RAIZ, 'out', nome, 'mix.wav')
sf.write(dst, mix.astype(np.float32), SR, subtype='PCM_24')
print(f"mix → out/{nome}/mix.wav  {len(mix)/SR:.2f} s  {meter.integrated_loudness(mix):.1f} LUFS  pico {20*np.log10(true_peak(mix)):.1f} dBTP  ({n} efeitos{', sem música' if SEM_MUSICA else ''})")
