// abertura — o problema: uma imagem em tela cheia, desfocada, com a frase digitada em tinta que assenta; o quadro encolhe
// para um card, o card se copia numa fileira ("tudo igual") e um wipe em pixels come tudo.
// Config: { tipo: "abertura", imagem, foco?: "50% 34%", linha1, linha2, copias?: [imagens], tinta?, cor_texto?, fundo_quadro? }
window.CENA_abertura = () => {
  const c = F.cena('abertura'); if (!c) return;
  const { tl, add, q, cue, C, popIn, popOut } = F;
  const cfg = c.cfg, O = c.off;
  const bar = (i, b) => F.bar(i, b) + O;
  const IMG = F.img(cfg.imagem);
  const s = F.scene('s1', 0, c.t1 + .06, 3);
  const frame = add(`<div class="s1-frame" style="background:${cfg.fundo_quadro || F.escuro(C.acento2, .7)}"><img src="${IMG}"></div>`, s);
  const fimg = q('img', frame);
  gsap.set(frame, { left: 0, top: 0, width: 1920, height: 1080, zIndex: 3 });
  gsap.set(fimg, { scale: 1.22, rotation: -1.5, filter: 'blur(46px) saturate(1.35) brightness(1.06)' });
  gsap.set(fimg, { objectPosition: cfg.foco || '50% 34%' });
  tl.fromTo(fimg, { scale: 1.22, rotation: -1.5 }, { scale: 1.12, rotation: 0, duration: 2.3, ease: 'none', immediateRender: false }, O);
  cue(0.5 + O, 'swell', 'open:swell', { note: 'swell reverso no primeiro acorde' });

  const t1 = add(`<div class="s1-t1"><span class="medir">${F.esc(cfg.linha1 ?? 'Toda imagem de IA')}</span></div>`, s);
  gsap.set(t1, { zIndex: 6, color: cfg.cor_texto || '#FFFFFF' });
  F.caber(t1, 1680, { nome: 'abertura.linha1', medir: q('.medir', t1) });
  F.typeChars(F.charsOf(q('.medir', t1)), .56 + O, Math.min(.048, 1.2 / Math.max(1, (cfg.linha1 || '').length)), { tint: cfg.tinta || F.claro(C.acento, .6), ink: cfg.cor_texto || '#FFFFFF', blur: 8, y: 8 });
  popOut(t1, 1.98 + O, { dur: .24, y: -6 });

  // o quadro cheio encolhe num card e a imagem aparece nítida
  const T = bar(1);
  tl.to(frame, { left: 810, top: 352, width: 300, height: 375, duration: .8, ease: 'io' }, T);
  tl.to(fimg, { scale: 1, rotation: 0, filter: 'blur(0px) saturate(1) brightness(1)', duration: .72, ease: 'io' }, T + .02);
  cue(T + .4, 'whoosh', 'open:shrink', { note: 'whoosh no pico de velocidade do encolhimento' });

  // cópias saem de trás do card (a mesma imagem, ou as do config)
  const copias = cfg.copias && cfg.copias.length ? cfg.copias : null;
  let n = 0;
  for (let k = 1; k <= 3; k++) for (const side of [-1, 1]) {
    const src = copias ? F.img(copias[n++ % copias.length]) : IMG;
    const cp = add(`<div class="s1-copy"><img src="${src}" style="object-position:${cfg.foco || '50% 34%'}"></div>`, s);
    gsap.set(cp, { zIndex: 3 - k, opacity: 0 });
    const t = T + .6 + (k - 1) * .085;
    tl.fromTo(cp, { x: 0, opacity: 0 }, { x: side * 328 * k, opacity: 1, duration: .6, ease: 'out', immediateRender: false }, t);
    if (side === 1) cue(t + .06, 'pop', `open:copy${k}`, { pitch: k - 1, pan: 0 });
  }
  const t2 = add(`<div class="s1-t2"><span class="medir">${F.esc(cfg.linha2 ?? 'parece igual.')}</span></div>`, s);
  F.caber(t2, 1680, { nome: 'abertura.linha2', medir: q('.medir', t2) });
  const w2 = F.wordsOf(q('.medir', t2));
  w2.forEach((w, i) => popIn(w, bar(1, 2) + i * Math.min(.12, .5 / w2.length), { y: 16, blur: 10, dur: .5 }));

  // wipe em pixels come tudo, de cima para baixo, até a cor de fundo da cena seguinte
  const wipe = FX.pixelWipe(s, { z: 30 });
  tl.fromTo(wipe.st, { p: 0 }, { p: 1, duration: .56, ease: 'quick', immediateRender: false }, 3.43 + O);
  F.apply(t => wipe.draw(t));
  cue(3.42 + O, 'granular', 'open:wipe', { dur: .6, note: 'ripple granular com o wipe' });
};
