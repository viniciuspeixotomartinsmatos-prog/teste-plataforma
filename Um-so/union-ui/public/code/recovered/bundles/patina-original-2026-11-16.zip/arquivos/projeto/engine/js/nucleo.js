// Núcleo do filme: lê o config (filmes/<nome>.json), monta a linha do tempo das cenas e oferece as peças comuns.
// Uma linha do tempo GSAP pausada + "aplicadores" (funções puras do tempo, para câmera e canvas).
// window.seek(t) leva o palco a qualquer instante, em qualquer ordem; é o que o render quadro a quadro usa.
// Os efeitos sonoros nascem aqui: cada evento é registrado no mesmo ponto em que a imagem anima (F.cue).
window.F = (() => {
  // ---------- config ----------
  const Q = new URLSearchParams(location.search);
  const FILME_ID = Q.get('filme') || 'demo';
  const xhr = new XMLHttpRequest();
  xhr.open('GET', `/filmes/${encodeURIComponent(FILME_ID)}.json?${Date.now()}`, false); xhr.send();
  if (xhr.status !== 200) throw new Error(`não achei filmes/${FILME_ID}.json`);
  const CFG = JSON.parse(xhr.responseText);
  const AVISOS = [];
  const aviso = m => { AVISOS.push(m); console.warn('[aviso] ' + m); };

  // ---------- cores ----------
  const rgbOf = h => { h = h.replace('#', ''); if (h.length === 3) h = [...h].map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
  const hexOf = c => '#' + c.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('').toUpperCase();
  const mix = (a, b, k) => { const x = rgbOf(a), y = rgbOf(b); return hexOf(x.map((v, i) => v + (y[i] - v) * k)); };
  const claro = (a, k) => mix(a, '#FFFFFF', k), escuro = (a, k) => mix(a, '#000000', k);
  const rgba = (h, a) => { const c = rgbOf(h); return `rgba(${c[0]},${c[1]},${c[2]},${a})`; };
  const cc = CFG.cores || {};
  const C = {};
  C.fundo = cc.fundo || '#F2EEE7';
  C.tinta = cc.tinta || '#161A18';
  C.apagado = cc.apagado || mix(C.fundo, C.tinta, .42);
  C.acento = cc.acento || '#C8693A';
  C.acento2 = cc.acento2 || mix(C.acento, C.tinta, .5);
  C.brilho = cc.brilho || claro(C.acento, .35);                 // a tinta clara das palavras de destaque
  C.base = cc.base || mix(C.fundo, C.tinta, .1);                 // o fundo de uma imagem que ainda não carregou
  C.paleta = (cc.paleta && cc.paleta.length >= 3 ? cc.paleta : [C.acento, mix(C.fundo, C.acento, .35), C.acento2, C.brilho, mix(C.tinta, C.fundo, .1)]).slice(0, 6);
  C.gradiente = (cc.gradiente && cc.gradiente.length >= 3 ? cc.gradiente : [C.acento, claro(C.acento2, .45), C.brilho, C.acento2, mix(C.acento, C.brilho, .5)]);
  while (C.gradiente.length < 5) C.gradiente.push(C.gradiente[C.gradiente.length % 3]);
  C.pixels = cc.pixels || [C.acento, C.acento2, C.gradiente[1], C.brilho, claro(C.acento2, .3), mix(C.acento, '#E0304A', .3), escuro(C.gradiente[1], .15), C.tinta];
  C.porta = cc.porta || claro(C.acento2, .25);                  // o pino das saídas de imagem (formatos)
  C.porta2 = cc.porta2 || C.gradiente[1];                         // o pino das saídas em vídeo
  C.sombra = cc.sombra || escuro(mix(C.fundo, C.acento, .35), .75);
  C.texto2 = cc.texto2 || mix(C.apagado, C.tinta, .35);          // o slogan do fecho
  C.fraco = mix('#FFFFFF', C.apagado, .55);                         // o texto bem apagado (legenda das saídas)
  C.trilho = mix(C.fundo, C.apagado, .35);                         // o trilho da lista de etapas
  // o texto sobre as superfícies brancas (pílulas, chips, cartões, a barra de vidro): com tinta clara (fundo escuro), escuro
  const lum = h => { const c = rgbOf(h).map(v => v / 255); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
  C.tintaC = cc.tinta_cartao || (lum(C.tinta) > .5 ? (lum(C.fundo) < .3 ? mix(C.fundo, '#000000', .2) : '#161A18') : C.tinta);
  C.apagadoC = lum(C.tinta) > .5 ? mix(C.tintaC, '#FFFFFF', .5) : C.apagado;
  const SOMBRA = rgbOf(C.sombra).join(',');
  const root = document.documentElement.style;
  for (const [k, v] of Object.entries({ fundo: C.fundo, tinta: C.tinta, apagado: C.apagado, acento: C.acento, acento2: C.acento2, brilho: C.brilho,
    base: C.base, fraco: C.fraco, trilho: C.trilho, texto2: C.texto2, 'tinta-c': C.tintaC, 'apagado-c': C.apagadoC })) root.setProperty('--' + k, v);
  root.setProperty('--sombra', SOMBRA);

  // ---------- tempo ----------
  const FPS = 30;
  // grade da música, 140 BPM. O compasso 0 do filme cai em 0,5 s (T0); antes dele, a entrada.
  const BAR = 1.713952, BEAT = BAR / 4, T0 = 0.5;
  const bar = (i, b = 0) => +(T0 + i * BAR + b * BEAT).toFixed(4);

  gsap.registerPlugin(CustomEase);
  CustomEase.create('out', '0.23,1,0.32,1');        // entradas (ease-out forte)
  CustomEase.create('io', '0.77,0,0.175,1');        // movimento na tela / câmera
  CustomEase.create('expo', '0.16,1,0.3,1');
  CustomEase.create('snap', '0.12,0.9,0.15,1');     // alças pulando
  CustomEase.create('quick', '0.4,0,0.6,1');
  CustomEase.create('exit', '0.55,0,0.9,0.5');      // saídas rápidas (filme, não UI)
  gsap.defaults({ ease: 'out', duration: .6, lazy: false });
  gsap.ticker.lagSmoothing(0);
  const EASE = n => gsap.parseEase(n);

  // ---------- as cenas: ordem, obrigatórias e o lugar de cada uma na grade ----------
  // Cada cena ocupa batidas inteiras (o drop e as viradas caem sempre na música). "canon" = onde a cena começa no filme
  // completo (todas as cenas); a cena desenha em tempos do filme completo somados ao seu deslocamento (F.cena(tipo).off).
  const ORDEM = ['abertura', 'gancho', 'vao', 'etapas', 'pedido', 'montagem', 'baralho', 'manifesto', 'formatos', 'chamada', 'fecho'];
  const OBRIGATORIAS = ['gancho', 'chamada', 'fecho'];
  const CANON = { abertura: bar(0), gancho: bar(2), vao: bar(3), etapas: bar(4), pedido: bar(6), montagem: 13.0, baralho: bar(9),
    manifesto: bar(12), formatos: bar(14), chamada: bar(18), fecho: bar(20) };
  const FECHO_S = 40.5 - bar(20);
  const lista = (CFG.cenas || []).filter(c => c && c.tipo && c.ativa !== false);
  const porTipo = {}; for (const c of lista) porTipo[c.tipo] = c;
  for (const t of OBRIGATORIAS) if (!porTipo[t]) { aviso(`a cena "${t}" é obrigatória e não está no config: entrou com os textos padrão`); porTipo[t] = { tipo: t }; }
  for (const c of lista) if (!ORDEM.includes(c.tipo)) aviso(`cena desconhecida: "${c.tipo}" (ignorada)`);
  const ATIVAS = ORDEM.filter(t => porTipo[t]);
  const ant = t => ATIVAS[ATIVAS.indexOf(t) - 1] || null, prox = t => ATIVAS[ATIVAS.indexOf(t) + 1] || null;
  const CENAS = {};
  let tb = 0;                                                    // batidas desde T0
  const pedMont = (bar(9) - 13.0) / BEAT;                        // 6,83: a montagem logo depois do pedido
  for (const t of ATIVAS) {
    let beats, lead = 0;
    if (t === 'abertura') beats = 8;
    else if (t === 'gancho' || t === 'vao') beats = 4;
    else if (t === 'etapas' || t === 'chamada') beats = 8;
    else if (t === 'pedido') beats = prox(t) === 'montagem' ? 12 - pedMont : 8;
    else if (t === 'montagem') { if (ant(t) === 'pedido') beats = pedMont; else { beats = 8; lead = 8 - pedMont; } }
    else if (t === 'baralho') beats = 12;
    else if (t === 'manifesto') beats = prox(t) === 'formatos' ? 8 : 12;
    else if (t === 'formatos') beats = 16;
    else beats = FECHO_S / BEAT;
    const t0 = T0 + tb * BEAT, t1 = t0 + beats * BEAT;
    CENAS[t] = { tipo: t, cfg: porTipo[t], t0: +t0.toFixed(4), t1: +t1.toFixed(4), off: +(t0 + lead * BEAT - CANON[t]).toFixed(4), lead: lead * BEAT, ant: ant(t), prox: prox(t) };
    tb += beats;
  }
  const primeira = ATIVAS[0];
  CENAS[primeira].t0 = 0;                                        // a primeira cena já está na tela desde o quadro 0
  const DUR = +(CENAS.fecho.t1).toFixed(4);
  // o drop: onde a música entra cheia. É a revelação da montagem; sem ela, a primeira cena depois do pedido.
  const DROP = CENAS.montagem ? bar(8) + CENAS.montagem.off
    : (CENAS[ATIVAS.find(t => ORDEM.indexOf(t) > ORDEM.indexOf('pedido'))] || CENAS.chamada).t0;
  const PARADA = bar(21) + CENAS.fecho.off;                        // o groove para e o logo trava
  const cena = t => CENAS[t] || null;
  const cfgDe = t => (CENAS[t] && CENAS[t].cfg) || {};

  const tl = gsap.timeline({ paused: true });
  const stage = document.getElementById('stage');
  const appliers = [], CUES = [];

  // ---------- texto ----------
  const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const rico = s => esc(s).replace(/\*\*(.+?)\*\*/g, '<b style="font-weight:600">$1</b>');   // **negrito**
  const palavras = s => String(s ?? '').trim().split(/\s+/).filter(Boolean);
  const img = p => p ? '/' + String(p).replace(/^\/+/, '') : '';

  const add = (html, parent) => { const t = document.createElement('template'); t.innerHTML = html.trim(); const n = t.content.firstElementChild; (parent || stage).appendChild(n); return n; };
  const q = (s, r = document) => r.querySelector(s), qa = (s, r = document) => [...r.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, k) => a + (b - a) * k;
  const pan = x => +clamp(((x - 960) / 960) * .6, -1, 1).toFixed(2);

  // cue de som: t em segundos; kind e id seguem o vocabulário da mixagem (tools/sfx.py)
  const cue = (t, kind, id, o = {}) => CUES.push({ t: +t.toFixed(4), f: +(t * FPS).toFixed(2), kind, id, ...o });
  const apply = fn => appliers.push(fn);

  // cena: <section> visível só entre from e to
  function scene(id, from, to, z = 1) {
    const s = add(`<section class="scene" id="${id}" style="z-index:${z}"></section>`);
    gsap.set(s, { autoAlpha: 0 }); tl.set(s, { autoAlpha: 1 }, Math.max(0, from)); tl.set(s, { autoAlpha: 0 }, to);
    if (from <= 0) gsap.set(s, { autoAlpha: 1 });
    return s;
  }

  // quadro-chave: kf(t, [[t0, v0], [t1, v1, 'ease'], ...]) → valor (segura o primeiro e o último)
  function kf(t, keys) {
    if (t <= keys[0][0]) return keys[0][1];
    for (let i = 1; i < keys.length; i++) {
      const [ta, va] = keys[i - 1], [tb, vb, e = 'io'] = keys[i];
      if (t <= tb) { const k = (t - ta) / (tb - ta); return lerp(va, vb, EASE(e)(clamp(k, 0, 1))); }
    }
    return keys[keys.length - 1][1];
  }

  // posição de um elemento no palco (1920×1080), já com as transformações aplicadas
  function rect(el) {
    const s = stage.getBoundingClientRect(), r = el.getBoundingClientRect(), k = s.width / 1920;
    return { x: (r.left - s.left) / k, y: (r.top - s.top) / k, w: r.width / k, h: r.height / k };
  }

  // texto que cabe: reduz a escala (--k) de um bloco até a largura medida caber em maxW (nunca abaixo de min)
  function caber(el, maxW, { min = .55, nome = '', medir = null } = {}) {
    el.style.setProperty('--k', 1);
    const w = rect(medir || el).w;
    let k = 1;
    if (w > maxW) { k = maxW / w; if (k < .7 && k >= min) aviso(`${nome || 'texto'} ficou em ${(k * 100).toFixed(0)}% do corpo: encurte para ficar maior`); if (k < min) { aviso(`${nome || 'texto'} longo demais: precisaria de ${(k * 100).toFixed(0)}% do corpo (mínimo ${min * 100}%); encurte`); k = min; } }
    el.style.setProperty('--k', k.toFixed(4));
    return k;
  }

  // entrada padrão: sobe pouco, sai do blur, nasce de 0,96 (nunca de 0)
  function popIn(el, t, { dur = .55, y = 14, x = 0, s = .96, blur = 8, ease = 'out', o = 1, tint = null } = {}) {
    const final = tint ? getComputedStyle(el).color : null;
    const bx = +gsap.getProperty(el, 'x') || 0, by = +gsap.getProperty(el, 'y') || 0;   // posição já definida com gsap.set
    tl.fromTo(el, { opacity: 0, y: by + y, x: bx + x, scale: s, filter: `blur(${blur}px)`, ...(tint ? { color: tint } : {}) },
      { opacity: o, y: by, x: bx, scale: 1, filter: 'blur(0px)', duration: dur, ease, immediateRender: false }, t);
    if (tint) tl.to(el, { color: final, duration: dur * 1.6, ease: 'power2.out' }, t + .08);
    gsap.set(el, { opacity: 0 });
  }
  const popOut = (el, t, { dur = .28, y = -10, x = 0, blur = 10, s = 1 } = {}) =>
    tl.to(el, { opacity: 0, y: `+=${y}`, x: `+=${x}`, scale: s, filter: `blur(${blur}px)`, duration: dur, ease: 'exit' }, t);

  // caracteres: cada um nasce tingido e assenta na cor final (a digitação com tinta que assenta)
  function charsOf(el) {
    const text = el.textContent; el.textContent = '';
    return [...text].map(c => { const s = document.createElement('span'); s.className = 'ch'; s.textContent = c === ' ' ? ' ' : c; el.appendChild(s); return s; });
  }
  function typeChars(spans, t0, dt, { tint = C.acento, ink = null, blur = 7, y = 6, dur = .34 } = {}) {
    spans.forEach((sp, i) => {
      const t = t0 + i * dt, fin = ink || getComputedStyle(sp).color;
      tl.fromTo(sp, { opacity: 0, filter: `blur(${blur}px)`, y, color: tint }, { opacity: 1, filter: 'blur(0px)', y: 0, duration: dur, ease: 'out', immediateRender: false }, t);
      tl.to(sp, { color: fin, duration: dur * 1.7, ease: 'power1.out' }, t + .05);
      gsap.set(sp, { opacity: 0 });
    });
    return t0 + spans.length * dt;
  }

  // palavras em spans (mantém espaços); devolve os spans
  function wordsOf(el) {
    const parts = el.innerHTML.split(/(\s+)/);
    el.innerHTML = parts.map(p => /^\s+$/.test(p) ? p : `<span class="w">${p}</span>`).join('');
    return qa('.w', el);
  }

  // alças de seleção: quatro quadradinhos de tinta nos cantos de um retângulo, que pulam no tempo
  function handles(parent, { size = 11, color = C.tinta, z = 20 } = {}) {
    const box = add(`<div class="handles" style="z-index:${z}"></div>`, parent);
    const sq = [0, 1, 2, 3].map(() => add(`<i class="hd" style="width:${size}px;height:${size}px;background:${color}"></i>`, box));
    gsap.set(sq, { opacity: 0, x: 960, y: 540 });
    const corners = r => [[r.x, r.y], [r.x + r.w, r.y], [r.x, r.y + r.h], [r.x + r.w, r.y + r.h]].map(([x, y]) => [x - size / 2, y - size / 2]);
    return {
      box, sq,
      show(t, r, { dur = .3 } = {}) { const c = corners(r); sq.forEach((s, i) => { tl.set(s, { x: c[i][0], y: c[i][1] }, t); tl.fromTo(s, { opacity: 0, scale: .4 }, { opacity: 1, scale: 1, duration: dur, ease: 'out', immediateRender: false }, t + i * .025); }); },
      to(t, r, { dur = .16, ease = 'snap' } = {}) { const c = corners(r); sq.forEach((s, i) => tl.to(s, { x: c[i][0], y: c[i][1], duration: dur, ease }, t)); },
      hide(t, { dur = .2 } = {}) { tl.to(sq, { opacity: 0, scale: .5, duration: dur, ease: 'exit', stagger: .02 }, t); },
    };
  }
  const pad = (r, p, py = p) => ({ x: r.x - p, y: r.y - py, w: r.w + 2 * p, h: r.h + 2 * py });

  function seek(t) {
    t = clamp(t, 0, DUR);
    tl.time(t, false);
    for (const fn of appliers) fn(t);
  }
  return { CFG, FILME_ID, AVISOS, aviso, C, rgbOf, hexOf, mix, claro, escuro, rgba, FPS, DUR, BAR, BEAT, T0, bar, EASE, ORDEM, OBRIGATORIAS, CANON, CENAS, ATIVAS, DROP, PARADA,
    cena, cfgDe, tl, stage, appliers, CUES, esc, rico, palavras, img, add, q, qa, clamp, lerp, pan, cue, apply, scene, kf, rect, caber,
    popIn, popOut, charsOf, typeChars, wordsOf, handles, pad, seek };
})();
