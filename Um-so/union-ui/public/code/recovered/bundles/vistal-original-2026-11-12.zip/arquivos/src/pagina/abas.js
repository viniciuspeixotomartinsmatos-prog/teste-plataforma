// Abas acessíveis (role=tablist): clique, setas, Home e End. `ao(aba)` faz a troca visual.
export function abas(lista, ao) {
  const todas = [...lista.querySelectorAll('[role="tab"]')];
  const ativa = (aba, foco = false) => {
    todas.forEach((a) => {
      const sim = a === aba;
      a.classList.toggle('is-ativa', sim);
      a.setAttribute('aria-selected', sim);
      a.tabIndex = sim ? 0 : -1;
    });
    if (foco) aba.focus();
    ao(aba);
  };
  lista.addEventListener('click', (e) => {
    const aba = e.target.closest('[role="tab"]');
    if (aba && !aba.classList.contains('is-ativa')) ativa(aba);
  });
  lista.addEventListener('keydown', (e) => {
    const i = todas.indexOf(document.activeElement);
    if (i < 0) return;
    const n = todas.length;
    const vai = { ArrowRight: i + 1, ArrowLeft: i - 1 + n, Home: 0, End: n - 1 }[e.key];
    if (vai === undefined) return;
    e.preventDefault();
    ativa(todas[vai % n], true);
  });
  return { ativa, todas };
}
