// Agendamento da visita: os seis próximos dias úteis (sem domingo) a partir de amanhã, horários com alguns já
// ocupados (fixos por dia e imóvel, para não mudar a cada clique), máscara do WhatsApp e a confirmação na tela.
// Não envia nada: no site do cliente, o envio vai para o WhatsApp ou para o e-mail dele.
const HORAS = ['9h', '10h30', '14h', '16h', '17h30'];
const SEMANA = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
const SEMANA_LONGA = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
const MES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

function proximosDias(n) {
  const dias = [];
  const d = new Date();
  while (dias.length < n) {
    d.setDate(d.getDate() + 1);
    if (d.getDay() !== 0) dias.push(new Date(d));
  }
  return dias;
}

// "ocupado" estável: um hash simples do dia, do horário e do imóvel
const ocupado = (dia, hora, imovel) => {
  let h = dia.getDate() * 31 + hora * 7;
  for (const c of imovel) h = (h * 33 + c.charCodeAt(0)) % 997;
  return h % 4 === 0;
};

const escolha = (nome, valor, conteudo, i) =>
  `<label class="escolha"><input type="radio" name="${nome}" value="${valor}"${i === 0 ? ' checked' : ''}><span>${conteudo}</span></label>`;

export function visita() {
  const form = document.querySelector('.agenda');
  const select = form.querySelector('select');
  const caixaDias = form.querySelector('[data-dias]');
  const caixaHoras = form.querySelector('[data-horas]');
  const resumo = form.querySelector('[data-resumo]');
  const feito = form.querySelector('.agenda__feito');
  const tituloFeito = form.querySelector('[data-feito]');
  const nome = form.elements.nome;
  const fone = form.elements.fone;
  const dias = proximosDias(6);

  caixaDias.innerHTML = dias.map((d, i) => escolha('dia', i, `<small>${SEMANA[d.getDay()]}</small>${d.getDate()}`, i)).join('');
  caixaHoras.innerHTML = HORAS.map((h, i) => escolha('hora', i, h, i)).join('');
  feito.hidden = false;
  feito.inert = true;

  const atual = () => ({
    dia: dias[+form.elements.dia.value],
    hora: form.elements.hora.value === '' ? null : HORAS[+form.elements.hora.value],
    imovel: select.value,
  });

  // horários ocupados do dia e do imóvel escolhidos; se o marcado ficou ocupado, passa para o primeiro livre
  const horarios = () => {
    const { dia, imovel } = atual();
    const radios = [...form.elements.hora];
    radios.forEach((r, i) => { r.disabled = ocupado(dia, i, imovel); });
    if (!radios.some((r) => r.checked && !r.disabled)) {
      const livre = radios.find((r) => !r.disabled);
      if (livre) livre.checked = true;
    }
    escreve();
  };
  const escreve = () => {
    const { dia, hora, imovel } = atual();
    resumo.textContent = `${imovel} · ${SEMANA[dia.getDay()]}, ${dia.getDate()} de ${MES[dia.getMonth()].slice(0, 3)}.${hora ? ` · ${hora}` : ''}`;
  };

  form.addEventListener('change', (e) => {
    if (e.target.name === 'dia' || e.target === select) horarios(); else escreve();
  });

  // (00) 00000-0000
  fone.addEventListener('input', () => {
    const n = fone.value.replace(/\D/g, '').slice(0, 11);
    let v = n;
    if (n.length > 2) v = `(${n.slice(0, 2)}) ${n.slice(2)}`;
    if (n.length > 7) v = `(${n.slice(0, 2)}) ${n.slice(2, n.length - 4)}-${n.slice(-4)}`;
    fone.value = v;
    fone.removeAttribute('aria-invalid');
  });
  nome.addEventListener('input', () => nome.removeAttribute('aria-invalid'));

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nomeOk = nome.value.trim().length >= 2;
    const foneOk = fone.value.replace(/\D/g, '').length >= 10;
    if (nomeOk) nome.removeAttribute('aria-invalid'); else nome.setAttribute('aria-invalid', 'true');
    if (foneOk) fone.removeAttribute('aria-invalid'); else fone.setAttribute('aria-invalid', 'true');
    if (!nomeOk || !foneOk) { (nomeOk ? fone : nome).focus(); return; }
    const { dia, hora, imovel } = atual();
    tituloFeito.textContent = `${imovel}, ${SEMANA_LONGA[dia.getDay()]}, ${dia.getDate()} de ${MES[dia.getMonth()]}, às ${hora}.`;
    form.classList.add('feito');
    form.querySelector('.agenda__passos').inert = true;
    feito.inert = false;
    feito.querySelector('.agenda__outra').focus({ preventScroll: true });
  });

  feito.querySelector('.agenda__outra').addEventListener('click', () => {
    form.classList.remove('feito');
    form.querySelector('.agenda__passos').inert = false;
    feito.inert = true;
    select.focus({ preventScroll: true });
  });

  horarios();

  // botão "Agendar visita" de um imóvel: chega aqui com ele escolhido
  return (imovel) => {
    if (![...select.options].some((o) => o.value === imovel)) return;
    select.value = imovel;
    horarios();
  };
}
