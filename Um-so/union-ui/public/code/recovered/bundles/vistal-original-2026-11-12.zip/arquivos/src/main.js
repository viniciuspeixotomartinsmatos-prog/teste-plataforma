import { enxame } from './motion/enxame.js';
import { rolando, revela, nav, atalhos } from './pagina/pagina.js';
import { residencias } from './pagina/residencias.js';
import { ardosia } from './pagina/ardosia.js';
import { visita } from './pagina/visita.js';

enxame();
// religa as transições depois do primeiro quadro pintado (index.html): nada anima do estilo de antes do CSS
requestAnimationFrame(() => requestAnimationFrame(() => document.documentElement.classList.add('assentou')));

rolando();
revela();
nav();
ardosia();
atalhos({ escolheTipo: residencias(), escolheImovel: visita() });
