// O que vale para a página toda: hover desligado enquanto rola, entrada das peças por marco, nav presa com a aba da
// seção atual, e os atalhos (pílula de tipo → aba das residências; botão de imóvel → visita com ele escolhido).
const raiz = document.documentElement;

export function rolando() {
  let t;
  addEventListener('scroll', () => {
    raiz.classList.add('rolando');
    clearTimeout(t);
    t = setTimeout(() => raiz.classList.remove('rolando'), 140);
  }, { passive: true });
}

// [data-revela] entra quando chega na tela e anima por tempo (CSS), mesmo se a rolagem passar rápido por ela
export function revela() {
  const io = new IntersectionObserver((itens) => {
    for (const i of itens) {
      if (!i.isIntersecting) continue;
      i.target.classList.add('visto');
      io.unobserve(i.target);
    }
  }, { rootMargin: '0px 0px -10% 0px' });
  document.querySelectorAll('[data-revela]').forEach((el) => io.observe(el));
}

export function nav() {
  const barra = document.querySelector('.nav');
  const abas = [...document.querySelectorAll('.nav__aba')];
  const hero = document.querySelector('.hero');
  // todas as seções contam: na que não tem aba (a visita), nenhuma fica acesa
  const alvos = [...document.querySelectorAll('main > section[id], footer[id]')];

  // passou do hero: a nav ganha um fundo para ler sobre as fotos
  const solta = () => barra.classList.toggle('solta', scrollY > hero.offsetHeight - 90);
  addEventListener('scroll', solta, { passive: true });
  solta();

  // aba da seção que está no meio da tela
  const marca = (id) => abas.forEach((a) => {
    const ativa = a.getAttribute('href') === `#${id}`;
    a.classList.toggle('is-ativa', ativa);
    if (ativa) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
  });
  const io = new IntersectionObserver((itens) => {
    for (const i of itens) if (i.isIntersecting) marca(i.target.id);
  }, { rootMargin: '-45% 0px -54% 0px' });
  alvos.forEach((s) => io.observe(s));
}

export function atalhos({ escolheTipo, escolheImovel }) {
  document.addEventListener('click', (e) => {
    const tipo = e.target.closest('[data-tipo]:not([role="tab"])');
    if (tipo) escolheTipo(tipo.dataset.tipo);
    const imovel = e.target.closest('a[data-imovel]');
    if (imovel) escolheImovel(imovel.dataset.imovel);
  });
}
