# Receitas das fotos da Vistal

As fotos do site foram geradas por IA a partir dos prompts desta pasta (`prompts/`, em inglês, que é como os geradores
de imagem respondem melhor). Servem para refazer uma foto, gerar mais uma no mesmo estilo ou trocar pelos imóveis da
pessoa. Qualquer gerador de imagem que aceite texto e imagem de referência serve (o do ChatGPT, o Gemini, o
Midjourney, o Ideogram); nenhum passo depende de uma conta específica.

## Ordem
1. **A casa do hero** (`casa`): é a peça principal e vem primeiro. Paisagem 3:2, a casa nos 58% de baixo, **o céu
   limpo nos 40% de cima** (o nome da marca fica ali, atrás do telhado), árvores só nas bordas, hora azul com todas as
   luzes acesas. Se o céu sair com nuvem, galho ou fio no meio, gere de novo: o recorte depende do céu liso.
2. **Os cômodos** (`int-sala`, `int-cozinha`, `int-suite`, `int-varanda`): mande a foto da casa junto como referência,
   para manter os materiais (concreto, ripas de cumaru, pedra, piscina) e a mesma luz. Deixe o lado esquerdo calmo:
   a legenda fica ali.
3. **As residências** (`res-jatoba`, `res-seixo`, `res-cobertura`, `res-duplex`, `res-terreno`) e a **porta**
   (`sobre-porta`, em pé, 2:3). Todos os prompts repetem o mesmo parágrafo de arquitetura e de luz: mantenha esse
   parágrafo em qualquer foto nova, é ele que deixa a série coerente.
4. **Exportar**: salve cada PNG com o nome do prompt em `arquivos/fonte/` e rode, de dentro dessa pasta,
   `sh exporta.sh`. Ele faz a máscara do céu e a versão crua da casa (`ceu.py`, `cru.py`) e converte tudo para WebP no
   tamanho do site, direto em `public/img/`. Precisa de `python3` com `numpy`, `pillow` e `scipy`
   (`pip install numpy pillow scipy`) e do `cwebp` (`brew install webp` no Mac).

## Tamanhos no site
- `casa.webp` e `casa-crua.webp`: 1536 × 1024; `casa-recorte.webp`: a máscara, no mesmo tamanho.
- `int-*.webp`: 1536 px de largura (tela cheia e fundo da visita).
- `res-*.webp`: 1280 px de largura (o CSS corta em 5:4 e o terreno em 5:2, pelo meio).
- `sobre-porta.webp`: 800 × 1200.

## Custo e alternativas
Cada imagem leva de 1 a 3 minutos; a série inteira (11 fotos) cabe numa tarde e, nos planos de assinatura dos
geradores, não custa nada além da mensalidade. Fotos reais dos imóveis da pessoa funcionam ainda melhor: respeite as
proporções e, na do hero, o céu limpo em cima. Foto real tirada de dia também serve; a montagem e o recorte funcionam
igual, só a cena final fica diurna em vez de hora azul.

## Adaptando para outro imóvel
- Prédio ou empreendimento: troque "beach house" pela fachada do prédio, de frente, com o céu em cima e o topo do
  prédio a ~42% da altura da imagem.
- Casa de campo ou de serra: troque o mar pela mata ou pela montanha no fundo; mantenha o parágrafo de arquitetura e
  de luz se quiser a mesma linguagem, ou troque pelo estilo dos imóveis da pessoa (e use o mesmo em todas as fotos).
