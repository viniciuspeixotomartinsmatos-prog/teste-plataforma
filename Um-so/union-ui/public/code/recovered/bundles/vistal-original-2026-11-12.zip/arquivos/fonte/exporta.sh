#!/bin/sh
# Refaz as imagens do site a partir das fotos em PNG (rodar de dentro de arquivos/fonte/, com as fotos ao lado).
# Precisa de python3 com numpy, pillow e scipy (pip install numpy pillow scipy) e do cwebp (libwebp).
set -e
SITE=../../public/img
# hero: casa.png → máscara do céu → versão crua → as três imagens do hero
if [ -f casa.png ]; then
  python3 ceu.py casa.png mascara.png
  python3 cru.py
  python3 -c "
from PIL import Image
m = Image.open('mascara.png').convert('L')
a = Image.new('LA', m.size, (0, 0)); a.putalpha(m); a.convert('RGBA').save('mascara-alfa.png')"
  cwebp -quiet -q 82 casa.png -o $SITE/casa.webp
  cwebp -quiet -q 80 cru.png -o $SITE/casa-crua.webp
  cwebp -quiet -lossless -z 9 mascara-alfa.png -o $SITE/casa-recorte.webp
  rm mascara-alfa.png
fi
# cômodos e fundo da visita em tela cheia: 1536 de largura
for f in int-sala int-cozinha int-suite int-varanda; do
  [ -f "$f.png" ] && cwebp -quiet -q 78 "$f.png" -o "$SITE/$f.webp"
done
# residências: 1280 de largura bastam
for f in res-jatoba res-seixo res-cobertura res-duplex; do
  [ -f "$f.png" ] && cwebp -quiet -q 76 -resize 1280 0 "$f.png" -o "$SITE/$f.webp"
done
[ -f res-terreno.png ] && cwebp -quiet -q 76 res-terreno.png -o $SITE/res-terreno.webp
[ -f sobre-porta.png ] && cwebp -quiet -q 80 -resize 800 1200 sobre-porta.png -o $SITE/sobre-porta.webp
ls -la $SITE
