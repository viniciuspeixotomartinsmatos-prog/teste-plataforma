// Casa Ardósia por dentro: a aba troca o cômodo por dissolve e a legenda acompanha. Enquanto a cena está na tela e
// ninguém mexeu nas abas, os cômodos andam sozinhos a cada 4,5 s.
import { abas } from './abas.js';

export function ardosia() {
  const secao = document.querySelector('.ardosia');
  const fotos = [...secao.querySelectorAll('.ardosia__foto')];
  const andar = secao.querySelector('[data-andar]');
  const nome = secao.querySelector('[data-nome]');
  const lista = secao.querySelector('.ardosia__abas');
  let trocaTexto;

  const mostra = (aba) => {
    fotos.forEach((f) => f.classList.toggle('is-ativa', f.dataset.comodo === aba.dataset.comodo));
    nome.classList.add('troca');
    clearTimeout(trocaTexto);
    trocaTexto = setTimeout(() => {
      andar.textContent = aba.dataset.andar;
      nome.textContent = aba.dataset.nome;
      nome.classList.remove('troca');
    }, 200);
  };
  const { ativa, todas } = abas(lista, mostra);

  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  let mexeu = false;
  let relogio;
  ['pointerdown', 'keydown'].forEach((t) => lista.addEventListener(t, () => { mexeu = true; clearInterval(relogio); }));
  new IntersectionObserver(([i]) => {
    clearInterval(relogio);
    if (!i.isIntersecting || mexeu) return;
    relogio = setInterval(() => {
      const atual = todas.findIndex((a) => a.classList.contains('is-ativa'));
      ativa(todas[(atual + 1) % todas.length]);
    }, 4500);
  }, { threshold: 0.55 }).observe(secao);
}
