// Residências: a aba troca o grupo de fotos (o que sai some, o que entra sobe). Os grupos fora da tela ficam inertes.
import { abas } from './abas.js';

export function residencias() {
  const lista = document.querySelector('.residencias__abas');
  const grupos = [...document.querySelectorAll('.residencias__grupo')];
  const mostra = (aba) => grupos.forEach((g) => {
    const sim = g.id === aba.getAttribute('aria-controls');
    g.classList.toggle('is-ativo', sim);
    g.inert = !sim;
  });
  const { ativa, todas } = abas(lista, mostra);
  mostra(todas[0]);
  return (tipo) => {
    const aba = todas.find((a) => a.dataset.tipo === tipo);
    if (aba) ativa(aba);
  };
}
