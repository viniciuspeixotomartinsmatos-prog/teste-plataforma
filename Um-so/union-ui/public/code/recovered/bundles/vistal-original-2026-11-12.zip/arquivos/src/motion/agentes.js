// Os agentes: cursores de um editor multiplayer, cada um com uma função (o nome na etiqueta) e uma cor. Cada um tem
// uma posição no documento (x, y), um modo (seta, mira ou texto) e anda em curva até onde vai trabalhar. Um ticker só
// desenha todos.
import { gsap } from 'gsap';

export const EQUIPE = [
  { nome: 'layout-01', cor: '#f5d84a' },
  { nome: 'foto-01', cor: '#5ee0e6' },
  { nome: 'nav-01', cor: '#ff6fb5' },
  { nome: 'vidro-01', cor: '#b9a3ff' },
  { nome: 'tipo-01', cor: '#ffa24c' },
  { nome: 'texto-01', cor: '#ff8a7a' },
  { nome: 'texto-02', cor: '#8fc4ff' },
  { nome: 'cor-01', cor: '#7ef08a' },
];

const SVG = `
<svg class="ag__seta" viewBox="0 0 20 20"><path d="M3.6 2.4 17.4 8.7c.8.36.75 1.05-.08 1.3l-5.9 1.75-1.9 6.1c-.25.82-.95.85-1.3.06z"/></svg>
<svg class="ag__mira" viewBox="0 0 20 20"><path class="f" d="M10 3v14M3 10h14"/><path d="M10 3v14M3 10h14"/></svg>
<svg class="ag__ibeam" viewBox="0 0 20 20"><path class="f" d="M7.2 2.8h5.6M10 2.8v14.4M7.2 17.2h5.6"/><path d="M7.2 2.8h5.6M10 2.8v14.4M7.2 17.2h5.6"/></svg>`;

export function criaAgentes(palco) {
  const lista = EQUIPE.map(({ nome, cor }, i) => {
    const el = document.createElement('div');
    el.className = 'ag';
    el.style.setProperty('--c', cor);
    el.innerHTML = `${SVG}<b class="ag__nome">${nome}</b>`;
    palco.append(el);
    return { i, el, nome, cor, x: -200, y: -200, rx: NaN, ry: NaN, vx: 0, vy: 0, px: NaN, py: NaN, modo: 'seta', mov: null };
  });
  // além de desenhar, mede a velocidade de cada um (px/s, suavizada): é dela que sai a saída de cena
  const desenha = (t, dtMs) => {
    const dt = Math.max(dtMs, 1) / 1000;
    for (const a of lista) {
      if (!Number.isNaN(a.px)) {
        a.vx += ((a.x - a.px) / dt - a.vx) * 0.4;
        a.vy += ((a.y - a.py) / dt - a.vy) * 0.4;
      }
      a.px = a.x;
      a.py = a.y;
      if (a.x === a.rx && a.y === a.ry) continue;
      a.el.style.transform = `translate3d(${a.x.toFixed(1)}px, ${a.y.toFixed(1)}px, 0)`;
      a.rx = a.x;
      a.ry = a.y;
    }
  };
  gsap.ticker.add(desenha);
  return { lista, remove: () => { gsap.ticker.remove(desenha); lista.forEach((a) => a.el.remove()); } };
}

export function modo(a, m) {
  if (a.modo === m) return;
  a.el.classList.remove('is-' + a.modo);
  a.modo = m;
  if (m !== 'seta') a.el.classList.add('is-' + m);
}

// anda em curva (bezier quadrática com o ponto de controle para um lado) e resolve true ao chegar, false se outro
// movimento o interromper
export function vai(a, x, y, o = {}) {
  const x0 = a.x, y0 = a.y;
  const dx = x - x0, dy = y - y0;
  const d = Math.hypot(dx, dy) || 1;
  const v = Math.hypot(a.vx, a.vy);
  const embalo = v > 120 && !o.ease;
  const dur = o.dur ?? Math.min(0.6, Math.max(0.2, 0.14 + d / 2600));
  let cx, cy;
  if (embalo) {
    // já em movimento: o ponto de controle fica na direção da velocidade e a curva sai tangente a ela, com a mesma
    // rapidez (no power2.out a saída anda 4 × alcance / dur)
    const alcance = Math.min(d * 0.45, (v * dur) / 4);
    cx = x0 + (a.vx / v) * alcance;
    cy = y0 + (a.vy / v) * alcance;
  } else {
    const k = (Math.random() * 2 - 1) * (o.curva ?? 0.22) * d;
    cx = x0 + dx / 2 - (dy / d) * k;
    cy = y0 + dy / 2 + (dx / d) * k;
  }
  const p = { t: 0 };
  a.mov?.kill();
  return new Promise((res) => {
    a.mov = gsap.to(p, {
      t: 1,
      duration: dur,
      ease: o.ease ?? (embalo ? 'power2.out' : 'power2.inOut'),
      onUpdate() {
        const t = p.t, u = 1 - t;
        a.x = u * u * x0 + 2 * u * t * cx + t * t * x;
        a.y = u * u * y0 + 2 * u * t * cy + t * t * y;
      },
      onComplete: () => res(true),
      onInterrupt: () => res(false),
    });
  });
}

export function para(a) {
  a.mov?.kill();
  a.mov = null;
}

// anel que abre no ponto do clique, na cor do agente
export function clique(a, palco) {
  const el = document.createElement('i');
  el.className = 'clique';
  el.style.setProperty('--c', a.cor);
  el.style.transform = `translate(${a.x}px, ${a.y}px)`;
  palco.append(el);
  gsap.fromTo(el, { scale: 0.2, opacity: 1 }, { scale: 1, opacity: 0, duration: 0.42, ease: 'power2.out', onComplete: () => el.remove(), onInterrupt: () => el.remove() });
}

// sai de cena sem parar: segue na direção em que já ia, acelerando até passar da borda da tela. Parado (ou quase),
// sai pela borda mais perto. Resolve quando some.
export function foge(a, { acel = 2600 } = {}) {
  para(a);
  let vx = a.vx, vy = a.vy;
  const v = Math.hypot(vx, vy);
  let dx, dy;
  if (v > 90) {
    dx = vx / v;
    dy = vy / v;
  } else {
    const x = a.x - scrollX, y = a.y - scrollY;
    [, dx, dy] = [[x, -1, 0], [innerWidth - x, 1, 0], [y, 0, -1], [innerHeight - y, 0, 1]].sort((p, q) => p[0] - q[0])[0];
    vx = dx * v;
    vy = dy * v;
  }
  return new Promise((res) => {
    const passo = (t, dtMs) => {
      const dt = Math.min(dtMs, 50) / 1000;
      vx += dx * acel * dt;
      vy += dy * acel * dt;
      a.x += vx * dt;
      a.y += vy * dt;
      const x = a.x - scrollX, y = a.y - scrollY;
      if (x < -130 || x > innerWidth + 30 || y < -50 || y > innerHeight + 50) {
        gsap.ticker.remove(passo);
        a.el.style.opacity = 0;
        res();
      }
    };
    gsap.ticker.add(passo);
  });
}
