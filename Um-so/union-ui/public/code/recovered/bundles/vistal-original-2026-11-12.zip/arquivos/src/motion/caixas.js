// Caixa de layout que um agente arrasta em volta de uma peça: fio pontilhado e fundo tingidos na cor dele, etiqueta
// mono com o seletor e a medida ao vivo ("article.destaque 316×236").
import { gsap } from 'gsap';

// dentro: etiqueta no canto de cima, por dentro (caixa colada no topo da tela); 'pe': no canto de baixo, por dentro
export function caixa(palco, r, { cor, seletor, dentro = false }) {
  const el = document.createElement('div');
  if (!dentro && r.y - scrollY < 22) dentro = true;
  el.className = 'cx' + (dentro === 'pe' ? ' cx--pe' : dentro ? ' cx--dentro' : '');
  el.style.setProperty('--c', cor);
  el.innerHTML = '<b class="cx__tag"></b>';
  el.style.transform = `translate(${r.x}px, ${r.y}px)`;
  const tag = el.querySelector('.cx__tag');
  palco.append(el);
  let viva = true;
  const api = {
    el,
    tamanho(w, h) {
      if (!viva) return;
      el.style.width = `${w}px`;
      el.style.height = `${h}px`;
      tag.textContent = `${seletor} ${Math.round(w)}×${Math.round(h)}`;
    },
    // conteúdo no lugar: o preenchimento sai, o fio fica fraco até a limpeza do fim
    feita() { if (viva) el.classList.add('feita'); },
    some(dur = 0.35) {
      if (!viva) return;
      viva = false;
      gsap.to(el, { opacity: 0, duration: dur, ease: 'power1.out', onComplete: () => el.remove(), onInterrupt: () => el.remove() });
    },
  };
  api.tamanho(0, 0);
  return api;
}
