# Versão crua da foto: céu cinza liso, casa em cinza, luzes quentes apagadas. Usa casa.png e mascara.png.
# uso (da pasta fonte/): python3 cru.py
import numpy as np, sys
from PIL import Image
im = np.asarray(Image.open('casa.png').convert('RGB')).astype(np.float32)/255
m = np.asarray(Image.open('mascara.png')).astype(np.float32)[...,None]/255
L = (im[...,0]*0.2126+im[...,1]*0.7152+im[...,2]*0.0722)[...,None]
quente = np.clip(((im[...,0]-im[...,2]))*2.2, 0, 1)[...,None]
Lc = L*(1-0.42*quente)                      # luz das janelas apagada
Lc = 0.06 + Lc*0.95
casa = Lc*np.array([0.97,1.0,1.04]) *0.85 + im*0.15*0.6 + Lc*0.0
casa = np.clip(casa,0,1)
h,w,_ = im.shape
y = np.linspace(0,1,h)[:,None,None]
topo = np.array([0x4e,0x5a,0x66])/255; pe = np.array([0x8d,0x98,0xa1])/255
ceu = topo*(1-y**0.9) + pe*(y**0.9)
ceu = np.broadcast_to(ceu,(h,w,3))
out = casa*m + ceu*(1-m)
Image.fromarray((np.clip(out,0,1)*255).astype(np.uint8)).save('cru.png')
