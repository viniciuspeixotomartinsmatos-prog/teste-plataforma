// O enxame: oito agentes com função montam o hero na frente de quem vê, como uma equipe num editor multiplayer.
//
// Começa no palco escuro com a grade de 12 colunas. Cada agente desenha a caixa da peça dele (pontilhada, na cor
// dele, com seletor e medida), e depois faz o trabalho: foto-01 varre a foto crua, tipo-01 digita o letreiro e passa o
// kerning, foto-01 recorta a casa para a frente das letras, vidro-01 acende os vidros, nav-01 e os dois texto-0x
// digitam, layout-01 confere o alinhamento. Por último cor-01 passa a cor (a foto crua vira a hora azul com as
// janelas acesas) e as sobras do editor somem. O painel da atividade registra cada passo.
//
// As tarefas são uma lista com dono e dependências; cada agente faz as suas na ordem, esperando as de que depende,
// e, sem nada para fazer, ronda a peça da próxima. ?pronto e movimento reduzido abrem o hero já montado (index.html).
import { gsap } from 'gsap';
import { EQUIPE, criaAgentes, modo, vai, para, foge, clique } from './agentes.js';
import { caixa } from './caixas.js';
import { divide, digita, junta } from './digita.js';

const raiz = document.documentElement;
const celular = matchMedia('(max-width: 760px)');
const rand = (a, b) => a + Math.random() * (b - a);
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const espera = (s) => new Promise((res) => { gsap.delayedCall(s, () => res(true)); });
const anima = (alvo, vars) => new Promise((res) => { gsap.to(alvo, { ...vars, onComplete: () => res(true), onInterrupt: () => res(false) }); });
const rectDoc = (el) => {
  const r = el.getBoundingClientRect();
  return { x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height };
};

export function enxame() {
  window.__enxame = true;
  if (!raiz.classList.contains('monta')) return;

  const hero = $('.hero');
  const letreiro = $('.hero__letreiro');
  const palco = document.createElement('div');
  palco.className = 'enxame';
  palco.setAttribute('aria-hidden', 'true');
  document.body.append(palco);

  const { lista: ags } = criaAgentes(palco);
  const ag = Object.fromEntries(ags.map((a) => [a.nome, a]));
  // tudo da montagem roda 1,2× (o tempo do painel é o do relógio de verdade)
  const RITMO = 1.2;
  gsap.globalTimeline.timeScale(RITMO);
  const inicio = performance.now();
  const agora = () => (performance.now() - inicio) / 1000;
  let ativos = 0;
  let encerrado = false;

  // ---------- painel da atividade ----------
  const painel = document.createElement('div');
  painel.className = 'atividade';
  painel.innerHTML = `
    <div class="atividade__topo">
      <span class="atividade__titulo">ATIVIDADE DO ENXAME</span>
      <span class="atividade__vivos"><i></i>${ags.length} agentes no ar</span>
      <span class="atividade__cores">${EQUIPE.map((e) => `<i style="--c:${e.cor}"></i>`).join('')}</span>
      <span class="atividade__ops">0 ops/s</span>
    </div>
    <div class="atividade__linhas"></div>`;
  palco.append(painel);
  const linhas = painel.querySelector('.atividade__linhas');
  const ops = painel.querySelector('.atividade__ops');
  const poePainel = () => {
    const r = rectDoc(hero);
    const w = painel.offsetWidth, h = painel.offsetHeight;
    // no celular, logo abaixo do telhado (entre o letreiro e o card); no desktop, no meio de baixo, como na casa
    const cena = $('.hero__cena').getBoundingClientRect();
    const telhado = cena.top + scrollY + cena.height * 0.474;
    const y = celular.matches ? telhado + 12 : r.y + r.h * 0.62;
    painel.style.left = `${r.x + (r.w - w) / 2}px`;
    painel.style.top = `${Math.min(y, r.y + r.h - h - 12)}px`;
  };
  poePainel();
  gsap.from(painel, { opacity: 0, y: 10, duration: 0.5, ease: 'power2.out' });
  const fmt = (t) => {
    const s = Math.max(0, t);
    return `${String(Math.floor(s / 60)).padStart(2, '0')}:${(s % 60).toFixed(2).padStart(5, '0')}`;
  };
  function log(a, texto, saida = false) {
    if (encerrado && !saida) return;
    const l = document.createElement('div');
    l.className = 'atividade__linha';
    l.style.setProperty('--c', a.cor);
    l.innerHTML = `<span class="atividade__t">${fmt(agora())}</span><span class="atividade__quem">${a.nome}</span><span class="atividade__o-que"></span>`;
    l.lastChild.textContent = texto;
    linhas.prepend(l);
    while (linhas.children.length > 6) linhas.lastChild.remove();
  }
  let opsN = 0;
  const contaOps = gsap.to({}, {
    duration: 0.3,
    repeat: -1,
    onRepeat() {
      const alvo = 14 + ativos * 7 + rand(0, 6);
      opsN += (alvo - opsN) * 0.5;
      ops.textContent = `${Math.round(opsN)} ops/s`;
    },
  });

  // ---------- peças ----------
  const caixas = new Map();
  const linha = (classe, cor) => {
    const el = document.createElement('i');
    el.className = `varre ${classe}`;
    if (cor) el.classList.add('varre--cor');
    palco.append(el);
    return el;
  };

  // um agente arrasta a caixa da peça de um canto ao outro, com a medida ao vivo
  async function desenha(a, id, el, seletor, { pad = 0, dentro = false } = {}) {
    const r0 = rectDoc(el);
    const r = { x: r0.x - pad, y: r0.y - pad, w: r0.w + pad * 2, h: r0.h + pad * 2 };
    await vai(a, r.x, r.y);
    modo(a, 'mira');
    const cx = caixa(palco, r, { cor: a.cor, seletor, dentro });
    caixas.set(id, cx);
    const p = { k: 0 };
    await anima(p, {
      k: 1,
      duration: Math.min(0.42, Math.max(0.2, 0.14 + Math.sqrt(r.w * r.h) / 2400)),
      ease: 'power2.inOut',
      onUpdate() {
        const w = r.w * p.k, h = r.h * p.k;
        a.x = r.x + w;
        a.y = r.y + h;
        cx.tamanho(w, h);
      },
    });
    modo(a, 'seta');
  }

  // texto letra a letra, com o cursor de texto
  async function escreve(a, el, o = {}) {
    const div = divide(el);
    const u0 = div.unidades.find((u) => u.textContent.trim()) ?? div.unidades[0];
    const r0 = u0.getBoundingClientRect();
    await vai(a, r0.left + scrollX + 4, r0.top + scrollY + r0.height * 0.75);
    modo(a, 'texto');
    el.classList.add('c-viva');
    await digita(div, a, palco, parseFloat(getComputedStyle(el).fontSize) || 16, o);
    modo(a, 'seta');
    junta(div);
    el.classList.add('c-pronta');
    el.classList.remove('c-viva');
  }

  // peça que aparece inteira com um clique
  async function mostra(a, el, { vem = true } = {}) {
    if (vem) {
      const r = rectDoc(el);
      await vai(a, r.x + r.w * rand(0.3, 0.7), r.y + r.h * rand(0.35, 0.65));
    }
    clique(a, palco);
    el.classList.add('c-viva');
    // a peça abre sozinha; o agente já segue para a próxima coisa
    anima(el, { startAt: { opacity: 0, scale: 0.94 }, opacity: 1, scale: 1, duration: 0.42, ease: 'expo.out' }).then(() => {
      el.classList.add('c-pronta');
      el.classList.remove('c-viva');
      gsap.set(el, { clearProps: 'opacity,scale,transform' });
    });
  }

  // várias peças com um clique só, em cascata
  async function mostraGrupo(a, els) {
    const r = rectDoc(els[0]);
    await vai(a, r.x + r.w * 0.5, r.y + r.h * 0.5);
    clique(a, palco);
    els.forEach((el) => el.classList.add('c-viva'));
    anima(els, { startAt: { opacity: 0, scale: 0.9 }, opacity: 1, scale: 1, duration: 0.42, ease: 'expo.out', stagger: 0.09 }).then(() => {
      els.forEach((el) => { el.classList.add('c-pronta'); el.classList.remove('c-viva'); });
      gsap.set(els, { clearProps: 'opacity,scale,transform' });
    });
  }

  // vidro: a casca ganha fundo, borda e desfoque pela transição do CSS
  async function vidro(a, el) {
    const r = rectDoc(el);
    await vai(a, r.x + r.w * rand(0.55, 0.8), r.y + Math.min(r.h * 0.5, 30));
    clique(a, palco);
    el.classList.add('c-pronta');
  }

  // linha-guia rosa que pisca numa borda alinhada
  function guia(x, y, w, h) {
    const el = document.createElement('i');
    el.className = 'guia';
    Object.assign(el.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
    palco.append(el);
    gsap.fromTo(el, { opacity: 0 }, { opacity: 1, duration: 0.08 });
    gsap.to(el, { opacity: 0, duration: 0.35, delay: 0.6, onComplete: () => el.remove() });
  }

  // ---------- carregamento ----------
  const fontes = document.fonts
    ? Promise.all([
        document.fonts.load('600 100px "Urbanist Variable"'),
        document.fonts.load('500 16px "Geist Variable"'),
        document.fonts.load('500 12px "Geist Mono Variable"'),
      ]).catch(() => {})
    : Promise.resolve();
  const imagens = Promise.all($$('.hero img').map((i) => (i.decode ? i.decode().catch(() => {}) : null)));

  // ---------- tarefas ----------
  const H = () => rectDoc(hero);
  let cardFalta = 2; // o card fecha quando os dois agentes dele terminam
  const tarefas = [
    // caixas
    { id: 'cx-palco', quem: 'foto-01', alvo: hero, async faz(a) {
      await desenha(a, 'cx-palco', hero, 'section.palco', { pad: -10, dentro: 'pe' });
      log(a, `palco ${Math.round(innerWidth)}×${Math.round(hero.offsetHeight)} · cena 3:2`);
    } },
    { id: 'cx-nav', quem: 'nav-01', alvo: $('.nav'), async faz(a) {
      await desenha(a, 'cx-nav', $('.nav'), 'nav.topo', { pad: -8 });
      log(a, 'moldura da nav · grade de 12 colunas');
    } },
    { id: 'cx-letreiro', quem: 'layout-01', alvo: letreiro, async faz(a) {
      await desenha(a, 'cx-letreiro', letreiro, 'p.letreiro');
      log(a, 'caixa do letreiro · telhado a 47%');
    } },
    { id: 'cx-chamada', quem: 'texto-01', alvo: $('.hero__chamada'), async faz(a) {
      await desenha(a, 'cx-chamada', $('.hero__chamada'), 'div.chamada', { pad: 6 });
      log(a, 'chamada · 3 linhas, à direita');
    } },
    { id: 'cx-destaque', quem: 'texto-02', alvo: $('.hero__destaque'), async faz(a) {
      await desenha(a, 'cx-destaque', $('.hero__destaque'), 'article.destaque');
      log(a, 'card de destaque · canto esquerdo');
    } },
    { id: 'cx-abas', quem: 'vidro-01', depois: ['cx-nav'], alvo: $('.nav__abas'), async faz(a) {
      if (!$('.nav__abas').offsetWidth) return;
      await desenha(a, 'cx-abas', $('.nav__abas'), 'nav.abas');
      log(a, `abas da nav · 5 itens · ${Math.round($('.nav__abas').offsetWidth)}×${Math.round($('.nav__abas').offsetHeight)}`);
    } },
    { id: 'cx-tipos', quem: 'vidro-01', depois: ['cx-abas'], alvo: $('.hero__tipos'), async faz(a) {
      if (!$('.hero__tipos').offsetWidth) return;
      await desenha(a, 'cx-tipos', $('.hero__tipos'), 'ul.tipos');
    } },

    // foto crua, varrida da esquerda para a direita
    { id: 'foto', quem: 'foto-01', depois: ['cx-palco'], alvo: hero, async faz(a) {
      await imagens;
      const r = H();
      const y = r.y + r.h * 0.4;
      await vai(a, r.x + 4, y);
      clique(a, palco);
      log(a, 'colocou casa-crua.webp · 1536×1024');
      const l = linha('varre--v');
      const p = { k: 0 };
      ativos++;
      await anima(p, {
        k: 1,
        duration: 1,
        ease: 'power2.inOut',
        onUpdate() {
          hero.style.setProperty('--revela', p.k);
          const x = r.x + r.w * p.k;
          l.style.transform = `translate(${x - 1}px, ${r.y}px)`;
          l.style.height = `${r.h}px`;
          a.x = x + 2;
          a.y = y + Math.sin(p.k * Math.PI) * 30;
        },
      });
      ativos--;
      gsap.to(l, { opacity: 0, duration: 0.3, onComplete: () => l.remove() });
      caixas.get('cx-palco')?.feita();
    } },

    // letreiro digitado e o kerning
    { id: 'letreiro', quem: 'tipo-01', depois: ['foto', 'cx-letreiro'], alvo: letreiro, async faz(a) {
      log(a, 'letreiro · Urbanist 600 · branco');
      ativos++;
      await escreve(a, letreiro, { cps: 7, altura: 0.82 });
      ativos--;
      caixas.get('cx-letreiro')?.feita();
    } },
    { id: 'kerning', quem: 'tipo-01', depois: ['letreiro'], alvo: letreiro, async faz(a) {
      const r = rectDoc(letreiro);
      const cx = caixas.get('cx-letreiro');
      const l = linha('varre--h');
      const largura = innerWidth;
      await vai(a, r.x + r.w * 0.5, r.y + r.h * 0.15);
      clique(a, palco);
      ativos++;
      const p = { k: 0, tr: 0.02 };
      const anda = anima(p, {
        k: 1,
        duration: 0.8,
        ease: 'power1.inOut',
        onUpdate() {
          const y = r.y + r.h * (0.12 + 0.72 * p.k);
          l.style.transform = `translate(0px, ${y}px)`;
          l.style.width = `${largura}px`;
          a.x = r.x + r.w * (0.5 + 0.08 * Math.sin(p.k * 6));
          a.y = y + 14;
        },
      });
      await anima(p, {
        tr: -0.035,
        duration: 0.75,
        ease: 'power2.inOut',
        onUpdate() {
          hero.style.setProperty('--tracking', `${p.tr}em`);
          const nr = rectDoc(letreiro);
          if (cx) { cx.el.style.transform = `translate(${nr.x}px, ${nr.y}px)`; cx.tamanho(nr.w, nr.h); }
        },
      });
      await anda;
      ativos--;
      log(a, 'kerning −0,035em · largura 85%');
      gsap.to(l, { opacity: 0, duration: 0.3, onComplete: () => l.remove() });
    } },

    // recorte: a casa e as árvores passam para a frente das letras
    { id: 'recorte', quem: 'foto-01', depois: ['letreiro'], alvo: letreiro, async faz(a) {
      const rl = rectDoc(letreiro);
      const fr = $('.hero__frente');
      const cena = fr.querySelector('.hero__cena').getBoundingClientRect();
      const telhado = cena.top + scrollY + cena.height * 0.474;
      await vai(a, rl.x + rl.w * 0.62, telhado + 18);
      clique(a, palco);
      const l = linha('varre--h');
      l.style.width = `${innerWidth}px`;
      l.style.transform = `translate(0px, ${telhado}px)`;
      gsap.fromTo(l, { opacity: 0 }, { opacity: 1, duration: 0.12, yoyo: true, repeat: 1, repeatDelay: 0.25, onComplete: () => l.remove() });
      anima(fr, { opacity: 1, duration: 0.45, ease: 'power1.out' });
      log(a, 'recorte da casa · telhado na frente das letras');
    } },

    // nav
    { id: 'marca', quem: 'nav-01', depois: ['cx-nav', 'foto'], alvo: $('.nav__marca'), async faz(a) {
      await mostra(a, $('.nav__simbolo'));
      await escreve(a, $('.nav__nome'));
      log(a, 'marca · símbolo em SVG');
    } },
    { id: 'abas', quem: 'vidro-01', depois: ['cx-abas', 'destaque'], alvo: $('.nav__abas'), async faz(a) {
      if (!$('.nav__abas').offsetWidth) return;
      await vidro(a, $('.nav__abas'));
      caixas.get('cx-abas')?.feita();
      log(a, 'vidro · desfoque 18 · borda 24%');
    } },
    { id: 'links', quem: 'nav-01', depois: ['abas', 'cta'], alvo: $('.nav__abas'), async faz(a) {
      if (!$('.nav__abas').offsetWidth) return;
      ativos++;
      for (const s of $$('.nav__aba span').slice(0, 3)) await escreve(a, s, { cps: 80 });
      ativos--;
      log(a, 'links · linha de base alinhada');
    } },
    // os dois últimos links ficam com o vidro, que já terminou as pílulas: a nav fecha junto
    { id: 'links-2', quem: 'vidro-01', depois: ['abas', 'tipos'], alvo: $('.nav__abas'), async faz(a) {
      if (!$('.nav__abas').offsetWidth) return;
      ativos++;
      for (const s of $$('.nav__aba span').slice(3)) await escreve(a, s, { cps: 80 });
      ativos--;
    } },
    { id: 'cta', quem: 'nav-01', depois: ['marca'], alvo: $('.nav__cta'), async faz(a) {
      await mostra(a, $('.nav__cta'));
      log(a, 'botão "Agendar visita" · branco');
    } },

    // pílulas e card
    { id: 'destaque', quem: 'vidro-01', depois: ['foto', 'cx-destaque'], alvo: $('.hero__destaque'), async faz(a) {
      await vidro(a, $('.hero__destaque'));
      log(a, 'card · vidro escuro 52% · raio 18');
    } },
    { id: 'tipos', quem: 'vidro-01', depois: ['abas', 'cx-tipos'], alvo: $('.hero__tipos'), async faz(a) {
      if (!$('.hero__tipos').offsetWidth) return;
      await mostraGrupo(a, $$('.hero__tipo'));
      caixas.get('cx-tipos')?.feita();
      log(a, 'pílulas · 3 tipos · 46 imóveis');
    } },
    { id: 'destaque-texto', quem: 'texto-02', depois: ['destaque'], alvo: $('.hero__destaque'), async faz(a) {
      ativos++;
      await escreve(a, $('.hero__selo'));
      await escreve(a, $('.hero__casa'), { cps: 40 });
      log(a, 'título "Casa Ardósia"');
      await escreve(a, $('.hero__onde'));
      await mostraGrupo(a, $$('.hero__specs li'));
      log(a, 'specs · 5 suítes · 6 vagas · 812 m²');
      ativos--;
      if (--cardFalta === 0) caixas.get('cx-destaque')?.feita();
    } },
    // o preço e o link do card ficam com quem terminou a chamada: dois agentes no mesmo card
    { id: 'destaque-preco', quem: 'texto-01', depois: ['chamada', 'destaque'], alvo: $('.hero__destaque'), async faz(a) {
      ativos++;
      await escreve(a, $('.hero__preco'), { cps: 48 });
      log(a, 'preço R$ 14.800.000');
      await escreve(a, $('.hero__ver'));
      ativos--;
      if (--cardFalta === 0) caixas.get('cx-destaque')?.feita();
    } },

    // chamada
    { id: 'chamada', quem: 'texto-01', depois: ['foto', 'cx-chamada'], alvo: $('.hero__chamada'), async faz(a) {
      ativos++;
      await escreve(a, $('.hero__texto'), { cps: 100 });
      log(a, 'h1 · 3 linhas · sombra 18');
      await escreve(a, $('.hero__link'));
      log(a, 'link "Ver residências"');
      ativos--;
      caixas.get('cx-chamada')?.feita();
    } },

    // layout confere margens e alinhamento na grade
    { id: 'alinha', quem: 'layout-01', depois: ['cx-destaque', 'cx-chamada', 'kerning'], alvo: $('.hero__destaque'), async faz(a) {
      const r = H();
      const d = rectDoc($('.hero__destaque'));
      const c = rectDoc($('.hero__chamada'));
      await vai(a, d.x, d.y - 20);
      guia(d.x, r.y + 60, 1, r.h - 70);
      await vai(a, c.x + c.w, c.y - 20);
      guia(c.x + c.w, r.y + 60, 1, r.h - 70);
      log(a, `margens ${Math.round(d.x - r.x)} px · grade de 12 ok`);
    } },

    // passe de cor: a foto crua vira a hora azul, com as janelas acesas
    { id: 'cor', quem: 'cor-01', depois: ['foto', 'recorte', 'kerning', 'cta', 'links', 'links-2', 'destaque-texto', 'destaque-preco', 'chamada', 'tipos'], alvo: hero, async faz(a) {
      const r = H();
      const y = r.y + r.h * 0.55;
      await vai(a, r.x + 6, y);
      clique(a, palco);
      caixas.get('cx-nav')?.feita();
      log(a, 'cor · hora azul · céu cobalto');
      equipeSai();
      const l = linha('varre--v', true);
      const p = { k: 0 };
      ativos += 2;
      await anima(p, {
        k: 1,
        duration: 1.6,
        ease: 'power2.inOut',
        onUpdate() {
          hero.style.setProperty('--grade', p.k);
          const x = r.x + r.w * p.k;
          l.style.transform = `translate(${x - 1}px, ${r.y}px)`;
          l.style.height = `${r.h}px`;
          if (a.fora) return;
          a.x = x + 2;
          a.y = y - Math.sin(p.k * Math.PI) * 40;
          // perto do fim solta a linha e segue no embalo para fora da tela, à frente dela
          if (p.k > 0.72) {
            log(a, 'janelas 2700 K · reflexo na piscina');
            log(a, `pronta · ${ags.length} agentes em ${agora().toFixed(1).replace('.', ',')} s`);
            saidas.push(sai(a));
          }
        },
      });
      ativos -= 2;
      gsap.to(l, { opacity: 0, duration: 0.35, onComplete: () => l.remove() });
    } },
  ];
  const porId = new Map(tarefas.map((t) => [t.id, t]));
  const feitas = new Set();

  // sinal de "terminou uma tarefa": acorda quem está esperando
  let sinal;
  let novidade = new Promise((r) => (sinal = r));
  const avisa = () => { const s = sinal; novidade = new Promise((r) => (sinal = r)); s(); };

  // sem tarefa liberada: confere a peça da próxima (ou a que acabou de fazer), contornando a caixa dela sem parar,
  // como quem mede. Sai do contorno no embalo assim que alguma coisa muda (outra tarefa terminou).
  function ronda(a, alvo) {
    const r0 = rectDoc(alvo ?? hero);
    // a volta fica dentro da tela e longe das bordas
    const x0 = Math.max(r0.x + 8, scrollX + 30), x1 = Math.min(r0.x + r0.w - 8, scrollX + innerWidth - 110);
    const y0 = Math.max(r0.y + 8, scrollY + 30), y1 = Math.min(r0.y + r0.h - 8, scrollY + innerHeight - 40);
    const w = Math.max(x1 - x0, 40), h = Math.max(y1 - y0, 30);
    const per = 2 * (w + h);
    const ponto = (s) => {
      s = ((s % per) + per) % per;
      if (s < w) return [x0 + s, y0];
      if ((s -= w) < h) return [x0 + w, y0 + s];
      if ((s -= h) < w) return [x0 + w - s, y0 + h];
      return [x0, y0 + h - (s - w)];
    };
    // começa no ponto do contorno mais perto de onde o agente está
    let s = 0, melhor = Infinity;
    for (let k = 0; k < per; k += 12) {
      const [px, py] = ponto(k);
      const d = Math.hypot(px - a.x, py - a.y);
      if (d < melhor) { melhor = d; s = k; }
    }
    const sentido = Math.random() < 0.5 ? 1 : -1;
    para(a);
    let vx = a.vx, vy = a.vy;
    const vel = rand(240, 320);
    return new Promise((res) => {
      const passo = (t, dtMs) => {
        if (encerrado || a.fora || a.ocupado) { gsap.ticker.remove(passo); res(); return; }
        const dt = (Math.min(dtMs, 50) / 1000) * RITMO;
        s += sentido * vel * 0.9 * dt;
        // persegue um ponto um pouco à frente no contorno: faz a curva nas quinas em vez de parar nelas
        const [tx, ty] = ponto(s + sentido * 40);
        let dx = tx - a.x, dy = ty - a.y;
        const d = Math.hypot(dx, dy) || 1;
        const quer = Math.min(vel * 1.4, vel * (0.6 + d / 80));
        const ax = (dx / d) * quer - vx, ay = (dy / d) * quer - vy;
        const k = Math.min(1, dt * 6);
        vx += ax * k;
        vy += ay * k;
        a.x += vx * dt;
        a.y += vy * dt;
      };
      gsap.ticker.add(passo);
      novidade.then(() => { gsap.ticker.remove(passo); res(); });
    });
  }

  async function vida(a) {
    while (!encerrado && !a.fora) {
      const minhas = tarefas.filter((t) => t.quem === a.nome && !t.pegou);
      if (!minhas.length) break;
      const t = minhas.find((x) => (x.depois ?? []).every((d) => feitas.has(d) || !porId.has(d)));
      if (!t) { await ronda(a, minhas[0].alvo); continue; }
      t.pegou = true;
      a.ocupado = true;
      try { await t.faz(a); } catch (e) { console.error(e); }
      a.ocupado = false;
      a.ultimo = t.alvo;
      modo(a, 'seta');
      feitas.add(t.id);
      terminou[a.nome] = agora();
      (window.__tempos ??= {})[t.id] = +agora().toFixed(2);
      avisa();
      if (feitas.size === tarefas.length) fim();
    }
    // sem mais nada: confere a peça que fez até a hora de sair
    while (!encerrado && !a.fora) await ronda(a, a.ultimo);
  }

  // ---------- fim: as sobras do editor somem e fica o site ----------
  // ---------- fim: a equipe sai como num editor multiplayer ----------
  // Quando cor-01 começa o passe de cor, os outros vão embora, um a um, na ordem em que terminaram (quem ainda tem
  // tarefa termina antes): cada um leva as caixas que desenhou, apaga a bolinha no painel, registra a saída e sai de
  // cena no embalo em que estava, sem parar (foge). cor-01 sai por último, no embalo da varredura. O contador do
  // painel desce a zero e só então o painel fecha.
  const terminou = {};
  const saidas = [];
  const vivos = painel.querySelector('.atividade__vivos');
  const bolinhas = [...painel.querySelectorAll('.atividade__cores i')];
  const dono = (id) => porId.get(id)?.quem;
  const livre = (a) => tarefas.every((t) => t.quem !== a.nome || feitas.has(t.id));
  let noAr = ags.length;
  let fechaPainel;

  function sai(a) {
    if (a.fora) return Promise.resolve();
    a.fora = true;
    modo(a, 'seta');
    for (const [id, cx] of caixas) if (dono(id) === a.nome) cx.some(0.35);
    bolinhas[EQUIPE.findIndex((e) => e.nome === a.nome)]?.classList.add('fora');
    const n = tarefas.filter((t) => t.quem === a.nome).length;
    log(a, `saiu · ${n} ${n === 1 ? 'tarefa' : 'tarefas'}`, true);
    noAr--;
    vivos.lastChild.textContent = `${noAr} agentes no ar`;
    // o último a sair fecha o painel: ele some enquanto o cursor ainda está deixando a tela
    if (noAr === 0) {
      vivos.classList.add('zero');
      fechaPainel = anima(painel, { opacity: 0, y: 12, duration: 0.3, delay: 0.15, ease: 'power2.in' });
    }
    return foge(a);
  }

  function equipeSai() {
    const fila = ags.filter((a) => a.nome !== 'cor-01').sort((p, q) => (terminou[p.nome] ?? 99) - (terminou[q.nome] ?? 99));
    fila.forEach((a, i) => {
      saidas.push((async () => {
        await espera(0.15 + i * 0.12);
        while (!livre(a)) await novidade;
        await sai(a);
      })());
    });
  }

  async function fim() {
    encerrado = true;
    await Promise.all(saidas);
    for (const cx of caixas.values()) cx.some(0.3);
    await fechaPainel;
    contaOps.kill();
    gsap.globalTimeline.timeScale(1);
    raiz.classList.remove('monta');
    raiz.classList.add('montada');
    hero.style.removeProperty('--revela');
    hero.style.removeProperty('--grade');
    hero.style.removeProperty('--tracking');
    gsap.set('.hero__frente', { clearProps: 'opacity' });
    palco.remove();
  }

  // resize no meio: fecha a montagem na hora (nada de caixa medida para outra tela)
  let largura = innerWidth;
  addEventListener('resize', () => {
    if (encerrado || innerWidth === largura) return;
    encerrado = true;
    gsap.globalTimeline.timeScale(1);
    gsap.globalTimeline.getChildren(true, true, true).forEach((t) => t.kill());
    $$('.ch').forEach((e) => e.classList.add('on'));
    raiz.classList.remove('monta');
    raiz.classList.add('montada');
    $$('[data-camada]').forEach((e) => e.classList.add('c-pronta'));
    hero.style.removeProperty('--revela');
    hero.style.removeProperty('--grade');
    hero.style.removeProperty('--tracking');
    gsap.set('.hero__frente', { clearProps: 'opacity' });
    palco.remove();
  });

  // ---------- início: os agentes aparecem espalhados pelo palco ----------
  const r = H();
  ags.forEach((a) => {
    a.x = r.x + r.w * rand(0.12, 0.88);
    a.y = r.y + r.h * rand(0.15, 0.85);
    gsap.from(a.el, { opacity: 0, duration: 0.4, delay: rand(0, 0.3) });
  });
  log(ag['layout-01'], `${ags.length} agentes no ar · 7 funções`);
  fontes.then(() => { poePainel(); ags.forEach((a) => vida(a)); });
}
