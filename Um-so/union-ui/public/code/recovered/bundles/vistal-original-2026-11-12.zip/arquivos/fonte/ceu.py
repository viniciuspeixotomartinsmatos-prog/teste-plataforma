# Recorte: tudo que não é céu (céu ligado ao topo + furos de céu entre as folhas), alfa macio nas bordas.
# uso (da pasta fonte/): python3 ceu.py casa.png mascara.png
import numpy as np, sys
from PIL import Image
from scipy import ndimage as nd
src, out = sys.argv[1], sys.argv[2]
im = np.asarray(Image.open(src).convert('RGB')).astype(np.float32)
R,G,B = im[...,0], im[...,1], im[...,2]
score = (B - R) - np.maximum(0, G - B*0.85)*2
soft = np.clip((score - 55) / 45, 0, 1)
dura = soft > 0.5
lab, n = nd.label(dura)
topo = set(np.unique(lab[0:3, :])) - {0}
cy = nd.center_of_mass(dura, lab, range(1, n+1))
area = nd.sum(dura, lab, range(1, n+1))
furos = {i+1 for i,(c,a) in enumerate(zip(cy, area)) if c[0] < 480 and a > 30}
ceu = np.isin(lab, list(topo | furos))
# região do céu um pouco dilatada para pegar a franja suave das folhas, e o alfa macio dentro dela
regiao = nd.binary_dilation(ceu, iterations=3)
alfa_ceu = np.where(regiao, soft, 0)
alfa_ceu = np.maximum(alfa_ceu, ceu.astype(np.float32))
alfa_ceu = nd.gaussian_filter(alfa_ceu, 0.7)
frente = 1 - alfa_ceu
Image.fromarray((frente*255).astype(np.uint8)).save(out)
print('componentes do topo', len(topo), 'ceu %', ceu.mean()*100)
