# Guia do projeto — Vistal

(Salve como `CLAUDE.md` na raiz do projeto se você usa o Claude Code, ou como `AGENTS.md` se usa o Codex, o Cursor ou outro agente. O conteúdo é o mesmo.)

Landing page da Vistal, uma imobiliária fictícia de residências de alto padrão ("casas de arquitetura autoral, visitadas com hora marcada e com a documentação conferida antes da primeira conversa"). Vite sem framework, GSAP (só na montagem do hero), fontes Urbanist, Geist e Geist Mono. **O site se monta na frente de quem chega, como uma equipe num editor ao vivo, e termina numa capa de revista: a casa na hora azul com o nome atrás do telhado.** O código já vem pronto em `arquivos/src/`, a página no `arquivos/index.html` e as fotos em `arquivos/public/`: o trabalho é montar, conferir e, depois, personalizar. A régua é site de premiação: se algo parece "ok", ainda não está pronto.

## Arquitetura
- **Uma seção por arquivo.** O `index.html` só tem o `<head>` e a ordem das seções (`<!-- @secao hero -->` etc.); o plugin `secoes` do `vite.config.js` troca cada marca pelo `src/sections/<nome>.html` no dev e no build. Os textos e os dados (imóveis, preços, cômodos, contatos) estão nesses HTML. Cada seção tem o seu CSS ao lado (`src/sections/<nome>.css`).
- **O CSS é uma folha só**, `src/styles/site.css` (por `@import`, nesta ordem: as fontes, `tokens.css`, `base.css`, `nav.css`, `hero.css`, `secoes.css`, as outras seções e, por último, `enxame.css`), ligada por `<link>` no `<head>`. Antes dela, inline: o script que escolhe o modo (`monta` ou `pronto`) e o fundo do palco. Nunca importe CSS pelo JS: no dev do Vite ele chega depois dos módulos e a página pinta crua por um instante a cada recarregamento.
- **Módulos**:

  | arquivo | o que faz |
  |---|---|
  | `src/main.js` | liga a montagem e, depois, a página: hover desligado ao rolar, entradas por marco, nav, cômodos e os atalhos |
  | `src/motion/enxame.js` | a montagem: a lista de tarefas com dono e dependências, o painel da atividade, a varredura, o letreiro, o recorte, os vidros, o passe de cor e a saída da equipe. `RITMO` (1,2) acelera tudo |
  | `src/motion/agentes.js` | os oito agentes (`EQUIPE`: nome e cor), o desenho dos cursores (seta, mira, texto), o andar em curva, o clique e a saída (`foge`) |
  | `src/motion/caixas.js`, `digita.js` | a caixa pontilhada arrastada com a medida ao vivo; a digitação letra a letra com o cursor de texto |
  | `src/pagina/pagina.js` | `html.rolando`, `[data-revela]`, a nav presa com o véu e a aba da seção atual, os atalhos (pílula de tipo → aba; botão de imóvel → visita) |
  | `src/pagina/abas.js` | abas acessíveis (setas, Home, End) usadas pelas residências e pelos cômodos |
  | `src/pagina/residencias.js`, `ardosia.js` | troca dos grupos de imóveis; troca dos cômodos por dissolve e o passeio automático a cada 4,5 s |
  | `src/pagina/visita.js` | o agendamento: seis próximos dias sem domingo, horários (`HORAS`) com ocupados fixos, máscara do WhatsApp, confirmação na tela. Não envia nada |
- **Parâmetros de URL**: `?pronto` abre o hero já montado (útil para trabalhar nas seções de baixo sem esperar a montagem).

## Design system
- Cores (só em `tokens.css`): palco e página `#0b1018`; texto branco e dois cinzas; vidro claro `rgba(255,255,255,.14)` com borda `.24`; vidro escuro `rgba(12,15,22,.52)`; escuro das abas e setas `#0d1016`; o ponto "em destaque" `#ffb35c`. As cores dos agentes ficam em `EQUIPE` e as das ferramentas (varredura `#5ee0e6`, guia `#ff4fa3`) em `tokens.css`.
- Tipos: Urbanist 600 (letreiro, marca, nomes das casas, títulos), Geist (interface e corpo), Geist Mono em caixa alta (etiquetas, painel, números das pílulas).
- Escala: no hero, `--u` é 1 px numa tela de 1440 × 900 (encolhe pelo lado que apertar); nas seções, título 64 (40 no celular), corpo 18 (16 no celular). Cada seção cabe numa tela de 1440 × 900.
- Fotos com cantos de 14 px, vão estreito entre elas; todas na mesma luz (hora azul, lâmpadas quentes acesas).

## Regras de movimento
- **A montagem é por tempo, nunca pela rolagem**, e dura ~8 s. Os agentes nunca param: sem tarefa liberada, contornam a caixa da próxima peça; saem no embalo em que estão. Não ponha pausa nem espere clique.
- **O letreiro depende do telhado.** A cena tem a proporção da foto (3:2) e é posicionada para o topo da laje cair a ~50% da altura (`--telhado` em `hero.css`, 47,4% da foto). O tamanho do letreiro sai dessa medida. Trocou a foto, meça onde fica o topo do telhado nela e ajuste esse número.
- **O recorte** é a mesma foto por cima do letreiro com `mask` pela `casa-recorte.webp` (alfa: opaco onde não é céu). Foto crua e foto em cor ficam empilhadas nas duas camadas; o passe de cor revela a de cor.
- **Depois do hero, a página rola nativa**: nada de rolagem suave por script nem de seção presa. As entradas são por marco, com tempo fixo (passar rápido não deixa meia palavra).
- Toda troca que existe no clique também acontece sozinha onde faz sentido (os cômodos andam sozinhos até alguém tocar). Hover é acabamento.
- **Primeira pintura**: o `<head>` traz o fundo do palco e `html:not(.assentou) *` sem transição; o `main.js` marca `assentou` depois de dois quadros. Sem isso, as peças com transição nascem visíveis e somem no primeiro quadro.
- `prefers-reduced-motion` e `?pronto`: hero montado, sem agentes.

## Celular: regras que não se quebram
- **Nunca rolar para o lado**, em nenhum momento da montagem (os agentes saem da tela por fora dela, o palco recorta). Se algo vazar, conserte a origem; `overflow-x: clip` no `html` e no `body` é só a rede de segurança (`clip`, não `hidden`).
- **Alturas em `svh`, nunca `100vh` nem `dvh`** (a barra do Safari some e volta rolando e mudaria o tamanho do hero no meio da rolagem).
- Hero em coluna: a chamada no céu, o letreiro de borda a borda, o card no pé; a nav fica só com a marca e "Agendar visita". iPhone baixo (~660 de altura): chamada menor. Conferir em 390 × 844, 393 × 659 e 375 × 553.
- Residências em uma coluna; a ficha da Ardósia logo abaixo da foto; o agendamento ocupa a largura toda; a nav presa ganha véu firme para o texto não aparecer por trás.
- Hover só dentro de `@media (hover: hover) and (pointer: fine)`; alvos de toque de 40 px no mínimo (links pequenos crescem por `::before`); campos com fonte de 16 px (o iPhone dá zoom abaixo disso).

## Como checar
- `npm run build` sem aviso de arquivo faltando.
- `npx vite preview`: console limpo; a montagem roda inteira (caixas, varredura, letreiro digitado, kerning, recorte, vidros, textos, passe de cor, equipe saindo e o painel fechando); recarregar nunca mostra a página crua; `?pronto` abre montado.
- Rolando de cima a baixo devagar e depressa: as entradas aparecem e nada fica pela metade; a nav acende a aba da seção certa.
- Clique numa pílula de tipo do hero (vai para a aba certa), troque as abas das residências, toque nos cômodos, clique em "Agendar visita" de uma foto (a visita abre com aquele imóvel) e confirme uma visita.
- Celular (390 px) e o `dist/` numa subpasta, com um servidor estático de verdade (o prompt diz como): sem 404.

## Personalizar

Vale para qualquer mudança, agora ou depois.

### As três perguntas
1. É a demo, a imobiliária (ou o empreendimento) da pessoa, ou peças soltas?
2. Que material ela já tem (fotos dos imóveis por fora e por dentro, logo, dados dos imóveis) e o que falta?
3. O que ela quer manter da demo (a montagem pelos agentes, as residências em abas, a casa por dentro, o agendamento)?

### O que muda e onde

| o quê | onde | precisa de material novo? |
|---|---|---|
| Nome da marca | `src/sections/hero.html` (`.hero__letreiro`), `nav.html`, `rodape.html` (nome de borda a borda), `<title>` e `description` no `index.html`; o texto que `tipo-01` digita e as linhas do painel em `enxame.js` | não. Nome curto (5 a 7 letras) funciona melhor: o letreiro ocupa ~75% da largura entre as árvores; com nome mais longo, reduza o corpo em `hero.css` |
| Símbolo | o `<svg>` da marca em `nav.html` e `rodape.html`, `public/favicon.svg` | se for o logo da pessoa: o SVG dela |
| Imóvel em destaque (card do hero e a ficha da Ardósia) | `hero.html` (`.hero__destaque`) e `ardosia.html` (`.ardosia__ficha`) | não |
| Imóveis à venda | os `.imovel` em `residencias.html` (foto, nome, onde, suítes, área, preço, `data-imovel` do botão) e as contagens das pílulas no `hero.html` e das abas | fotos dos imóveis |
| Lista do agendamento | o `<select>` em `visita.html` (os nomes têm de bater com o `data-imovel` dos botões) e `HORAS` em `src/pagina/visita.js` | não |
| Cômodos | as quatro `<img>` e as quatro abas em `ardosia.html` (`data-comodo`, `data-andar`, `data-nome`) | fotos dos cômodos |
| Como funciona, rodapé, contatos, CRECI | `como.html`, `rodape.html` | não |
| Envio da visita | `src/pagina/visita.js` (hoje só mostra a confirmação) | ligar ao WhatsApp ou ao e-mail da pessoa |
| Agentes (nomes, cores, ritmo) | `EQUIPE` em `agentes.js`, `RITMO` em `enxame.js` | não |
| Cores e fontes | `src/styles/tokens.css` e o `@import` das fontes em `site.css` | não |

### Material da pessoa

Para cada peça visual, do mais simples ao mais trabalhoso:

- **Foto do hero** (`public/img/casa.webp`, `casa-crua.webp`, `casa-recorte.webp`): (1) manter a da demo; (2) uma foto da pessoa de uma casa **de frente, em paisagem 3:2, com o céu limpo ocupando os 40% de cima** (sem fio, sem galho cruzando o meio) e de preferência na hora azul com as luzes acesas: salve como `arquivos/fonte/casa.png` e rode `sh exporta.sh` de dentro de `arquivos/fonte/` (precisa de `python3` com `numpy`, `pillow` e `scipy`, e do `cwebp`); o script recorta o céu, faz a versão crua e exporta as três. Depois ajuste `--telhado` em `hero.css` para onde cai o topo do telhado; (3) gerar com o prompt de `arquivos/receitas/prompts/casa.txt`. Foto com céu nublado ou sem céu não serve para o letreiro atrás do telhado: nesse caso, o letreiro vai para a frente da foto e o recorte sai (diga isso à pessoa).
- **Residências** (`public/img/res-*.webp`): paisagem 3:2, 1280 px de largura (o corte 5:4 e 5:2 é feito pelo CSS, com o assunto no meio); **cômodos** (`int-*.webp`): 3:2, 1536 px, com o lado esquerdo calmo para a legenda; **porta** (`sobre-porta.webp`): retrato 2:3, 800 px. Fotos reais no mesmo formato servem; todas na mesma luz deixam o site coerente. O `exporta.sh` converte de PNG para WebP no tamanho certo.
- O cliente pode trocar as fotos, mas a montagem do hero depende da foto do topo: sem céu limpo, o efeito do letreiro atrás do telhado não acontece.

### Regras ao trocar
- Nada de dado inventado como se fosse da pessoa: preço, área, CRECI, telefone, e-mail e contagem de imóveis que ela não mandou ficam `[preencher]` (nunca no título nem no letreiro).
- Mantenha a estrutura que dá o efeito: a foto com céu em cima, o letreiro entre a foto e o recorte, as tarefas da montagem apontando para peças que existem (se tirar uma peça do hero, tire a tarefa dela em `enxame.js`).
- O agendamento é uma demonstração: não envia nada. Para valer, ligue o "Confirmar visita" ao WhatsApp (link `wa.me` com a mensagem montada) ou a um formulário de e-mail, e diga isso à pessoa.
- Nada de cidade real na demo; no site da pessoa, use o endereço dela.
- Termine com a lista do que ainda é da demo: fotos, imóveis, preços, CRECI, contatos.
