# Vistal: comece aqui

1. Abra esta pasta no Claude Code, no Codex ou na sua IA de código.
2. Cole o prompt (ele está no PROMPT.md) ou escreva para a IA: "siga o PROMPT.md".
3. Responda às perguntas dela e deixe ela trabalhar até o fim. Se parar no meio, escreva "continue".

O CLAUDE.md e o AGENTS.md são o mesmo guia: a IA lê sozinha, não precisa colar.

## Passo a passo completo

1. Abra a pasta no Claude Code ou no Codex, cole o prompt inteiro e responda às perguntas: montar a demo, fazer o site da sua imobiliária ou usar só algumas peças.
2. Deixe a IA trabalhar até o fim: ela instala tudo sozinha e monta a demo primeiro. Se ela parar no meio, escreva "continue".
3. Peça "abre o site para eu ver" e abra o link que ela mostrar (algo como localhost:5173).
4. Assista à abertura: oito cursores com nome desenham as peças, digitam o nome atrás da casa e, no fim, a foto ganha cor e as janelas acendem.
5. Role até a casa em destaque e veja os cômodos trocarem sozinhos; clique em "Agendar visita" numa foto e marque uma visita de teste até a confirmação.
6. Abra o mesmo link no celular (ou peça à IA um print no tamanho de celular) e confira que nada fica cortado nem escorrega para o lado.
7. Peça para trocar nome, imóveis, preços, contatos e CRECI pelos seus; a IA segue a seção "Personalizar" do guia e diz o que ainda é da demo.
8. As fotos são da demo: mande as suas no formato que o guia pede (a do topo precisa de céu limpo em cima) ou gere com os prompts de arquivos/receitas/ (o LEIA.md explica).
9. Para publicar, peça "gera a versão final" e suba a pasta dist/ na sua hospedagem (Vercel, Netlify, Hostinger ou outra).
