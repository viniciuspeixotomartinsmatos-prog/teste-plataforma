// variacoes — many versions of one thing: one big word re-forms on every eighth note through a pixel-block scramble,
// a caption underneath; the last word collapses into the text caret, where the logo is born.
// Config: { "tipo": "variacoes", "palavras": ["Hello", "Olá", "Hola", "Bonjour"], "legenda": "100+ languages." }
//   2 to 8 words (one per eighth note, 4 beats), each up to ~12 letters.
import { el, prog, lerp, E, clamp, rng, hash, rgb, PAL, acc, FONT } from '../core.js';
import { makeLine, exitColor } from '../type.js';
import { S, cue } from '../timeline.js';
import { caret0 } from './fecho.js';

const SW = 0.13;           // scramble length
const BOX = { x: 0, y: 404, w: 1024, h: 200 }; // CSS px region holding the word
const BS = 6;              // block size (CSS px)
let V, WORDS, AT, canv = [], blocks = [], caption, CARET0;

export function init(C, cfg) {
  V = S.P.variacoes;
  WORDS = (cfg.palavras || []).slice(0, 8);
  if (WORDS.length < 2) throw new Error('variacoes: de 2 a 8 palavras');
  AT = WORDS.map((_, i) => V.start + i * V.eighth);
  CARET0 = caret0();
  const ink = rgb(PAL.ink);
  for (const w of WORDS) {
    const c = document.createElement('canvas');
    c.width = BOX.w * 2; c.height = BOX.h * 2;
    const x = c.getContext('2d');
    x.fillStyle = ink;
    let size = 118 * 2;
    x.font = `640 ${size}px ${FONT.display}`;
    const mw = x.measureText(w).width;
    if (mw > 940 * 2) { size *= (940 * 2) / mw; x.font = `640 ${size}px ${FONT.display}`; }
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(w, BOX.w, BOX.h + 6);
    canv.push({ c, data: x.getImageData(0, 0, c.width, c.height).data });
  }
  // blocks that carry ink in any word
  const R = rng(11);
  const cols = Math.ceil(BOX.w / BS), rows = Math.ceil(BOX.h / BS);
  for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
    const inkB = canv.map(({ data }) => {
      let s = 0;
      for (let yy = 0; yy < BS * 2; yy += 3) for (let xx = 0; xx < BS * 2; xx += 3) {
        const px = (i * BS * 2 + xx), py = (j * BS * 2 + yy);
        if (px < BOX.w * 2 && py < BOX.h * 2) s += data[(py * BOX.w * 2 + px) * 4 + 3];
      }
      return s > 0;
    });
    if (inkB.some(Boolean)) blocks.push({ i, j, ink: inkB, r: R(), n: R() });
  }
  caption = makeLine(C.type, String(cfg.legenda ?? '').split(/\s+/).filter(Boolean).map((w) => ({ text: w })), { y: 640, size: 40, weight: 400 });
  AT.forEach((t, i) => cue(t, `variacoes:palavra:${i}`, i === 0 ? 'appear' : 'scramble', WORDS[i]));
  if (AT[1]) cue(AT[1], 'variacoes:legenda', 'word', 'caption');
  cue(V.collapse, 'variacoes:recolhe', 'collapse', 'the word collapses into the caret');
}

function wordIndex(t) { let k = -1; for (let i = 0; i < AT.length; i++) if (t >= AT[i]) k = i; return k; }

export function render(t, C) {
  const on = t >= V.a && t < V.b;
  caption.show(on && t >= (AT[1] ?? AT[0]));
  if (!on) return false;
  caption.color(exitColor(t, V.collapse - 0.12, 0.4));
  caption.root.style.opacity = '0.72';
  const fx = C.fx;
  const k = wordIndex(t);
  if (k < 0) return true;
  const p = k > 0 ? prog(t, AT[k], AT[k] + SW) : 1;
  const A = canv[Math.max(0, k - 1)].c, B = canv[k].c;
  const col = prog(t, V.collapse, V.b);
  if (p >= 1 && col <= 0) {
    fx.drawImage(B, 0, 0, B.width, B.height, BOX.x, BOX.y, BOX.w, BOX.h);
    return true;
  }
  // block pass (scramble or collapse)
  const cx = CARET0.cx, cTop = CARET0.cy - CARET0.h / 2, cH = CARET0.h;
  const a0 = acc(0);
  for (const b of blocks) {
    const sx = b.i * BS, sy = b.j * BS;
    let src = b.r < p ? B : A;
    const inkB = b.ink[k], inkA = b.ink[Math.max(0, k - 1)];
    const inkHere = b.r < p ? inkB : inkA;
    const edge = Math.abs(b.r - p) < 0.16 && p < 1;
    let dx = BOX.x + sx, dy = BOX.y + sy;
    if (col > 0) {
      if (!inkB) continue;
      // fly to the caret: x to the bar, y squeezed into the bar's height
      const e = E.inOutCubic(clamp((col - b.n * 0.35) / 0.65));
      const ty = cTop + ((b.j * BS) / BOX.h) * cH;
      dx = lerp(dx, cx - BS / 2 + (b.r - 0.5) * 8 * (1 - e), e);
      dy = lerp(dy, ty, e);
      src = B;
    } else if (!inkHere && !edge) continue;
    if (edge && (inkA || inkB) && col <= 0) {
      const f = hash(b.i * 13.1 + b.j * 7.3 + Math.floor(t * 50));
      fx.fillStyle = f > 0.5
        ? rgb([a0[0], lerp(a0[1], 255, 0.12 + f * 0.45), lerp(a0[2], 255, 0.08 + f * 0.35)], 0.55 + 0.45 * f)
        : rgb(PAL.ink, 0.35 + 0.6 * f);
      fx.fillRect(dx, dy, BS, BS);
      continue;
    }
    fx.drawImage(src, sx * 2, sy * 2, BS * 2, BS * 2, dx, dy, BS, BS);
  }
  return true;
}
