// voz-elevenlabs.mjs — gera as falas do filme pela API da ElevenLabs (caminho sem MCP).
//   ELEVENLABS_API_KEY=... node tools/voz-elevenlabs.mjs <filme> [--so gancho,fecho] [--refaz]
// A chave também pode ficar num arquivo .env ou .env.local na raiz do projeto (ELEVENLABS_API_KEY=... ou XI_API_KEY=...). Uso comercial do áudio
// exige plano pago da ElevenLabs. Grava audio/voz/<filme>/<tipo>.mp3 para cada cena com "fala" no config e roda
// tools/voz.mjs no fim (corta o silêncio, mede as durações e avisa se alguma não cabe na cena).
// Voz e ajustes: "elevenlabs" no config do filme (todos opcionais):
//   { "voz": "<voice_id>", "modelo": "eleven_v4", "estabilidade": 0.45, "similaridade": 0.75, "estilo": 0.1,
//     "velocidade": 1.0, "idioma": "pt", "seed": 1234 }
// Padrão: a voz da demonstração (Scheila, Voice Library). Se a conta não tiver acesso a ela, escolha uma voz em
// português na Voice Library, adicione às suas vozes e ponha o voice_id em "voz".
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { RAIZ, args, lerFilme } from './comum.mjs';

const { pos, opt } = args();
const nome = pos[0];
if (!nome) { console.log('uso: node tools/voz-elevenlabs.mjs <filme> [--so tipo,tipo] [--refaz]'); process.exit(1); }
const cfg = lerFilme(nome);
let KEY = process.env.ELEVENLABS_API_KEY || process.env.XI_API_KEY;
for (const f of ['.env', '.env.local']) {
  const envf = path.join(RAIZ, f);
  if (!KEY && fs.existsSync(envf)) KEY = (fs.readFileSync(envf, 'utf8').match(/^(?:ELEVENLABS_API_KEY|XI_API_KEY)\s*=\s*"?([^"\n]+)/m) || [])[1];
}
if (!KEY) { console.log('falta a chave: ELEVENLABS_API_KEY no ambiente ou no .env da raiz do projeto'); process.exit(1); }
const E = { voz: 'cyD08lEy76q03ER1jZ7y', modelo: 'eleven_v4', estabilidade: 0.45, similaridade: 0.75, estilo: 0.1,
  velocidade: 1.0, idioma: 'pt', seed: 1234, ...(cfg.elevenlabs || {}) };
const so = opt.so ? String(opt.so).split(',') : null;
const dir = path.join(RAIZ, 'audio/voz', nome);
fs.mkdirSync(dir, { recursive: true });

async function tts(texto, modelo) {
  const body = { text: texto, model_id: modelo, language_code: E.idioma, seed: E.seed,
    voice_settings: { stability: E.estabilidade, similarity_boost: E.similaridade, style: E.estilo, use_speaker_boost: true, speed: E.velocidade } };
  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${E.voz}?output_format=mp3_44100_192`, {
    method: 'POST', headers: { 'xi-api-key': KEY, 'Content-Type': 'application/json', Accept: 'audio/mpeg' }, body: JSON.stringify(body) });
  if (!r.ok) { const t = await r.text(); const e = new Error(`${r.status} ${t.slice(0, 300)}`); e.status = r.status; throw e; }
  return Buffer.from(await r.arrayBuffer());
}

let chars = 0;
for (const c of cfg.cenas) {
  if (!c.fala || c.ativa === false || (so && !so.includes(c.tipo))) continue;
  const dst = path.join(dir, `${c.tipo}.mp3`);
  if (fs.existsSync(dst) && !opt.refaz) { console.log(`  ${c.tipo}: já existe (use --refaz para gerar de novo)`); continue; }
  let buf;
  try { buf = await tts(c.fala, E.modelo); }
  catch (e) {
    if (e.status === 400 || e.status === 422) { console.log(`  modelo ${E.modelo} recusou (${e.message.slice(0, 120)}); tentando eleven_multilingual_v2`); buf = await tts(c.fala, 'eleven_multilingual_v2'); }
    else { console.log(`erro na fala de ${c.tipo}: ${e.message}`); if (e.status === 404 || /voice/i.test(e.message)) console.log('a voz não está na sua conta: adicione pela Voice Library ou troque "elevenlabs.voz" no config'); process.exit(1); }
  }
  fs.writeFileSync(dst, buf); chars += c.fala.length;
  console.log(`  ${c.tipo}: ${c.fala.length} caracteres → ${path.relative(RAIZ, dst)}`);
}
console.log(`${chars} caracteres gerados`);
execFileSync('node', [path.join(RAIZ, 'tools/voz.mjs'), nome], { stdio: 'inherit', cwd: RAIZ });
