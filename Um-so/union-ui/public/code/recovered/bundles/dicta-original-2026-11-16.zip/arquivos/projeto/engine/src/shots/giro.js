// giro — the caret turns out to be the edge of the app icon: it flips open in 3D, spins like a tossed chrome icon
// (fast start, long deceleration, the faces flashing white as they pass the key light) and lands face-on, on a beat.
// Config: { "tipo": "giro" } (no fields: the icon carries the brand symbol from marca.simbolo)
import { prog, lerp, E, bezier, clamp } from '../core.js';
import { S, cue } from '../timeline.js';
import { CARET } from './gancho.js';

export const HERO = { cx: 512, cy: 500, size: 268 };
const TURNS = 3;                      // full turns after the first quarter (edge-on -> face)
const R0 = -Math.PI / 2;              // edge-on, face to the left
const R1 = TURNS * 2 * Math.PI;       // face-on
const spinEase = bezier(0.22, 0.62, 0.16, 1);
let A, LAND, HOLD_END;

export function iconAt(t) {
  if (t < A) return null;
  const u = prog(t, A, LAND);
  const q = spinEase(u);
  let ry = lerp(R0, R1, q);
  // tiny settle after the landing
  const after = Math.max(0, t - LAND);
  ry += 0.07 * Math.exp(-after * 7) * Math.sin(after * 15) * (t > LAND ? 1 : 0);
  const su = E.outCubic(prog(t, A, A + 1.25));
  const size = lerp(CARET.h * 1.02, HERO.size, su);
  const pu = E.outCubic(prog(t, A, LAND - 0.15));
  const cx = lerp(CARET.cx, HERO.cx, pu);
  const toss = Math.sin(Math.PI * clamp(u * 1.08)) * 58 * (1 - u * 0.35);
  const cy = lerp(CARET.cy, HERO.cy, pu) - toss;
  const rx = 0.30 * Math.sin(2.2 * Math.PI * u) * Math.pow(1 - u, 1.6);
  const rz = -0.16 * Math.pow(1 - u, 2.2);
  // light sweep across the face while it rests
  const envRot = -0.25 + 0.85 * E.inOutCubic(prog(t, LAND - 0.2, HOLD_END + 0.3));
  return { visible: true, cx, cy, size, rx, ry, rz, envRot };
}
export const giroTimes = () => ({ A, LAND, HOLD_END });

export function init() {
  ({ A, LAND, HOLD_END } = S.P.giro);
  cue(A, 'giro:abre', 'whoosh', 'the caret flips open into the icon');
  cue(A + 0.42, 'giro:pico', 'swish', 'spin velocity still high');
  cue(LAND, 'giro:pousa', 'land', 'icon lands face-on');
}

export function render(t, C) {
  if (t < A || t >= HOLD_END) return false;
  C.icon = iconAt(t);
  return true;
}
