// render.mjs — desenha o filme no Chromium headless.
//   node tools/render.mjs <filme> linha                                  a linha do tempo (out/<filme>/linha.json)
//   node tools/render.mjs <filme> folha [--passo 15] [--escala 0.25]     folha de contato (sem desfoque de movimento)
//   node tools/render.mjs <filme> quadros <lista> [--escala 1] [--saida out/<filme>/quadros]
//   node tools/render.mjs <filme> filme [--escala 1] [--abas 3] [--refaz] [--saida out/<filme>/filme]
//   node tools/render.mjs <filme> compara <referencia.mp4> [--passo 1]   pares lado a lado (nosso | referência), a cada N segundos
// <lista>: "0,10,20" | "100-140" | "100-140:4" (quadros). Escala 1 = a saída final (1080 px no lado menor).
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import sharp from 'sharp';
import { RAIZ, args, quadros, servidor, navegador, abrir, quadro, pad, ffmpeg } from './comum.mjs';

const { pos, opt } = args();
const [nome, modo = 'folha', lista] = pos;
if (!nome) { console.log('uso: node tools/render.mjs <filme> linha|folha|quadros|filme|compara [...]'); process.exit(1); }

const srv = await servidor(); const porta = srv.address().port;
const browser = await navegador();
const OUT = path.join(RAIZ, 'out', nome);
fs.mkdirSync(OUT, { recursive: true });

async function folhaDe(pngs, cols, out, tileW) {
  const metas = await Promise.all(pngs.map((b) => sharp(b).metadata()));
  const tw = tileW, th = Math.round(tw * metas[0].height / metas[0].width), g = 4;
  const rows = Math.ceil(pngs.length / cols);
  const tiles = await Promise.all(pngs.map((b) => sharp(b).resize(tw, th).toBuffer()));
  await sharp({ create: { width: cols * (tw + g) - g, height: rows * (th + g) - g, channels: 3, background: '#333' } })
    .composite(tiles.map((b, i) => ({ input: b, left: (i % cols) * (tw + g), top: Math.floor(i / cols) * (th + g) })))
    .jpeg({ quality: 86 }).toFile(out);
}

try {
  if (modo === 'linha') {
    const p = await abrir(browser, porta, nome, 0.25);
    const L = { ...p.film, cfg: undefined };
    fs.writeFileSync(path.join(OUT, 'linha.json'), JSON.stringify(L, null, 1));
    resumo(p.film);
    avisos(p.erros);
  } else if (modo === 'folha' || modo === 'quadros') {
    const escala = Number(opt.escala || (modo === 'folha' ? 0.25 : 1));
    const p = await abrir(browser, porta, nome, escala);
    const total = p.film.total;
    const fs_ = modo === 'folha' ? quadros(`0-${total - 1}:${opt.passo || 15}`) : quadros(lista, total);
    if (modo === 'folha') {
      const pngs = [];
      for (const F of fs_) pngs.push(await quadro(p, F, { blur: !!opt.blur }));
      const out = path.join(OUT, 'folha.jpg');
      await folhaDe(pngs, Number(opt.colunas || 8), out, Math.min(p.outW, 270));
      console.log(`folha (${fs_.length} quadros, 1 a cada ${opt.passo || 15}, da esquerda para a direita) → ${path.relative(RAIZ, out)}`);
    } else {
      const dir = path.resolve(opt.saida || path.join(OUT, 'quadros'));
      fs.mkdirSync(dir, { recursive: true });
      for (const F of fs_) fs.writeFileSync(path.join(dir, pad(F) + '.png'), await quadro(p, F, { blur: !opt['sem-desfoque'] }));
      console.log(`${fs_.length} quadros → ${path.relative(RAIZ, dir)}`);
    }
    resumo(p.film);
    avisos(p.erros);
  } else if (modo === 'compara') {
    const ref = path.resolve(lista || 'arquivos/referencia.mp4');
    if (!fs.existsSync(ref)) throw new Error('não achei a referência: ' + ref);
    const p = await abrir(browser, porta, nome, Number(opt.escala || 0.5));
    const passo = Number(opt.passo || 1);
    const tempos = []; for (let s = 0.5; s < p.film.end; s += passo) tempos.push(s);
    const pngs = [];
    for (const s of tempos) {
      pngs.push(await quadro(p, Math.round(s * p.film.fps)));
      pngs.push(execFileSync(ffmpeg(), ['-v', 'error', '-ss', String(s), '-i', ref, '-frames:v', '1', '-vf', `scale=${p.outW}:${p.outH}`, '-f', 'image2pipe', '-vcodec', 'png', '-'], { maxBuffer: 1 << 28 }));
    }
    const out = path.join(OUT, 'compara.jpg');
    await folhaDe(pngs, 6, out, 300);
    console.log(`compara: ${tempos.length} pares (nosso | referência) a cada ${passo} s → ${path.relative(RAIZ, out)}`);
    avisos(p.erros);
  } else if (modo === 'filme') {
    const escala = Number(opt.escala || 1);
    const dir = path.resolve(opt.saida || path.join(OUT, 'filme'));
    if (opt.refaz) fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    const p0 = await abrir(browser, porta, nome, 0.25);
    const total = p0.film.total; await p0.ctx.close();
    fs.writeFileSync(path.join(OUT, 'linha.json'), JSON.stringify(p0.film, null, 1));
    const todo = []; for (let F = 0; F < total; F++) if (!fs.existsSync(path.join(dir, pad(F) + '.png'))) todo.push(F);
    const nAbas = Number(opt.abas || 3);
    console.log(`${todo.length} quadros de ${total} (${(total / p0.film.fps).toFixed(1)} s a ${p0.film.fps} fps) com ${nAbas} abas`);
    let next = 0, feitos = 0; const t0 = Date.now(); const erros = new Set();
    await Promise.all(Array.from({ length: nAbas }, async () => {
      let p = await abrir(browser, porta, nome, escala);
      while (next < todo.length) {
        const F = todo[next++];
        for (let tent = 0; ; tent++) {
          let tm; const limite = new Promise((_, rej) => { tm = setTimeout(() => rej(new Error('travou')), 120000); });
          try { fs.writeFileSync(path.join(dir, pad(F) + '.png'), await Promise.race([quadro(p, F), limite])); clearTimeout(tm); break; }
          catch (e) {
            clearTimeout(tm); if (tent >= 2) throw new Error(`o quadro ${F} travou 3 vezes`);
            console.log(`  quadro ${F} travou; reabrindo a aba`);
            p.erros.forEach((x) => erros.add(x)); await p.ctx.close().catch(() => {}); p = await abrir(browser, porta, nome, escala);
          }
        }
        if (++feitos % 50 === 0) console.log(`  ${feitos}/${todo.length}  ${((Date.now() - t0) / feitos).toFixed(0)} ms/quadro`);
      }
      p.erros.forEach((e) => erros.add(e)); await p.ctx.close();
    }));
    avisos([...erros]);
    console.log(`pronto: ${feitos} quadros em ${((Date.now() - t0) / 1000).toFixed(0)} s → ${path.relative(RAIZ, dir)}`);
  } else console.log('modos: linha | folha | quadros | filme | compara');
} finally { await browser.close(); srv.close(); }

function resumo(f) {
  console.log(`linha: ${f.total} quadros, ${f.end.toFixed(2)} s, ${f.fps} fps, ${f.saida[0]}×${f.saida[1]} (${f.formato})`);
  const m = f.marcos;
  const nomes = ['gancho', 'giro', 'demo', 'marca', 'usos', 'slogan', 'variacoes', 'fecho'];
  for (const n of nomes) if (m[n] != null && (n === 'gancho' || n === 'giro' || n === 'demo' || n === 'marca' || n === 'fecho' || f.cenas.includes(n)))
    console.log(`  ${n.padEnd(10)} ${m[n].toFixed(2).padStart(6)} s  (quadro ${Math.round(m[n] * f.fps)})`);
  console.log(`  drop       ${m.drop.toFixed(2).padStart(6)} s · batida final ${m.final.toFixed(2)} s · corte ${m.corte.toFixed(2)} s`);
}
function avisos(e) { const u = [...new Set(e)].filter((x) => !/favicon|GPU stall|WebGL|willReadFrequently/.test(x)); if (u.length) console.log('avisos do navegador:\n  ' + u.join('\n  ')); }
