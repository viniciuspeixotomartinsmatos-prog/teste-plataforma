// fecho — the logo. The text caret comes back (the film opened on it) and becomes the symbol: the other parts of the
// symbol grow out of it in turn (accent while they travel, text colour when they land, a granular shimmer along
// them); then the symbol, centred and big, slides left as it shrinks while the name is revealed from behind it with
// a soft blurred edge. On the music's final hit the lockup locks, a glint crosses the name and the call lands.
// Hard cut to black.
// Config: { "tipo": "fecho", "chamada": "Out now for Mac." }   (the name is marca.nome; chamada "" = none)
import { el, prog, lerp, E, clamp, rng, mixc, rgb, PAL, acc, ink, FONT } from '../core.js';
import { S, cue } from '../timeline.js';
import { MARCA, partHTML, inkViewBox } from '../marca.js';

const NS = 'http://www.w3.org/2000/svg';
const LOCK_Y = 484;
const S0 = 1.6;                 // start scale (centred)
let T, G = null, wrap, box, partEls = [], caretEl, word, sub, wordW = 0, lockLeft = 0, parts = [], WORD_SIZE = 138, GAPF = 0.2;

/** the logo's geometry (also read by variacoes, whose last word collapses into the caret) */
export function caret0() {
  if (G) return G.CARET0;
  const B = MARCA.box, an = MARCA.anchor;
  const U1 = Math.min(124 / B.h, 250 / B.w);       // px per symbol unit at rest: 124 px tall, at most 250 wide
  const v = inkViewBox();
  G = {
    B, an, U1, v,
    CARET0: { cx: 512 + (an.cx - B.cx) * U1 * S0, cy: LOCK_Y + (an.cy - B.cy) * U1 * S0, w: an.w * U1 * S0, h: an.h * U1 * S0 },
  };
  return G.CARET0;
}

/** sample points inside a part (in symbol units) by rasterising it */
async function samplePart(i, n, R) {
  const v = G.v, size = 360, k = size / Math.max(v.w, v.h);
  const svg = `<svg xmlns="${NS}" viewBox="${v.x} ${v.y} ${v.w} ${v.h}" width="${v.w * k}" height="${v.h * k}">${partHTML(i, '#fff')}</svg>`;
  const img = new Image();
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  await img.decode();
  const c = document.createElement('canvas'); c.width = Math.ceil(v.w * k); c.height = Math.ceil(v.h * k);
  const x = c.getContext('2d'); x.drawImage(img, 0, 0, c.width, c.height);
  const d = x.getImageData(0, 0, c.width, c.height).data;
  const pts = [];
  for (let tries = 0; pts.length < n && tries < n * 60; tries++) {
    const px = Math.floor(R() * c.width), py = Math.floor(R() * c.height);
    if (d[(py * c.width + px) * 4 + 3] > 128) pts.push({ x: v.x + px / k, y: v.y + py / k });
  }
  return pts;
}

const deg = (r) => (r * 180) / Math.PI;
const angDiff = (a, b) => { let d = a - b; while (d > 180) d -= 360; while (d < -180) d += 360; return d; };

export async function init(C, cfg) {
  caret0();
  T = S.P.fecho;
  const { B, an, U1, v } = G;
  const nome = (S.cfg.marca && S.cfg.marca.nome) || '';
  wrap = el('div', 'abs', C.type);
  Object.assign(wrap.style, { left: 0, top: 0, width: '1024px', height: '1024px' });
  // the symbol: one stacked svg per part, in a box that slides and scales
  box = el('div', 'abs', wrap);
  const bw = v.w * U1, bh = v.h * U1;
  Object.assign(box.style, { width: bw + 'px', height: bh + 'px', transformOrigin: '50% 50%' });
  const ax = (an.cx - v.x) * U1, ay = (an.cy - v.y) * U1; // the caret's centre in the box (px)
  const others = MARCA.parts.map((_, i) => i).filter((i) => i !== an.part);
  const step = others.length > 2 ? Math.min(T.step, 0.52 / (others.length - 1)) : T.step;
  MARCA.parts.forEach((p, i) => {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', `${v.x} ${v.y} ${v.w} ${v.h}`);
    Object.assign(s.style, { position: 'absolute', left: 0, top: 0, width: bw + 'px', height: bh + 'px', overflow: 'visible', transformOrigin: `${ax}px ${ay}px` });
    s.innerHTML = partHTML(i, 'currentColor');
    box.appendChild(s);
    const pb = p.box;
    const pcx = (pb.x0 + pb.x1) / 2, pcy = (pb.y0 + pb.y1) / 2;
    const th0 = deg(Math.atan2(pcy - an.cy, pcx - an.cx));
    let hmax = 0;
    for (const [qx, qy] of [[pb.x0, pb.y0], [pb.x1, pb.y0], [pb.x0, pb.y1], [pb.x1, pb.y1], [pcx, pb.y0], [pcx, pb.y1], [pb.x0, pcy], [pb.x1, pcy]]) {
      hmax = Math.max(hmax, Math.abs(angDiff(deg(Math.atan2(qy - an.cy, qx - an.cx)), th0)));
    }
    // a part that surrounds the caret (or the whole symbol when there is no bar) opens all the way round
    const inside = an.cx >= pb.x0 && an.cx <= pb.x1 && an.cy >= pb.y0 && an.cy <= pb.y1;
    hmax = inside ? 180 : Math.min(180, hmax + 6);
    const order = others.indexOf(i);
    partEls.push({ el: s, i, anchor: i === an.part, th0, hmax, start: order >= 0 ? T.arc1 + order * step : T.caret });
  });
  // without a bar in the symbol, the film's caret stands in for it and fades as the symbol grows
  caretEl = el('div', 'abs', box);
  const cw = Math.max(an.w * U1, 6), ch = an.h * U1;
  Object.assign(caretEl.style, { left: (ax - cw / 2) + 'px', top: (ay - ch / 2) + 'px', width: cw + 'px', height: ch + 'px', borderRadius: cw / 2 + 'px', background: rgb(PAL.ink) });
  if (an.part != null) caretEl.style.display = 'none';
  // the name
  word = el('div', 'abs', wrap);
  word.textContent = nome;
  Object.assign(word.style, { fontSize: WORD_SIZE + 'px', fontWeight: 640, letterSpacing: '-0.025em', lineHeight: '1', whiteSpace: 'pre', color: rgb(PAL.ink), fontFamily: FONT.display });
  wordW = word.getBoundingClientRect().width;
  let markW = B.w * U1;
  const total = markW + GAPF * WORD_SIZE + wordW;
  if (total > 900) { // long names: the name shrinks (the symbol keeps its size down to 70 %)
    const f = Math.max(0.45, (900 - markW * 0.7) / (GAPF * WORD_SIZE + wordW));
    WORD_SIZE *= Math.min(1, f);
    word.style.fontSize = WORD_SIZE + 'px';
    wordW = word.getBoundingClientRect().width;
  }
  G.fit = Math.min(1, (900 - GAPF * WORD_SIZE - wordW) / markW);
  markW *= G.fit;
  lockLeft = 512 - (markW + GAPF * WORD_SIZE + wordW) / 2;
  G.markW = markW;
  word.style.left = (lockLeft + markW + GAPF * WORD_SIZE) + 'px';
  word.style.top = (LOCK_Y - WORD_SIZE * 0.5 - 4) + 'px';
  sub = el('div', 'abs', wrap);
  sub.textContent = cfg.chamada ?? '';
  Object.assign(sub.style, { left: '62px', width: '900px', textAlign: 'center', top: (LOCK_Y + 126) + 'px', fontSize: '38px', fontWeight: 400, letterSpacing: '-0.01em', color: ink(0.8), fontFamily: FONT.display, lineHeight: '1.15', textWrap: 'balance' });
  if (sub.getBoundingClientRect().height > 50) sub.style.fontSize = '32px';
  // shimmer particles inside each growing part
  const R = rng(23);
  for (const pe of partEls) {
    if (pe.anchor) continue;
    const pts = await samplePart(pe.i, 110, R);
    for (const q of pts) {
      const th = deg(Math.atan2(q.y - an.cy, q.x - an.cx));
      const rel = Math.min(1, Math.abs(angDiff(th, pe.th0)) / Math.max(1, pe.hmax));
      const dirx = q.x - an.cx, diry = q.y - an.cy, dl = Math.hypot(dirx, diry) || 1;
      const sc = Math.max(B.w, B.h) / 71.2;
      parts.push({ pe, x: q.x, y: q.y, ux: dirx / dl, uy: diry / dl, rel, dr: (6 + R() * 26) * sc, life: 0.3 + R() * 0.35, s: 1 + R() * 1.6, w: R() });
    }
  }
  cue(T.caret, 'fecho:cursor', 'caret', 'the caret comes back');
  partEls.filter((p) => !p.anchor).forEach((p, k) => cue(p.start, `fecho:parte:${k}`, 'wave', 'a part of the symbol grows'));
  cue(T.slide, 'fecho:desliza', 'swoosh', 'symbol slides left, name revealed');
  cue(T.hit, 'fecho:final', 'final', 'final hit: lockup locks, the call lands');
  cue(T.cut, 'fecho:corte', 'cut', 'hard cut to black');
}

export function render(t, C) {
  const on = t >= T.caret && t < T.cut;
  wrap.style.display = on ? '' : 'none';
  if (!on) return false;
  const { B, U1, v } = G;
  sub.style.display = t >= T.hit ? '' : 'none';
  // symbol transform: centred at S0, then slide + shrink to the lockup
  const su = E.inOutCubic(prog(t, T.slide, T.slide + T.slideDur));
  const sc = lerp(S0, G.fit, su) * (t >= T.hit ? 1 + 0.018 * Math.exp(-(t - T.hit) * 9) * Math.cos((t - T.hit) * 30) : 1);
  const bw = v.w * U1, bh = v.h * U1;
  const cxEnd = lockLeft + G.markW / 2;
  const cx = lerp(512, cxEnd, su);
  // the box is centred on the ink centre
  const offX = (B.cx - v.x) * U1 - bw / 2, offY = (B.cy - v.y) * U1 - bh / 2;
  box.style.left = (cx - bw / 2 - offX) + 'px';
  box.style.top = (LOCK_Y - bh / 2 - offY) + 'px';
  box.style.transformOrigin = `${(B.cx - v.x) * U1}px ${(B.cy - v.y) * U1}px`;
  box.style.transform = `scale(${sc})`;
  const E0 = acc(0.06);
  let lastSettle = 0;
  for (const pe of partEls) {
    if (pe.anchor) { pe.el.style.color = rgb(PAL.ink); pe.el.style.display = ''; continue; }
    const g = E.outCubic(prog(t, pe.start, pe.start + T.arcDur));
    if (g <= 0.001) { pe.el.style.display = 'none'; continue; }
    pe.el.style.display = '';
    pe.el.style.transform = `scale(${lerp(0.42, 1, g)})`;
    const h = pe.hmax * lerp(0.08, 1, g);
    if (h >= 179.5) { pe.el.style.webkitMaskImage = 'none'; pe.el.style.maskImage = 'none'; }
    else {
      const ax = (G.an.cx - v.x) * U1, ay = (G.an.cy - v.y) * U1;
      const F = Math.min(4, h * 0.3);
      const m = `conic-gradient(from ${pe.th0 - h + 90}deg at ${ax}px ${ay}px, transparent 0deg, #000 ${F}deg, #000 ${2 * h - F}deg, transparent ${2 * h}deg)`;
      pe.el.style.webkitMaskImage = m; pe.el.style.maskImage = m;
    }
    const settle = prog(t, pe.start + T.arcDur * 0.55, pe.start + T.arcDur + 0.25);
    lastSettle = Math.max(lastSettle, prog(t, pe.start, pe.start + 0.3));
    pe.el.style.color = rgb(mixc(E0, PAL.ink, settle));
  }
  if (G.an.part == null) caretEl.style.opacity = String(1 - lastSettle);
  // shimmer
  const fx = C.fx;
  for (const q of parts) {
    const t0 = q.pe.start + q.rel * T.arcDur * 0.75;
    const lt = (t - t0) / q.life;
    if (lt < 0 || lt > 1) continue;
    const d = q.dr * E.outCubic(lt);
    const mx = q.x + q.ux * d, my = q.y + q.uy * d;
    const sx = cx + (mx - B.cx) * U1 * sc, sy = LOCK_Y + (my - B.cy) * U1 * sc;
    const al = (1 - lt) * (0.6 + 0.4 * q.w);
    fx.fillStyle = lt < 0.5 ? rgb(mixc(acc(0.15), acc(0.8), lt * 2), al) : rgb(PAL.ink, al);
    fx.fillRect(sx - q.s / 2, sy - q.s / 2, q.s, q.s);
  }
  // the name, revealed from behind the symbol: soft mask edge + clearing blur + a small slide
  const wu = E.outQuad(prog(t, T.word, T.word + T.wordDur));
  const reveal = lerp(-20, 120, wu);
  const m = `linear-gradient(90deg, #000 ${reveal - 18}%, transparent ${reveal}%)`;
  word.style.webkitMaskImage = m; word.style.maskImage = m;
  word.style.filter = wu < 0.999 ? `blur(${(1 - wu) * 6}px)` : 'none';
  word.style.transform = `translateX(${(1 - wu) * -0.06 * wordW}px)`;
  word.style.visibility = t >= T.word ? 'visible' : 'hidden';
  // glint across the name after the final hit
  const gl = prog(t, T.hit + 0.05, T.hit + 0.75);
  if (gl > 0 && gl < 1) {
    const x = lerp(-30, 130, E.inOutCubic(gl));
    const W = rgb(PAL.ink), P = rgb(mixc(acc(0.72), PAL.ink, 0.1));
    word.style.backgroundImage = `linear-gradient(100deg, ${W} ${x - 14}%, ${P} ${x - 4}%, ${W} ${x}%, ${P} ${x + 4}%, ${W} ${x + 14}%)`;
    word.style.webkitBackgroundClip = 'text'; word.style.backgroundClip = 'text'; word.style.color = 'transparent';
  } else {
    word.style.backgroundImage = 'none'; word.style.color = rgb(PAL.ink);
  }
  return true;
}
