// marca — the hard cut on the music's entrance: "[symbol] Name" lands on the first hit, the slogan's words land on the
// next eighth notes, the drop sends a wave out of the symbol, and the line leaves through the tinted fade.
// Config: { "tipo": "marca", "slogan": "Talk to type." }   (the name is marca.nome; slogan: 1 to ~5 words)
import { el, prog, E, rgb, ac, FONT } from '../core.js';
import { makeLine, exitColor } from '../type.js';
import { S, cue } from '../timeline.js';
import { markSVG, MARCA, inkViewBox } from '../marca.js';

const SIZE = 76;
let M, line, markEl, markRect = null, groups;

/** split the slogan's words into at most 3 groups (one per eighth note) */
function grupos(words) {
  if (words.length <= 3) return words.map((w) => [w]);
  const out = [[], [], []];
  words.forEach((w, i) => out[Math.min(2, Math.floor(i * 3 / words.length))].push(w));
  return out;
}

export function init(C, cfg) {
  M = S.P.marca;
  const nome = (S.cfg.marca && S.cfg.marca.nome) || '';
  const words = String(cfg.slogan ?? '').split(/\s+/).filter(Boolean);
  groups = grupos(words);
  const B = MARCA.box;
  const wEm = Math.min(2.4, 0.9 * ((B.w + 2 * inkViewBox().pad) / (B.h + 2 * inkViewBox().pad))) + 0.15;
  const markHTML = `<span class="mk" style="display:inline-block;width:${wEm.toFixed(3)}em;height:0.9em;vertical-align:-0.13em;margin-right:0.2em">${markSVG('currentColor')}</span>`;
  line = makeLine(C.type, [
    { html: markHTML + `<span style="font-weight:640;letter-spacing:-0.02em">${esc(nome)}</span>` },
    ...groups.map((g) => ({ text: g.join(' '), weight: 300 })),
  ], { y: 512, size: SIZE, weight: 300, tracking: -0.01, min: 0.7, breakAfter: 0 });
  markEl = line.parts[0].querySelector('.mk');
  const svg = markEl.querySelector('svg');
  svg.style.width = '100%'; svg.style.height = '100%'; svg.style.display = 'block';
  line.show(true);
  const r = svg.getBoundingClientRect();
  const cr = C.type.getBoundingClientRect();
  markRect = { x: r.left - cr.left, y: r.top - cr.top, w: r.width, h: r.height };
  line.show(false);
  const at = M.at.slice(0, 1 + groups.length);
  at.forEach((t, i) => cue(t, `marca:palavra:${i}`, i === 0 ? 'wordmark' : 'word', i === 0 ? nome : groups[i - 1].join(' ')));
  cue(S.P.drop, 'marca:onda', 'drop', 'the drop: a wave leaves the symbol');
  cue(M.exit, 'marca:sai', 'exit', 'tinted fade');
}
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function render(t, C) {
  const on = t >= M.a && t < M.b;
  line.show(on);
  if (!on) return false;
  line.setOn(0, t >= M.at[0]);
  groups.forEach((_, i) => line.setOn(i + 1, t >= M.at[i + 1]));
  line.color(exitColor(t, M.exit, 0.8));
  // the wave on the drop: two arcs expand and fade (drawn on the fx canvas)
  const fx = C.fx;
  const v = inkViewBox();
  const scale = Math.min(markRect.h / v.h, markRect.w / v.w);
  const offX = (markRect.w - v.w * scale) / 2, offY = (markRect.h - v.h * scale) / 2;
  const o = MARCA.onda;
  const c0x = markRect.x + offX + (o.cx - v.x) * scale;
  const c0y = markRect.y + offY + (o.cy - v.y) * scale;
  const drop = S.P.drop;
  for (let i = 0; i < 2; i++) {
    const u = prog(t, drop + i * 0.11, drop + i * 0.11 + 0.9);
    if (u <= 0 || u >= 1) continue;
    const rr = (o.r * scale) * (1 + E.outCubic(u) * 2.6);
    const a = (1 - u) * 0.55;
    fx.save();
    fx.strokeStyle = ac(0.04, a);
    fx.lineWidth = (o.sw * scale) * (1 - u * 0.6);
    fx.lineCap = 'round';
    fx.beginPath();
    const h = (Math.min(180, o.ang) * Math.PI) / 180;
    if (h >= Math.PI - 1e-3) fx.arc(c0x, c0y, rr, 0, Math.PI * 2);
    else fx.arc(c0x, c0y, rr, -h, h);
    fx.stroke();
    fx.restore();
  }
  return true;
}
