// main.js — reads the config, plans the timeline, builds every shot once, then window.seekFrame(f) sets the whole
// stage for film frame f (fractional frames are allowed: the renderer averages sub-frames for motion blur).
import { plan, CUES, S, cena } from './timeline.js';
import { setPalette, PAL, rgb } from './core.js';
import { loadMarca } from './marca.js';
import { createIcon } from './icon3d.js';
import * as gancho from './shots/gancho.js';
import * as giro from './shots/giro.js';
import * as demo from './shots/demo.js';
import * as marca from './shots/marca.js';
import * as usos from './shots/usos.js';
import * as slogan from './shots/slogan.js';
import * as variacoes from './shots/variacoes.js';
import * as fecho from './shots/fecho.js';

const SHOTS = { gancho, giro, demo, marca, usos, slogan, variacoes, fecho };
export const FORMATOS = { quadrado: [1080, 1080], vertical: [1080, 1920], horizontal: [1920, 1080] };

const warn = (m) => console.warn(m);

async function boot() {
  const q = new URLSearchParams(location.search);
  const nome = q.get('filme') || 'demo';
  const get = async (u) => { const r = await fetch(u, { cache: 'no-store' }); if (!r.ok) throw new Error('não achei ' + u); return r.json(); };
  const cfg = await get(`/filmes/${nome}.json`);
  const trilha = await get(`/audio/trilha/${cfg.trilha || 'trilha'}.json`);
  const fmt = FORMATOS[cfg.formato || 'quadrado'];
  if (!fmt) throw new Error('formato desconhecido: ' + cfg.formato + ' (quadrado, vertical ou horizontal)');
  const short = Math.min(fmt[0], fmt[1]);
  const W = 1024 * fmt[0] / short, H = 1024 * fmt[1] / short;
  const ox = (W - 1024) / 2, oy = (H - 1024) / 2;
  const dpr = window.devicePixelRatio || 1;

  setPalette(cfg.cores || {});
  const stage = document.getElementById('stage');
  Object.assign(stage.style, { width: W + 'px', height: H + 'px', background: rgb(PAL.bg), color: rgb(PAL.ink) });
  document.body.style.background = rgb(PAL.bg);
  const comp = document.getElementById('comp');
  Object.assign(comp.style, { left: ox + 'px', top: oy + 'px' });
  for (const id of ['gl', 'fx']) {
    const c = document.getElementById(id);
    Object.assign(c.style, { left: -ox + 'px', top: -oy + 'px', width: W + 'px', height: H + 'px' });
    c.width = Math.round(W * dpr); c.height = Math.round(H * dpr);
  }

  // fonts: the brand's (optional) as 'Marca', Inter for the rest
  const f = cfg.marca && cfg.marca.fonte;
  if (f && Array.isArray(f.arquivos)) {
    for (const a of f.arquivos) {
      try {
        const ff = new FontFace('Marca', `url(/${a.arquivo})`, { weight: String(a.peso || 400), style: 'normal' });
        await ff.load(); document.fonts.add(ff);
      } catch (e) { warn('fonte da marca não carregou: ' + a.arquivo); }
    }
  }
  await Promise.all(['300', '400', '500', '600', '640', '700'].map((w) => document.fonts.load(`${w} 40px Inter`)));
  await document.fonts.load('400 20px "Geist Mono"');
  await document.fonts.ready;

  await loadMarca(cfg);
  const P = plan(cfg, trilha);

  const fxc = document.getElementById('fx');
  const fx = fxc.getContext('2d');
  const icon = createIcon(document.getElementById('gl'), W, H, dpr);
  const C = {
    world: document.getElementById('world'), over: document.getElementById('over'), type: document.getElementById('type'),
    fx, icon: null, worldT: null, stage: { W, H, ox, oy, dpr },
  };
  const active = Object.entries(SHOTS).filter(([n]) => cena(cfg, n));
  for (const [name, s] of active) {
    try { await s.init(C, cena(cfg, name)); } catch (e) { console.error('init ' + name, e); throw e; }
  }
  window.seekFrame = (fr) => {
    const t = fr / P.fps;
    fx.setTransform(1, 0, 0, 1, 0, 0);
    fx.clearRect(0, 0, fxc.width, fxc.height);
    fx.setTransform(dpr, 0, 0, dpr, ox * dpr, oy * dpr);
    C.icon = { visible: false };
    C.worldT = '';
    const on = [];
    for (const [name, s] of active) if (s.render(t, C)) on.push(name);
    C.world.style.transform = C.worldT || '';
    C.over.style.transform = C.worldT || '';
    icon.render(C.icon);
    return on;
  };
  const cenas = active.map(([n]) => n);
  window.FILM = {
    fps: P.fps, total: P.total, end: P.end, W, H, formato: cfg.formato || 'quadrado', saida: fmt,
    cues: CUES, musica: P.musica, blur: P.blur, cenas, beat: P.beat,
    marcos: { gancho: 0, giro: P.giro.A, demo: P.giro.HOLD_END, marca: P.cut, drop: P.drop,
      usos: P.usos?.a, slogan: P.slogan?.a, variacoes: P.variacoes?.a, fecho: P.fecho.a, final: P.fecho.hit, corte: P.fecho.cut },
  };
  window.ready = true;
}
boot().catch((e) => { window.__initError = String(e && e.stack || e); console.error(e); });
