A mídia de cada filme fica em midia/<nome-do-filme>/ (o símbolo em SVG e, se houver, a fonte da marca). Ver o guia, seção Mídia.
