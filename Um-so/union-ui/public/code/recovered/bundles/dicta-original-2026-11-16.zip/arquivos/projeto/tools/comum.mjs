// comum.mjs — servidor local, navegador headless, abertura do filme e captura de quadros. Usado pelas outras ferramentas.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import sharp from 'sharp';

export const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function args(argv = process.argv.slice(2)) {
  const pos = [], opt = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2), v = argv[i + 1];
      if (v === undefined || v.startsWith('--')) opt[k] = true; else { opt[k] = v; i++; }
    } else pos.push(a);
  }
  return { pos, opt };
}

/** "0,10,20" | "100-140" | "100-140:4", misturáveis com vírgula */
export function quadros(s, total) {
  const out = [];
  for (const part of String(s).split(',')) {
    const [range, step] = part.split(':');
    let [a, b] = range.split('-').map(Number);
    if (b === undefined || Number.isNaN(b)) b = a;
    if (total !== undefined) b = Math.min(b, total - 1);
    for (let f = a; f <= b; f += Number(step || 1)) out.push(f);
  }
  return out;
}

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.json': 'application/json', '.svg': 'image/svg+xml' };

/** serve a raiz do projeto */
export function servidor(porta = 0) {
  return new Promise((res) => {
    const srv = http.createServer((req, rsp) => {
      const p = decodeURIComponent(req.url.split('?')[0]);
      const file = path.join(RAIZ, p);
      if (!file.startsWith(RAIZ)) { rsp.writeHead(403); rsp.end(); return; }
      fs.readFile(file, (err, buf) => {
        if (err) { rsp.writeHead(404); rsp.end(); return; }
        rsp.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
        rsp.end(buf);
      });
    }).listen(porta, '127.0.0.1', () => res(srv));
  });
}

/** Chromium headless com GPU (Metal/D3D11/Vulkan); sem o Chromium completo instalado, cai no headless padrão */
export async function navegador() {
  const ANGLE = process.platform === 'win32' ? 'd3d11' : process.platform === 'darwin' ? 'metal' : 'vulkan';
  try {
    return await chromium.launch({ channel: 'chromium', headless: true, args: [`--use-angle=${ANGLE}`, '--enable-gpu', '--ignore-gpu-blocklist'] });
  } catch {
    return await chromium.launch({ headless: true, args: ['--ignore-gpu-blocklist', '--enable-unsafe-swiftshader'] });
  }
}

export function lerFilme(nome) {
  const f = path.join(RAIZ, 'filmes', nome + '.json');
  if (!fs.existsSync(f)) throw new Error(`não achei filmes/${nome}.json`);
  return JSON.parse(fs.readFileSync(f, 'utf8'));
}

export const FORMATOS = { quadrado: [1080, 1080], vertical: [1080, 1920], horizontal: [1920, 1080] };

/** abre o filme numa aba. escala 1 = a saída final (1080 no lado menor); 0,5 = metade */
export async function abrir(browser, porta, nome, escala = 1) {
  const cfg = lerFilme(nome);
  const fmt = FORMATOS[cfg.formato || 'quadrado'];
  if (!fmt) throw new Error('formato desconhecido: ' + cfg.formato + ' (use quadrado, vertical ou horizontal)');
  const short = Math.min(fmt[0], fmt[1]);
  const W = 1024 * fmt[0] / short, H = 1024 * fmt[1] / short;
  const dpr = (short / 1024) * escala;
  const ctx = await browser.newContext({ viewport: { width: Math.ceil(W), height: Math.ceil(H) }, deviceScaleFactor: dpr });
  const page = await ctx.newPage();
  const erros = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') erros.push(m.text()); });
  page.on('pageerror', (e) => erros.push(e.message));
  await page.goto(`http://127.0.0.1:${porta}/engine/index.html?filme=${encodeURIComponent(nome)}`);
  await page.waitForFunction(() => window.ready === true || window.__initError, null, { timeout: 180000 });
  const falha = await page.evaluate(() => window.__initError || null);
  if (falha) throw new Error('o filme não abriu: ' + falha + '\n' + erros.join('\n'));
  const film = await page.evaluate(() => JSON.parse(JSON.stringify(window.FILM)));
  const outW = Math.round(fmt[0] * escala), outH = Math.round(fmt[1] * escala);
  return { ctx, page, erros, cfg, film, W, H, outW, outH, escala };
}

/** quantos sub-quadros o quadro f leva (desfoque de movimento: obturador de 180°) */
export function subquadros(film, f) {
  const t = f / film.fps;
  let k = 1;
  for (const r of film.blur) if (t >= r.a && t <= r.b) k = Math.max(k, Math.ceil(r.k50 * 50 / film.fps));
  return k;
}

async function grab(p, f) {
  await p.page.evaluate((x) => window.seekFrame(x), f);
  await p.page.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))));
  return p.page.screenshot({ clip: { x: 0, y: 0, width: p.W, height: p.H }, animations: 'disabled' });
}

/** um quadro como PNG no tamanho exato da saída; blur = false desliga o desfoque de movimento (folhas rápidas) */
export async function quadro(p, f, { blur = true } = {}) {
  const k = blur ? subquadros(p.film, f) : 1;
  const fit = (img) => img.resize(p.outW, p.outH, { fit: 'fill' });
  if (k <= 1) return fit(sharp(await grab(p, f))).removeAlpha().png({ compressionLevel: 3 }).toBuffer();
  let acc = null, info = null;
  const shutter = 0.5; // 180°
  for (let i = 0; i < k; i++) {
    const sub = f + ((i + 0.5) / k - 0.5) * shutter;
    const r = await fit(sharp(await grab(p, sub))).removeAlpha().raw().toBuffer({ resolveWithObject: true });
    info = r.info;
    if (!acc) acc = new Float32Array(r.data.length);
    for (let j = 0; j < acc.length; j++) acc[j] += r.data[j];
  }
  const out = Buffer.alloc(acc.length);
  for (let j = 0; j < acc.length; j++) out[j] = Math.min(255, Math.round(acc[j] / k));
  return sharp(out, { raw: { width: info.width, height: info.height, channels: 3 } }).png({ compressionLevel: 3 }).toBuffer();
}

export const pad = (n) => String(n).padStart(4, '0');

/** caminho do ffmpeg: o do pacote @ffmpeg-installer (vem com o npm install) ou o do sistema */
export function ffmpeg() {
  const plat = `${process.platform}-${process.arch}`;
  const bin = path.join(RAIZ, 'node_modules/@ffmpeg-installer', plat, process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
  if (!fs.existsSync(bin)) return 'ffmpeg';
  // o npm pode bloquear o script que dá permissão de execução ao binário: dá aqui
  try { fs.accessSync(bin, fs.constants.X_OK); } catch { try { fs.chmodSync(bin, 0o755); } catch {} }
  return bin;
}

/** o Python do projeto (.venv) ou o do sistema */
export function python() {
  for (const p of ['.venv/bin/python', '.venv/Scripts/python.exe']) if (fs.existsSync(path.join(RAIZ, p))) return path.join(RAIZ, p);
  return process.platform === 'win32' ? 'python' : 'python3';
}
