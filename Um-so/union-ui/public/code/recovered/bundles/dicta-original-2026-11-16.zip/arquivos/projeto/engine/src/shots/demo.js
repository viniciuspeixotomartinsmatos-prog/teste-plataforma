// demo — the product at work, in pieces of UI: "messy input -> clean result". The camera pulls back from the icon: a
// window flies in from in front of the lens (depth-of-field fly-in), the icon shrinks into the product's pill, the
// trigger key is held, the raw input streams in, the key is released, the parts to remove turn to the accent, are
// struck through and dissolve into pixels that fly into the icon, and the kept words close ranks into one clean text
// (new words fade in, replaced words cross-fade). Then the camera dives into the symbol and floods to white for the
// cut on the music's entrance.
// Config: { "tipo": "demo",
//   "janela": { "titulo": "New Message", "campo": "To", "valor": "Maya Chen" },   campo/valor optional ("" hides)
//   "entrada": "[um] [so] let's>Let's move the launch to [uh] [Friday…] [no,] Thursday",
//              [x] removed · a>B cleaned to B · +B only in the result · _ = space inside one block
//   "ponto": ".",                                   the punctuation that lands last ("" = none)
//   "tecla": { "texto": "fn", "icone": "globe" },    the key held while the input streams (null = no key)
//   "contador": true }                               the 0:0N timer in the pill
import { el, prog, lerp, E, clamp, spring, rgb, mixc, rng, noise1, EASE_SETTLE, PAL, ac, acc, ink, surf, FONT } from '../core.js';
import { S, cue } from '../timeline.js';
import { iconAt, giroTimes, HERO } from './giro.js';
import { MARCA } from '../marca.js';
import { lucide } from '../icones.js';

// ---- layout (CSS px in the 1024 composition)
const WIN = { x: 130, y: 186, w: 764, h: 392, r: 22 };
const BODY = { x: WIN.x + 42, y: WIN.y + 108 + 30, maxW: WIN.w - 84, size: 33, lh: 47 };
const HUD = { x: 343, y: 614, h: 70, wFull: 338 };
export const SLOT = { cx: HUD.x + 35, cy: HUD.y + 35, size: 48 };
const KEY = { cx: 512, cy: 812, s: 102 };

let T, TOKENS, CFG, EMBER, RAW, HOLD_END;
let root, win, hud, hudFill, bars, timer, shimmer, key, keyTop, keyGlow, caret, period, textLayer, lastClean;
let sp = 8;
const glyph = { dx: 0, dy: 0 };

function mkWin(parent) {
  const j = CFG.janela || {};
  const w = el('div', 'abs', parent);
  Object.assign(w.style, {
    left: WIN.x + 'px', top: WIN.y + 'px', width: WIN.w + 'px', height: WIN.h + 'px', borderRadius: WIN.r + 'px',
    background: `linear-gradient(180deg, ${surf(0.098)} 0%, ${surf(0.067)} 100%)`,
    boxShadow: `0 40px 90px rgba(0,0,0,0.65), inset 0 1px 0 ${ink(0.07)}, 0 0 0 1px ${ink(0.08)}`, fontFamily: FONT.ui,
  });
  const dots = el('div', 'abs', w);
  Object.assign(dots.style, { left: '24px', top: '17px', display: 'flex', gap: '10px' });
  for (let i = 0; i < 3; i++) { const d = el('div', '', dots); Object.assign(d.style, { width: '13px', height: '13px', borderRadius: '6.5px', background: ink(0.16) }); }
  const title = el('div', 'abs', w);
  title.textContent = j.titulo ?? '';
  Object.assign(title.style, { left: '110px', width: (WIN.w - 220) + 'px', top: '14px', textAlign: 'center', fontSize: '17px', fontWeight: 500, color: ink(0.42), whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' });
  const hr = (y) => { const l = el('div', 'abs', w); Object.assign(l.style, { left: '0px', width: WIN.w + 'px', top: y + 'px', height: '1px', background: ink(0.07) }); };
  hr(48);
  const campo = j.campo ?? '', valor = j.valor ?? '';
  if (campo || valor) {
    const to = el('div', 'abs', w);
    Object.assign(to.style, { left: '42px', top: '63px', fontSize: '20px', color: ink(0.4), display: 'flex', gap: '12px', alignItems: 'center', whiteSpace: 'nowrap', maxWidth: (WIN.w - 84) + 'px', overflow: 'hidden' });
    if (campo) { const a = el('span', '', to); a.textContent = campo; }
    if (valor) {
      const b = el('span', '', to); b.textContent = valor;
      Object.assign(b.style, { color: ink(1), background: ink(0.08), padding: '4px 12px', borderRadius: '14px', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis' });
    }
  }
  hr(106);
  return w;
}

function mkHud(parent) {
  const h = el('div', 'abs', parent);
  Object.assign(h.style, { left: HUD.x + 'px', top: HUD.y + 'px', height: HUD.h + 'px', width: HUD.h + 'px', borderRadius: HUD.h / 2 + 'px', overflow: 'hidden', fontFamily: FONT.ui });
  hudFill = el('div', 'abs', h);
  Object.assign(hudFill.style, { left: 0, top: 0, right: 0, bottom: 0, borderRadius: HUD.h / 2 + 'px', background: `linear-gradient(180deg, ${surf(0.118, 0.98)}, ${surf(0.063, 0.98)})` });
  bars = [];
  for (let i = 0; i < 24; i++) {
    const b = el('div', 'abs', h);
    Object.assign(b.style, { width: '4.5px', left: (88 + i * 8.5) + 'px', borderRadius: '2.25px', background: `linear-gradient(180deg, ${ac(0.22)}, ${ac(0)})` });
    bars.push(b);
  }
  timer = el('div', 'abs', h, '0:00');
  Object.assign(timer.style, { right: '24px', top: '24px', fontSize: '18px', fontWeight: 500, color: ink(0.46), fontVariantNumeric: 'tabular-nums' });
  if (CFG.contador === false) timer.style.visibility = 'hidden';
  shimmer = el('div', 'abs', h);
  Object.assign(shimmer.style, { top: 0, height: HUD.h + 'px', width: '120px', background: `linear-gradient(90deg, ${ac(0.45, 0)}, ${ac(0.45, 0.22)}, ${ac(0.45, 0)})` });
  return h;
}

function mkKey(parent) {
  const tc = CFG.tecla === undefined ? { texto: 'fn', icone: 'globe' } : CFG.tecla;
  const k = el('div', 'abs', parent);
  Object.assign(k.style, { left: (KEY.cx - KEY.s / 2) + 'px', top: (KEY.cy - KEY.s / 2) + 'px', width: KEY.s + 'px', height: KEY.s + 'px', fontFamily: FONT.ui });
  if (!tc) { k.style.display = 'none'; return null; }
  keyGlow = el('div', 'abs', k);
  Object.assign(keyGlow.style, { left: '-22px', top: '-22px', right: '-22px', bottom: '-30px', borderRadius: '40px', background: `radial-gradient(closest-side, ${ac(0, 0.5)}, ${ac(0, 0)})`, opacity: 0 });
  const base = el('div', 'abs', k);
  Object.assign(base.style, { left: 0, top: '7px', width: KEY.s + 'px', height: KEY.s + 'px', borderRadius: '18px', background: rgb(mixc(PAL.bg, [8, 8, 10], 0.6)), boxShadow: `0 16px 30px rgba(0,0,0,0.7), 0 0 0 1px ${ink(0.05)}` });
  keyTop = el('div', 'abs', k);
  Object.assign(keyTop.style, { left: 0, top: 0, width: KEY.s + 'px', height: KEY.s + 'px', borderRadius: '18px', background: `linear-gradient(180deg, ${surf(0.17)} 0%, ${surf(0.103)} 100%)`, boxShadow: `inset 0 1px 0 ${ink(0.13)}, 0 0 0 1px ${ink(0.07)}` });
  const label = el('div', 'abs', keyTop);
  label.textContent = tc.texto ?? '';
  const ls = (tc.texto || '').length > 3 ? Math.max(13, 22 * 3 / tc.texto.length) : 22;
  Object.assign(label.style, { right: '15px', top: '12px', fontSize: ls + 'px', fontWeight: 500, color: ink(0.8), whiteSpace: 'nowrap' });
  if (tc.icone) {
    const ic = el('div', 'abs', keyTop, lucide(tc.icone, 26, ink(0.8), 1.6));
    Object.assign(ic.style, { left: '14px', bottom: '14px' });
  }
  return k;
}

function textSpan(parent, text) {
  const s = el('span', 'abs', parent);
  Object.assign(s.style, { fontSize: BODY.size + 'px', fontWeight: 400, whiteSpace: 'pre', letterSpacing: '-0.005em', lineHeight: '1', fontFamily: FONT.ui });
  s.textContent = text;
  return s;
}
function measure(parent, text) { const s = textSpan(parent, text); const w = s.getBoundingClientRect().width; s.remove(); return w; }

function layout(list, widthOf) {
  const pos = []; let x = 0, y = 0;
  list.forEach((tok, i) => {
    const w = widthOf(tok);
    if (i > 0 && x + w > BODY.maxW) { x = 0; y += BODY.lh; }
    pos.push({ x, y, w });
    x += w + sp;
  });
  return pos;
}
const nLines = (pos) => (pos.length ? pos[pos.length - 1].y / BODY.lh + 1 : 1);

export function init(C, cfg) {
  CFG = cfg; T = S.P.demo.T; TOKENS = S.P.demo.toks; HOLD_END = giroTimes().HOLD_END;
  EMBER = acc(0.06); RAW = mixc(PAL.ink, PAL.bg, 0.41);
  root = el('div', 'abs', C.world);
  Object.assign(root.style, { left: 0, top: 0, width: '1024px', height: '1024px' });
  win = mkWin(root);
  hud = mkHud(root);
  key = mkKey(root);
  textLayer = el('div', 'abs', root);
  Object.assign(textLayer.style, { left: 0, top: 0, width: '1024px', height: '1024px' });
  const ponto = cfg.ponto ?? '.';
  // the body text shrinks (down to 24 px) until the raw input fits 4 lines and the result 3
  for (let pass = 0; pass < 12; pass++) {
    sp = measure(textLayer, 'a b') - measure(textLayer, 'ab');
    TOKENS.forEach((tk) => { tk.w = tk.raw ? measure(textLayer, tk.raw) : 0; tk.wc = tk.clean != null ? measure(textLayer, tk.clean) : tk.w; });
    const rawL = nLines(layout(TOKENS.filter((q) => !q.novo), (q) => q.w));
    const cl = TOKENS.filter((q) => !q.f);
    const clL = nLines(layout(cl, (q) => q.wc + (q === cl[cl.length - 1] ? measure(textLayer, ponto) + 8 : 0)));
    if ((rawL <= 4 && clL <= 3) || BODY.size <= 24) break;
    BODY.size = Math.max(24, BODY.size - 2); BODY.lh = Math.round(BODY.size * 1.42);
  }
  const rawToks = TOKENS.filter((q) => !q.novo);
  const rawPos = layout(rawToks, (q) => q.w);
  const kept = TOKENS.filter((q) => !q.f);
  const cleanPos = layout(kept, (q) => q.wc);
  rawToks.forEach((tk, i) => { tk.p0 = rawPos[i]; });
  kept.forEach((tk, i) => { tk.p1 = cleanPos[i]; tk.k = i; if (tk.novo) tk.p0 = cleanPos[i]; });
  lastClean = kept[kept.length - 1];
  let j = 0;
  for (const tk of TOKENS) {
    tk.el = textSpan(textLayer, tk.novo ? tk.clean : tk.raw);
    if (tk.clean != null && !tk.novo) tk.el2 = textSpan(textLayer, tk.clean);
    if (tk.f) {
      tk.j = j++;
      tk.strike = el('div', 'abs', textLayer);
      Object.assign(tk.strike.style, { height: '3px', borderRadius: '2px', background: rgb(EMBER) });
    }
  }
  period = textSpan(textLayer, ponto);
  caret = el('div', 'abs', textLayer);
  Object.assign(caret.style, { width: '3px', height: (BODY.size * 41 / 33) + 'px', borderRadius: '1.5px', background: rgb(PAL.ink) });
  // particles: sample each removed word's glyph pixels once (2x canvas, every 3rd px)
  const oc = document.createElement('canvas'); oc.width = 1400; oc.height = 120;
  const ox = oc.getContext('2d');
  const R = rng(7);
  for (const tk of TOKENS) {
    if (!tk.f) continue;
    ox.clearRect(0, 0, oc.width, oc.height);
    ox.font = `400 ${BODY.size * 2}px ${FONT.ui}`;
    ox.fillStyle = '#fff'; ox.textBaseline = 'alphabetic';
    ox.fillText(tk.raw, 4, 76);
    const img = ox.getImageData(0, 0, oc.width, oc.height).data;
    tk.parts = [];
    for (let y = 0; y < 120; y += 3) for (let x = 0; x < oc.width; x += 3) {
      if (img[(y * oc.width + x) * 4 + 3] > 110) tk.parts.push({ x: (x - 4) / 2, y: (y - 76) / 2, d: R() * 0.16 + (x / 600) * 0.2, r1: R(), r2: R(), r3: R() });
    }
  }
  // the dive aims at the symbol's bar (marca.ancora) or its centre
  const B = MARCA.box, an = MARCA.anchor;
  const gScale = 1.12 / Math.max(B.w, B.h);
  glyph.dx = (an.cx - B.cx) * gScale * (SLOT.size / 2);
  glyph.dy = (an.cy - B.cy) * gScale * (SLOT.size / 2);
  // cues
  cue(T.pull, 'demo:recua', 'swoosh', 'camera pulls back, window flies in');
  cue(T.hudGrow, 'demo:pilula', 'hud', 'the pill extends from the icon');
  if (key) cue(T.keyIn, 'demo:tecla', 'pop', 'the key arrives');
  cue(T.press, 'demo:aperta', 'click', 'key pressed: input starts');
  rawToks.forEach((tk, i) => cue(tk.at, `demo:palavra:${i}`, 'stream', tk.raw));
  cue(T.release, 'demo:solta', 'release', 'key released');
  TOKENS.filter((q) => q.f).forEach((tk) => cue(T.highlight + 0.1 + tk.j * 0.045, `demo:risca:${tk.j}`, 'strike', tk.raw));
  cue(T.dissolve, 'demo:dissolve', 'granular', 'removed words burst into pixels and fly into the icon');
  cue(T.flip, 'demo:junta', 'slide', 'clean words close ranks');
  if (ponto) cue(T.period, 'demo:ponto', 'tick', 'the punctuation lands');
  cue(T.zoom, 'demo:mergulho', 'dive', 'camera dives into the icon');
  cue(T.cut, 'demo:corte', 'hit', 'cut to the brand on the music');
}

function speechAmp(t) {
  if (t < T.press + 0.06 || t > T.release) return 0;
  let a = 0;
  for (const tk of TOKENS) {
    if (tk.novo) continue;
    const len = 0.1 + Math.min(10, tk.raw.length) * 0.024;
    const dt = t - (tk.at - 0.1);
    if (dt > 0 && dt < len + 0.12) a = Math.max(a, Math.sin(Math.PI * clamp(dt / (len + 0.12))));
  }
  return a;
}

export function render(t, C) {
  const on = t >= T.pull - 0.01 && t < T.cut;
  root.style.display = on ? '' : 'none';
  if (!on) return false;

  // ---- zoom-through: a camera dolly (DOM scale about the focus = GL camera move)
  const zu = prog(t, T.zoom, T.cut - 0.02);
  const k = Math.exp(Math.log(300) * Math.pow(zu, 2.35));
  const zx = SLOT.cx + glyph.dx, zy = SLOT.cy + glyph.dy;
  if (k > 1.0001) C.worldT = `translate(${zx}px, ${zy}px) scale(${k}) translate(${-zx}px, ${-zy}px)`;
  root.style.visibility = k < 14 ? 'visible' : 'hidden';

  // ---- window fly-in from in front of the lens
  const wu = EASE_SETTLE(prog(t, T.winIn, T.winInEnd));
  win.style.transformOrigin = `${512 - WIN.x}px ${600 - WIN.y}px`;
  win.style.transform = `translateY(${(1 - wu) * 40}px) scale(${lerp(2.5, 1, wu)})`;
  win.style.filter = wu < 0.999 ? `blur(${(1 - wu) * 18}px)` : 'none';
  win.style.opacity = clamp(prog(t, T.winIn, T.winIn + 0.3)) + '';

  // ---- icon: hero -> pill slot, then sits in the pill
  let ic;
  if (t < T.pull) ic = iconAt(t);
  else {
    const hero = iconAt(HOLD_END - 0.001) || { cx: HERO.cx, cy: HERO.cy, size: HERO.size, rx: 0, ry: 0, rz: 0, envRot: 0.6 };
    const u = prog(t, T.pull, T.pullEnd);
    const e = E.inOutCubic(u);
    const arc = Math.sin(Math.PI * u) * 26;
    ic = {
      visible: true,
      cx: lerp(hero.cx, SLOT.cx, e) - arc * 0.4,
      cy: lerp(hero.cy, SLOT.cy, e) - arc,
      size: lerp(hero.size, SLOT.size, E.inOutQuart(u)),
      rx: 0.18 * Math.sin(Math.PI * u), ry: hero.ry + 0.35 * Math.sin(Math.PI * u), rz: 0,
      envRot: lerp(hero.envRot, 0.2, e),
    };
    const absorb = Math.exp(-Math.pow((t - (T.dissolve + 0.5)) / 0.2, 2));
    ic.glyphGlow = 0.86 + absorb * 0.3;
  }
  ic.zoom = k; ic.zx = zx; ic.zy = zy;
  C.icon = ic;

  // ---- the pill: extends from the icon to the right
  const hg = t < T.hudGrow ? 0 : spring(t - T.hudGrow, { freq: 2.6, damping: 0.74 });
  const hw = lerp(HUD.h, HUD.wFull, hg);
  hud.style.display = t >= T.pullEnd - 0.14 ? '' : 'none';
  hud.style.opacity = clamp(prog(t, T.pullEnd - 0.14, T.pullEnd)) + '';
  hud.style.width = hw + 'px';
  const listening = t >= T.press && t < T.release;
  const amp = speechAmp(t);
  bars.forEach((b, i) => {
    b.style.display = 88 + i * 8.5 + 10 < hw - 56 ? '' : 'none';
    const n = noise1(t * 11 + i * 1.7) * 0.5 + 0.5;
    const shape = Math.sin(Math.PI * (i + 0.5) / bars.length);
    let h = 4;
    if (listening) h = 4 + amp * (6 + 26 * n * (0.45 + 0.55 * shape)) + 2 * n;
    else if (t >= T.release) h = 4 + Math.max(0, 1 - (t - T.release) / 0.2) * 6 * n;
    b.style.height = h + 'px';
    b.style.top = (HUD.h / 2 - h / 2) + 'px';
    b.style.opacity = (listening || t >= T.release ? 1 : 0.35) * clamp(prog(t, T.hudGrow + 0.1, T.hudGrow + 0.3)) + '';
  });
  const secs = listening ? Math.floor(t - T.press) : t >= T.release ? Math.floor(T.release - T.press) : 0;
  timer.textContent = `0:0${Math.min(9, secs)}`;
  timer.style.opacity = clamp(prog(t, T.hudGrow + 0.18, T.hudGrow + 0.36)) + '';
  const sh = prog(t, T.release + 0.02, T.dissolve + 0.1);
  shimmer.style.left = lerp(-140, HUD.wFull + 20, E.inOutCubic(sh)) + 'px';
  shimmer.style.display = sh > 0 && sh < 1 ? '' : 'none';
  hudFill.style.boxShadow = listening
    ? `inset 0 1px 0 ${ink(0.09)}, inset 0 0 0 1px ${ac(0.15, 0.42)}`
    : `inset 0 1px 0 ${ink(0.09)}, inset 0 0 0 1px ${ink(0.11)}`;

  // ---- the key: springs up, held down while the input streams
  if (key) {
    const kin = t < T.keyIn ? 0 : spring(t - T.keyIn, { freq: 2.4, damping: 0.62 });
    key.style.display = t >= T.keyIn ? '' : 'none';
    const pressA = t >= T.press ? E.outCubic(prog(t, T.press, T.press + 0.06)) : 0;
    const relA = t >= T.release ? E.outCubic(prog(t, T.release, T.release + 0.08)) : 0;
    const down = pressA * (1 - relA);
    key.style.transform = `translateY(${(1 - kin) * 70}px) scale(${lerp(0.82, 1, kin)})`;
    key.style.opacity = clamp(prog(t, T.keyIn, T.keyIn + 0.12)) + '';
    keyTop.style.transform = `translateY(${down * 6}px)`;
    keyGlow.style.opacity = (down * (0.78 + 0.22 * Math.sin(t * 9))) + '';
  }

  // ---- words
  const bx = BODY.x, by = BODY.y;
  let lastX = bx, lastY = by;
  for (const tk of TOKENS) {
    tk.el.style.display = 'none';
    if (tk.el2) tk.el2.style.display = 'none';
    if (tk.strike) tk.strike.style.display = 'none';
    if (tk.novo) {
      // only in the result: fades in at its place while the others close ranks
      const nu = EASE_SETTLE(prog(t, T.flip + 0.12 + tk.k * 0.028, T.flip + 0.62 + tk.k * 0.028));
      if (nu <= 0) continue;
      const x = bx + tk.p1.x, y = by + tk.p1.y;
      tk.el.style.display = '';
      Object.assign(tk.el.style, { left: x + 'px', top: (y + (1 - nu) * 6) + 'px', opacity: nu + '', color: rgb(PAL.ink), filter: nu < 0.99 ? `blur(${(1 - nu) * 5}px)` : 'none' });
      if (tk === lastClean) { lastX = x + tk.wc; lastY = y; }
      continue;
    }
    if (t < tk.at) continue;
    const a = clamp((t - tk.at) / 0.08);
    let x = bx + tk.p0.x, y = by + tk.p0.y;
    let col = RAW, alpha = a, visible = true;
    const blur = (1 - a) * 5;
    if (tk.f) {
      const hl = prog(t, T.highlight + tk.j * 0.045, T.highlight + tk.j * 0.045 + 0.12);
      col = mixc(RAW, EMBER, hl);
      const st = E.outCubic(prog(t, T.highlight + 0.1 + tk.j * 0.045, T.highlight + 0.26 + tk.j * 0.045));
      if (st > 0 && t < T.dissolve) {
        tk.strike.style.display = '';
        Object.assign(tk.strike.style, { left: (x - 2) + 'px', top: (y + BODY.size * 0.5) + 'px', width: ((tk.w + 4) * st) + 'px' });
      }
      if (t >= T.dissolve) visible = false;
      else { lastX = x + tk.w; lastY = y; }
    } else {
      const fu = EASE_SETTLE(prog(t, T.flip + tk.k * 0.028, T.flip + tk.k * 0.028 + 0.62));
      x = lerp(x, bx + tk.p1.x, fu); y = lerp(y, by + tk.p1.y, fu);
      col = mixc(RAW, PAL.ink, prog(t, T.flip, T.flip + 0.5));
      let w = tk.w;
      if (tk.el2) {
        const cf = prog(t, T.flip + 0.05, T.flip + 0.25);
        tk.el2.style.display = '';
        Object.assign(tk.el2.style, { left: x + 'px', top: y + 'px', opacity: cf * alpha + '', color: rgb(col) });
        alpha *= 1 - cf;
        w = lerp(tk.w, tk.wc, cf);
      }
      lastX = x + w; lastY = y;
    }
    if (visible) {
      tk.el.style.display = '';
      Object.assign(tk.el.style, { left: x + 'px', top: y + 'px', opacity: alpha + '', color: rgb(col), filter: blur > 0.05 ? `blur(${blur}px)` : 'none' });
    }
  }
  // the punctuation lands after the last word of the result
  if (t >= T.period && period.textContent) {
    const lx = bx + lastClean.p1.x + (lastClean.novo || lastClean.clean != null ? lastClean.wc : lastClean.w);
    const ly = by + lastClean.p1.y;
    const pu = spring(t - T.period, { freq: 3, damping: 0.6 });
    period.style.display = '';
    Object.assign(period.style, { left: lx + 'px', top: ly + 'px', color: rgb(PAL.ink), transform: `translateY(${(1 - pu) * -10}px)`, opacity: clamp((t - T.period) / 0.05) + '' });
    lastX = lx + 8; lastY = ly;
  } else period.style.display = 'none';
  // caret at the insertion point: blinks while idle, solid while text arrives or moves
  const typing = t >= T.press && t < T.flip + 0.7;
  const blink = typing || (Math.floor((t - T.winInEnd) / 0.5) % 2 === 0);
  caret.style.display = t >= T.winInEnd - 0.1 && blink ? '' : 'none';
  Object.assign(caret.style, { left: (lastX + 3) + 'px', top: (lastY - 4 * BODY.size / 33) + 'px' });

  // ---- pixel dissolve: burst, then a curved flight into the icon
  if (t >= T.dissolve && t < T.dissolve + 1.2 && k < 2) {
    const fx = C.fx;
    const e0 = acc(0.06), e1 = acc(0.62);
    for (const tk of TOKENS) {
      if (!tk.f) continue;
      const ox = bx + tk.p0.x, oy = by + tk.p0.y + BODY.size * 0.82;
      for (const p of tk.parts) {
        const lt = (t - T.dissolve - p.d) / (0.55 + p.r3 * 0.25);
        if (lt > 1) continue;
        const sx = ox + p.x, sy = oy + p.y;
        if (lt < 0) {
          // still part of the word: an accent pixel in place, shimmering a little before it lets go
          const shv = 0.75 + 0.25 * Math.sin((t * 60 + p.r1 * 40));
          fx.fillStyle = rgb(e0, shv);
          fx.fillRect(sx - 0.9, sy - 0.9, 1.8, 1.8);
          continue;
        }
        const cx1 = sx + (p.r1 - 0.5) * 80, cy1 = sy - 24 - p.r2 * 70;
        const e = E.inOutCubic(lt);
        const qx = (1 - e) * (1 - e) * sx + 2 * (1 - e) * e * cx1 + e * e * SLOT.cx;
        const qy = (1 - e) * (1 - e) * sy + 2 * (1 - e) * e * cy1 + e * e * SLOT.cy;
        const sz = lerp(2.4, 1.0, lt);
        const al = 1 - Math.pow(lt, 3);
        fx.fillStyle = rgb(mixc(acc(0.15), e1, lt), al);
        fx.fillRect(qx - sz / 2, qy - sz / 2, sz, sz);
      }
    }
  }

  // ---- white flood at the end of the dive (the whole stage)
  if (t >= T.flood) {
    const fl = prog(t, T.flood, T.cut - 0.005);
    const st = C.stage;
    C.fx.fillStyle = rgb(PAL.ink, E.inQuad(fl));
    C.fx.fillRect(-st.ox, -st.oy, st.W, st.H);
  }
  return true;
}
