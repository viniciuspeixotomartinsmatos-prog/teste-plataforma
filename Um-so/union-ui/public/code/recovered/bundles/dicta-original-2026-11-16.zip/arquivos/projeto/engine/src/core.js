// core.js — deterministic animation helpers (no wall clock anywhere: every value is a function of film time t).
export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, p) => a + (b - a) * p;
export const invlerp = (a, b, x) => (x - a) / (b - a);
/** 0..1 progress of t inside [a, b], clamped */
export const prog = (t, a, b) => clamp((t - a) / (b - a));
export const smoothstep = (a, b, x) => { const p = prog(x, a, b); return p * p * (3 - 2 * p); };

// easings (p in 0..1)
export const E = {
  linear: (p) => p,
  inQuad: (p) => p * p,
  outQuad: (p) => 1 - (1 - p) * (1 - p),
  inCubic: (p) => p * p * p,
  outCubic: (p) => 1 - Math.pow(1 - p, 3),
  inOutCubic: (p) => (p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2),
  outQuart: (p) => 1 - Math.pow(1 - p, 4),
  inQuart: (p) => p * p * p * p,
  inOutQuart: (p) => (p < 0.5 ? 8 * p ** 4 : 1 - Math.pow(-2 * p + 2, 4) / 2),
  outQuint: (p) => 1 - Math.pow(1 - p, 5),
  inQuint: (p) => p ** 5,
  inOutQuint: (p) => (p < 0.5 ? 16 * p ** 5 : 1 - Math.pow(-2 * p + 2, 5) / 2),
  outExpo: (p) => (p >= 1 ? 1 : 1 - Math.pow(2, -10 * p)),
  inExpo: (p) => (p <= 0 ? 0 : Math.pow(2, 10 * p - 10)),
  inOutExpo: (p) => (p <= 0 ? 0 : p >= 1 ? 1 : p < 0.5 ? Math.pow(2, 20 * p - 10) / 2 : (2 - Math.pow(2, -20 * p + 10)) / 2),
  outBack: (p, s = 1.70158) => 1 + (s + 1) * Math.pow(p - 1, 3) + s * Math.pow(p - 1, 2),
  inOutSine: (p) => -(Math.cos(Math.PI * p) - 1) / 2,
};

/** CSS-style cubic-bezier easing */
export function bezier(x1, y1, x2, y2) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const sx = (t) => ((ax * t + bx) * t + cx) * t;
  const sy = (t) => ((ay * t + by) * t + cy) * t;
  const dsx = (t) => (3 * ax * t + 2 * bx) * t + cx;
  return (x) => {
    if (x <= 0) return 0; if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) { const d = sx(t) - x; if (Math.abs(d) < 1e-6) break; const s = dsx(t); if (Math.abs(s) < 1e-6) break; t -= d / s; }
    let lo = 0, hi = 1;
    for (let i = 0; i < 30 && Math.abs(sx(t) - x) > 1e-6; i++) { if (sx(t) < x) lo = t; else hi = t; t = (lo + hi) / 2; }
    return sy(t);
  };
}
// house curves: a confident ease-out (fast start, long settle) and a "snap" for UI pops
export const EASE_SETTLE = bezier(0.16, 1, 0.3, 1);
export const EASE_SNAP = bezier(0.2, 0.9, 0.1, 1);
export const EASE_SWEEP = bezier(0.65, 0, 0.35, 1);

/** critically/under-damped spring step response: 0 -> 1, time in seconds */
export function spring(time, { freq = 2.2, damping = 0.55 } = {}) {
  if (time <= 0) return 0;
  const w = 2 * Math.PI * freq, z = damping;
  if (z >= 1) return 1 - Math.exp(-w * time) * (1 + w * time);
  const wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * time) * (Math.cos(wd * time) + (z * w / wd) * Math.sin(wd * time));
}

/** deterministic hash noise */
export function hash(n) { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453123; return s - Math.floor(s); }
export function rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 1e9) / 1e9; }; }
export function noise1(x) { const i = Math.floor(x), f = x - i; const u = f * f * (3 - 2 * f); return lerp(hash(i), hash(i + 1), u) * 2 - 1; }

// colours
export const hex = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
export const rgb = (c, a = 1) => `rgba(${Math.round(c[0])},${Math.round(c[1])},${Math.round(c[2])},${a})`;
export const mixc = (a, b, p) => [lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)];

// ---- palette: every colour of the film comes from the config (cores.fundo, cores.texto, cores.acento) through PAL.
// The film was designed on pure black, white and one accent; the accent family (lighter, deeper, pale) is derived here.
export const PAL = { bg: [0, 0, 0], ink: [255, 255, 255], acc: [255, 90, 54] };
const hexOk = (h) => typeof h === 'string' && /^#[0-9a-f]{6}$/i.test(h.trim());
export function setPalette(cores = {}) {
  PAL.bg = hexOk(cores.fundo) ? hex(cores.fundo.trim()) : [0, 0, 0];
  PAL.ink = hexOk(cores.texto) ? hex(cores.texto.trim()) : [255, 255, 255];
  PAL.acc = hexOk(cores.acento) ? hex(cores.acento.trim()) : [255, 90, 54];
  const W = PAL.ink, A = PAL.acc, B = PAL.bg;
  // the exit fade: text colour -> tinted -> accent -> deep accent -> background (~0.8 s), as measured on the design
  PAL.fade = [
    [0.0, W],
    [0.14, mixc(W, A, 0.11)],
    [0.33, mixc(W, A, 0.45)],
    [0.52, mixc(mixc(A, [0, 0, 0], 0.1), W, 0.12)],
    [0.70, mixc(B, A, 0.58)],
    [0.86, mixc(B, A, 0.26)],
    [1.0, B],
  ];
}
/** accent mixed toward white (w > 0) or black (w < 0), as an rgba string */
export function ac(w = 0, a = 1) {
  const c = w >= 0 ? mixc(PAL.acc, [255, 255, 255], w) : mixc(PAL.acc, [0, 0, 0], -w);
  return rgb(c, a);
}
export const acc = (w = 0) => (w >= 0 ? mixc(PAL.acc, [255, 255, 255], w) : mixc(PAL.acc, [0, 0, 0], -w));
/** text colour with alpha */
export const ink = (a = 1) => rgb(PAL.ink, a);
/** a surface just above the background (window fills): k = how far toward the text colour */
export const surf = (k, a = 1) => rgb(mixc(PAL.bg, mixc(PAL.ink, [235, 235, 255], 0.5), k), a);
export function emberFade(p) {
  p = clamp(p);
  const S = PAL.fade;
  for (let i = 1; i < S.length; i++) {
    const [b, cb] = S[i];
    const [a, ca] = S[i - 1];
    if (p <= b) return mixc(ca, cb, (p - a) / (b - a));
  }
  return PAL.bg;
}

export const FONT = {
  display: "'Marca', 'Inter', system-ui, sans-serif",
  ui: "'Inter', system-ui, sans-serif",
  mono: "'Geist Mono', ui-monospace, monospace",
};

/** DOM helper */
export function el(tag, cls, parent, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  if (parent) parent.appendChild(e);
  return e;
}
export function show(e, on) { e.style.display = on ? '' : 'none'; }
