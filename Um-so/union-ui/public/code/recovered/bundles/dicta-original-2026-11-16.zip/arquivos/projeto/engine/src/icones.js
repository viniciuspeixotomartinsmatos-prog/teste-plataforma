// icones.js — lucide icons (ISC, lucide.dev) by kebab-case name, from engine/lucide.js. A name that does not exist
// becomes a neutral dot icon and a warning in the render log (fix the name: grep '"name"' engine/lucide.js).
const warned = new Set();
export function lucide(name, size = 20, color = 'currentColor', sw = 1.8) {
  const all = window.LUCIDE_ALL || {};
  let inner = all[name];
  if (!inner) {
    if (name && !warned.has(name)) { console.warn('ícone desconhecido: ' + name); warned.add(name); }
    inner = '<circle cx="12" cy="12" r="3"/>';
  }
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" style="display:block">${inner}</svg>`;
}
