// gancho — cold open in silence: the problem. Line 1 arrives whole words at a time; line 2 is typed one key at a time
// (with an optional typo and a backspace). The text caret stays behind: it is about to turn out to be the edge of the
// app icon (giro).
// Config: { "tipo": "gancho", "linha1": "Thoughts are fast.", "linha2": "Typing isn't.", "erro": 4 }
import { el, prog, rgb, PAL, FONT } from '../core.js';
import { makeLine, exitColor, fitSize } from '../type.js';
import { S, cue } from '../timeline.js';

const SIZE = 58, MAXW = 860;
const Y1 = 458, Y2 = 548;
export const CARET = { w: 4.5, h: 66, cx: 512, cy: Y2 + 2 }; // read by giro
let G, line1, l2, l2text, caret, size;

function typedAt(t) {
  let s = '';
  for (const [k, key] of G.keys) {
    if (t < k) break;
    s = key === 'BS' ? s.slice(0, -1) : s + key;
  }
  return s;
}

export function init(C) {
  G = S.P.gancho;
  // one size for both lines: the largest that fits the longer one
  size = Math.min(fitSize(C.type, G.w1.join(' '), SIZE, MAXW), fitSize(C.type, G.l2 + '  ', SIZE, MAXW));
  size = Math.max(size, 34);
  line1 = makeLine(C.type, G.w1.map((w) => ({ text: w })), { y: Y1 + (SIZE - size) * 0.3, size, weight: 500, maxW: MAXW + 40 });
  const y2 = Y2 - (SIZE - size) * 0.3;
  l2 = el('div', 'line', C.type);
  Object.assign(l2.style, { fontSize: size + 'px', fontWeight: 500, fontFamily: FONT.display, letterSpacing: '-0.012em', lineHeight: '1', top: (y2 - size * 0.5) + 'px', height: size + 'px' });
  l2text = el('span', '', l2);
  l2text.textContent = G.l2;
  const w = l2text.getBoundingClientRect().width;
  const gap = 4 * size / SIZE;
  CARET.w = 4.5 * size / SIZE; CARET.h = 66 * size / SIZE;
  const x0 = Math.round(512 - (w + gap + CARET.w) / 2);
  l2.style.left = x0 + 'px';
  caret = el('div', 'abs', C.type);
  Object.assign(caret.style, { width: CARET.w + 'px', height: CARET.h + 'px', borderRadius: CARET.w / 2 + 'px', background: rgb(PAL.ink) });
  CARET.x0 = x0; CARET.gap = gap;
  CARET.cx = x0 + w + gap + CARET.w / 2;
  CARET.cy = y2 + 2;
  G.words.forEach((tt, i) => cue(tt, `gancho:palavra:${i}`, 'tick', G.w1[i]));
  G.keys.forEach(([tt, k], i) => cue(tt, `gancho:tecla:${i}`, k === 'BS' ? 'backspace' : k === ' ' ? 'space' : 'key', k));
}

export function render(t, C) {
  const on = t < G.handoff + 0.02;
  line1.show(on); l2.style.display = on ? '' : 'none'; caret.style.display = on ? '' : 'none';
  if (!on) return false;
  G.words.forEach((a, i) => line1.setOn(i, t >= a));
  const fadeC = exitColor(t, G.fadeA, G.fadeDur);
  line1.color(fadeC);
  l2.style.color = rgb(fadeC);
  const s = typedAt(t);
  l2text.textContent = s;
  // caret: after the typed text; solid while typing, visible from caretOn
  const w = s ? l2text.getBoundingClientRect().width : 0;
  const cx = CARET.x0 + w + CARET.gap + CARET.w / 2;
  // thicken + brighten right before the hand-off to the 3D edge
  const th = prog(t, G.handoff - 0.1, G.handoff);
  const cw = CARET.w + th * CARET.w;
  caret.style.left = (cx - cw / 2) + 'px';
  caret.style.top = (CARET.cy - CARET.h / 2) + 'px';
  caret.style.width = cw + 'px';
  caret.style.borderRadius = cw / 2 + 'px';
  caret.style.visibility = t >= G.caretOn && t < G.handoff ? 'visible' : 'hidden';
  return true;
}
