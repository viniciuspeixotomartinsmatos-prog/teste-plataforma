// timeline.js — the film's clock, built from the config (filmes/<nome>.json) and the music (audio/trilha/trilha.json).
// Everything is in seconds of film time. The film has three parts:
//   1. a cold open in silence (gancho: the problem line arrives, the second line is typed);
//   2. the music's intro, from the moment the text caret flips into the app icon (giro) until the cut to the brand
//      (demo: the product turns a messy input into a clean result, then the camera dives into the icon);
//   3. the groove, counted in beats from the music's drop: marca, usos, slogan, variacoes, fecho (logo + call).
// Fixed moves keep their measured length; the parts that depend on the content (letters typed, words of the input)
// stretch, and the intro is rounded to whole beats so the music always starts on a beat.

export const S = { cfg: null, P: null }; // filled by plan(); read by every shot

export const CUES = [];
export const cue = (t, id, kind, note = '') => { CUES.push({ t: +t.toFixed(4), id, kind, note }); return t; };

export const ORDEM = ['gancho', 'giro', 'demo', 'marca', 'usos', 'slogan', 'variacoes', 'fecho'];
export const OBRIGATORIAS = ['gancho', 'giro', 'demo', 'marca', 'fecho'];

/** the scene object of the config (or null when the scene is off). Mandatory scenes always exist ({} if missing). */
export function cena(cfg, tipo) {
  const c = (cfg.cenas || []).find((x) => x.tipo === tipo);
  if (c && c.ativa === false && !OBRIGATORIAS.includes(tipo)) return null;
  if (!c) return OBRIGATORIAS.includes(tipo) ? { tipo } : null;
  return c;
}

/** "[um] [so] let's>Let's move the launch +today Thursday" -> tokens
 *  [x] = only in the raw input (struck and dissolved) · a>B = shown as a, cleaned to B · +B = only in the clean result
 *  "_" inside a token is a space (a token is one block that moves together). */
export function parseEntrada(s) {
  const out = [];
  for (const raw of String(s || '').trim().split(/\s+/).filter(Boolean)) {
    const sp = (x) => x.replace(/_/g, ' ');
    if (/^\[.*\]$/.test(raw)) out.push({ raw: sp(raw.slice(1, -1)), f: 1 });
    else if (raw.startsWith('+') && raw.length > 1) out.push({ raw: '', clean: sp(raw.slice(1)), novo: 1 });
    else if (raw.includes('>')) { const [a, b] = raw.split('>'); out.push({ raw: sp(a), clean: sp(b) }); }
    else out.push({ raw: sp(raw) });
  }
  return out;
}

// the measured keystroke rhythm of the typed line (seconds between keys), repeated
const KEY_GAPS = [0.12, 0.13, 0.15, 0.11, 0.15, 0.12, 0.15, 0.13, 0.11, 0.14, 0.12, 0.11, 0.13];

export function plan(cfg, trilha) {
  const beat = 60 / trilha.bpm;
  const P = { fps: cfg.fps || 30, beat, blur: [] };
  const blur = (a, b, k50, why) => P.blur.push({ a, b, k50, why });

  // ---- 1. gancho: line 1 word by word, line 2 typed (with an optional typo + backspace)
  const g = cena(cfg, 'gancho');
  const w1 = String(g.linha1 ?? '').split(/\s+/).filter(Boolean);
  const l2 = String(g.linha2 ?? '');
  const words = w1.map((_, i) => 0.40 + i * 0.18);
  const caretOn = (words.length ? words[words.length - 1] : 0.4) + 0.24;
  const speed = l2.length > 16 ? Math.max(0.72, 16 / l2.length) : 1; // long lines type a little faster
  const keys = [];
  let t = caretOn + 0.15, gi = 0;
  const erro = Number.isInteger(g.erro) && g.erro > 0 && g.erro < l2.length - 1 && l2[g.erro] !== ' ' && l2[g.erro + 1] !== ' ' ? g.erro : -1;
  for (let i = 0; i < l2.length; i++) {
    if (i === erro) {
      keys.push([t, l2[i + 1]]); t += 0.32 * speed;            // the wrong key, a pause, then backspace
      keys.push([t, 'BS']); t += 0.15 * speed;
    }
    keys.push([t, l2[i]]);
    if (i < l2.length - 1) t += KEY_GAPS[gi++ % KEY_GAPS.length] * speed;
  }
  const lastKey = keys.length ? keys[keys.length - 1][0] : caretOn;
  P.gancho = { words, w1, l2, keys, caretOn, fadeA: lastKey + 0.12, fadeDur: 0.42, handoff: lastKey + 0.50 };

  // ---- 2. giro + demo (the music's intro)
  const A = P.gancho.handoff;
  const LAND = A + 3 * beat;
  P.giro = { A, LAND, HOLD_END: LAND + 0.533 };
  blur(A, A + 1.6, 8, 'icon spin'); blur(A + 1.62, LAND + 0.25, 4, 'spin settle');
  const d = cena(cfg, 'demo');
  const toks = parseEntrada(d.entrada ?? '');
  if (!toks.some((t) => !t.f)) throw new Error('demo: o campo "entrada" precisa de pelo menos uma palavra que fica no resultado');
  if (!toks.some((t) => !t.novo)) throw new Error('demo: a "entrada" precisa de pelo menos uma palavra que aparece antes de limpar');
  const P0 = P.giro.HOLD_END;
  const T = { pull: P0, pullEnd: P0 + 0.82, winIn: P0 + 0.06, winInEnd: P0 + 0.88, hudGrow: P0 + 0.82, keyIn: P0 + 0.90, press: P0 + 1.22 };
  let at = T.press + 0.14, prev = null;
  for (const tk of toks) {
    if (tk.novo) continue;
    if (prev) {
      const r = prev.raw;
      at += 0.12 + 0.02 * Math.min(10, r.length) + (/…$/.test(r) ? 0.18 : /[,.;:!?]$/.test(r) ? 0.08 : 0) + (prev.pausa || 0);
    }
    tk.at = at; prev = tk;
  }
  // release, then the fixed ending of the demo (2.302 s: strike, dissolve, close ranks, dive), rounded to whole beats
  let release = at + 0.34;
  let cut = release + 2.302;
  const n = Math.ceil((cut - A) / beat - 0.04);
  release += A + n * beat - cut;
  cut = A + n * beat;
  Object.assign(T, {
    release, highlight: release + 0.18, dissolve: release + 0.498, flip: release + 0.658, period: release + 1.138,
    zoom: cut - 0.675, flood: cut - 0.06, cut,
  });
  P.demo = { T, toks };
  blur(T.pull - 0.02, T.pull + 0.9, 6, 'pull-back + window fly-in');
  blur(T.zoom, T.zoom + 0.32, 12, 'zoom-through (early)'); blur(T.zoom + 0.34, cut, 28, 'zoom-through (fast end)');

  // ---- 3. the groove, in beats from the drop
  const drop = cut + (trilha.drop - trilha.entrada);
  P.cut = cut; P.drop = drop;
  let cur = drop + 4 * beat;
  P.marca = { a: cut, b: cur - 0.2, at: [0, 1, 2, 3].map((i) => cut + i * beat / 2), exit: cur - 1.02 };
  if (cena(cfg, 'usos')) {
    const b = cur + 6 * beat;
    P.usos = { a: cur - 0.02, b: b - 0.04, fly: [0, 0.25, 0.5, 0.75].map((x) => cur + x * beat - 0.02),
      cap: [1, 1.5, 2].map((x) => cur + x * beat), ins: [2, 2.5, 3, 3.5].map((x) => cur + x * beat), out: b - 0.54 };
    blur(P.usos.a, P.usos.a + 0.78, 6, 'cards fly in'); blur(P.usos.b - 0.56, P.usos.b, 6, 'cards fly out');
    cur = b;
  }
  if (cena(cfg, 'slogan')) {
    const b = cur + 6 * beat;
    P.slogan = { a: cur - 0.02, b: b - 0.12, at: [0, 1, 2, 3].map((x) => cur + x * beat), exit: b - 0.88 };
    cur = b;
  }
  if (cena(cfg, 'variacoes')) {
    const b = cur + 4 * beat;
    P.variacoes = { a: cur, b: b + 0.02, eighth: beat / 2, start: cur, collapse: b - 0.2 };
    blur(b - 0.22, b + 0.02, 6, 'word collapses into the caret');
    cur = b;
  }
  const k = beat / 0.625; // the logo build was timed at 96 BPM: it follows the tempo
  const L = { a: cur - 0.14, caret: cur - 0.01, arc1: cur + 0.16 * k, step: 0.26 * k, arcDur: 0.42, slide: cur + 0.95 * k,
    slideDur: 0.85, word: cur + 1.55 * k, wordDur: 0.8, hit: cur + 4 * beat };
  L.cut = L.hit + 2.0;
  P.fecho = L;
  blur(L.slide, L.slide + 0.9, 4, 'logo slide');
  P.end = L.cut + 0.52;
  P.total = Math.round(P.end * P.fps);

  // ---- the music edit (read by tools/trilha.py): intro (filtered) -> groove -> the track's own ending hit
  P.musica = {
    inicio: A,                                   // film time the music starts (on a beat)
    trilhaInicio: trilha.entrada - (cut - A),     // track time at that moment
    entrada: cut, drop, fim: L.hit,               // film times
    abre: T.zoom - 0.6,                           // the intro's filter starts opening (the dive)
  };
  S.cfg = cfg; S.P = P;
  return P;
}
