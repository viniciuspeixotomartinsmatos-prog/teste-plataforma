// marca.js — the brand symbol from the config (marca.simbolo: an SVG file of one colour, filled shapes).
// Each top-level shape of the SVG is a "part". Optional:
//   marca.ancora = index of the part that is a vertical bar (a text caret, a letter stem): the film's caret becomes it
//                  in the logo, and the dive in the demo aims at it. Without it, the caret sits at the symbol's centre.
//   marca.onda   = { cx, cy, r, ang, sw } in the SVG's units: the "signal" wave that leaves the mark on the music's
//                  drop (an arc around (cx, cy), half-angle ang in degrees). Without it, a ring around the symbol.
// One parsed definition feeds the inline SVGs (lockup, logo, cards) and the 3D glyph of the app icon.

const NS = 'http://www.w3.org/2000/svg';
const DRAW = ['path', 'rect', 'circle', 'ellipse', 'polygon', 'polyline', 'line', 'g'];

export const MARCA = { svgText: '', viewBox: [0, 0, 100, 100], parts: [], box: null, anchor: null, onda: null, ancoraIdx: null };

export async function loadMarca(cfg, base = '/') {
  const m = cfg.marca || {};
  const url = base + (m.simbolo || 'midia/demo/simbolo.svg');
  const r = await fetch(url);
  if (!r.ok) throw new Error('símbolo não encontrado: ' + (m.simbolo || ''));
  const text = await r.text();
  const doc = new DOMParser().parseFromString(text, 'image/svg+xml');
  const svg = doc.querySelector('svg');
  if (!svg) throw new Error('o símbolo não é um SVG: ' + m.simbolo);
  let vb = (svg.getAttribute('viewBox') || '').split(/[\s,]+/).map(Number);
  if (vb.length !== 4 || vb.some(isNaN)) vb = [0, 0, parseFloat(svg.getAttribute('width')) || 100, parseFloat(svg.getAttribute('height')) || 100];
  const parts = [...svg.children].filter((e) => DRAW.includes(e.localName));
  // measure every part (attached, hidden) to get the ink boxes
  const host = document.createElementNS(NS, 'svg');
  host.setAttribute('viewBox', vb.join(' '));
  Object.assign(host.style, { position: 'absolute', left: '-9999px', top: '0', width: '200px', height: '200px', visibility: 'hidden' });
  document.body.appendChild(host);
  MARCA.parts = parts.map((p) => {
    const c = document.importNode(p, true);
    host.appendChild(c);
    const b = c.getBBox();
    const stroked = (c.getAttribute('stroke') && c.getAttribute('stroke') !== 'none') || /stroke\s*:/.test(c.getAttribute('style') || '');
    const sw = stroked ? parseFloat(c.getAttribute('stroke-width') || '1') : 0;
    return { html: p.outerHTML, box: { x0: b.x - sw / 2, y0: b.y - sw / 2, x1: b.x + b.width + sw / 2, y1: b.y + b.height + sw / 2 } };
  });
  host.remove();
  if (!MARCA.parts.length) throw new Error('o símbolo não tem nenhuma forma: ' + m.simbolo);
  const B = MARCA.parts.reduce((a, p) => ({ x0: Math.min(a.x0, p.box.x0), y0: Math.min(a.y0, p.box.y0), x1: Math.max(a.x1, p.box.x1), y1: Math.max(a.y1, p.box.y1) }),
    { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity });
  B.w = B.x1 - B.x0; B.h = B.y1 - B.y0; B.cx = (B.x0 + B.x1) / 2; B.cy = (B.y0 + B.y1) / 2;
  MARCA.svgText = text; MARCA.viewBox = vb; MARCA.box = B;
  const ai = Number.isInteger(m.ancora) && MARCA.parts[m.ancora] ? m.ancora : null;
  MARCA.ancoraIdx = ai;
  if (ai != null) {
    const a = MARCA.parts[ai].box;
    MARCA.anchor = { cx: (a.x0 + a.x1) / 2, cy: (a.y0 + a.y1) / 2, w: a.x1 - a.x0, h: a.y1 - a.y0, part: ai };
  } else {
    // no bar in the symbol: the film's caret stands at the centre, 62 % of the symbol's height
    MARCA.anchor = { cx: B.cx, cy: B.cy, w: Math.max(B.h * 0.09, 1), h: B.h * 0.62, part: null };
  }
  const o = m.onda;
  MARCA.onda = o && isFinite(o.cx) && isFinite(o.r)
    ? { cx: o.cx, cy: o.cy, r: o.r, ang: o.ang ?? 50, sw: o.sw ?? Math.max(B.w, B.h) * 0.14 }
    : { cx: B.cx, cy: B.cy, r: Math.max(B.w, B.h) * 0.56, ang: 180, sw: Math.max(B.w, B.h) * 0.08 };
  return MARCA;
}

/** a part's markup recoloured: fills and strokes that are not "none" take the colour */
export function partHTML(i, color) {
  return recolor(MARCA.parts[i].html, color);
}
function recolor(html, color) {
  return html
    .replace(/fill="(?!none)[^"]*"/g, `fill="${color}"`)
    .replace(/stroke="(?!none)[^"]*"/g, `stroke="${color}"`)
    .replace(/(fill|stroke)\s*:\s*(?!none)[^;"]+/g, `$1:${color}`);
}

/** the viewBox of the ink with a small margin (2 % of the larger side, as the design did) */
export function inkViewBox(pad = null) {
  const B = MARCA.box;
  const p = pad ?? Math.max(B.w, B.h) * 0.028;
  return { x: B.x0 - p, y: B.y0 - p, w: B.w + 2 * p, h: B.h + 2 * p, pad: p };
}

/** the whole symbol as an SVG string, cropped to its ink (fill = colour) */
export function markSVG(color = '#fff', { parts = null } = {}) {
  const v = inkViewBox();
  const body = MARCA.parts.map((p, i) => {
    const a = parts ? parts[i] ?? 1 : 1;
    if (a <= 0) return '';
    const h = recolor(p.html, color);
    // shapes without any fill attribute inherit the root fill
    return a < 1 ? `<g opacity="${a}">${h}</g>` : h;
  }).join('');
  return `<svg xmlns="${NS}" viewBox="${v.x} ${v.y} ${v.w} ${v.h}" fill="${color}">${body}</svg>`;
}
