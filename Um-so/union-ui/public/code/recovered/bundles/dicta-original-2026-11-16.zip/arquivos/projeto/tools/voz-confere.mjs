// voz-confere.mjs — transcreve cada fala pronta (ElevenLabs Speech to Text) e mostra ao lado do texto do config,
// para conferir o que a voz disse sem ouvir: nome da marca, palavras engolidas, pronúncia trocada.
//   node tools/voz-confere.mjs <filme> [--so gancho,fecho]
// Usa a mesma chave do voz-elevenlabs.mjs (ELEVENLABS_API_KEY ou XI_API_KEY, no ambiente ou no .env/.env.local).
// Custa pouco (alguns segundos de transcrição por fala). Lê audio/voz/<filme>/proc/<tipo>.wav (rode tools/voz.mjs antes).
import fs from 'node:fs';
import path from 'node:path';
import { RAIZ, args, lerFilme } from './comum.mjs';

const { pos, opt } = args();
const nome = pos[0];
if (!nome) { console.log('uso: node tools/voz-confere.mjs <filme> [--so tipo,tipo]'); process.exit(1); }
const cfg = lerFilme(nome);
let KEY = process.env.ELEVENLABS_API_KEY || process.env.XI_API_KEY;
for (const f of ['.env', '.env.local']) {
  const envf = path.join(RAIZ, f);
  if (!KEY && fs.existsSync(envf)) KEY = (fs.readFileSync(envf, 'utf8').match(/^(?:ELEVENLABS_API_KEY|XI_API_KEY)\s*=\s*"?([^"\n]+)/m) || [])[1];
}
if (!KEY) { console.log('falta a chave: ELEVENLABS_API_KEY no ambiente ou no .env da raiz do projeto'); process.exit(1); }
const so = opt.so ? String(opt.so).split(',') : null;
const dir = path.join(RAIZ, 'audio/voz', cfg.vozDe || nome, 'proc');
const idioma = { pt: 'por', en: 'eng', es: 'spa' }[(cfg.elevenlabs || {}).idioma || 'pt'] || 'por';
const norm = t => t.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

for (const c of cfg.cenas) {
  if (!c.fala || c.ativa === false || (so && !so.includes(c.tipo))) continue;
  const f = path.join(dir, `${c.tipo}.wav`);
  if (!fs.existsSync(f)) { console.log(`  ${c.tipo}: sem áudio (rode tools/voz.mjs)`); continue; }
  const form = new FormData();
  form.append('model_id', 'scribe_v1');
  form.append('language_code', idioma);
  form.append('file', new Blob([fs.readFileSync(f)], { type: 'audio/wav' }), `${c.tipo}.wav`);
  const r = await fetch('https://api.elevenlabs.io/v1/speech-to-text', { method: 'POST', headers: { 'xi-api-key': KEY }, body: form });
  if (!r.ok) { console.log(`  ${c.tipo}: erro ${r.status} ${(await r.text()).slice(0, 200)}`); continue; }
  const ouvido = (await r.json()).text || '';
  const ok = norm(ouvido).replace(/ /g, '') === norm(c.fala).replace(/ /g, '');
  console.log(`${ok ? '  igual ' : '  CONFIRA'} ${c.tipo.padEnd(9)} pedido: "${c.fala}"\n${' '.repeat(18)}ouvido: "${ouvido.trim()}"`);
}
console.log('Diferença só de grafia fonética (ex.: "Cláudy" ouvido como "Claude") está certa. Palavra trocada ou faltando: gere de novo só essa fala.');
