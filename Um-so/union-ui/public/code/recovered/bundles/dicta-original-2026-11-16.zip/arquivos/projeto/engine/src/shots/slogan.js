// slogan — the promise as a text card on the groove's beats: one part per beat. The "messy" part arrives jittery
// (letters a little off their line) and snaps straight when the last part lands.
// Config: { "tipo": "slogan", "partes": ["Speak", "messy.", "Send", "clean."], "baguncada": 1 }   2 to 4 parts
import { prog, spring, hash } from '../core.js';
import { makeLine, exitColor } from '../type.js';
import { S, cue } from '../timeline.js';

let L, line, messy = [], AT;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function init(C, cfg) {
  L = S.P.slogan;
  const partes = (cfg.partes || []).slice(0, 4);
  if (partes.length < 2) throw new Error('slogan: de 2 a 4 partes');
  const bi = Number.isInteger(cfg.baguncada) ? cfg.baguncada : -1;
  AT = L.at.slice(0, partes.length);
  line = makeLine(C.type, partes.map((p, i) => (i === bi
    ? { html: [...String(p)].map((ch) => `<span class="ch" style="display:inline-block">${ch === ' ' ? '&nbsp;' : esc(ch)}</span>`).join('') }
    : { text: p })), { y: 512, size: 64, weight: 500 });
  messy = bi >= 0 && line.parts[bi] ? [...line.parts[bi].querySelectorAll('.ch')] : [];
  AT.forEach((t, i) => cue(t, `slogan:parte:${i}`, 'word', partes[i]));
  if (messy.length) cue(AT[AT.length - 1], 'slogan:encaixa', 'snap', 'the messy part snaps straight');
  cue(L.exit, 'slogan:sai', 'exit', 'tinted fade');
}

export function render(t, C) {
  const on = t >= L.a && t < L.b;
  line.show(on);
  if (!on) return false;
  AT.forEach((a, i) => line.setOn(i, t >= a));
  line.color(exitColor(t, L.exit, 0.74));
  const last = AT[AT.length - 1];
  const snap = t < last ? 0 : spring(t - last, { freq: 3.2, damping: 0.5 });
  const k = line.size / 64;
  messy.forEach((c, i) => {
    const j = 1 - snap;
    const dy = (hash(i * 3.1 + 1) - 0.5) * 14 * j * k;
    const rot = (hash(i * 7.7 + 2) - 0.5) * 16 * j;
    const dx = (hash(i * 5.3 + 3) - 0.5) * 6 * j * k;
    c.style.transform = `translate(${dx}px, ${dy}px) rotate(${rot}deg)`;
  });
  return true;
}
