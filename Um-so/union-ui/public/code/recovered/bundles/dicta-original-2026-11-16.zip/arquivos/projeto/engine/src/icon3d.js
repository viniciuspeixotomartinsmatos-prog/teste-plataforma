// icon3d.js — the app icon in three.js: a thick graphite-chrome squircle with the brand symbol raised on both faces,
// lit by an HDR studio of soft boxes so the faces flash white as it turns.
// Screen mapping: a long-lens perspective camera at z = D sees the stage (W x H CSS px) on the z = 0 plane, with the
// 1024 x 1024 composition in the middle, so an icon of size S px centred at (cx, cy) composition px is a mesh scaled
// S/2 at (cx - 512, 512 - cy, 0).
import * as THREE from 'three';
import { SVGLoader } from 'three/addons/loaders/SVGLoader.js';
import { MARCA } from './marca.js';

/** the symbol's filled shapes, centred on its ink box, y up, in the SVG's units */
function symbolShapes() {
  const data = new SVGLoader().parse(MARCA.svgText);
  const B = MARCA.box;
  const shapes = [];
  for (const p of data.paths) {
    const st = p.userData && p.userData.style;
    if (st && st.fill === 'none') continue;
    for (const sh of SVGLoader.createShapes(p)) shapes.push(sh);
  }
  // re-centre and flip: build new shapes from the transformed points (holes kept)
  const tf = (v) => new THREE.Vector2(v.x - B.cx, -(v.y - B.cy));
  const out = shapes.map((sh) => {
    const ext = sh.extractPoints(48);
    const s = new THREE.Shape(ext.shape.map(tf));
    s.holes = ext.holes.map((h) => new THREE.Path(h.map(tf)));
    return s;
  });
  return { shapes: out, box: B };
}

export const D = 4200;

function roundedRectShape(half, r) {
  const s = new THREE.Shape();
  const a = half;
  // start mid-edge and let the path close itself: no duplicated start/end point (it creased the bevel)
  s.moveTo(0, -a);
  s.lineTo(a - r, -a); s.absarc(a - r, -a + r, r, -Math.PI / 2, 0, false);
  s.lineTo(a, a - r); s.absarc(a - r, a - r, r, 0, Math.PI / 2, false);
  s.lineTo(-a + r, a); s.absarc(-a + r, a - r, r, Math.PI / 2, Math.PI, false);
  s.lineTo(-a, -a + r); s.absarc(-a + r, -a + r, r, Math.PI, 1.5 * Math.PI, false);
  return s;
}

function studio() {
  // an HDR "light studio": black room, a big key softbox upper right, a tall strip on the left (rim), a low floor
  // bounce and a cool kicker behind. Emissive values > 1 survive into the PMREM (half-float).
  const s = new THREE.Scene();
  s.background = new THREE.Color(0x000000);
  const box = (w, h, k, pos, tint = [1, 1, 1]) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }));
    m.material.color.setRGB(k * tint[0], k * tint[1], k * tint[2]);
    m.position.set(...pos); m.lookAt(0, 0, 0); s.add(m); return m;
  };
  box(7.5, 4.6, 10, [4.4, 4.2, 4.2]);         // key
  box(4.5, 3.2, 3.2, [-4.6, 3.8, 3.4], [0.95, 0.97, 1]); // fill softbox upper left
  box(1.0, 9, 4.0, [-6.2, 0.6, 1.6]);        // left rim strip
  box(9, 0.9, 1.6, [0, -5.5, 2.5]);          // floor bounce
  box(4, 4, 1.4, [-2.5, 2.5, -6], [0.85, 0.92, 1]); // back kicker
  box(1.4, 6, 2.2, [6.5, -1, -2]);           // right back strip (edge highlight when edge-on)
  box(9, 6, 0.32, [0.6, 2.2, 8.5]);          // big dim card behind the camera: graphite gradient on the face at rest
  box(0.55, 7, 5.5, [2.6, 0.4, 8.0]);        // narrow strip near the lens axis: the glint the env sweep drags across the face
  // faint dome so dark faces are never dead black
  const dome = new THREE.Mesh(new THREE.SphereGeometry(30, 32, 16), new THREE.MeshBasicMaterial({ side: THREE.BackSide }));
  dome.material.color.setRGB(0.012, 0.012, 0.014); s.add(dome);
  return s;
}

export function createIcon(canvas, W = 1024, H = 1024, dpr = 2) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true, premultipliedAlpha: true });
  renderer.setPixelRatio(dpr);
  renderer.setSize(W, H, false);
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const scene = new THREE.Scene();
  const fov = (2 * Math.atan((H / 2) / D) * 180) / Math.PI;
  const camera = new THREE.PerspectiveCamera(fov, W / H, 5, D * 3);
  camera.position.set(0, 0, D);
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(studio(), 0.0).texture;

  // geometry: body (width 2, total thickness ~0.34: a thick slab)
  const bevel = 0.07, depth = 0.2, half = 1 - bevel;
  const body = new THREE.ExtrudeGeometry(roundedRectShape(half, 0.44 - bevel * 0.6), {
    depth, bevelEnabled: true, bevelThickness: 0.07, bevelSize: bevel, bevelSegments: 10, curveSegments: 64,
  });
  body.translate(0, 0, -depth / 2);
  body.computeVertexNormals();
  const zFace = depth / 2 + 0.07;

  const faceMat = new THREE.MeshPhysicalMaterial({ color: 0x5a5a62, metalness: 1, roughness: 0.24, clearcoat: 1, clearcoatRoughness: 0.05 });
  const sideMat = new THREE.MeshPhysicalMaterial({ color: 0xd8d8de, metalness: 1, roughness: 0.14, clearcoat: 0.6, clearcoatRoughness: 0.08 });
  const bodyMesh = new THREE.Mesh(body, [faceMat, sideMat]);

  // glyph on both faces
  const { shapes, box } = symbolShapes();
  const u = Math.max(box.w, box.h) / 71.2;      // the bevels were tuned on a 71-unit-tall symbol: keep them in proportion
  const gScale = 1.12 / Math.max(box.w, box.h); // the symbol spans ~56 % of the face
  const gGeo = new THREE.ExtrudeGeometry(shapes, { depth: 1.2 * u, bevelEnabled: true, bevelThickness: 0.9 * u, bevelSize: 0.7 * u, bevelSegments: 6, curveSegments: 40 });
  gGeo.scale(gScale, gScale, gScale);
  gGeo.computeVertexNormals();
  const glyphMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.1, roughness: 0.35, emissive: 0xffffff, emissiveIntensity: 0.86 });
  glyphMat.toneMapped = false;
  const gFront = new THREE.Mesh(gGeo, glyphMat);
  gFront.position.z = zFace - 0.004;
  const gBack = new THREE.Mesh(gGeo, glyphMat);
  gBack.rotation.y = Math.PI; gBack.position.z = -zFace + 0.004;

  const icon = new THREE.Group();
  icon.add(bodyMesh, gFront, gBack);
  const pivot = new THREE.Group();
  pivot.add(icon);
  scene.add(pivot);

  // a little direct light for crisp bevel specular
  const key = new THREE.DirectionalLight(0xffffff, 1.4); key.position.set(3, 4, 6); scene.add(key);
  const rim = new THREE.DirectionalLight(0xffeee6, 0.8); rim.position.set(-5, 1, -2); scene.add(rim);

  const state = { visible: false };
  function render(st) {
    Object.assign(state, st);
    pivot.visible = !!state.visible;
    if (state.visible) {
      const S = state.size; // px
      pivot.position.set(state.cx - 512, 512 - state.cy, state.z || 0);
      pivot.scale.setScalar(S / 2);
      icon.rotation.set(state.rx || 0, state.ry || 0, state.rz || 0, 'YXZ');
      scene.environmentRotation.set(0, state.envRot || 0, 0);
      faceMat.roughness = state.faceRough ?? 0.24;
      glyphMat.emissiveIntensity = state.glyphGlow ?? 0.86;
      renderer.toneMappingExposure = state.exposure ?? 1.0;
    }
    // camera dolly for the zoom-through: towards (fx, fy) CSS px, distance from the z=0 plane = D / k
    const k = state.zoom || 1;
    const fx = (state.zx ?? 512) - 512, fy = 512 - (state.zy ?? 512);
    camera.position.set(fx * (1 - 1 / k), fy * (1 - 1 / k), D / k);
    camera.lookAt(fx * (1 - 1 / k), fy * (1 - 1 / k), 0);
    camera.near = Math.max(0.5, (D / k) * 0.02);
    camera.updateProjectionMatrix();
    renderer.render(scene, camera);
  }
  return { render, renderer, THREE };
}
