// usos — the result in many places: 2 to 4 window fragments fly in from in front of the lens (depth-of-field blur)
// and land as a grid; the same result then arrives in each, written the way that place needs it. A mini pill with the
// symbol pops on each insert. The caption lands word group by word group on the beat.
// Config: { "tipo": "usos", "legenda": ["Works", "in every", "app."],
//   "cartoes": [                                     2 to 4; each has "nome", "icone" (lucide) and one body:
//     { "nome": "Mail",  "icone": "mail", "tipo": "texto",  "titulo": "Hi Maya,", "corpo": "Let's ...", "assinatura": "Best, Sam" },
//     { "nome": "Chat",  "icone": "message-square", "tipo": "chat", "recebida": "when are we launching?", "enviada": "let's move it to thursday" },
//     { "nome": "Notes", "icone": "notebook-pen", "tipo": "lista", "titulo": "Launch plan", "itens": ["Move launch to Thursday", "..."] },
//     { "nome": "Editor","icone": "code", "tipo": "codigo", "inicio": 12, "linhas": ["// TODO: ...", "const launchDay = 'thursday';"] } ] }
import { el, prog, lerp, E, clamp, spring, EASE_SETTLE, ac, ink, surf, FONT, rgb, PAL } from '../core.js';
import { makeLine, exitColor } from '../type.js';
import { S, cue } from '../timeline.js';
import { markSVG } from '../marca.js';
import { lucide } from '../icones.js';

const CW = 404, CH = 244, GAP = 26;
const GX = 512 - CW - GAP / 2, GY = 300;
let U, CARDS, cards = [], caption, capParts, POS;

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/** a tiny syntax colouring for the code card: comments, keywords, strings */
function codeLine(s) {
  const t = String(s);
  if (/^\s*(\/\/|#|--)/.test(t)) return `<span style="color:${rgb([143, 150, 163])}">${esc(t)}</span>`;
  return esc(t)
    .replace(/(&quot;[^&]*&quot;|'[^']*'|`[^`]*`)/g, `<span style="color:${ac(0.55)}">$1</span>`)
    .replace(/\b(const|let|var|function|return|if|else|def|import|from|class|await|async|export|new|true|false|null)\b/g, `<span style="color:${ac(0.12)}">$1</span>`);
}

function body(c) {
  const tipo = c.tipo || 'texto';
  if (tipo === 'chat') {
    return { html: `<div style="display:flex;flex-direction:column;gap:12px;align-items:flex-start">
      ${c.recebida ? `<div style="font-size:18px;color:${ink(0.86)};background:${ink(0.08)};padding:9px 14px;border-radius:16px 16px 16px 5px;max-width:300px">${esc(c.recebida)}</div>` : ''}
      <div class="ins" style="align-self:flex-end;font-size:19px;color:${rgb(PAL.ink)};background:linear-gradient(180deg,${ac(0.12)},${ac(-0.06)});padding:9px 15px;border-radius:16px 16px 5px 16px;max-width:320px">${esc(c.enviada)}</div></div>`, partial: true };
  }
  if (tipo === 'lista') {
    return { html: `${c.titulo ? `<div style="font-size:21px;font-weight:600;color:${ink(1)};margin-bottom:8px">${esc(c.titulo)}</div>` : ''}
      <div style="font-size:19px;line-height:1.55;color:${ink(0.88)}">${(c.itens || []).map((x) => '• ' + esc(x)).join('<br>')}</div>` };
  }
  if (tipo === 'codigo') {
    const n0 = Number.isInteger(c.inicio) ? c.inicio : 12;
    return { html: `<div style="font-family:${FONT.mono};font-size:16.5px;line-height:1.7;color:${ink(0.86)};white-space:pre">${(c.linhas || []).map((l, i) =>
      `<span style="color:${ink(0.28)}">${n0 + i}</span>  ${codeLine(l)}`).join('<br>')}</div>` };
  }
  return { html: `<div style="font-size:20px;line-height:1.5;color:${ink(1)}">${c.titulo ? esc(c.titulo) + '<br>' : ''}${esc(c.corpo)}${c.assinatura ? `<br><span style="color:${ink(0.62)}">${esc(c.assinatura)}</span>` : ''}</div>` };
}

export function init(C, cfg) {
  U = S.P.usos;
  CARDS = (cfg.cartoes || []).slice(0, 4);
  if (CARDS.length < 2) throw new Error('usos: de 2 a 4 cartões');
  const n = CARDS.length;
  const row2 = GY + CH + GAP;
  POS = n === 4 ? [[GX, GY], [GX + CW + GAP, GY], [GX, row2], [GX + CW + GAP, row2]]
    : n === 3 ? [[GX, GY], [GX + CW + GAP, GY], [512 - CW / 2, row2]]
      : [[GX, GY + (CH + GAP) / 2], [GX + CW + GAP, GY + (CH + GAP) / 2]];
  const root = el('div', 'abs', C.world);
  Object.assign(root.style, { left: 0, top: 0, width: '1024px', height: '1024px', transformStyle: 'preserve-3d' });
  CARDS.forEach((c, i) => {
    const d = el('div', 'abs', root);
    Object.assign(d.style, {
      left: POS[i][0] + 'px', top: POS[i][1] + 'px', width: CW + 'px', height: CH + 'px', borderRadius: '18px',
      background: `linear-gradient(180deg, ${surf(0.098)} 0%, ${surf(0.067)} 100%)`,
      boxShadow: `0 30px 70px rgba(0,0,0,0.6), inset 0 1px 0 ${ink(0.07)}, 0 0 0 1px ${ink(0.08)}`,
      overflow: 'hidden', fontFamily: FONT.ui,
    });
    const head = el('div', 'abs', d, `<span style="display:inline-flex;vertical-align:-4px;margin-right:9px">${lucide(c.icone || 'app-window', 20, 'currentColor', 1.8)}</span>${esc(c.nome)}`);
    Object.assign(head.style, { left: '20px', top: '15px', fontSize: '17px', fontWeight: 500, color: ink(0.5), display: 'flex', alignItems: 'center', whiteSpace: 'nowrap', maxWidth: (CW - 40) + 'px', overflow: 'hidden' });
    head.firstChild.style.display = 'inline-flex';
    const hr = el('div', 'abs', d); Object.assign(hr.style, { left: 0, right: 0, top: '50px', height: '1px', background: ink(0.07) });
    const b = body(c);
    const bd = el('div', 'abs', d, b.html);
    Object.assign(bd.style, { left: '22px', right: '22px', top: '68px', transformOrigin: '0 0' });
    // fit: the body scales down (to 72 %) until it fits above the pill
    const room = CH - 68 - 48;
    const h0 = bd.scrollHeight, w0 = bd.scrollWidth;
    const sc = Math.max(0.72, Math.min(1, room / h0, (CW - 44) / w0));
    if (sc < 1) { bd.style.transform = `scale(${sc})`; bd.style.width = ((CW - 44) / sc) + 'px'; bd.style.right = 'auto'; }
    if (h0 * sc > room + 30) console.warn(`usos: o cartão "${c.nome}" tem texto demais (corte o texto)`);
    const target = b.partial ? bd.querySelector('.ins') : bd;
    // mini pill
    const pill = el('div', 'abs', d);
    Object.assign(pill.style, { right: '14px', bottom: '14px', height: '30px', width: '86px', borderRadius: '15px', background: surf(0.115, 0.98), boxShadow: `inset 0 0 0 1px ${ink(0.12)}`, display: 'flex', alignItems: 'center', gap: '5px', paddingLeft: '10px', boxSizing: 'border-box' });
    pill.innerHTML = `<span style="width:13px;height:15px;display:inline-block;margin-right:4px">${markSVG(rgb(PAL.ink))}</span>` +
      [10, 16, 8, 14, 6, 12].map((h) => `<span style="width:3px;height:${h}px;border-radius:2px;background:${ac(0.06)};display:inline-block"></span>`).join('');
    pill.querySelector('svg').style.width = '13px'; pill.querySelector('svg').style.height = '15px';
    cards.push({ d, body: bd, target, pill });
  });
  const leg = Array.isArray(cfg.legenda) ? cfg.legenda : String(cfg.legenda ?? '').split('|');
  capParts = leg.slice(0, 3);
  const words = [];
  capParts.forEach((p, gi) => String(p).split(/\s+/).filter(Boolean).forEach((w) => words.push({ text: w, g: gi })));
  caption = makeLine(C.type, words.map((w) => ({ text: w.text })), { y: 198, size: 50, weight: 500 });
  caption.groups = words.map((w) => w.g);
  U.fly.slice(0, n).forEach((t, i) => cue(t, `usos:entra:${i}`, 'fly', CARDS[i].nome));
  U.ins.slice(0, n).forEach((t, i) => cue(t, `usos:insere:${i}`, 'insert', CARDS[i].nome));
  U.cap.slice(0, capParts.length).forEach((t, i) => cue(t, `usos:legenda:${i}`, 'word', capParts[i]));
  cue(U.out, 'usos:sai', 'whoosh', 'cards fly past the lens');
}

export function render(t, C) {
  const on = t >= U.a && t < U.b;
  cards.forEach((c) => { c.d.style.display = on ? '' : 'none'; });
  caption.show(on);
  if (!on) return false;
  caption.groups.forEach((g, i) => caption.setOn(i, t >= U.cap[g]));
  caption.color(exitColor(t, U.out - 0.1, 0.55));
  // a slow camera float over the grid
  const drift = E.inOutSine(prog(t, U.ins[0], U.out));
  const ox = 512, oy = 545;
  const out = E.inQuart(prog(t, U.out, U.b));
  cards.forEach((c, i) => {
    const fly = U.fly[i];
    const u = EASE_SETTLE(prog(t, fly, fly + 0.72));
    const [x, y] = POS[i];
    const cx = x + CW / 2 - ox, cy = y + CH / 2 - oy;
    // from in front of the lens (big, blurred, pushed out from the centre) into the grid
    const s = lerp(2.7, 1, u) * (1 + drift * 0.045) * lerp(1, 2.4, out);
    const push = lerp(1.9, 1, u) * lerp(1, 2.1, out);
    const tx = cx * push - cx, ty = cy * push - cy;
    const blur = (1 - u) * 22 + out * 26;
    c.d.style.transform = `translate(${tx - drift * 14}px, ${ty - drift * 6}px) scale(${s})`;
    c.d.style.filter = blur > 0.2 ? `blur(${blur}px)` : 'none';
    c.d.style.opacity = clamp(prog(t, fly, fly + 0.18)) * (1 - out) + '';
    // the text arrives: left-to-right wipe with a soft edge
    const ins = U.ins[i];
    const w = E.outCubic(prog(t, ins, ins + 0.34));
    const m = `linear-gradient(90deg, #000 ${w * 130 - 30}%, transparent ${w * 130}%)`;
    c.target.style.webkitMaskImage = m; c.target.style.maskImage = m;
    // mini pill pops on the insert and leaves
    const pu = t < ins - 0.12 ? 0 : spring(t - (ins - 0.12), { freq: 3, damping: 0.55 });
    const pl = E.inCubic(prog(t, ins + 0.55, ins + 0.8));
    c.pill.style.transform = `scale(${lerp(0.6, 1, pu) * (1 - pl * 0.3)})`;
    c.pill.style.opacity = clamp(pu * 2) * (1 - pl) + '';
  });
  return true;
}
