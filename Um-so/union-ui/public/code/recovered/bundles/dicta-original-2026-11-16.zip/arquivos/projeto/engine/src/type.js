// type.js — the film's typography: one centred line (two when it does not fit), final layout fixed from the first
// frame, words switched on in place (no fade, no slide) on musical hits, and an exit that runs the colour through a
// tint of the accent into the background.
import { el, rgb, emberFade, prog, FONT, PAL } from './core.js';

export const MAX_W = 880; // widest a line may be (CSS px of the 1024 composition)

/**
 * parts: [{ text, weight, size?, html?, style?, join? }] — rendered inline, separated by spaces unless join is false
 * Fits: the size drops down to `min` × size to stay on one line; past that the line breaks in two (balanced).
 * returns { root, parts: [span], size, lines, setOn(i, on), color(c), show(on) }
 */
export function makeLine(parent, parts, { y = 512, size = 56, weight = 500, tracking = -0.012, cls = '', min = 0.78, maxW = MAX_W, font = FONT.display, breakAfter = null } = {}) {
  const root = el('div', 'line ' + cls, parent);
  Object.assign(root.style, {
    left: (512 - maxW / 2) + 'px', width: maxW + 'px', textAlign: 'center', fontWeight: weight, fontFamily: font,
    letterSpacing: tracking + 'em', lineHeight: '1', whiteSpace: 'nowrap',
  });
  const spans = [];
  parts.forEach((p, i) => {
    if (i > 0 && p.join !== false) root.appendChild(document.createTextNode(' '));
    const s = el('span', 'w ' + (p.cls || ''), root, p.html ?? null);
    if (p.html == null) s.textContent = p.text;
    if (p.weight) s.style.fontWeight = p.weight;
    if (p.style) Object.assign(s.style, p.style);
    spans.push(s);
  });
  // fit: measure the natural width at the design size
  const setSize = (s) => {
    root.style.fontSize = s + 'px';
    parts.forEach((p, i) => { if (p.size) spans[i].style.fontSize = (p.size * s / size) + 'px'; });
  };
  setSize(size);
  root.style.width = 'auto'; root.style.display = 'inline-block';
  const natural = root.getBoundingClientRect().width;
  root.style.display = ''; root.style.width = maxW + 'px';
  let s = size, lines = 1;
  if (natural > maxW) {
    s = size * maxW / natural;
    if (s < size * min) {
      // two lines, balanced, at up to 90 % of the design size
      lines = 2;
      s = Math.max(size * 0.55, Math.min(size * 0.9, (size * maxW / natural) * 2 * 0.92));
      root.style.whiteSpace = 'normal';
      root.style.textWrap = 'balance';
      root.style.lineHeight = '1.12';
      if (breakAfter != null && spans[breakAfter] && spans[breakAfter].nextSibling) {
        // a chosen break (the name on line 1, the rest on line 2)
        spans[breakAfter].parentNode.replaceChild(document.createElement('br'), spans[breakAfter].nextSibling);
        root.style.textWrap = 'nowrap';
        root.style.whiteSpace = 'nowrap';
        setSize(s);
        root.style.width = 'auto'; root.style.display = 'inline-block';
        const wn = root.getBoundingClientRect().width;
        root.style.display = ''; root.style.width = maxW + 'px';
        if (wn > maxW) s = s * maxW / wn;
      }
    }
  }
  setSize(s);
  const h = lines === 1 ? s : root.getBoundingClientRect().height;
  root.style.top = (y - h / 2) + 'px';
  root.style.height = h + 'px';
  return {
    root, parts: spans, size: s, lines, height: h,
    setOn(i, on) { spans[i].style.visibility = on ? 'visible' : 'hidden'; },
    color(c) { root.style.color = typeof c === 'string' ? c : rgb(c); },
    show(on) { root.style.display = on ? '' : 'none'; },
  };
}

/** largest size (<= size) at which `text` fits maxW on one line */
export function fitSize(parent, text, size, maxW, { weight = 500, tracking = -0.012, font = FONT.display } = {}) {
  const s = el('span', '', parent);
  Object.assign(s.style, { position: 'absolute', whiteSpace: 'pre', fontSize: size + 'px', fontWeight: weight, letterSpacing: tracking + 'em', fontFamily: font, visibility: 'hidden' });
  s.textContent = text;
  const w = s.getBoundingClientRect().width;
  s.remove();
  return w > maxW ? size * maxW / w : size;
}

/** colour of the exit at time t for an exit that starts at a and lasts dur (0.8 s by default) */
export function exitColor(t, a, dur = 0.8) {
  return emberFade(prog(t, a, a + dur));
}
export { PAL };
