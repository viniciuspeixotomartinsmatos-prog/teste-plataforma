// voz.mjs — prepara as falas do filme e confere se cada uma cabe na cena dela.
//   node tools/voz.mjs <filme>
// Lê audio/voz/<filme>/<tipo>.(wav|mp3|m4a|ogg|flac) — um arquivo por cena com "fala" no config; o nome do arquivo é
// o tipo da cena (gancho.mp3, demo.mp3, marca.mp3, ...). Corta o silêncio das pontas, converte para WAV mono 44,1 kHz
// em audio/voz/<filme>/proc/<tipo>.wav e grava audio/voz/<filme>/voz.json com as durações.
// O filme segue a música: as cenas não esticam para a voz. A fala começa 0,15 s depois do início da cena ("atraso" no
// objeto da cena muda isso) e tem de acabar antes da cena seguinte: o script avisa quando não cabe (encurte a frase).
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { RAIZ, args, lerFilme, ffmpeg } from './comum.mjs';

const { pos } = args();
const nome = pos[0];
if (!nome) { console.log('uso: node tools/voz.mjs <filme>'); process.exit(1); }
const cfg = lerFilme(nome);
const dir = path.join(RAIZ, 'audio/voz', nome);
const proc = path.join(dir, 'proc');
fs.mkdirSync(proc, { recursive: true });
const linhaF = path.join(RAIZ, 'out', nome, 'linha.json');
if (!fs.existsSync(linhaF)) execFileSync('node', [path.join(RAIZ, 'tools/render.mjs'), nome, 'linha'], { stdio: 'ignore', cwd: RAIZ });
const L = JSON.parse(fs.readFileSync(linhaF, 'utf8'));
const ordem = ['gancho', 'giro', 'demo', 'marca', 'usos', 'slogan', 'variacoes', 'fecho'].filter((t) => L.marcos[t] != null && (L.cenas.includes(t)));
const espaco = (tipo) => {
  const i = ordem.indexOf(tipo);
  const fim = i >= 0 && i < ordem.length - 1 ? L.marcos[ordem[i + 1]] : L.marcos.corte;
  return fim - L.marcos[tipo];
};
const out = {};
const faltam = [], longas = [];
for (const c of cfg.cenas) {
  if (!c.fala || c.ativa === false) continue;
  const src = ['wav', 'mp3', 'm4a', 'ogg', 'flac'].map((e) => path.join(dir, `${c.tipo}.${e}`)).find((f) => fs.existsSync(f));
  const dst = path.join(proc, `${c.tipo}.wav`);
  if (!src) { faltam.push(c.tipo); continue; }
  execFileSync(ffmpeg(), ['-v', 'error', '-y', '-i', src, '-ac', '1', '-ar', '44100', '-c:a', 'pcm_s16le', '-af',
    'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.04,areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.08,areverse',
    dst]);
  const dur = duracao(dst);
  const cabe = espaco(c.tipo) - (c.atraso ?? 0.15) - 0.2;
  out[c.tipo] = { dur: +dur.toFixed(3), espaco: +cabe.toFixed(2), texto: c.fala };
  const ok = dur <= cabe;
  if (!ok) longas.push(c.tipo);
  console.log(`  ${c.tipo.padEnd(10)} ${dur.toFixed(2)} s de ${cabe.toFixed(2)} s ${ok ? '' : ' ← NÃO CABE: encurte a frase'}  "${c.fala}"`);
}
fs.writeFileSync(path.join(dir, 'voz.json'), JSON.stringify(out, null, 1));
if (faltam.length) console.log(`sem arquivo de voz para: ${faltam.join(', ')} (essas cenas ficam sem fala)`);
if (longas.length) console.log(`falas longas demais: ${longas.join(', ')}. O filme segue a música; a fala não pode passar da cena.`);
console.log(`voz.json → ${path.relative(RAIZ, path.join(dir, 'voz.json'))}`);

function duracao(f) {
  const b = fs.readFileSync(f);
  let i = 12;
  while (i < b.length - 8) {
    const id = b.toString('ascii', i, i + 4), n = b.readUInt32LE(i + 4);
    if (id === 'data') return n / (44100 * 2);
    i += 8 + n + (n % 2);
  }
  throw new Error('WAV sem bloco de dados: ' + f);
}
