# Créditos e licenças

- **Trilha** (`audio/trilha/secrets-of-the-schoolyard.mp3`): "Secrets of the Schoolyard", Kevin MacLeod (incompetech.com), licença Creative Commons Attribution 4.0 (https://creativecommons.org/licenses/by/4.0/). Uso comercial e sincronização com vídeo liberados **com crédito obrigatório**. O filme usa a faixa editada (um trecho abafado como introdução, o groove a partir da virada e a batida final da própria faixa, mixados com efeitos). Ao postar, ponha na legenda, na descrição ou nos créditos:

  > "Secrets of the Schoolyard" Kevin MacLeod (incompetech.com)
  > Licensed under Creative Commons: By Attribution 4.0 License
  > http://creativecommons.org/licenses/by/4.0/
  > Editada do original (recortada e mixada com efeitos sonoros).

  Sem crédito: gere o filme com `--sem-musica` e use uma música da biblioteca do Instagram ou do TikTok.
- **Efeitos sonoros** (`audio/sfx/`): sintetizados em código (receitas DSP do earshot, licença MIT), sem gravação de terceiros. Livres para uso comercial.
- **Narração** (opcional): gerada na conta da ElevenLabs de quem faz o filme; uso comercial exige plano pago.
- **Fontes**: Inter e Geist Mono (SIL Open Font License; o texto da licença do Inter está em `engine/fonts/Inter-OFL.txt`). A fonte da marca, se houver, é responsabilidade de quem a coloca: só fontes gratuitas para uso comercial.
- **Ícones**: lucide (ISC, lucide.dev).
- **Bibliotecas**: three.js (MIT), Playwright (Apache 2.0), sharp (Apache 2.0), ffmpeg pelo pacote @ffmpeg-installer (LGPL), numpy, scipy, soundfile, pyloudnorm.
- **Demonstração**: a Dicta é uma marca fictícia; nomes e mensagens da demonstração são inventados.
