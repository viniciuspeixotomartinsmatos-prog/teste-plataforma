"""som.py <filme> [--sem-musica] [--sem-efeitos] [--sem-voz] — a trilha do filme: música editada na linha do tempo +
efeitos nos marcos que as cenas registram + falas (opcionais) → out/<filme>/mix.wav, -14 LUFS, pico ≤ -1 dBTP.

Lê out/<filme>/linha.json (tools/render.mjs <filme> linha). A música (audio/trilha/trilha.json) entra assim:
  silêncio      a abertura (gancho), só as teclas
  introdução    do giro do ícone até o corte para a marca: a própria faixa, abafada (sem graves e sem agudos), que se
                abre durante o mergulho na câmera e cai 9 dB nos últimos 0,3 s (o "respiro" antes do corte)
  groove        do corte em diante, a faixa inteira, contínua (o drop cai na onda que sai do símbolo)
  final         na batida final do filme, a batida final da própria faixa, com a cauda
Efeitos: audio/sfx/*.wav (sintetizados em código, livres). Falas: audio/voz/<filme>/<cena>.wav|mp3 (tools/voz.mjs).
"""
import json, os, sys, shutil, subprocess, platform
import numpy as np, soundfile as sf, pyloudnorm as pyln
from scipy import signal
from scipy.ndimage import minimum_filter1d, uniform_filter1d

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 48000
nome = sys.argv[1]
SEM_MUSICA = '--sem-musica' in sys.argv
SEM_EFEITOS = '--sem-efeitos' in sys.argv
SEM_VOZ = '--sem-voz' in sys.argv
L = json.load(open(os.path.join(RAIZ, 'out', nome, 'linha.json')))
cfg = json.load(open(os.path.join(RAIZ, 'filmes', nome + '.json')))
TR = json.load(open(os.path.join(RAIZ, 'audio', 'trilha', (cfg.get('trilha') or 'trilha') + '.json')))
DUR = L['end']
N = int(round(DUR * SR)) + SR // 2
M = L['musica']
CT = {}
for c in L['cues']:
    CT.setdefault(c['id'], c['t'])


def ffmpeg():
    plat = {'darwin': 'darwin', 'linux': 'linux', 'win32': 'win32'}.get(sys.platform, sys.platform) + '-' + \
        {'arm64': 'arm64', 'aarch64': 'arm64', 'x86_64': 'x64', 'AMD64': 'x64'}.get(platform.machine(), 'x64')
    ff = os.path.join(RAIZ, 'node_modules/@ffmpeg-installer', plat, 'ffmpeg.exe' if sys.platform == 'win32' else 'ffmpeg')
    if os.path.exists(ff):
        try: os.chmod(ff, 0o755)
        except OSError: pass
        return ff
    return shutil.which('ffmpeg') or 'ffmpeg'


def decode(path):
    raw = subprocess.run([ffmpeg(), '-v', 'error', '-i', path, '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).reshape(-1, 2).astype(np.float64)


def db(x): return 10 ** (x / 20)


def place(bus, x, t):
    i = int(round(t * SR))
    if i < 0: x = x[-i:]; i = 0
    j = min(len(bus), i + len(x))
    if j > i: bus[i:j] += x[:j - i]


# ------------------------------------------------------------------ música
def musica():
    out = np.zeros((N, 2))
    src = decode(os.path.join(RAIZ, TR['arquivo']))
    A, cut, hit = M['inicio'], M['entrada'], M['fim']
    tau0 = M['trilhaInicio']
    # 1. introdução: um trecho da faixa que termina em trilha.introFim (mesma fase do compasso que a entrada), abafado
    #    (sem graves, agudos macios), que se abre durante o mergulho; 2. groove: da entrada em diante, contínuo
    i0, ic, i1 = int(round(A * SR)), int(round(cut * SR)), int(round(hit * SR))
    def trecho(t0, n):
        idx = np.arange(n) + int(round(t0 * SR))
        seg = np.zeros((n, 2)); ok = (idx >= 0) & (idx < len(src)); seg[ok] = src[idx[ok]]
        return seg
    fimIntro = TR.get('introFim', TR['entrada'])
    seg = trecho(fimIntro - (cut - A), ic - i0)
    groove = trecho(TR['entrada'], i1 - ic)
    n_intro = ic - i0
    abre0, abre1 = M['abre'] - A, cut - A
    blk = 256
    hp_st = lp_st = None
    U = np.zeros(n_intro)
    filtra = TR.get('filtroIntro', True)  # uma faixa com introdução própria (calma) dispensa o filtro
    for b in range(0, n_intro if filtra else 0, blk):
        t = (b + blk / 2) / SR
        u = np.clip((t - abre0) / max(1e-3, abre1 - abre0), 0, 1) ** 2.2
        U[b:b + blk] = u
        hpf = 260 * (20 / 260) ** u            # 260 Hz -> 20 Hz
        lpf = 4500 * (20000 / 4500) ** u       # 4,5 kHz -> 20 kHz
        hp = signal.butter(2, hpf, 'high', fs=SR, output='sos')
        lp = signal.butter(2, min(lpf, SR / 2 - 100), 'low', fs=SR, output='sos')
        x = seg[b:b + blk]
        if hp_st is None:
            hp_st = np.zeros((hp.shape[0], 2, 2)); lp_st = np.zeros((lp.shape[0], 2, 2))
        y = np.empty_like(x)
        for ch in range(2):
            yy, hp_st[:, :, ch] = signal.sosfilt(hp, x[:, ch], zi=hp_st[:, :, ch])
            yy, lp_st[:, :, ch] = signal.sosfilt(lp, yy, zi=lp_st[:, :, ch])
            y[:, ch] = yy
        seg[b:b + blk] = y
    # a introdução fica 3 dB abaixo do groove (medido), e chega ao nível dele enquanto o filtro abre
    mt = pyln.Meter(SR)
    try:
        if not filtra: raise ValueError
        gi = (mt.integrated_loudness(groove[:int(6 * SR)]) - 3.0) - mt.integrated_loudness(seg[:max(int(0.5 * SR), int(abre0 * SR))])
        gi = float(np.clip(gi, -6, 12))
    except Exception:
        gi = 0.0
    seg *= db(gi * (1 - U))[:, None]
    # fade-in curto no começo (a faixa começa no meio de um compasso)
    k = int(0.05 * SR); seg[:k] *= np.linspace(0, 1, k)[:, None]
    # o respiro antes do corte: -9 dB nos últimos 0,3 s da introdução, e uma emenda de 4 ms no corte
    t = np.arange(len(seg)) / SR + A
    g = np.where(t >= cut - 0.32, -9.0 * np.clip((t - (cut - 0.32)) / 0.08, 0, 1), 0.0)
    seg *= db(g)[:, None]
    xf = int(0.004 * SR)
    seg[-xf:] *= np.linspace(1, 0, xf)[:, None]
    groove[:xf] *= np.linspace(0, 1, xf)[:, None]
    # fim do groove: fusão de 10 ms para a batida final
    xf = int(0.010 * SR)
    groove[-xf:] *= np.linspace(1, 0, xf)[:, None]
    out[i0:ic] += seg
    out[ic:i1] += groove
    # 2. a batida final da própria faixa, com a cauda
    e0 = int(round((TR['fim'] - 0.010) * SR))
    tail = src[e0:e0 + int((DUR - hit + 1.0) * SR)].copy()
    tail[:xf] *= np.linspace(0, 1, xf)[:, None]
    place(out, tail, hit - 0.010)
    return out * db(-9.0)


# ------------------------------------------------------------------ efeitos
_cache = {}


def fx(nome_):
    if nome_ not in _cache:
        x, sr = sf.read(os.path.join(RAIZ, 'audio', 'sfx', nome_ + '.wav'), dtype='float64', always_2d=True)
        if x.shape[1] == 1: x = np.repeat(x, 2, axis=1)
        if sr != SR: x = signal.resample_poly(x, SR, sr, axis=0)
        e = 10 * np.log10(uniform_filter1d((x ** 2).mean(1), int(0.005 * SR)) + 1e-12)
        pk = int(np.argmax(e)); above = np.where(e > e[pk] - 20)[0]
        on = int(above[0]) if len(above) else 0
        act = x[on:(above[-1] + 1) if len(above) else len(x)]
        _cache[nome_] = {'y': x, 'onset': on / SR, 'peak_t': pk / SR,
                         'rms': 10 * np.log10((act ** 2).mean() + 1e-12), 'peak': 20 * np.log10(np.abs(x).max() + 1e-12)}
    return _cache[nome_]


def rate(s, r):
    """afina por reamostragem (mais curto e mais agudo com r > 1)"""
    if r == 1: return s
    y = signal.resample(s['y'], max(8, int(round(len(s['y']) / r))), axis=0)
    return {**s, 'y': y, 'onset': s['onset'] / r, 'peak_t': s['peak_t'] / r}


def bed_db(bed, t, span=0.35):
    a, b = max(0, int((t - span) * SR)), max(1, int(t * SR))
    seg = bed[a:b]
    return 10 * np.log10((seg ** 2).mean() + 1e-12) if len(seg) else -120


EVENTS = []


def add(at, s, align='onset', rel=None, peak=None, bed=None):
    """align: 'onset' põe o ataque em at, 'peak' põe o ponto mais alto em at, 'start' a primeira amostra.
    rel: dB acima do nível da música logo antes (quando há música); peak: pico absoluto em dBFS."""
    off = {'onset': s['onset'] - 0.002, 'peak': s['peak_t'], 'start': 0.0}[align]
    if rel is not None and bed is not None and bed_db(bed, at) > -60:
        g = (bed_db(bed, at) + rel) - s['rms']
    else:
        g = (peak if peak is not None else -18) - s['peak']
    EVENTS.append((at - off, s['y'] * db(g)))


def efeitos(bed):
    R = np.random.default_rng(42)
    cues = L['cues']
    by = lambda pre: [c for c in cues if c['id'].startswith(pre)]
    # abertura: cada palavra um tique; as teclas de notebook no silêncio
    for i, c in enumerate(by('gancho:palavra:')):
        add(c['t'], rate(fx('tique'), 1.0 + 0.06 * i), peak=-24 + i)
    teclas = [fx(f'tecla{k}') for k in range(1, 7)]
    for i, c in enumerate(by('gancho:tecla:')):
        if c['kind'] == 'backspace': add(c['t'], fx('apagar'), peak=-12.0)
        elif c['kind'] == 'space': add(c['t'], fx('espaco'), peak=-13.0)
        else: add(c['t'], teclas[(i * 4) % 6], peak=-13.0 + R.uniform(-1.2, 1.2))
    # giro
    A = CT['giro:abre']
    add(A + 0.42, fx('giro_ar'), align='peak', rel=3.0, bed=bed, peak=-15)
    add(A + 0.95, fx('giro_frio'), align='peak', rel=-1.0, bed=bed, peak=-20)
    add(A + 1.45, rate(fx('giro_leve'), 1.12), align='peak', rel=-7.0, bed=bed, peak=-24)
    add(CT['giro:pousa'] + 0.02, fx('pousa'), align='peak', rel=7.0, bed=bed, peak=-10)
    # demo
    add(CT['demo:recua'] + 0.30, fx('recua'), align='peak', rel=0.0, bed=bed, peak=-18)
    add(CT['demo:pilula'] + 0.03, fx('pilula'), align='onset', peak=-15)
    if 'demo:tecla' in CT: add(CT['demo:tecla'] + 0.05, fx('tecla_chega'), peak=-18)
    add(CT['demo:aperta'], fx('clique'), peak=-11)
    add(CT['demo:solta'], rate(fx('clique_solta'), 0.9), peak=-16)
    riscas = by('demo:risca:')
    if riscas: add(riscas[len(riscas) // 2]['t'] + 0.02, rate(fx('risca'), 1.2), align='peak', rel=1.0, bed=bed, peak=-18)
    add(CT['demo:dissolve'], fx('dissolve'), align='start', rel=3.0, bed=bed, peak=-16)
    add(CT['demo:junta'] + 0.22, fx('junta'), align='peak', rel=-6.0, bed=bed, peak=-24)
    if 'demo:ponto' in CT: add(CT['demo:ponto'], rate(fx('ponto'), 1.1), peak=-20)
    add(CT['demo:corte'] - 0.075, fx('subida'), align='peak', rel=2.0, bed=bed, peak=-14)
    add(CT['demo:corte'], fx('corte'), peak=-9.5)
    add(CT['demo:corte'], fx('corte_grave'), peak=-13)
    # usos
    if 'usos:entra:0' in CT:
        add(CT['usos:entra:0'] + 0.22, fx('cartoes'), align='peak', rel=-4.0, bed=bed)
        for i, c in enumerate(by('usos:insere:')):
            add(c['t'], fx(f'gota{i % 4 + 1}'), peak=-13)
        add(CT['usos:sai'] + 0.22, fx('cartoes_saem'), align='peak', rel=-1.0, bed=bed)
    # slogan
    if 'slogan:parte:0' in CT:
        add(CT['slogan:parte:0'], fx('tecla_chega'), peak=-16)
        if 'slogan:encaixa' in CT: add(CT['slogan:encaixa'] + 0.01, rate(fx('estalo'), 1.1), peak=-17)
    # variações: um grão por palavra
    for i, c in enumerate(by('variacoes:palavra:')):
        add(c['t'], fx(f'grao{i % 3 + 1}'), align='start', rel=-2.0 + 0.3 * i, bed=bed)
    if 'variacoes:recolhe' in CT:
        add(CT['fecho:cursor'] + 0.01, fx('recolhe'), align='peak', rel=-3.0, bed=bed)
    # fecho
    add(CT['fecho:cursor'] + 0.02, rate(fx('pilula'), 0.92), peak=-16)
    for i, c in enumerate(by('fecho:parte:')[:3]):
        add(c['t'], rate(fx('brilho'), 1.0 + 0.08 * i), align='start', rel=-3.0 - i, bed=bed)
    add(CT['fecho:desliza'] + 0.43, fx('desliza'), align='peak', rel=-3.0, bed=bed)
    add(CT['fecho:final'], fx('final'), align='onset', rel=-2.0, bed=bed)
    add(CT['fecho:corte'], rate(fx('clique'), 0.86), peak=-18)


# ------------------------------------------------------------------ falas
def falas():
    voice = np.zeros((N, 2))
    if SEM_VOZ or cfg.get('voz', 'sem') == 'sem':
        return voice, 0
    vd = os.path.join(RAIZ, 'audio', 'voz', nome, 'proc')
    marcos = L['marcos']
    n = 0
    hp = signal.butter(2, 90, 'high', fs=SR, output='sos')
    pres = signal.butter(2, [3000, 7000], 'band', fs=SR, output='sos')
    for c in cfg.get('cenas', []):
        if not c.get('fala'): continue
        p = os.path.join(vd, c['tipo'] + '.wav')
        if not os.path.exists(p) or marcos.get(c['tipo']) is None: continue
        a, sr = sf.read(p, dtype='float64')
        if a.ndim > 1: a = a.mean(1)
        if sr != SR: a = signal.resample_poly(a, SR, sr)
        a = signal.sosfilt(hp, a); a = a + 0.26 * signal.sosfilt(pres, a)
        place(voice, np.stack([a, a], 1) * db(-6), marcos[c['tipo']] + float(c.get('atraso', 0.15))); n += 1
    return voice, n


bed = np.zeros((N, 2)) if SEM_MUSICA else musica()
ref_bed = musica() if SEM_MUSICA else bed  # os efeitos medem o nível contra a música mesmo quando ela sai
if not SEM_EFEITOS: efeitos(ref_bed)
fxbus = np.zeros((N, 2))
for at, y in EVENTS: place(fxbus, y, at)
voice, nv = falas()
if nv:
    vk = np.abs(voice[:, 0]); env = uniform_filter1d(vk, int(0.05 * SR))
    duck = 1 - (1 - db(-8)) * np.clip(env / db(-30), 0, 1)
    bed = bed * uniform_filter1d(duck, int(0.12 * SR))[:, None]
mix = bed + fxbus + voice
meter = pyln.Meter(SR)


def true_peak(x): return np.abs(signal.resample_poly(x, 4, 1, axis=0)).max()


def limit(x, ceil, look=0.003):
    up = np.abs(signal.resample_poly(x, 4, 1, axis=0)).max(1)
    pk = up[:len(x) * 4].reshape(-1, 4).max(1)[:len(x)]
    g = np.minimum(1.0, ceil / np.maximum(pk, 1e-9)); w = int(look * SR) | 1
    return x * uniform_filter1d(minimum_filter1d(g, 2 * w + 1), 2 * w + 1)[:, None]


mix = mix[:int(round(DUR * SR))]
for _ in range(6):
    mix *= db(-14 - meter.integrated_loudness(mix)); mix = limit(mix, db(-1.3))
    if true_peak(mix) <= db(-1.0) and abs(meter.integrated_loudness(mix) + 14) < 0.15: break
# o fim do filme: 60 ms de fade para não estalar
k = int(0.06 * SR); mix[-k:] *= np.linspace(1, 0, k)[:, None]
dst = os.path.join(RAIZ, 'out', nome, 'mix.wav')
sf.write(dst, mix.astype(np.float32), SR, subtype='PCM_24')
print(f"mix → out/{nome}/mix.wav  {len(mix)/SR:.2f} s  {meter.integrated_loudness(mix):.1f} LUFS  pico {20*np.log10(true_peak(mix)):.1f} dBTP  "
      f"({nv} falas, {len(EVENTS)} efeitos{', sem música' if SEM_MUSICA else ''})")
