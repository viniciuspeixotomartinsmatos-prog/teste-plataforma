// filme.mjs — o filme inteiro de uma vez: linha do tempo → quadros → trilha e mixagem → MP4.
//   node tools/filme.mjs <filme> [--rascunho] [--sem-musica] [--sem-efeitos] [--abas 3] [--refaz]
// Saída: out/<filme>/<filme>.mp4 (H.264 + AAC, no formato e no fps do config). --rascunho: metade da resolução.
// Os quadros já renderizados são reaproveitados; --refaz apaga e desenha de novo (use depois de mudar o config).
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { RAIZ, args, ffmpeg, python } from './comum.mjs';

const { pos, opt } = args();
const nome = pos[0];
if (!nome) { console.log('uso: node tools/filme.mjs <filme> [--rascunho] [--sem-musica] [--refaz]'); process.exit(1); }
const OUT = path.join(RAIZ, 'out', nome);
const run = (cmd, a) => execFileSync(cmd, a, { stdio: 'inherit', cwd: RAIZ });
const escala = opt.rascunho ? 0.5 : 1;
const dir = path.join(OUT, opt.rascunho ? 'filme-rascunho' : 'filme');
if (opt.refaz) fs.rmSync(dir, { recursive: true, force: true });

const cfg = JSON.parse(fs.readFileSync(path.join(RAIZ, 'filmes', nome + '.json'), 'utf8'));
if (cfg.voz && cfg.voz !== 'sem' && fs.existsSync(path.join(RAIZ, 'audio/voz', nome))) { console.log('— voz'); run('node', ['tools/voz.mjs', nome]); }
console.log('— quadros');
run('node', ['tools/render.mjs', nome, 'filme', '--escala', String(escala), '--saida', dir, '--abas', String(opt.abas || 3)]);
console.log('— trilha e mixagem');
run(python(), ['tools/som.py', nome, ...(opt['sem-musica'] ? ['--sem-musica'] : []), ...(opt['sem-efeitos'] ? ['--sem-efeitos'] : [])]);
console.log('— MP4');
const L = JSON.parse(fs.readFileSync(path.join(OUT, 'linha.json'), 'utf8'));
const mp4 = path.join(OUT, `${nome}${opt.rascunho ? '-rascunho' : ''}${opt['sem-musica'] ? '-sem-musica' : ''}.mp4`);
execFileSync(ffmpeg(), ['-v', 'error', '-y', '-framerate', String(L.fps), '-i', path.join(dir, '%04d.png'), '-i', path.join(OUT, 'mix.wav'),
  '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p', '-c:v', 'libx264', '-preset', 'slow', '-crf', opt.rascunho ? '22' : '16',
  '-profile:v', 'high', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
  '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', '-shortest', '-movflags', '+faststart', mp4], { stdio: 'inherit' });
console.log(`pronto → ${path.relative(RAIZ, mp4)} (${L.saida[0] * escala}×${L.saida[1] * escala}, ${L.fps} fps, ${L.end.toFixed(1)} s)`);
