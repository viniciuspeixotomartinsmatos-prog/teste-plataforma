// A conversa do hero: a demonstração que digita sozinha com o campo vazio, os painéis de anexo e modelo, o
// microfone que "ouve" e o envio (o convite para continuar).
import { REDUZIDO } from './ease.js';

const DEMOS = [
  'Resuma a ata da reunião e liste quem ficou com cada tarefa',
  'Compare os três orçamentos e diga qual tem o melhor prazo',
  'Escreva um post sobre o lançamento no tom da marca',
  'Encontre na planilha os clientes que não compram há 90 dias',
];
const SUGESTOES = {
  'Resumir um contrato': 'Resuma este contrato e aponte as cláusulas de multa, prazo e renovação.',
  'Escrever um e-mail': 'Escreva um e-mail cordial cobrando o retorno da proposta enviada na semana passada.',
  'Analisar uma planilha': 'Analise a planilha de vendas e mostre o que mudou do último trimestre para este.',
  'Planejar a semana': 'Monte minha semana com as reuniões fixas e duas horas livres por dia para foco.',
};

export function conversa() {
  const form = document.querySelector('[data-conversa]');
  const campo = form.querySelector('.conversa__texto');
  const demo = form.querySelector('.conversa__demo-txt');
  const resposta = form.querySelector('[data-resposta]');
  const eco = form.querySelector('[data-eco]');

  // campo que cresce com o texto
  function crescer() {
    campo.style.height = 'auto';
    campo.style.height = `${Math.min(200, campo.scrollHeight)}px`;
    form.classList.toggle('is-cheia', campo.value.trim().length > 0);
  }

  // demonstração: digita, segura, apaga, próxima. Para no foco ou quando a pessoa escreve.
  let iDemo = 0, timer = 0, ligada = false;
  function passoDemo(txt, n, apagando) {
    if (!ligada) return;
    demo.textContent = txt.slice(0, n);
    if (!apagando && n < txt.length) {
      timer = setTimeout(() => passoDemo(txt, n + 1, false), 42 + Math.random() * 60);
    } else if (!apagando) {
      timer = setTimeout(() => passoDemo(txt, n, true), 2200);
    } else if (n > 0) {
      timer = setTimeout(() => passoDemo(txt, n - 3 < 0 ? 0 : n - 3, true), 14);
    } else {
      iDemo = (iDemo + 1) % DEMOS.length;
      timer = setTimeout(() => passoDemo(DEMOS[iDemo], 0, false), 500);
    }
  }
  function ligarDemo(atraso = 900) {
    if (ligada || campo.value || document.activeElement === campo) return;
    ligada = true;
    form.classList.add('is-demo');
    demo.textContent = '';
    timer = setTimeout(() => passoDemo(DEMOS[iDemo], 0, false), atraso);
  }
  function desligarDemo() {
    ligada = false;
    clearTimeout(timer);
    form.classList.remove('is-demo');
  }
  if (REDUZIDO) form.classList.remove('is-demo');

  campo.addEventListener('focus', desligarDemo);
  campo.addEventListener('blur', () => { if (!campo.value) setTimeout(() => ligarDemo(1400), 300); });
  campo.addEventListener('input', crescer);
  campo.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); }
  });

  // painéis (anexo, modelo): abre um por vez, fecha com Esc, clique fora ou escolha
  const botoesPop = form.querySelectorAll('[data-pop]');
  function fecharPops(exceto) {
    botoesPop.forEach((b) => {
      if (b === exceto) return;
      b.setAttribute('aria-expanded', 'false');
      form.querySelector(`[data-pop-painel="${b.dataset.pop}"]`).hidden = true;
    });
  }
  botoesPop.forEach((b) => {
    const painel = form.querySelector(`[data-pop-painel="${b.dataset.pop}"]`);
    b.addEventListener('click', () => {
      const abrir = b.getAttribute('aria-expanded') !== 'true';
      fecharPops(b);
      b.setAttribute('aria-expanded', String(abrir));
      painel.hidden = !abrir;
      if (abrir) painel.querySelector('[aria-selected="true"], .pop__item')?.focus({ preventScroll: true });
    });
    painel.addEventListener('click', (e) => {
      const item = e.target.closest('.pop__item');
      if (!item) return;
      if (item.dataset.valor) {
        painel.querySelectorAll('.pop__item').forEach((i) => i.setAttribute('aria-selected', String(i === item)));
        form.querySelector('[data-modelo-nome]').textContent = item.dataset.valor;
      }
      fecharPops();
      b.focus({ preventScroll: true });
    });
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('.pop, [data-pop]')) fecharPops(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fecharPops(); });

  // pesquisa na web: liga e desliga
  const web = form.querySelector('[data-web]');
  web.addEventListener('click', () => {
    web.setAttribute('aria-pressed', String(web.getAttribute('aria-pressed') !== 'true'));
  });

  // microfone: "ouve" por alguns segundos (as barrinhas no lugar do ícone) e desliga sozinho
  const mic = form.querySelector('[data-mic]');
  let ouvindo = 0;
  mic.addEventListener('click', () => {
    const liga = mic.getAttribute('aria-pressed') !== 'true';
    mic.setAttribute('aria-pressed', String(liga));
    clearTimeout(ouvindo);
    if (liga) ouvindo = setTimeout(() => mic.setAttribute('aria-pressed', 'false'), 4200);
  });

  // sugestões: preenchem o campo
  document.querySelectorAll('.sugestao').forEach((s) => {
    s.addEventListener('click', () => {
      desligarDemo();
      campo.value = SUGESTOES[s.textContent.trim()] || s.textContent.trim();
      crescer();
      campo.focus({ preventScroll: true });
      campo.setSelectionRange(campo.value.length, campo.value.length);
    });
  });

  // envio: o convite para continuar
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const txt = campo.value.trim();
    if (!txt) {
      form.classList.remove('is-tremendo');
      void form.offsetWidth;
      form.classList.add('is-tremendo');
      campo.focus({ preventScroll: true });
      return;
    }
    eco.textContent = txt;
    resposta.hidden = false;
    campo.value = '';
    crescer();
    campo.blur();
  });
  form.querySelector('[data-nova]').addEventListener('click', () => {
    resposta.hidden = true;
    campo.focus({ preventScroll: true });
  });

  crescer();
  return { ligarDemo, desligarDemo };
}
