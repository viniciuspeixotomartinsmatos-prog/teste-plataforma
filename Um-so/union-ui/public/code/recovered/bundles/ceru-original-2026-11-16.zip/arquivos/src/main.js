// O CSS não entra por aqui: vem em <link> no index.html (importado pelo JS, a página aparecia crua no recarregamento).
window.__ceru = true; // avisa a trava do index.html que o JS subiu (senão a abertura cai em 4 s)
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { criarScroll } from './motion/smooth.js';
import { criarGuia } from './motion/guia.js';
import { scrollbar } from './motion/scrollbar.js';
import './motion/rolando.js';
import { ancoras } from './motion/ancoras.js';
import { criarHero } from './motion/hero.js';
import { conversa as criarConversa } from './motion/conversa.js';
import { abertura } from './motion/abertura.js';
import { nav } from './motion/nav.js';
import { secoes } from './motion/secoes.js';
import { pesquisa } from './motion/pesquisa.js';

// nada transiciona do estilo de antes do CSS: as transições voltam depois do primeiro quadro pintado
requestAnimationFrame(() => requestAnimationFrame(() => document.documentElement.classList.add('assentou')));
if (location.hash === '') scrollTo(0, 0);

// botões: o rótulo vira dois spans (o de cima sai e o de baixo entra no hover)
for (const b of document.querySelectorAll('.botao')) {
  if (b.querySelector('.botao__txt')) continue;
  const seta = b.querySelector('.botao__seta');
  seta?.remove();
  const txt = b.textContent.trim();
  b.innerHTML = `<span class="botao__txt"><span>${txt}</span><span aria-hidden="true">${txt}</span></span>`;
  if (seta) b.append(seta);
}

const lenis = criarScroll();
if (import.meta.env.DEV) window.__lenis = lenis; // auditoria headless
criarGuia({ lenis });
scrollbar({ lenis });
ancoras({ lenis });

const hero = criarHero();
const conversa = criarConversa();
nav({ lenis });

const fonte = Promise.race([
  Promise.all([document.fonts.load('400 100px "Source Serif 4 Variable"'), document.fonts.load('500 16px "Schibsted Grotesk Variable"')]),
  new Promise((r) => setTimeout(r, 1500)),
]);
fonte.then(() => {
  hero.medirVeu?.();
  secoes();
  pesquisa();
  abertura({ hero, conversa, lenis });
  ScrollTrigger.refresh();
  lenis?.resize();
});
