// Pesquisa profunda: o mesmo shader do hero com duas imagens. O céu do dia rasga a partir do canto de cima à direita
// enquanto a seção atravessa a tela e mostra o céu da noite atrás; cada ponto da linha do tempo acende quando o
// rasgo passa por ele. O rasgo segue a rolagem (é imagem, não texto).
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { criarCeu } from '../gl/ceu.js';
import { REDUZIDO, CELULAR, clamp } from './ease.js';

export function pesquisa() {
  const sec = document.querySelector('.pesquisa');
  if (!sec) return;
  const caixa = sec.querySelector('.pesquisa__ceu');
  const canvas = sec.querySelector('.pesquisa__gl');
  const itens = [...sec.querySelectorAll('.linha__item')];
  const celula = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--celula')) || 3;

  let ceu = null;
  try { ceu = criarCeu(canvas, { caixa, celula }); } catch (e) { console.warn(e); }
  if (!ceu) return;
  const { estado } = ceu;
  estado.tom = [0.0, 1.05, 1.0];
  estado.rasgo = 0.25;
  const posicao = () => (CELULAR() ? [0.62, 0.88, 0.5] : [0.8, 0.36, 0.7]); // centro e raio máximo (fração da altura)
  // véu atrás do texto (em pixel, como no hero): à esquerda no desktop, em cima no celular
  const veu = () => (CELULAR() ? [0.4, 0.12, 0.9, 0.26] : [0.1, 0.5, 0.27, 1.3]);
  function posicionar() {
    [estado.rasgoC[0], estado.rasgoC[1], estado.rasgoC[2]] = posicao();
    estado.veu = veu();
    estado.veuForca = 0.62;
  }
  posicionar();
  // o céu do dia sem as copas das árvores dos cantos (ficariam escuras atrás do texto)
  estado.focoImg[0] = [0.2, 0.15];
  estado.zoomImg[0] = 1.3;
  estado.focoImg[1] = [0.6, 0.4];

  let prontas = 0;
  const carregar = (i, src) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => { ceu.imagem(i, img); prontas++; desenhar(); };
    img.src = src;
  };
  carregar(0, './img/k2-nuvens.jpg');
  carregar(1, './img/k3-noite.jpg');

  let pedido = 0;
  function desenhar() {
    if (pedido) return;
    pedido = requestAnimationFrame(() => { pedido = 0; if (prontas === 2) ceu.desenhar(); });
  }

  // rasgo pela rolagem: começa pequeno quando a seção entra e abre até cobrir a direita
  ScrollTrigger.create({
    trigger: sec, start: 'top 85%', end: 'bottom 35%',
    onUpdate: (st) => {
      const p = REDUZIDO ? 1 : st.progress;
      estado.rasgo = 0.22 + 0.78 * clamp(p * 1.15);
      itens.forEach((it, k) => it.classList.toggle('is-on', p > 0.18 + k * 0.17));
      desenhar();
    },
  });

  new ResizeObserver(() => {
    ceu.medir();
    posicionar();
    desenhar();
  }).observe(caixa);
}
