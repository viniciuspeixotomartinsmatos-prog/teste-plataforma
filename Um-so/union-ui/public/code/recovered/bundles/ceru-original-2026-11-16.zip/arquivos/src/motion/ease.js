// Curvas da marca e o que a página sabe do aparelho.
import gsap from 'gsap';
import { CustomEase } from 'gsap/CustomEase';

gsap.registerPlugin(CustomEase);

// as mesmas do tokens.css: saída longa e macia, entrada seca, ida e volta para os deslizes
CustomEase.create('ce-out', '0.16, 1, 0.3, 1');
CustomEase.create('ce-in', '0.7, 0, 0.84, 0');
CustomEase.create('ce-io', '0.83, 0, 0.17, 1');

export const REDUZIDO = matchMedia('(prefers-reduced-motion: reduce)').matches;
export const TOQUE = matchMedia('(hover: none)').matches;
export const CELULAR = () => innerWidth <= 760;

// a altura das cenas é 100svh (a tela com as barras do navegador abertas). O innerHeight cresce quando a barra do
// Safari some no meio da rolagem: medir por ele mudaria o tamanho das peças em pleno movimento.
const regua = document.createElement('div');
regua.style.cssText = 'position:fixed;left:0;top:0;width:0;height:100svh;visibility:hidden;pointer-events:none';
document.body.append(regua);
export const alturaTela = () => regua.offsetHeight || innerHeight;

export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
/** onde v está entre a e b, de 0 a 1 */
export const faixa = (v, a, b) => clamp((v - a) / (b - a));
