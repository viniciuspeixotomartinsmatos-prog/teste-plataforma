// Nav: as caixas ganham fio fora do hero; o link da seção na tela acende; o menu do celular abre e fecha.
import { ScrollTrigger } from 'gsap/ScrollTrigger';

export function nav({ lenis }) {
  const el = document.querySelector('[data-nav]');
  const hero = document.querySelector('.hero');
  ScrollTrigger.create({
    trigger: hero, start: 'bottom 80px', end: 'max',
    onToggle: (st) => el.classList.toggle('is-sobre-pagina', st.isActive),
  });

  const links = [...el.querySelectorAll('.nav__link')];
  for (const a of links) {
    const alvo = document.querySelector(a.getAttribute('href'));
    if (!alvo) continue;
    ScrollTrigger.create({ trigger: alvo, start: 'top 50%', end: 'bottom 50%', onToggle: (st) => a.classList.toggle('is-ativo', st.isActive) });
  }

  const botao = el.querySelector('.nav__menu');
  const menu = el.querySelector('#menu');
  const fechar = () => { botao.setAttribute('aria-expanded', 'false'); menu.hidden = true; lenis?.start(); };
  botao.addEventListener('click', () => {
    const abrir = menu.hidden;
    botao.setAttribute('aria-expanded', String(abrir));
    menu.hidden = !abrir;
    if (abrir) lenis?.stop(); else lenis?.start();
  });
  menu.addEventListener('click', (e) => { if (e.target.closest('a')) fechar(); });
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && !menu.hidden) { fechar(); botao.focus(); } });
}
