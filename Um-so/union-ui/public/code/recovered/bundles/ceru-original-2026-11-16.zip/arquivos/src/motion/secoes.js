// As seções do meio: imagens em pixel que chegam em blocos ao entrar na tela, faixa de logos, abas dos recursos,
// passos, manifesto que acende, chaves e botões dos cartões. Entradas por marco (por tempo), nunca presas ao scroll.
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { criarPixel } from '../gl/pixel.js';
import { REDUZIDO, CELULAR } from './ease.js';

const celula = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--celula')) || 3;
const foco = (s) => (s ? s.split(' ').map(Number) : [0.5, 0.5]);

/** chama f uma vez quando el entra na tela (com folga) */
function aoVer(el, f, margem = '0px 0px -12% 0px') {
  const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { io.disconnect(); f(); } }, { rootMargin: margem });
  io.observe(el);
}

export function secoes() {
  // imagens em pixel soltas
  document.querySelectorAll('[data-pixel]').forEach((el) => {
    const desfaz = el.classList.contains('fecho__visual') ? { topo: 0.42, base: 0 } : undefined;
    const px = criarPixel(el, el.dataset.pixel, { foco: foco(el.dataset.foco), celula, desfaz });
    aoVer(el, () => px.preparar(), '150% 0px 150% 0px'); // a versão fina fica pronta antes de a imagem chegar
    aoVer(el, () => (REDUZIDO ? px.desenhar(0) : px.chegar(0.6)), '0px 0px 10% 0px');
  });

  logos();
  recursos();
  passos();
  manifesto();
  cartoes();
  entradas();
}

function logos() {
  const trilho = document.querySelector('.logos__trilho');
  if (!trilho) return;
  // a faixa anda -50%: a segunda metade é a cópia da primeira
  for (const li of [...trilho.children]) {
    const c = li.cloneNode(true);
    c.setAttribute('aria-hidden', 'true');
    trilho.append(c);
  }
}

function recursos() {
  const sec = document.querySelector('.recursos');
  if (!sec) return;
  const abas = [...sec.querySelectorAll('.aba')];
  const painel = sec.querySelector('[data-painel]');
  const cartao = sec.querySelector('[data-cartao]');
  const visual = sec.querySelector('[data-pixel-recursos]');
  const modelos = [...sec.querySelectorAll('template[data-aba-conteudo]')];
  let atual = -1;
  const px = criarPixel(visual, modelos[0].dataset.img, { foco: foco(modelos[0].dataset.foco), celula });

  function montar(i) {
    const frag = modelos[i].content.cloneNode(true);
    const card = frag.querySelector('.cartao-ui');
    card.remove();
    painel.replaceChildren(frag);
    cartao.replaceChildren(card);
    painel.setAttribute('aria-labelledby', abas[i].id);
    // os botões do cartão também respondem
    card.querySelectorAll('.chave').forEach(ligarChave);
    card.querySelectorAll('button.chip').forEach((b) => b.addEventListener('click', () => piscar(b)));
  }

  function ir(i, { foco: focar = false, primeira = false } = {}) {
    if (i === atual) return;
    abas.forEach((a, k) => {
      a.setAttribute('aria-selected', String(k === i));
      a.tabIndex = k === i ? 0 : -1;
    });
    if (focar) abas[i].focus();
    const m = modelos[i];
    if (primeira) {
      montar(i);
    } else {
      sec.classList.add('is-trocando');
      setTimeout(() => { montar(i); requestAnimationFrame(() => sec.classList.remove('is-trocando')); }, 170);
      px.trocar(m.dataset.img, foco(m.dataset.foco));
    }
    atual = i;
    reiniciarTempo();
  }

  // troca sozinha a cada 6 s enquanto a seção está na tela; clicar numa aba para a troca automática
  const tempo = document.createElement('span');
  tempo.className = 'aba__tempo';
  let auto = !REDUZIDO, tween = null, naTela = false;
  function reiniciarTempo() {
    tween?.kill();
    abas[atual].append(tempo);
    gsap.set(tempo, { scaleX: 0 });
    if (!auto || !naTela) return;
    tween = gsap.to(tempo, { scaleX: 1, duration: 6, ease: 'none', onComplete: () => ir((atual + 1) % abas.length) });
  }
  ScrollTrigger.create({ trigger: sec, start: 'top 70%', end: 'bottom 30%', onToggle: (st) => { naTela = st.isActive; reiniciarTempo(); } });

  abas.forEach((a, i) => {
    a.addEventListener('click', () => { auto = false; ir(i); tempo.remove(); });
    a.addEventListener('keydown', (e) => {
      const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
      if (!d) return;
      e.preventDefault();
      auto = false;
      ir((atual + d + abas.length) % abas.length, { foco: true });
      tempo.remove();
    });
  });

  ir(0, { primeira: true });
  aoVer(visual, () => px.preparar(), '150% 0px 150% 0px');
  aoVer(visual, () => (REDUZIDO ? px.desenhar(0) : px.chegar(0.6)), '0px 0px 10% 0px');
}

function passos() {
  const lista = document.querySelectorAll('.passo');
  lista.forEach((p, i) => aoVer(p, () => setTimeout(() => p.classList.add('is-visto'), i * 140)));
}

// manifesto: cada palavra acende quando a linha dela passa do meio da tela (troca por tempo, com transição)
function manifesto() {
  const el = document.querySelector('[data-acende]');
  if (!el) return;
  const palavras = el.textContent.trim().split(/\s+/);
  el.innerHTML = palavras.map((p) => `<span class="p">${p}</span>`).join(' ');
  const spans = [...el.querySelectorAll('.p')];
  if (REDUZIDO) { spans.forEach((s) => s.classList.add('is-on')); return; }
  ScrollTrigger.create({
    trigger: el, start: 'top 85%', end: 'bottom 40%',
    onUpdate: (st) => {
      const linha = innerHeight * (CELULAR() ? 0.7 : 0.62);
      for (const s of spans) s.classList.toggle('is-on', s.getBoundingClientRect().top < linha);
    },
  });
}

function ligarChave(ch) {
  ch.addEventListener('click', (e) => {
    e.preventDefault();
    ch.setAttribute('aria-checked', String(ch.getAttribute('aria-checked') !== 'true'));
  });
}
function piscar(b) {
  b.animate([{ transform: 'scale(0.96)' }, { transform: 'none' }], { duration: 260, easing: 'cubic-bezier(0.16, 1, 0.3, 1)' });
}

function cartoes() {
  // chaves das regras (o label inteiro liga e desliga)
  document.querySelectorAll('.regra').forEach((r) => {
    const ch = r.querySelector('.chave');
    ligarChave(ch);
    r.addEventListener('click', (e) => { if (e.target === r || e.target.tagName === 'SPAN') ch.click(); });
  });
  const aplicar = document.querySelector('.vidro__botao');
  aplicar?.addEventListener('click', () => {
    aplicar.classList.add('is-feito');
    aplicar.textContent = 'Regras aplicadas';
    setTimeout(() => { aplicar.classList.remove('is-feito'); aplicar.textContent = 'Aplicar a todos os assistentes'; }, 2400);
  });
  // + do fluxo: acrescenta um passo (uma vez) e depois só pisca
  const mais = document.querySelector('.fluxo__mais');
  mais?.addEventListener('click', () => {
    if (!mais.dataset.feito) {
      const p = document.createElement('div');
      p.className = 'fluxo__passo';
      p.innerHTML = '<b>04</b>Avisar no chat do time';
      mais.before(p);
      p.animate([{ opacity: 0, transform: 'translateY(-8px)' }, { opacity: 1, transform: 'none' }], { duration: 420, easing: 'cubic-bezier(0.16, 1, 0.3, 1)' });
      mais.dataset.feito = '1';
    } else piscar(mais);
  });

  // ação: enviar ao time
  const enviar = document.querySelector('[data-enviar]');
  const aviso = document.querySelector('[data-aviso]');
  enviar?.addEventListener('click', () => {
    const feito = enviar.classList.toggle('is-feito');
    enviar.querySelector('[data-rotulo]').textContent = feito ? 'Enviado ✓' : 'Enviar ao time';
    aviso.textContent = feito ? 'Enviado para as 6 pessoas da reunião' : '';
  });
  document.querySelector('.acao__editar')?.addEventListener('click', (e) => {
    piscar(e.currentTarget);
    aviso.textContent = 'Editor aberto ao lado da conversa';
    setTimeout(() => { if (aviso.textContent.startsWith('Editor')) aviso.textContent = ''; }, 2200);
  });
}

// entradas por marco: títulos e blocos sobem um pouco quando chegam na tela
function entradas() {
  if (REDUZIDO) return;
  const grupos = [
    '.prova__selo', '.recursos__texto', '.recursos__visual', '.topo-dividido', '.grade-cortes .celula',
    '.como__topo', '.pesquisa__texto', '.pesquisa__pilha .cartao-ui', '.acao__visual', '.fecho__miolo', '.rodape__miolo',
  ];
  for (const sel of grupos) {
    const els = gsap.utils.toArray(sel);
    els.forEach((el, i) => {
      gsap.set(el, { autoAlpha: 0, y: 26 });
      aoVer(el, () => gsap.to(el, { autoAlpha: 1, y: 0, duration: 1, ease: 'ce-out', delay: (i % 3) * 0.08 }));
    });
  }
}
