// A paleta do pixel vem do CSS (tokens.css, --px-0 … --px-7 e --fundo): trocar de tema troca o céu também.
export function hexParaRgb(hex) {
  const h = hex.trim().replace('#', '');
  const v = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
  return [0, 2, 4].map((i) => parseInt(v.slice(i, i + 2), 16) / 255);
}

export function lerPaleta() {
  const cs = getComputedStyle(document.documentElement);
  const tons = Array.from({ length: 8 }, (_, i) => cs.getPropertyValue(`--px-${i}`).trim() || '#ffffff');
  return { tons, fundo: cs.getPropertyValue('--fundo').trim() || '#ffffff' };
}
