// Hero: o céu em pixel. O shader desenha o vídeo (ou o pôster, até o vídeo tocar) célula a célula; aqui ficam a
// abertura (os blocos que ganham resolução), o véu atrás do texto e a saída pela rolagem. O canvas só desenha com o
// hero na tela e só quando há o que mudar: um quadro novo do vídeo, a abertura, a rolagem ou o tamanho.
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { criarCeu } from '../gl/ceu.js';
import { REDUZIDO, CELULAR, clamp } from './ease.js';

export function criarHero() {
  const hero = document.querySelector('.hero');
  const caixa = hero.querySelector('.hero__ceu');
  const canvas = hero.querySelector('.hero__gl');
  const video = hero.querySelector('.hero__video');
  const foto = hero.querySelector('.hero__foto'); // o pôster: o 1º quadro do vídeo (ou a imagem, sem vídeo)
  const conversa = hero.querySelector('.conversa');

  const celula = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--celula')) || 3;
  let ceu = null;
  try { ceu = criarCeu(canvas, { caixa, celula, foco: [0.5, 0.62] }); } catch (e) { console.warn(e); }
  if (!ceu) {
    hero.classList.add('is-sem-gl');
    return { ceu: null, abrir: (tl) => tl, medirVeu() {} };
  }
  hero.classList.add('is-gl');
  const { estado } = ceu;
  let visivel = true, pedido = 0, sujo = true; // estado do desenho sob pedido (pedir/quadro, mais abaixo)
  // com abertura, o céu nasce em blocos grandes desde o primeiro quadro (a abertura espera a fonte)
  if (document.documentElement.classList.contains('abertura') && !REDUZIDO) estado.abre = 0;
  estado.tom = [0.0, 1.06, 1.0];
  // no celular em pé o recorte do meio é quase só céu: puxa para as nuvens grandes da esquerda
  const enquadrar = () => { estado.focoImg[0] = CELULAR() ? [0.24, 0.5] : [0.5, 0.5]; };
  enquadrar();

  // o pôster primeiro (é o 1º quadro exato do vídeo), depois o vídeo quando tiver quadro
  let temVideo = false;
  const poster = new Image();
  poster.decoding = 'async';
  poster.src = foto.currentSrc || foto.src;
  const comPoster = () => { if (!temVideo) { ceu.imagem(0, poster); pedir(); } };
  if (poster.complete && poster.naturalWidth) comPoster(); else poster.addEventListener('load', comPoster, { once: true });

  // o vídeo vira a textura assim que tem o 1º quadro (igual ao pôster, então a troca não aparece). Quadro novo: com
  // requestVideoFrameCallback, só quando ele chega; sem ele (Firefox), a cada quadro; e a cada seek (vídeo parado
  // levado a outro instante, como na gravação da prévia)
  // sem <video> no hero.html, fica a imagem do pôster parada, no mesmo shader
  const porQuadro = !!video && 'requestVideoFrameCallback' in video;
  let quadroNovo = false;
  function ligarVideo() {
    if (temVideo) return;
    temVideo = true;
    ceu.imagem(0, video);
    pedir();
    if (REDUZIDO) return; // movimento reduzido: fica a pintura parada no 1º quadro
    const toca = video.play();
    if (toca) toca.catch(() => {}); // modo de economia do iOS: fica o 1º quadro
    if (porQuadro) {
      const cb = () => { quadroNovo = true; pedir(); video.requestVideoFrameCallback(cb); };
      video.requestVideoFrameCallback(cb);
    }
  }
  if (video) {
    video.addEventListener('seeked', () => { quadroNovo = true; pedir(); });
    video.addEventListener('loadeddata', ligarVideo, { once: true });
    video.load();
    if (video.readyState >= 2) ligarVideo();
  }

  // o véu atrás do título e da conversa, medido no DOM (em fração da caixa)
  function medirVeu() {
    const rc = caixa.getBoundingClientRect();
    const t = hero.querySelector('.hero__titulo').getBoundingClientRect();
    const c = conversa.getBoundingClientRect();
    const topo = t.top - rc.top, base = c.bottom - rc.top;
    const cx = (t.left + t.right) / 2 - rc.left;
    const larg = Math.max(t.width, c.width);
    estado.veu = [cx / rc.width, (topo + base) / 2 / rc.height, (larg * 0.62) / rc.width, ((base - topo) * 0.62) / rc.height];
    // a abertura parte da conversa
    estado.foco = [cx / rc.width, (c.top + c.height / 2 - rc.top) / rc.height];
    pedir();
  }
  medirVeu();
  estado.veuForca = CELULAR() ? 0.62 : 0.55;

  // saída: o céu se desfaz na página enquanto o hero sobe
  ScrollTrigger.create({
    trigger: hero, start: 'top top', end: 'bottom top',
    onUpdate: (st) => { estado.sai = st.progress; pedir(); },
  });

  // desenho sob pedido: um quadro por pedido, só com o hero visível e a aba aberta
  new IntersectionObserver(([e]) => { visivel = e.isIntersecting; if (visivel) pedir(); }).observe(hero);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) pedir(); });

  function quadro() {
    pedido = 0;
    if (!visivel || document.hidden) return;
    if (temVideo && (quadroNovo || (!porQuadro && !video.paused))) { ceu.subir(0); quadroNovo = false; sujo = true; }
    if (sujo) { ceu.desenhar(); sujo = false; }
    if (temVideo && !porQuadro && !video.paused) pedir(); // sem aviso de quadro novo: acompanha o vídeo
  }
  function pedir() {
    sujo = true;
    if (!pedido) pedido = requestAnimationFrame(quadro);
  }
  pedir();

  let largura = innerWidth;
  new ResizeObserver(() => {
    ceu.medir();
    medirVeu();
    // no celular a barra do navegador muda a altura a toda hora: só a largura troca o enquadramento
    if (innerWidth !== largura) { largura = innerWidth; enquadrar(); }
    pedir();
  }).observe(caixa);

  /** abertura: os blocos ganham resolução a partir da conversa; o texto entra junto */
  function abrir(tl) {
    estado.abre = 0;
    const proxy = { p: 0 };
    tl.to(proxy, {
      p: 1, duration: 1.5, ease: 'power1.inOut',
      onUpdate: () => { estado.abre = clamp(proxy.p); pedir(); },
    }, 0);
    return tl;
  }

  return { ceu, abrir, medirVeu };
}
