# Receitas: como a paisagem e as imagens da Ceru foram feitas

Tudo o que aparece em pixel na página é uma **pintura de paisagem** (gerada) passada pelo pontilhado do site. O
pontilhado é código e funciona com qualquer imagem: o que estas receitas fazem é dar ao site uma pintura com a mesma
luz e o mesmo clima. Os prompts estão em `prompts/`, em inglês (os geradores entendem melhor).

## A ordem

1. **O quadro do hero** (`prompts/k1-paisagem.txt`): a pintura de paisagem em 16:9, com céu azul, nuvens brancas nos
   dois lados e um vão claro no meio (onde ficam o título e a conversa), montanhas no horizonte, lago e árvores
   escuras nas bordas. Qualquer gerador de imagem serve (o do ChatGPT, Midjourney, Ideogram, Gemini). Peça 16:9 e
   confira: o meio tem de ser claro e calmo, e as bordas, escuras.
2. **O vídeo** (`prompts/video-loop.txt`): o mesmo quadro, animado num gerador de vídeo com "imagem para vídeo"
   (Kling, Runway, Luma, Higgsfield, Veo). **Câmera parada**, 10 s, só as nuvens andando, a água brilhando e as
   árvores balançando de leve. 720p basta: o pixel do site não usa mais detalhe que isso, e custa menos (é o clipe
   mais barato do gerador, em geral alguns créditos).
3. **O loop**: da raiz do projeto, `npm install -E -D @ffmpeg-installer/ffmpeg@1.1.0` e
   `node arquivos/fonte/loop.mjs caminho/do/clipe.mp4`. Ele corta o começo, funde o fim no começo (sem salto), reduz
   e grava `public/video/ceu.mp4` e o pôster `public/img/ceu-poster.jpg` (o 1º quadro exato).
4. **As imagens das seções** (`prompts/k2-nuvens.txt`, `k3-noite.txt`, `k4-campo.txt`): no mesmo estilo de pintura,
   de preferência passando o quadro do hero como referência de estilo. Salve em `public/img/` com os mesmos nomes
   (`k2-nuvens.jpg`, `k3-noite.jpg`, `k4-campo.jpg`), em JPG de 960 px de largura: o site reduz e pinta em pixel
   sozinho. O quadro do hero também vira a imagem do fecho e de uma das abas (`k1-lago.jpg`).

## O que adaptar

- **Outra paisagem** (mar, serra, campo, deserto): mantenha o que faz o pontilhado ficar bonito: céu claro em cima,
  um vão claro no meio para o texto, escuro nas bordas e embaixo, tons frios (a paleta é de azuis; uma pintura
  quente vira cinzas). Nada de pessoas, prédios, texto ou logo na imagem.
- **Outra cor de marca**: não precisa gerar de novo. A cor sai da paleta do site (os oito tons `--px-0` a `--px-7`
  em `src/styles/tokens.css`); a imagem só dá a luz e a forma.
- **Foto em vez de pintura**: funciona, mas a pintura tem pincelada larga, que o pixel lê melhor. Foto com muito
  detalhe miúdo (folhagem fina, cidade) vira ruído.

## Sem vídeo

O hero funciona só com a imagem: apague o `<video>` de `src/sections/hero.html` e troque `public/img/ceu-poster.jpg`
pela sua pintura (16:9, 960 px ou mais). O pixel, a abertura e a saída continuam iguais; só as nuvens ficam paradas.
