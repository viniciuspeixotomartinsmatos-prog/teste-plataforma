#version 300 es
// Céu em pixel: o shader da Ceru.
// Cada pixel do canvas é uma célula da tela (o CSS amplia o canvas com image-rendering: pixelated, então cada célula
// sai como um quadrado de canto vivo). Para cada célula: amostra o vídeo (ou a foto) já com a média da área da célula
// (mipmap), passa pelo tratamento (tom e véu atrás do texto) e imprime a cor com os dois tons da paleta que melhor
// a misturam, escolhidos por um limiar ordenado de Bayer 8×8. De longe é pintura; de perto, oito tons de céu em
// quadradinhos.
// Extras da marca:
// - abertura: a imagem nasce em blocos de 64 células e ganha resolução em degraus de potência de 2, a partir da
//   conversa para as bordas (a imagem "pensa" e chega);
// - saída: na rolagem a imagem se desfaz na cor da página, em blocos que engrossam perto da borda;
// - rasgo (seção de pesquisa): um buraco de borda rasgada abre o céu do dia e mostra o céu da noite atrás.
precision highp float;
precision highp int;

uniform sampler2D u_a;        // imagem principal: quadro do vídeo ou foto
uniform sampler2D u_b;        // céu de trás (só no rasgo)
uniform vec2 u_grade;         // tamanho do canvas, em células
uniform vec4 u_capa;          // object-fit cover da imagem a: escala do uv (xy) e deslocamento (zw)
uniform vec4 u_capaB;         // o mesmo para a imagem b
uniform vec2 u_lod;           // log2 de texels por célula, das imagens a e b
uniform float u_abre;         // abertura: 0 = blocos de 64 células, 1 = célula inteira
uniform vec2 u_foco;          // de onde a abertura parte, em células (y de cima para baixo)
uniform float u_sai;          // saída: 0 = inteira, 1 = desfeita na cor da página
uniform vec4 u_veu;           // véu atrás do texto: centro e raios, em células
uniform float u_veuForca;
uniform float u_rasgo;        // rasgo: < 0 desliga; 0..1 abertura
uniform vec3 u_rasgoC;        // centro do rasgo (células) e raio máximo (células)
uniform vec3 u_pal[8];        // paleta, em luz linear
uniform vec3 u_fundo;         // cor da página, em sRGB
uniform vec3 u_tom;           // exposição, contraste, saturação

out vec4 cor;

const vec3 PESO = vec3(0.30, 0.59, 0.11);
const float PENA = 0.12; // castigo para misturar tons distantes (o padrão fica áspero)

// limiar de Bayer 8×8, de 0 a 1: entrelaça os bits de (x xor y) e y
float bayer(vec2 c) {
  ivec2 i = ivec2(mod(c, 8.0));
  int a = i.x ^ i.y, b = i.y;
  int v = ((a & 1) << 5) | ((b & 1) << 4) | ((a & 2) << 2) | ((b & 2) << 1) | ((a & 4) >> 1) | ((b & 4) >> 2);
  return (float(v) + 0.5) / 64.0;
}

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float ruido(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

// os dois tons da paleta cuja mistura chega mais perto de c (luz linear), e quanto do segundo entra
vec3 pontilha(vec3 c, float limiar) {
  float melhor = 1e9;
  vec3 A = u_pal[0], B = u_pal[0];
  float T = 0.0;
  for (int i = 0; i < 8; i++) {
    for (int j = i; j < 8; j++) {
      vec3 a = u_pal[i], ab = u_pal[j] - a;
      float t = clamp(dot(c - a, ab) / max(dot(ab, ab), 1e-6), 0.0, 1.0);
      vec3 e = a + ab * t - c;
      float erro = dot(e * e, PESO) + PENA * dot(ab * ab, PESO) * t * (1.0 - t);
      if (erro < melhor) { melhor = erro; A = a; B = u_pal[j]; T = t; }
    }
  }
  return limiar < T ? B : A;
}

vec3 amostra(sampler2D tex, vec4 capa, float lod, vec2 celula) {
  vec2 uv = clamp(celula / u_grade, 0.0, 1.0) * capa.xy + capa.zw;
  return textureLod(tex, uv, lod).rgb;
}

vec3 tratar(vec3 s) {
  s = (s - 0.5) * u_tom.y + 0.5 + u_tom.x;
  float l = dot(s, vec3(0.2126, 0.7152, 0.0722));
  s = clamp(mix(vec3(l), s, u_tom.z), 0.0, 1.0);
  return pow(s, vec3(2.2));
}

void main() {
  // a célula, com y de cima para baixo
  vec2 c = vec2(floor(gl_FragCoord.x), u_grade.y - 1.0 - floor(gl_FragCoord.y));

  // abertura: blocos de 2^nível células, mais finos perto do foco
  float nivel = 0.0;
  if (u_abre < 1.0) {
    float d = length((c - u_foco) / u_grade.y);
    float resta = 1.0 - u_abre;
    nivel = clamp(floor(resta * 6.4 + d * 2.6 * resta), 0.0, 6.0);
  }
  float bs = exp2(nivel);
  vec2 bloco = floor(c / bs);
  vec2 centro = (bloco + 0.5) * bs;

  float lodA = u_lod.x + nivel;
  vec3 s = tratar(amostra(u_a, u_capa, lodA, centro));

  // rasgo: um buraco de borda irregular mostra o céu de trás; a borda é papel claro, com sombra para dentro
  if (u_rasgo >= 0.0) {
    vec2 dr = (centro - u_rasgoC.xy) / u_rasgoC.z;
    float ang = atan(dr.y, dr.x);
    float r = length(dr * vec2(0.82, 1.0));
    float borda = u_rasgo * (0.78 + 0.22 * ruido(vec2(ang * 2.2, 3.0))) + 0.05 * (ruido(c * 0.35) - 0.5) * u_rasgo;
    borda *= 1.0 + 0.10 * sin(ang * 3.0 + 1.3);
    float papel = 1.6 / u_rasgoC.z * (0.6 + ruido(c * 0.5 + 7.0));
    if (r < borda) {
      vec3 n = tratar(amostra(u_b, u_capaB, u_lod.y + nivel, centro));
      float sombra = smoothstep(borda - 8.0 / u_rasgoC.z, borda, r);
      s = mix(n, n * 0.35, sombra * 0.8);
    } else if (r < borda + papel && u_rasgo > 0.01) {
      s = mix(u_pal[0], u_pal[1], step(0.6, ruido(c * 0.9)));
    }
  }

  // véu atrás do título e da conversa: o céu clareia em pixel, sem desfoque
  vec2 dvv = (centro - u_veu.xy) / u_veu.zw;
  float veu = exp(-dot(dvv, dvv) * 1.6) * u_veuForca;
  s = mix(s, mix(u_pal[1], u_pal[0], 0.5), veu);

  vec3 px = pontilha(s, bayer(bloco));

  // pé: na saída, a imagem se desfaz na cor da página em blocos que engrossam perto da borda. Com o hero inteiro na
  // tela não há nada desfeito; depois de ~6% de rolagem o pé nasce na borda de baixo e engrossa até ~40% da altura,
  // com blocos de até 8 células (a parte do hero que ainda está na tela continua inteira em cima)
  float y = (c.y + 0.5) / u_grade.y;
  float pe = max(0.0, u_sai - 0.06) * 0.42;
  float k = smoothstep(1.0 - pe, 1.0, y);
  if (k > 0.0) {
    float nb = floor(k * (1.99 + u_sai * 2.0));
    if (bayer(floor(c / exp2(nb)) + vec2(3.0, 5.0)) < k) { cor = vec4(u_fundo, 1.0); return; }
  }

  cor = vec4(pow(px, vec3(1.0 / 2.2)), 1.0);
}
