// O canvas do céu em pixel (shader em ceu.frag.glsl). Um canvas do tamanho da grade de células, ampliado pelo CSS
// sem suavizar: cada pixel do canvas vira um quadrado de canto vivo na tela. A célula tem um número inteiro de
// pixels da tela (3 px de CSS = 6 px num retina), e o canvas fica um pouco maior que a caixa, cortado nas bordas,
// para nenhuma célula sair torta.
import frag from './ceu.frag.glsl?raw';
import { lerPaleta, hexParaRgb } from './paleta.js';

const VERT = `#version 300 es
in vec2 p;
void main() { gl_Position = vec4(p, 0.0, 1.0); }`;

function compilar(gl, tipo, fonte) {
  const s = gl.createShader(tipo);
  gl.shaderSource(s, fonte);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}

/**
 * @param {HTMLCanvasElement} canvas
 * @param {{ caixa: HTMLElement, celula?: () => number, foco?: [number, number] }} op
 */
export function criarCeu(canvas, op) {
  const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, depth: false, stencil: false, premultipliedAlpha: false, powerPreference: 'high-performance' });
  if (!gl) return null;

  const prog = gl.createProgram();
  gl.attachShader(prog, compilar(gl, gl.VERTEX_SHADER, VERT));
  gl.attachShader(prog, compilar(gl, gl.FRAGMENT_SHADER, frag));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  gl.useProgram(prog);

  // um triângulo que cobre a tela
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, 'p');
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

  const U = {};
  const n = gl.getProgramParameter(prog, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) {
    const nome = gl.getActiveUniform(prog, i).name.replace(/\[0\]$/, ''); // vetores: o local do primeiro item
    U[nome] = gl.getUniformLocation(prog, nome);
  }

  // texturas: a (principal) na unidade 0, b (rasgo) na 1
  const tex = [gl.createTexture(), gl.createTexture()];
  const fonteTex = [null, null];
  const tamTex = [[1, 1], [1, 1]];
  for (let i = 0; i < 2; i++) {
    gl.activeTexture(gl.TEXTURE0 + i);
    gl.bindTexture(gl.TEXTURE_2D, tex[i]);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([200, 220, 245, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }
  gl.uniform1i(U.u_a, 0);
  gl.uniform1i(U.u_b, 1);

  // estado que a página mexe (o hero e a seção de pesquisa)
  const estado = {
    abre: 1, foco: op.foco || [0.5, 0.5], sai: 0,
    veu: [0.5, 0.45, 0.3, 0.2], veuForca: 0, // centro e raios em fração da caixa
    rasgo: -1, rasgoC: [0.5, 0.5, 0.5], // centro em fração da caixa, raio em fração da altura
    tom: [0, 1, 1], // exposição, contraste, saturação
    focoImg: [[0.5, 0.5], [0.5, 0.5]], // onde o cover segura a imagem (como object-position)
    zoomImg: [1, 1], // aproxima a imagem dentro do cover (1 = cover puro)
  };
  let W = 1, H = 1, celDev = 1, dpr = 1, celCss = 3;
  function medir() {
    dpr = Math.min(devicePixelRatio || 1, 3);
    celCss = op.celula ? op.celula() : 3;
    celDev = Math.max(1, Math.round(celCss * dpr));
    const r = op.caixa.getBoundingClientRect();
    W = Math.max(1, Math.ceil((r.width * dpr) / celDev));
    H = Math.max(1, Math.ceil((r.height * dpr) / celDev));
    canvas.width = W;
    canvas.height = H;
    canvas.style.width = `${(W * celDev) / dpr}px`;
    canvas.style.height = `${(H * celDev) / dpr}px`;
    gl.viewport(0, 0, W, H);
    gl.uniform2f(U.u_grade, W, H);
  }

  // object-fit: cover em células (as células são quadradas)
  function capa(i) {
    const [tw, th] = tamTex[i];
    const ag = W / H, at = tw / th;
    let sx = 1, sy = 1;
    if (ag > at) sy = at / ag; else sx = ag / at;
    sx /= estado.zoomImg[i]; sy /= estado.zoomImg[i];
    const [fx, fy] = estado.focoImg[i];
    const visiveis = tw * sx; // texels na largura visível
    return { v: [sx, sy, (1 - sx) * fx, (1 - sy) * fy], lod: Math.max(0, Math.log2(visiveis / W)) };
  }

  /** troca a imagem de uma unidade: <img>, <video> ou <canvas> */
  function imagem(i, fonte) {
    fonteTex[i] = fonte;
    subir(i);
  }
  function subir(i) {
    const f = fonteTex[i];
    if (!f) return;
    const w = f.videoWidth || f.naturalWidth || f.width, h = f.videoHeight || f.naturalHeight || f.height;
    if (!w || !h) return;
    tamTex[i] = [w, h];
    gl.activeTexture(gl.TEXTURE0 + i);
    gl.bindTexture(gl.TEXTURE_2D, tex[i]);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, f);
    gl.generateMipmap(gl.TEXTURE_2D);
  }

  function paleta() {
    const { tons, fundo } = lerPaleta();
    const arr = new Float32Array(24);
    tons.forEach((hex, k) => {
      const [r, g, b] = hexParaRgb(hex);
      arr.set([r ** 2.2, g ** 2.2, b ** 2.2], k * 3);
    });
    gl.uniform3fv(U.u_pal, arr);
    gl.uniform3fv(U.u_fundo, hexParaRgb(fundo));
  }

  function desenhar() {
    const a = capa(0), b = capa(1);
    gl.uniform4fv(U.u_capa, a.v);
    gl.uniform4fv(U.u_capaB, b.v);
    gl.uniform2f(U.u_lod, a.lod, b.lod);
    gl.uniform1f(U.u_abre, estado.abre);
    gl.uniform2f(U.u_foco, estado.foco[0] * W, estado.foco[1] * H);
    gl.uniform1f(U.u_sai, estado.sai);
    gl.uniform4f(U.u_veu, estado.veu[0] * W, estado.veu[1] * H, Math.max(1, estado.veu[2] * W), Math.max(1, estado.veu[3] * H));
    gl.uniform1f(U.u_veuForca, estado.veuForca);
    gl.uniform1f(U.u_rasgo, estado.rasgo);
    gl.uniform3f(U.u_rasgoC, estado.rasgoC[0] * W, estado.rasgoC[1] * H, Math.max(1, estado.rasgoC[2] * H));
    gl.uniform3fv(U.u_tom, estado.tom);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  medir();
  paleta();

  return {
    gl, estado, medir, imagem, subir, paleta, desenhar,
    get celulaCss() { return celDev / dpr; },
    get grade() { return [W, H]; },
  };
}
