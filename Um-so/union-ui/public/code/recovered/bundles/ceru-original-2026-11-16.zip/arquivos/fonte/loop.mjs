// Transforma um clipe de paisagem (de qualquer gerador de vídeo ou filmado) no vídeo em loop do hero.
// Corta o começo, funde os últimos segundos no início (o fim emenda no começo sem salto), reduz para 960 × 540 (o pixel
// do hero não usa mais que isso) e grava, da raiz do projeto:
//   public/video/ceu.mp4      o loop, H.264 mudo, um quadro-chave só (sem "pulso" de compressão a cada 2 s)
//   public/img/ceu-poster.jpg o 1º quadro exato do loop (o hero mostra ele enquanto o vídeo carrega)
//
// Uso (da raiz do projeto):
//   npm install -E -D @ffmpeg-installer/ffmpeg@1.1.0     (ou tenha o ffmpeg instalado no sistema)
//   node arquivos/fonte/loop.mjs caminho/do/clipe.mp4 [--inicio 0.5] [--fusao 2]
// --inicio: segundos cortados do começo (muitos geradores seguram o 1º quadro parado por meio segundo)
// --fusao: segundos do fim que se fundem no começo (2 serve para nuvens; movimento rápido pede menos)
// O clipe ideal: câmera parada, 8 a 10 s, 16:9, nuvens andando e água brilhando, sem corte nem texto.
import { spawnSync } from 'node:child_process';
import { mkdirSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';

const args = process.argv.slice(2);
const entrada = args.find((a) => !a.startsWith('--'));
const opcao = (nome, padrao) => {
  const i = args.indexOf(`--${nome}`);
  return i >= 0 ? Number(args[i + 1]) : padrao;
};
if (!entrada || !existsSync(entrada)) {
  console.error('uso: node arquivos/fonte/loop.mjs caminho/do/clipe.mp4 [--inicio 0.5] [--fusao 2]');
  process.exit(1);
}

// o ffmpeg: o do pacote @ffmpeg-installer, se estiver instalado; senão, o do sistema
let ffmpeg = 'ffmpeg';
try { ffmpeg = createRequire(import.meta.url)('@ffmpeg-installer/ffmpeg').path; } catch {}
const roda = (a) => {
  const r = spawnSync(ffmpeg, a, { encoding: 'utf8' });
  if (r.error) { console.error('ffmpeg não encontrado: instale com npm install -E -D @ffmpeg-installer/ffmpeg@1.1.0'); process.exit(1); }
  return r;
};

// duração do clipe (o ffmpeg escreve "Duration: 00:00:10.04" na saída de erro)
const info = roda(['-hide_banner', '-i', entrada]).stderr;
const m = info.match(/Duration: (\d+):(\d+):([\d.]+)/);
if (!m) { console.error('não consegui ler a duração do clipe'); process.exit(1); }
const dur = Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
const inicio = opcao('inicio', 0.5);
const fusao = opcao('fusao', 2);
const fim = Math.floor(dur * 100) / 100;
const corpo = fim - inicio - fusao; // o loop dura isso
if (corpo < fusao + 2) { console.error(`clipe curto demais (${dur.toFixed(1)} s): use um de 6 s ou mais`); process.exit(1); }

mkdirSync('public/video', { recursive: true });
mkdirSync('public/img', { recursive: true });
const filtro = [
  '[0:v]split[a][b]',
  `[a]trim=start=${inicio + fusao}:end=${fim},setpts=PTS-STARTPTS[corpo]`,
  `[b]trim=start=${inicio}:end=${inicio + fusao},setpts=PTS-STARTPTS[cabeca]`,
  `[corpo][cabeca]xfade=transition=fade:duration=${fusao}:offset=${corpo - fusao},scale=960:540:force_original_aspect_ratio=increase,crop=960:540,format=yuv420p[v]`,
].join(';');
const quadros = Math.round(corpo * 60); // um quadro-chave só, até 60 fps
const r = roda([
  '-v', 'error', '-y', '-i', entrada, '-filter_complex', filtro, '-map', '[v]', '-an',
  '-c:v', 'libx264', '-profile:v', 'high', '-preset', 'slow', '-crf', '21',
  '-g', String(quadros), '-keyint_min', String(quadros), '-sc_threshold', '0', '-x264-params', 'ipratio=1.05:pbratio=1.05',
  '-movflags', '+faststart', '-bsf:v', 'h264_metadata=colour_primaries=1:transfer_characteristics=13:matrix_coefficients=1',
  'public/video/ceu.mp4',
]);
if (r.status !== 0) { console.error(r.stderr); process.exit(1); }
const p = roda(['-v', 'error', '-y', '-i', 'public/video/ceu.mp4', '-frames:v', '1', '-q:v', '2', 'public/img/ceu-poster.jpg']);
if (p.status !== 0) { console.error(p.stderr); process.exit(1); }
console.log(`pronto: public/video/ceu.mp4 (${corpo.toFixed(1)} s em loop) e public/img/ceu-poster.jpg`);
