// Abertura: o hero é o carregamento. O céu nasce em blocos grandes e ganha resolução a partir da conversa; o título,
// o texto e a conversa sobem junto, e a demonstração começa a digitar. Qualquer gesto (roda, toque, tecla) pula para
// o fim.
import gsap from 'gsap';
import { REDUZIDO } from './ease.js';

export function abertura({ hero, conversa, lenis }) {
  const html = document.documentElement;
  const tl = gsap.timeline({ paused: true });
  const pecas = ['.hero__titulo', '.hero__sub', '.conversa', '.sugestoes'];

  if (!html.classList.contains('abertura') || REDUZIDO) {
    html.classList.remove('abertura');
    conversa.ligarDemo(1200);
    return;
  }
  html.classList.add('abertura-viva');
  lenis?.stop();

  hero.abrir(tl);
  tl.from(pecas, { autoAlpha: 0, y: 22, duration: 1.1, ease: 'ce-out', stagger: 0.09 }, 0.42)
    .from('.nav', { autoAlpha: 0, y: -10, duration: 0.8, ease: 'ce-out' }, 0.8)
    .add(() => conversa.ligarDemo(200), 1.5);

  const pular = () => { if (tl.progress() < 1) tl.progress(1); };
  const fim = () => {
    lenis?.start();
    html.classList.remove('abertura', 'abertura-viva');
    gsap.set([...pecas, '.nav'], { clearProps: 'all' });
    ['wheel', 'touchstart', 'keydown'].forEach((t) => removeEventListener(t, pular));
  };
  tl.eventCallback('onComplete', fim);
  ['wheel', 'touchstart', 'keydown'].forEach((t) => addEventListener(t, pular, { passive: true }));
  requestAnimationFrame(() => tl.play());
}
