// Pixel das imagens das seções: o mesmo pontilhado do shader do hero (os dois tons da paleta que melhor misturam a
// cor, limiar de Bayer 8×8), feito em JS num canvas 2D, uma vez por tamanho. Cada imagem entra na tela em blocos
// grandes que ganham resolução em degraus (como a abertura do hero) e refaz a paleta quando o tema muda.
import { lerPaleta, hexParaRgb } from './paleta.js';

const BAYER = new Float32Array(64);
for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
  const a = x ^ y, b = y;
  const v = ((a & 1) << 5) | ((b & 1) << 4) | ((a & 2) << 2) | ((b & 2) << 1) | ((a & 4) >> 1) | ((b & 4) >> 2);
  BAYER[y * 8 + x] = (v + 0.5) / 64;
}
const PESO = [0.3, 0.59, 0.11];
const PENA = 0.12;

let paletaAtual = null;
function paleta() {
  if (paletaAtual) return paletaAtual;
  const { tons, fundo } = lerPaleta();
  const lin = tons.map((h) => hexParaRgb(h).map((v) => v ** 2.2));
  const srgb = tons.map((h) => hexParaRgb(h).map((v) => Math.round(v * 255)));
  paletaAtual = { lin, srgb, fundo: hexParaRgb(fundo).map((v) => Math.round(v * 255)), memo: new Int32Array(32768).fill(-1) };
  return paletaAtual;
}

// melhor par (i, j) e a fração t do segundo para uma cor (sRGB 0..255), memorizado por cor em 5 bits por canal
// (32 mil cores no máximo: o pontilhado não precisa de mais). Volta i | j << 3 | t * 1023 << 6 num inteiro só.
function par(P, r, g, b) {
  const chave = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
  const m = P.memo[chave];
  if (m >= 0) return m;
  const c0 = (((r >> 3) * 8 + 4) / 255) ** 2.2, c1 = (((g >> 3) * 8 + 4) / 255) ** 2.2, c2 = (((b >> 3) * 8 + 4) / 255) ** 2.2;
  let melhor = Infinity, res = 0;
  for (let i = 0; i < 8; i++) {
    const a = P.lin[i];
    for (let j = i; j < 8; j++) {
      const bb = P.lin[j];
      const d0 = bb[0] - a[0], d1 = bb[1] - a[1], d2 = bb[2] - a[2];
      const den = d0 * d0 + d1 * d1 + d2 * d2;
      let t = den > 1e-6 ? ((c0 - a[0]) * d0 + (c1 - a[1]) * d1 + (c2 - a[2]) * d2) / den : 0;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const e0 = a[0] + d0 * t - c0, e1 = a[1] + d1 * t - c1, e2 = a[2] + d2 * t - c2;
      const erro = e0 * e0 * PESO[0] + e1 * e1 * PESO[1] + e2 * e2 * PESO[2]
        + PENA * (d0 * d0 * PESO[0] + d1 * d1 * PESO[1] + d2 * d2 * PESO[2]) * t * (1 - t);
      if (erro < melhor) { melhor = erro; res = i | (j << 3) | (Math.round(t * 1023) << 6); }
    }
  }
  P.memo[chave] = res;
  return res;
}

/**
 * Uma imagem em pixel dentro de uma caixa (cover, como object-fit), com degraus de resolução.
 * @param {HTMLElement} caixa  o elemento que recebe o canvas (position relative, overflow hidden)
 * @param {string} src
 * @param {{ foco?: [number, number], tom?: number[], celula?: () => number, zoom?: number }} op
 */
export function criarPixel(caixa, src, op = {}) {
  const canvas = document.createElement('canvas');
  canvas.className = 'pixel__canvas';
  canvas.setAttribute('aria-hidden', 'true');
  caixa.prepend(canvas);
  const ctx = canvas.getContext('2d');
  const tmp = document.createElement('canvas');
  const tctx = tmp.getContext('2d', { willReadFrequently: true });
  const img = new Image();
  img.decoding = 'async';
  let pronta = false, W = 0, H = 0, nivelAtual = -1, fino = null;
  const tom = op.tom || [0, 1.06, 1];

  function medir() {
    const dpr = Math.min(devicePixelRatio || 1, 3);
    const cel = op.celula ? op.celula() : 3;
    const celDev = Math.max(1, Math.round(cel * dpr));
    const r = caixa.getBoundingClientRect();
    const w = Math.max(1, Math.ceil((r.width * dpr) / celDev)), h = Math.max(1, Math.ceil((r.height * dpr) / celDev));
    canvas.style.width = `${(w * celDev) / dpr}px`;
    canvas.style.height = `${(h * celDev) / dpr}px`;
    if (w === W && h === H) return false;
    W = w; H = h;
    canvas.width = W; canvas.height = H; // limpa o canvas: quem chamou redesenha
    return true;
  }

  // a imagem reduzida (média por área) para uma grade de gw × gh, em cover
  function reduzir(gw, gh) {
    tmp.width = gw; tmp.height = gh;
    const iw = img.naturalWidth, ih = img.naturalHeight;
    const z = op.zoom || 1;
    const ag = gw / gh, ai = iw / ih;
    let sw = iw, sh = ih;
    if (ag > ai) sh = iw / ag; else sw = ih * ag;
    sw /= z; sh /= z;
    const [fx, fy] = op.foco || [0.5, 0.5];
    tctx.imageSmoothingEnabled = true;
    tctx.imageSmoothingQuality = 'high';
    tctx.drawImage(img, (iw - sw) * fx, (ih - sh) * fy, sw, sh, 0, 0, gw, gh);
    return tctx.getImageData(0, 0, gw, gh);
  }

  // op.desfaz = { topo, base }: fração da altura que se desfaz na cor da página (como o pé do hero)
  const desfaz = op.desfaz || { topo: 0, base: 0 };
  const suave = (a, b, v) => { const t = Math.min(1, Math.max(0, (v - a) / (b - a))); return t * t * (3 - 2 * t); };
  // pontilha as linhas [y0, y1) de dados (tratamento igual ao do shader: contraste, exposição, saturação)
  const q = (v) => (v <= 0 ? 0 : v >= 1 ? 255 : (v * 255) | 0);
  function pontilharLinhas(dados, y0, y1) {
    const P = paleta();
    const d = dados.data, gw = dados.width, gh = dados.height;
    const [ex, ct, sat] = tom;
    for (let y = y0; y < y1; y++) {
      const yy = (y + 0.5) / gh;
      const k = Math.max(desfaz.topo ? suave(desfaz.topo, 0, yy) : 0, desfaz.base ? suave(1 - desfaz.base, 1, yy) : 0);
      const lb = (y & 7) * 8, lf = ((y + 5) & 7) * 8;
      for (let x = 0, i = y * gw * 4; x < gw; x++, i += 4) {
        let c;
        if (k > 0 && BAYER[lf + ((x + 3) & 7)] < k) c = P.fundo;
        else {
          let r = (d[i] / 255 - 0.5) * ct + 0.5 + ex, g = (d[i + 1] / 255 - 0.5) * ct + 0.5 + ex, b = (d[i + 2] / 255 - 0.5) * ct + 0.5 + ex;
          const l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
          r = l + (r - l) * sat; g = l + (g - l) * sat; b = l + (b - l) * sat;
          const m = par(P, q(r), q(g), q(b));
          c = BAYER[lb + (x & 7)] < (m >> 6) / 1023 ? P.srgb[(m >> 3) & 7] : P.srgb[m & 7];
        }
        d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255;
      }
    }
  }
  const pontilhar = (dados) => { pontilharLinhas(dados, 0, dados.height); return dados; };

  // a versão fina (célula a célula) sai em fatias de poucos ms por quadro, para nunca travar a rolagem
  let preparo = null;
  function preparar() {
    if (fino || preparo || !pronta) return preparo;
    const dados = reduzir(W, H);
    const este = {};
    let y = 0;
    preparo = este;
    este.p = new Promise((fim) => {
      const fatia = () => {
        if (preparo !== este) return; // a imagem ou o tamanho mudou no meio
        const t0 = performance.now();
        while (y < dados.height && performance.now() - t0 < 5) { pontilharLinhas(dados, y, Math.min(dados.height, y + 4)); y += 4; }
        if (y < dados.height) requestAnimationFrame(fatia);
        else { fino = dados; preparo = null; fim(); }
      };
      requestAnimationFrame(fatia);
    });
    return preparo;
  }

  /** desenha num nível (0 = célula; n = blocos de 2^n células) */
  function desenhar(nivel) {
    if (!pronta) return;
    if (nivel === 0) {
      if (!fino) { preparar()?.p.then(() => desenhar(0)); return; }
      ctx.putImageData(fino, 0, 0);
    } else {
      const s = 2 ** nivel;
      const gw = Math.ceil(W / s), gh = Math.ceil(H / s);
      const d = pontilhar(reduzir(gw, gh));
      tctx.putImageData(d, 0, 0);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(tmp, 0, 0, gw, gh, 0, 0, gw * s, gh * s);
    }
    nivelAtual = nivel;
  }

  let anim = 0, pendente = false;
  /** chega em degraus: blocos de 32 → 16 → 8 → 4 células → célula (o último espera a versão fina ficar pronta) */
  function chegar(duracao = 0.55, de = 5) {
    cancelAnimationFrame(anim);
    if (!pronta) { pendente = true; return; }
    preparar();
    const t0 = performance.now();
    const passo = (agora) => {
      const p = Math.min(1, (agora - t0) / (duracao * 1000));
      let n = Math.max(0, Math.ceil(de * (1 - p) - 0.001));
      if (n < 2) n = fino ? 0 : 2;
      if (n !== nivelAtual) desenhar(n);
      if (p < 1 || nivelAtual !== 0) anim = requestAnimationFrame(passo);
    };
    desenhar(de);
    anim = requestAnimationFrame(passo);
  }

  function refazer() {
    fino = null;
    preparo = null;
    if (pronta && nivelAtual >= 0) desenhar(nivelAtual);
  }

  img.addEventListener('load', () => {
    pronta = true;
    fino = null;
    preparo = null;
    medir();
    if (pendente) { pendente = false; chegar(); } else if (op.imediata) desenhar(0);
  });
  img.src = src;

  /** troca a imagem (abas): a nova chega em blocos assim que carregar */
  function trocar(novo, foco) {
    if (foco) op.foco = foco;
    pronta = false;
    pendente = true;
    img.src = novo;
    preparo = null;
    if (img.complete && img.naturalWidth) { pronta = true; fino = null; medir(); pendente = false; chegar(); }
  }

  let rz = 0;
  new ResizeObserver(() => {
    clearTimeout(rz);
    rz = setTimeout(() => { if (medir()) refazer(); }, 120);
  }).observe(caixa);

  return {
    canvas, chegar, desenhar, refazer, trocar,
    preparar: () => { if (pronta) preparar(); else img.addEventListener('load', () => preparar(), { once: true }); },
    get pronta() { return pronta; },
  };
}
