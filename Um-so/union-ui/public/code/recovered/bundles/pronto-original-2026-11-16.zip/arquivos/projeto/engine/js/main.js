// Monta o filme depois que as fontes e as imagens estão prontas (as medidas de texto dependem da fonte carregada).
// O filme tem os blocos obrigatórios e os opcionais listados em CFG.cenas, sempre na ordem do roteiro.
(async () => {
  try {
    document.title = `${CFG.marca && CFG.marca.nome || 'filme'} — ${CFG._nome}`;
    for (const w of [400, 500, 600, 700]) await document.fonts.load(`${w} 100px '${FONTE}'`);
    await document.fonts.ready;
    // toda a mídia citada no config (fotos, símbolo, logotipo) carrega antes de medir
    const paths = new Set();
    const walk = v => { if (typeof v === 'string' && /\.(jpe?g|png|webp|svg|avif)$/i.test(v)) paths.add(v); else if (v && typeof v === 'object') Object.values(v).forEach(walk); };
    walk(CFG);
    const sizes = {};
    await Promise.all([...paths].map(p => new Promise(r => { const i = new Image(); i.onload = () => { sizes[p] = [i.naturalWidth, i.naturalHeight]; r(); };
      i.onerror = () => { console.error('mídia não encontrada: ' + p); r(); }; i.src = M(p); })));
    const m = CFG.marca || {};
    if (m.simbolo && sizes[m.simbolo]) B.aspect = sizes[m.simbolo][0] / sizes[m.simbolo][1];
    if (m.logotipo && sizes[m.logotipo]) B.aspectLogotipo = sizes[m.logotipo][0] / sizes[m.logotipo][1];
    if (B.modo === 'simbolo' && !m.simbolo) throw new Error('marca.simbolo é obrigatório (ou marca.logo = "monolinha" só na demo)');
    const tipos = (CFG.cenas || []).map(c => c.tipo);
    const desconhecidas = tipos.filter(t => !F.ORDEM.includes(t));
    if (desconhecidas.length) throw new Error('cena desconhecida no config: ' + desconhecidas.join(', '));
    const P = F.plano(tipos);
    F.DUR = P.total + 1;
    for (const b of F.ORDEM) if (P.blocos[b]) window['BLOCO_' + b]();
    F.bloco('abertura');
    K.grain(F.stage);
    window.CUES = { fps: F.FPS, total: Math.round(P.total * F.FPS), events: F.CUES.slice().sort((a, b) => a.f - b.f) };
    window.LINHA = { fps: F.FPS, total: Math.round(P.total * F.FPS), duracao: P.total, blocos: P.ordem.map(t => { const b = P.blocos[t]; return { tipo: t, a: b.a, b: b.b, A: b.A, B: b.B }; }) };
    F.seek(0);
    document.documentElement.dataset.ready = '1';
    window.ready = true;
  } catch (e) {
    console.error('o filme não montou', e && e.stack || e);
    window.erroFilme = String(e && e.message || e);
    document.documentElement.dataset.ready = 'error';
  }
})();
