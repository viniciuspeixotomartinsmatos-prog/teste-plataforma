// Blocos "abertura" (0–5 s, obrigatório) e "problema" (5–11 s, opcional), no tempo canônico.
// abertura: o cursor de texto pisca três vezes e, no tempo forte (3,0 s), acende e troca de cor a cada batida.
// problema: a frase do problema é digitada; o jeito antigo dá trabalho: a busca, a cascata de itens e a escada de
// janelas que se multiplica, com o contador.
window.X = window.X || {};

window.BLOCO_abertura = () => {
  const { tl, el, scene, cue } = F;
  const st = F.stage;
  F.bloco('abertura');
  // fundo de papel (o filme inteiro, por baixo de tudo) e o preto do primeiro instante
  X.paper = el(`<div class="paper" style="z-index:0"></div>`, st);
  const black = el(`<div class="full" style="background:#000;z-index:950"></div>`, st);
  tl.set(black, { opacity: 1 }, 0); tl.set(black, { opacity: 0 }, .4);

  const s1 = scene('s1', 0, 5.05, 5);
  const cam1 = el(`<div class="full"></div>`, s1);
  tl.fromTo(cam1, { scale: 1 }, { scale: 1.06, duration: 5, ease: 'none', immediateRender: false }, 0);
  const c1 = K.caret(cam1, { x: 960 - 4, y: 540 - 58, w: 8, h: 116 });
  gsap.set(c1, { opacity: 0 });
  K.blink(c1, .5, 2.5, { period: 1, on: .45, sound: 'blink', id: 's1:blink' });
  tl.set(c1, { opacity: 1 }, 2.5); cue(2.5, 'blink', 's1:blink:2');
  cue(3.0, 'riser', 's1:riser', { end: true });
  const bl = c1.bloom;
  const pulse = (t, col, k, big = .9) => {
    tl.to(c1, { backgroundColor: col, duration: .08, ease: 'none' }, t);
    tl.fromTo(bl, { background: col, opacity: big }, { opacity: .28, duration: .5, ease: 'out', immediateRender: false }, t);
    tl.fromTo(c1, { scaleY: 1.16 }, { scaleY: 1, duration: .45, ease: 'out', immediateRender: false }, t);
    cue(t, k === 0 ? 'flare' : 'pulse', `s1:pulse:${k}`, { color: col });
  };
  pulse(3.0, C.grad[0], 0, 1); pulse(3.5, C.grad[1], 1); pulse(4.0, C.grad[2], 2); pulse(4.5, C.grad[3], 3);
  tl.to(c1, { backgroundColor: C.acao, width: 6, height: 116, x: 1, duration: .2 }, 4.8);
  tl.to(bl, { opacity: 0, duration: .25 }, 4.8);
  tl.set(c1, { opacity: 0 }, 5.0);
  X.c1 = c1;
};

window.BLOCO_problema = () => {
  const { tl, el, scene, cue, lerp, E, rng } = F;
  if (!F.bloco('problema')) return;
  const cfg = CENA('problema') || {};
  const busca = cfg.busca || {};
  const ITENS = (cfg.itens || []).map(i => typeof i === 'string' ? { titulo: i, fonte: '' } : i);
  while (ITENS.length < 14) ITENS.push(...ITENS.slice(0, 14 - ITENS.length));

  // ---- a frase do problema (5–7 s) ----
  const s2 = scene('s2', 4.98, 9.2, 6);
  const L1 = K.typeLine(s2, cfg.frase || '', { t0: 5.02, cps: 15.5, size: 104, x: 960, y: 540, id: 's2:type', caretH: 116, caretW: 6, maxW: 1640, tmax: 6.45 });
  K.blink(L1.caret, L1.end + .05, 6.6, { period: .5, on: .25 });
  tl.to(L1.caret, { opacity: 0, duration: .1 }, 6.6);
  tl.to(L1.line, { y: -L1.H / 2 - 230, scale: .5, duration: .55, ease: 'inout' }, 6.62);
  tl.to(L1.chars, { color: '#6b6b73', duration: .55 }, 6.62);

  // ---- o jeito antigo: a busca (7–9 s) ----
  const s3 = scene('s3', 6.7, 11.2, 7);
  const world3 = el(`<div class="full" style="perspective:1600px;perspective-origin:960px 420px"></div>`, s3);
  const page3 = el(`<div class="full" style="transform-style:preserve-3d;transform-origin:960px 300px"></div>`, world3);
  const box = el(`<div class="abs pill" style="left:${960 - 450}px;top:${540 - 37}px;width:900px;height:74px;background:#fff;border:1px solid #dcdcd8;box-shadow:0 2px 6px rgba(17,17,20,.06),0 14px 30px -18px rgba(17,17,20,.25)">
    <div class="abs" style="left:26px;top:22px">${K.icon(busca.icone || 'lupa', 30, '#8b8b93', 2.2)}</div>
    <div class="abs ui muted ph ell" style="left:74px;top:19px;font-size:29px;font-weight:400;max-width:790px">${H(busca.placeholder || '')}</div></div>`, page3);
  K.popIn(box, 6.95, { dur: .45, y: 18, s: .97 });
  const ph = box.querySelector('.ph');
  tl.to(ph, { opacity: 0, duration: .05 }, 7.22);
  const Q = K.typeLine(box, busca.texto || '', { t0: 7.25, cps: 25, size: 29, weight: 400, x: 74, y: 37, align: 'left', recenter: false, maxW: 790, tmax: 8.62,
    tint: C.ink, glow: false, settle: .01, caretColor: C.ink, caretW: 2, caretH: 34, caretGap: 3, id: 's3:type', soundEvery: 2 });
  cue(8.72, 'enter', 's3:enter');
  tl.to(box, { scale: .985, duration: .06, ease: 'none' }, 8.72); tl.to(box, { scale: 1, duration: .25 }, 8.78);
  tl.to(Q.caret, { opacity: 0, duration: .05 }, 8.8);
  tl.fromTo(world3, { scale: 1 }, { scale: 1.05, duration: 1.8, ease: 'none', immediateRender: false }, 7.0);

  // ---- a cascata de itens e a escada de janelas (9–11 s) ----
  tl.to(L1.line, { opacity: 0, y: -L1.H / 2 - 330, duration: .35, ease: 'power2.in' }, 8.85);
  tl.to(box, { y: -360, duration: .5, ease: 'inout' }, 8.85);
  const list = el(`<div class="abs" style="left:${960 - 450}px;top:300px;width:900px;transform-style:preserve-3d"></div>`, page3);
  const rows = ITENS.slice(0, 14).map((it, i) => el(`<div class="abs" style="left:0;top:${i * 118}px;width:900px">
    <div class="ui ell" style="font-size:17px;color:#5f6368;font-weight:400"><span style="display:inline-block;width:22px;height:22px;border-radius:50%;background:hsl(${i * 47 % 360} 45% 86%);vertical-align:-6px;margin-right:10px"></span>${H(it.fonte || '')}</div>
    <div class="ui ell" style="font-size:29px;color:var(--link);font-weight:500;margin-top:6px">${H(it.titulo)}</div>
    <div style="margin-top:10px;height:12px;width:${78 + (i * 37 % 20)}%;border-radius:6px;background:#e3e3e0"></div>
    <div style="margin-top:8px;height:12px;width:${52 + (i * 23 % 30)}%;border-radius:6px;background:#e9e9e6"></div></div>`, list));
  rows.forEach((r, i) => { const t = 9.02 + i * .075; K.popIn(r, t, { dur: .35, y: 26, blur: 6 }); if (i < 10) cue(t + .05, 'tick', `s4:link:${i}`, { step: i }); });
  tl.fromTo(page3, { rotationX: 0, rotationZ: 0, y: 0, z: 0 }, { rotationX: 42, rotationZ: -14, y: -40, z: -260, duration: 1.0, ease: 'inout', immediateRender: false }, 9.55);
  tl.fromTo(list, { y: 0 }, { y: -900, duration: 1.4, ease: 'power1.in', immediateRender: false }, 9.6);
  cue(9.95, 'swoosh_long', 's4:tilt');
  const tabs = el(`<div class="full" style="perspective:1700px;perspective-origin:1200px 300px;z-index:3"></div>`, s3);
  const stair = el(`<div class="full" style="transform-style:preserve-3d"></div>`, tabs);
  const N = 26, r4 = rng(44), hues = [214, 152, 18, 280, 340, 46, 190, 8, 260, 120];
  const curto = s => { const a = [...String(s)]; return a.length > 22 ? H(a.slice(0, 22).join('')) + '…' : H(s); };
  for (let i = 0; i < N; i++) {
    const hue = hues[i % hues.length], w = 470, h = 312;
    const win = el(`<div class="abs card" style="left:0;top:0;width:${w}px;height:${h}px;border-radius:16px;overflow:hidden;transform-style:preserve-3d">
      <div style="height:34px;background:#eceef1;display:flex;align-items:center;gap:7px;padding:0 12px">
        <i style="width:10px;height:10px;border-radius:50%;background:#ff6159"></i><i style="width:10px;height:10px;border-radius:50%;background:#ffbd2e"></i><i style="width:10px;height:10px;border-radius:50%;background:#28c840"></i>
        <div style="margin-left:10px;height:20px;width:150px;border-radius:6px 6px 0 0;background:#fff;font:500 11px var(--font);color:#555;padding:3px 8px;white-space:nowrap;overflow:hidden">${curto(ITENS[i % ITENS.length].titulo)}</div></div>
      <div style="height:22px;background:#fff;border-bottom:1px solid #eee;padding:4px 12px"><div style="height:12px;width:58%;border-radius:6px;background:#f0f0f0"></div></div>
      <div style="display:flex;gap:12px;padding:14px">
        <div style="width:160px;height:110px;border-radius:10px;background:linear-gradient(135deg,hsl(${hue} 70% 72%),hsl(${(hue + 40) % 360} 75% 58%))"></div>
        <div style="flex:1"><div style="height:16px;width:90%;border-radius:6px;background:hsl(${hue} 40% 30%)"></div>
          <div style="height:10px;width:100%;border-radius:5px;background:#e8e8e8;margin-top:12px"></div><div style="height:10px;width:84%;border-radius:5px;background:#e8e8e8;margin-top:8px"></div>
          <div style="height:10px;width:92%;border-radius:5px;background:#e8e8e8;margin-top:8px"></div><div style="height:22px;width:60%;border-radius:11px;background:hsl(${hue} 70% 55%);margin-top:14px"></div></div></div>
      <div style="padding:0 14px"><div style="height:10px;width:100%;border-radius:5px;background:#eee"></div><div style="height:10px;width:70%;border-radius:5px;background:#eee;margin-top:8px"></div></div></div>`, stair);
    const k = i / (N - 1);
    const fx = lerp(-260, 1560, k) + (r4() - .5) * 140, fy = lerp(820, -200, k) + (r4() - .5) * 110, fz = 120 - i * 46 + (r4() - .5) * 80;
    const sx = 760, sy = 470 + (i % 6) * 40;
    const t = 10.0 + i * .028;
    gsap.set(win, { x: sx, y: sy, z: 300, rotationY: -28, rotationX: 8, rotationZ: -6, scale: .2, opacity: 0, transformOrigin: '50% 50%' });
    tl.to(win, { opacity: 1, duration: .12, ease: 'none' }, t);
    tl.to(win, { x: fx, y: fy, z: fz, scale: 1, duration: .62, ease: 'expo' }, t);
  }
  cue(10.0, 'whoosh_cold', 's4:tabs');
  cue(10.05, 'tabs_texture', 's4:tabs:tex', { dur: .8 });
  tl.fromTo(stair, { x: 0, y: 0, z: 0, rotationY: 0 }, { x: -120, y: 30, z: 120, rotationY: -6, duration: 1.2, ease: 'none', immediateRender: false }, 10.0);
  // o contador (as janelas que se acumulam)
  const ab = cfg.contador || {};
  const de = ab.de ?? 3, ate = ab.ate ?? 37;
  const chip = el(`<div class="chip" style="right:80px;top:70px;left:auto;z-index:6;font-size:26px;height:58px;padding:0 26px;max-width:820px">
    ${K.icon(ab.icone || 'abas', 26, '#111', 2)}
    <b class="n" style="font-weight:700;min-width:${String(ate).length * 17}px;text-align:right">${de}</b><span class="muted ell" style="color:#666">${H(ab.rotulo || '')}</span></div>`, s3);
  K.popIn(chip, 10.02, { dur: .35, y: -10 });
  K.count(chip.querySelector('.n'), de, ate, 10.05, 10.95, v => String(Math.round(v)), E.lin);
  tl.to(list, { opacity: 0, duration: .3 }, 10.0); tl.to(box, { opacity: 0, duration: .3 }, 10.0);
  X.stair = stair; X.chip = chip; X.s3 = s3;
};
