"""mix.py <filme> [--sem-musica] — trilha (out/<filme>/trilha.wav, de tools/trilha.py) + efeitos sintetizados (os cues da
imagem em out/<filme>/linha.json, tocados por tools/sfx.py) → out/<filme>/mix.wav a -14 LUFS, pico verdadeiro ≤ -1 dBTP.
--sem-musica grava só os efeitos, para usar uma música da biblioteca do Instagram/TikTok na hora de postar."""
import json, sys, os, numpy as np, soundfile as sf, pyloudnorm as pyln
from scipy.signal import resample_poly
from scipy.ndimage import minimum_filter1d, uniform_filter1d
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools')); import sfx
SR = 48000
nome = sys.argv[1]; SEM_MUSICA = '--sem-musica' in sys.argv
L = json.load(open(os.path.join(RAIZ, 'out', nome, 'linha.json')))
total = L['duracao']
N = int(total * SR) + SR // 2
B = L['blocos']
def db(x): return 10 ** (x / 20)
def place(bus, x, t):
    i = int(round(t * SR))
    if i < 0: x = x[-i:]; i = 0
    j = min(len(bus), i + len(x))
    if j > i: bus[i:j] += x[:j - i]

# volume da música no tempo do roteiro completo: abaixa sob a digitação do pedido, no escuro, sob as telas de interface
# e sob a frase final; cheia nos drops, no refrão (45 s) e no acorde final
AUTO = [(0, 0), (17.85, 0), (18.0, -3), (20.85, -3), (21.1, 0), (23.0, 0), (23.15, -2), (26.9, -2), (27.1, 0), (29.35, 0), (29.5, -4),
        (44.85, -4), (44.99, 0), (56.9, 0), (57.0, -5), (60.85, -5), (60.98, 0), (63.6, 0), (64.92, -48), (65.0, -90)]
pts = []
for b in B:
    for t, g in AUTO:
        if b['a'] <= t <= b['b']: pts.append((b['A'] + t - b['a'], g))
pts.sort()
tt = np.arange(N) / SR
gain = np.interp(tt, [p[0] for p in pts], [p[1] for p in pts])

music = np.zeros((N, 2), np.float32)
if not SEM_MUSICA:
    m, _ = sf.read(os.path.join(RAIZ, 'out', nome, 'trilha.wav'), dtype='float32'); place(music, m, 0)
    music *= db(gain)[:, None].astype(np.float32)

fx = np.zeros((N, 2), np.float32)
cache = {}
n_ev = 0
for ev in L['eventos']:
    regra = sfx.SONS.get(ev['kind'])
    if not regra: continue
    for tipo, a, nivel, off in regra(ev):
        k = (tipo, json.dumps(a, sort_keys=True))
        if k not in cache: cache[k] = sfx.LIB[tipo](**a)
        place(fx, cache[k] * db(nivel), ev['t'] + off); n_ev += 1
fx *= db(3.0)   # o bus de efeitos, 3 dB acima da música
mix = music + fx
meter = pyln.Meter(SR)
def true_peak(x): return np.abs(resample_poly(x, 4, 1, axis=0)).max()
def limit(x, ceil, look=0.003):
    up = np.abs(resample_poly(x, 4, 1, axis=0)).max(1)
    pk = up[:len(x) * 4].reshape(-1, 4).max(1)[:len(x)]
    g = np.minimum(1.0, ceil / np.maximum(pk, 1e-9)); w = int(look * SR) | 1
    return x * uniform_filter1d(minimum_filter1d(g, 2 * w + 1), 2 * w + 1)[:, None]
for _ in range(6):
    mix *= db(-14 - meter.integrated_loudness(mix)); mix = limit(mix, db(-1.3))
    if true_peak(mix) <= db(-1.0) and abs(meter.integrated_loudness(mix) + 14) < 0.15: break
mix = mix[:int(total * SR)]
dst = os.path.join(RAIZ, 'out', nome, 'mix.wav')
sf.write(dst, mix.astype(np.float32), SR, subtype='PCM_24')
print(f"mix → out/{nome}/mix.wav  {len(mix)/SR:.2f} s  {meter.integrated_loudness(mix):.1f} LUFS  pico {20*np.log10(true_peak(mix)):.1f} dBTP  ({n_ev} sons{', sem música' if SEM_MUSICA else ''})")
