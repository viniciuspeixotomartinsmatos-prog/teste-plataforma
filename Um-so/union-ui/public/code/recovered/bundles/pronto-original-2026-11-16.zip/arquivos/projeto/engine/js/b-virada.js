// Bloco "virada" (11–17 s, obrigatório): tudo congela; a pergunta da virada é digitada no silêncio; no drop (13,0 s)
// o cursor vira o logo (monolinha: a haste do p + o anel; símbolo: o cursor varre e revela o símbolo, o anel passa em
// volta), o nome sai de trás com máscara e desfoque, o slogan entra; na saída, o anel se estica e vira a barra do produto.
window.BLOCO_virada = () => {
  const { tl, el, scene, apply, cue, prog, E } = F;
  const st = F.stage;
  const b = F.bloco('virada');
  const cfg = CENA('virada') || {};
  // com o problema antes: tudo congela, perde a cor e desfoca
  if (F.tem('problema') && X.stair) {
    tl.to([X.stair, X.chip], { filter: 'blur(18px) grayscale(.7)', opacity: .32, duration: .45, ease: 'out' }, 11.0);
  }
  cue(11.0, 'stop', 's5:freeze');
  const s5 = scene('s5', 11.1, 13.4, 9);
  const L2 = K.typeLine(s5, cfg.pergunta || '', { t0: 11.28, cps: 17.5, size: 104, x: 960, y: 540, id: 's5:type', caretH: 116, caretW: 6, maxW: 1640, tmax: 12.6 });
  K.blink(L2.caret, L2.end + .05, 12.72, { period: .5, on: .25 });
  cue(13.0, 'riser', 's5:riser', { end: true, len: 1.0 });

  const s6 = scene('s6', 12.6, 17.35, 12);
  const tS = 12.72, tD = 13.0;
  // sucção das letras para o centro
  L2.chars.forEach((c, i) => {
    const mid = (L2.ends[i] - c.offsetWidth / 2) - L2.ends[L2.ends.length - 1] / 2;
    const d = Math.abs(mid) / (L2.W / 2);
    tl.to(c, { x: -mid * .92, scaleX: .25, opacity: 0, filter: 'blur(10px)', duration: .26 - d * .08, ease: 'power3.in' }, tS + d * .06);
  });
  const c2 = K.caret(s6, { x: 0, y: 0, w: 6, h: 116, color: C.acao, z: 30 });
  gsap.set(c2, { opacity: 0 });
  const caretStartX = 960 + L2.ends[L2.ends.length - 1] / 2 + L2.size * .06, caretH0 = Math.round(116 * L2.size / 104);
  tl.set(L2.caret, { opacity: 0 }, tS); tl.set(c2, { opacity: 1, left: caretStartX, top: 540 - caretH0 / 2, width: 6, height: caretH0 }, tS);
  cue(tD, 'drop', 's6:drop');
  // clarão de luz no drop
  const flash = el(`<div class="full" style="background:radial-gradient(60% 60% at 50% 50%,#fff,rgba(255,255,255,0));z-index:11;opacity:0"></div>`, st);
  tl.fromTo(flash, { opacity: 0 }, { opacity: .9, duration: .06, ease: 'none', immediateRender: false }, tD);
  tl.to(flash, { opacity: 0, duration: .7, ease: 'out' }, tD + .06);
  if (F.tem('problema') && X.stair) { tl.to([X.stair, X.chip], { opacity: 0, duration: .2 }, tD); tl.set(X.s3, { visibility: 'hidden' }, tD + .2); }

  const burstDots = (canvas, R0, cxL, cyL, t0, n = 140) => {
    const ctx = canvas.getContext('2d');
    const dots = Array.from({ length: n }, (_, i) => ({ a: i / n * Math.PI * 2, sp: .6 + (i * 37 % 13) / 13 * .9, s: 3 + (i * 17 % 5) }));
    apply(t => {
      const p = prog(t, t0, t0 + .75); ctx.clearRect(0, 0, canvas.width, canvas.height); if (p <= 0 || p >= 1) return;
      dots.forEach(d => { const rr = R0 + (230 * d.sp) * E.out(p); const x = cxL + Math.cos(d.a) * rr, y = cyL + Math.sin(d.a) * rr;
        ctx.globalAlpha = (1 - p) * .85; ctx.fillStyle = C.grad[Math.floor((d.a / (Math.PI * 2)) * 4) % 4];
        const s = d.s * (1 - p * .6); ctx.fillRect(x - s / 2, y - s / 2, s, s); });
    }, t0 - .05, t0 + .8, true);
  };
  const tR = tD + .06, tC = tD + .58, tN = tC + .2, tX = 16.38, tM = tX + .3;
  let ring = null; // { cx, cy, r, sw } do anel na tela no instante da saída
  const nameEls = [];
  if (B.modo === 'monolinha') {
    const u = 1.35, cx = 960, cy = 540;
    const lg = B.create(s6, { cx, cy, u, z: 20 });
    const g = lg.geo;
    const pCenter = g.x0 + 50 * u, dxCenter = cx - pCenter;
    gsap.set(lg.root, { x: dxCenter });
    gsap.set(lg.rest, { opacity: 0 }); gsap.set([lg.stem], { opacity: 0 }); gsap.set(lg.ringg, { opacity: 0 });
    lg.ring.style.strokeDashoffset = lg.RING_LEN;
    const stemX = g.stemX + dxCenter, stemH = 150 * u, stemW = 24 * u;
    tl.to(c2, { left: stemX - 3, duration: .28, ease: 'power3.inOut' }, tS);
    tl.to(c2, { left: stemX - stemW / 2, top: g.stemTop, width: stemW, height: stemH, backgroundColor: C.ink, duration: .32, ease: 'expo' }, tD);
    tl.set(c2, { opacity: 0 }, tD + .34); tl.set(lg.stem, { opacity: 1 }, tD + .34);
    tl.set(lg.ringg, { opacity: 1 }, tR);
    tl.fromTo(lg.ringg, { x: 260, rotation: -220, scale: .7 }, { x: 0, rotation: 0, scale: 1, duration: .52, ease: 'expo', immediateRender: false }, tR);
    tl.fromTo(lg.ring, { strokeDashoffset: lg.RING_LEN }, { strokeDashoffset: 0, duration: .5, ease: 'power2.out', immediateRender: false }, tR);
    cue(tR + .05, 'ring_in', 's6:ring'); cue(tD + .3, 'snap', 's6:snap');
    const burst = el(`<canvas class="abs" width="900" height="900" style="left:${g.ringCx + dxCenter - 450}px;top:${g.ringCy - 450}px;z-index:19"></canvas>`, s6);
    burstDots(burst, g.ringR + 20, 450, 450, tC);
    cue(tC, 'pixels', 's6:pixels');
    tl.fromTo(lg.p, { scale: 1 }, { scale: 1.04, duration: .12, ease: 'out', immediateRender: false, transformOrigin: '50% 40%' }, tC);
    tl.to(lg.p, { scale: 1, duration: .4, ease: 'out' }, tC + .12);
    tl.to(lg.root, { x: 0, duration: .72, ease: 'inout' }, tN);
    gsap.set(lg.rest, { '--rv': '0%', WebkitMaskImage: 'linear-gradient(90deg,#000 calc(var(--rv) - 22%),transparent var(--rv))' });
    lg.rest.style.maskImage = 'linear-gradient(90deg,#000 calc(var(--rv) - 22%),transparent var(--rv))';
    tl.set(lg.rest, { opacity: 1 }, tN + .08);
    tl.fromTo(lg.rest, { '--rv': '0%', x: -70 * u, filter: 'blur(9px)' }, { '--rv': '122%', x: 0, filter: 'blur(0px)', duration: .78, ease: 'out', immediateRender: false }, tN + .1);
    cue(tN + .12, 'name', 's6:name');
    apply(t => { lg.grad.setAttribute('gradientTransform', `rotate(${(t - tC - .5) * 22} 50 50)`); }, tC + .5, 17.3, true);
    // saída: o nome volta para trás do p, a haste cai
    tl.to(lg.rest, { '--rv': '0%', x: -70 * u, filter: 'blur(8px)', duration: .36, ease: 'power2.in' }, tX);
    tl.to(lg.stem, { opacity: 0, duration: .2 }, tX + .22);
    tl.set(lg.ringg, { opacity: 0 }, tM);
    ring = { cx: g.ringCx, cy: g.ringCy, r: g.ringR, sw: g.sw };
  } else {
    // o símbolo do cliente: o cursor anda até a borda esquerda do símbolo, cresce até a altura dele e varre para a
    // direita revelando o símbolo; o anel em gradiente passa em volta e estoura em pixels; o nome sai de trás.
    const h = 176, cy = 540;
    const lk = B.lockup(s6, { cx: 960, cy, h, z: 20, maxW: 1560 });
    const g = lk.geo, dxCenter = 960 - g.symCx;
    gsap.set(lk.root, { x: dxCenter });
    const symL = g.symX + dxCenter, cw = Math.max(8, h * .08);
    gsap.set(lk.sym, { clipPath: 'inset(0 100% 0 0)' });
    gsap.set(lk.name, { opacity: 0 });
    tl.to(c2, { left: symL - 3, duration: .28, ease: 'power3.inOut' }, tS);
    tl.to(c2, { left: symL - cw / 2, top: cy - h / 2, width: cw, height: h, backgroundColor: C.acao, duration: .3, ease: 'expo' }, tD);
    // varredura: o cursor atravessa o símbolo e o revela por trás
    const tV = tD + .26, dV = .34;
    tl.to(c2, { left: symL + g.sw - cw / 2, duration: dV, ease: 'power2.inOut' }, tV);
    tl.fromTo(lk.sym, { clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)', duration: dV, ease: 'power2.inOut', immediateRender: false }, tV);
    tl.to(c2, { opacity: 0, width: cw * .4, duration: .16, ease: 'power2.in' }, tV + dV - .1);
    cue(tD + .3, 'snap', 's6:snap');
    // o anel
    const an = B.anel(s6, { cx: 960, cy, r: g.ringR, sw: 16, z: 21 });
    tl.fromTo(an.svg, { rotation: -200, scale: .8, opacity: 1 }, { rotation: 0, scale: 1, duration: .6, ease: 'expo', immediateRender: false, transformOrigin: '50% 50%' }, tR);
    tl.fromTo(an.ring, { strokeDashoffset: an.L }, { strokeDashoffset: 0, duration: .52, ease: 'power2.out', immediateRender: false }, tR);
    tl.to(an.svg, { opacity: 0, scale: 1.12, duration: .45, ease: 'power2.out' }, tC + .05);
    cue(tR + .05, 'ring_in', 's6:ring');
    const burst = el(`<canvas class="abs" width="1100" height="1100" style="left:${960 - 550}px;top:${cy - 550}px;z-index:19"></canvas>`, s6);
    burstDots(burst, g.ringR + 14, 550, 550, tC);
    cue(tC, 'pixels', 's6:pixels');
    tl.fromTo(lk.sym, { scale: 1 }, { scale: 1.05, duration: .12, ease: 'out', immediateRender: false, transformOrigin: '50% 50%' }, tC);
    tl.to(lk.sym, { scale: 1, duration: .4, ease: 'out' }, tC + .12);
    tl.to(lk.root, { x: 0, duration: .72, ease: 'inout' }, tN);
    lk.name.style.webkitMaskImage = lk.name.style.maskImage = 'linear-gradient(90deg,#000 calc(var(--rv) - 22%),transparent var(--rv))';
    gsap.set(lk.name, { '--rv': '0%' });
    tl.set(lk.name, { opacity: 1 }, tN + .08);
    tl.fromTo(lk.name, { '--rv': '0%', x: -g.gap * 1.6, filter: 'blur(9px)' }, { '--rv': '122%', x: 0, filter: 'blur(0px)', duration: .78, ease: 'out', immediateRender: false }, tN + .1);
    cue(tN + .12, 'name', 's6:name');
    tl.to(lk.name, { '--rv': '0%', x: -g.gap * 1.6, filter: 'blur(8px)', duration: .36, ease: 'power2.in' }, tX);
    tl.to(lk.sym, { opacity: 0, scale: .85, filter: 'blur(6px)', duration: .3, ease: 'power2.in' }, tX + .12);
    ring = { cx: g.symCx, cy, r: g.ringR, sw: 16 };
  }
  // slogan
  const tag = el(`<div class="abs" style="left:0;width:1920px;top:${540 + 125}px;text-align:center;font-size:${K.fit(cfg.slogan || '', { size: 46, weight: 500, tracking: -.015, maxW: 1600 })}px;font-weight:500;letter-spacing:-.015em;color:#3d3d45;z-index:21;white-space:nowrap"></div>`, s6);
  tag.innerHTML = String(cfg.slogan || '').split(' ').filter(Boolean).map(w => `<span style="display:inline-block;margin:0 .14em">${H(w)}</span>`).join('');
  [...tag.children].forEach((w, i) => K.popIn(w, 15.0 + i * .07, { dur: .55, y: 12, blur: 10 }));
  if (cfg.slogan) cue(15.0, 'tagline', 's6:tag');
  tl.fromTo(s6, { scale: 1 }, { scale: 1.035, duration: 3.6, ease: 'none', immediateRender: false, transformOrigin: '50% 50%' }, 13.4);
  tl.to([...tag.children], { opacity: 0, y: -8, filter: 'blur(8px)', duration: .25, stagger: .03, ease: 'power2.in' }, tX);
  // a pílula que nasce do anel e estica até a barra do pedido (a borda é o anel; o branco de dentro é outra camada)
  const ring2 = el(`<div class="abs" style="z-index:25;border-radius:999px;opacity:0">
    <div class="fillw full" style="border-radius:inherit;background:#fff;opacity:0"></div>
    <div class="edge full" style="border-radius:inherit;background:linear-gradient(90deg,${C.grad[0]},${C.grad[1]} 35%,${C.grad[2]} 70%,${C.grad[3]});
      -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude"></div></div>`, s6);
  const r2fill = ring2.querySelector('.fillw'), r2edge = ring2.querySelector('.edge');
  const BAR = X.BAR = { x: 960 - 560, y: 540 - 64, w: 1120, h: 128 };
  const R = ring.r, sw = ring.sw;
  tl.set(ring2, { opacity: 1, left: ring.cx - R - sw / 2, top: ring.cy - R - sw / 2, width: (R + sw / 2) * 2, height: (R + sw / 2) * 2 }, tM);
  tl.set(r2edge, { padding: sw }, tM);
  tl.to(ring2, { left: BAR.x, top: BAR.y, width: BAR.w, height: BAR.h, duration: .62, ease: 'inout' }, tM);
  tl.to(r2edge, { padding: 3, duration: .62, ease: 'inout' }, tM);
  tl.fromTo(r2fill, { opacity: 0 }, { opacity: 1, duration: .4, ease: 'none', immediateRender: false }, tM + .22);
  cue(tM + .25, 'morph', 's6:morph');
  X.ring2 = ring2;
  tl.set(ring2, { opacity: 0 }, 17.3);
};
