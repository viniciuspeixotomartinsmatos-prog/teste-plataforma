// Bloco "resultado" (29–37 s, obrigatório): o balão da resposta chega com motion blur; o resultado monta em perspectiva
// (cabeçalho, medidor, 3 ou 4 cartões com foto e linhas, o cartão de destaque e o lateral); duas palavras gigantes em
// 3D; o controle é arrastado pelo cursor do mouse (que segura o botão medido no quadro, com a câmera 3D) e o resultado
// ganha uma linha por cartão; o cartão de destaque descola e vem para a câmera (vira o acompanhamento, se houver).
window.BLOCO_resultado = () => {
  const { tl, el, scene, apply, cue, E } = F;
  F.bloco('resultado');
  const cfg = CENA('resultado') || {};
  const iri = `background:conic-gradient(from 40deg at 40% 55%, ${[C.grad[0], C.grad[1], C.grad[2], C.grad[3], C.grad[0]].map(c => C.mix(c, '#ffffff', .55)).join(', ')});filter:blur(18px) saturate(1.2)`;

  const s9 = scene('s9', 28.95, 37.45, 18);
  el(`<div class="paper"></div>`, s9);
  const bal = cfg.balao || {};
  const bub = el(`<div class="abs card pill" style="left:0;top:0;height:86px;padding:0 40px 0 26px;display:flex;align-items:center;gap:18px;z-index:5;white-space:nowrap;font-size:${K.fit((bal.forte || '') + ' ' + (bal.texto || ''), { size: 33, weight: 500, maxW: 1500 })}px;font-weight:500">
    ${B.mark(34)}<span><b style="font-weight:700">${H(bal.forte || '')}</b> ${H(bal.texto || '')}</span></div>`, s9);
  const bw = bub.offsetWidth;
  gsap.set(bub, { x: 960 - bw / 2, y: 110, opacity: 0 });
  tl.fromTo(bub, { opacity: 0, scaleX: 2.4, scaleY: .5, filter: 'blur(22px)', y: 470 }, { opacity: 1, scaleX: 1, scaleY: 1, filter: 'blur(0px)', y: 110, duration: .62, ease: 'expo', immediateRender: false }, 29.0);
  cue(29.02, 'land', 's9:bubble');

  const W9 = el(`<div class="full" style="perspective:2000px;perspective-origin:960px 500px"></div>`, s9);
  const C9 = el(`<div class="full" style="transform-style:preserve-3d;transform-origin:960px 560px"></div>`, W9);
  const BW = 1560, BH = 900;
  const board = el(`<div class="abs card" style="left:${960 - BW / 2}px;top:${600 - BH / 2}px;width:${BW}px;height:${BH}px;border-radius:44px;overflow:hidden"></div>`, C9);
  const ctl = cfg.controle || null, med = cfg.medidor || null;
  const headMax = ctl ? 520 : med ? 900 : 1300;
  const head = el(`<div class="abs" style="left:56px;top:46px;display:flex;align-items:center;gap:18px">${B.mark(38)}
    <div><div style="font-size:${K.fit(cfg.titulo || '', { size: 46, weight: 700, tracking: -.03, maxW: headMax, min: 26 })}px;font-weight:700;letter-spacing:-.03em;white-space:nowrap">${H(cfg.titulo || '')}</div>
    <div style="font-size:${K.fit(cfg.subtitulo || '', { size: 23, weight: 400, maxW: headMax, min: 15 })}px;color:#77777f;margin-top:4px;white-space:nowrap">${H(cfg.subtitulo || '')}</div></div></div>`, board);
  let budget = null;
  if (med) {
    budget = el(`<div class="abs" style="left:1040px;top:52px;width:460px">
      <div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px"><span class="ell" style="font-size:20px;color:#77777f">${H(med.rotulo || '')}</span>
      <span style="font-size:28px;font-weight:600;white-space:nowrap"><b class="bv" style="font-weight:700">${NUM(0, med)}</b><span style="color:#9a9aa2"> ${H(med.de || 'de')} ${NUM(med.total, med)}</span></span></div>
      <div style="margin-top:12px;height:14px;border-radius:7px;background:#ededea;overflow:hidden"><div class="bf" style="height:100%;width:0%;border-radius:7px;background:linear-gradient(90deg,${C.grad[0]},${C.grad[1]},${C.grad[2]})"></div></div></div>`, board);
  }
  const opcoes = ctl ? (ctl.opcoes || []) : [];
  const alvoIdx = ctl ? Math.min(opcoes.length - 1, ctl.alvo ?? 1) : 0;
  const pct = opcoes.length > 1 ? alvoIdx / (opcoes.length - 1) : .5;
  const pace = ctl ? el(`<div class="abs" style="left:640px;top:60px;width:330px;opacity:0">
    <div style="font-size:19px;color:#77777f;margin-bottom:12px">${H(ctl.rotulo || '')}</div>
    <div style="position:relative;height:10px;border-radius:5px;background:#ededea"><div class="pf" style="position:absolute;left:0;top:0;height:10px;width:0;border-radius:5px;background:${C.acao}"></div>
      <div class="pk" style="position:absolute;left:-14px;top:-9px;width:28px;height:28px;border-radius:50%;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.25),0 0 0 3px ${C.acao}"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:${K.fit(opcoes.join('   '), { size: 17, weight: 400, maxW: 330, min: 12 })}px;color:#8b8b93;margin-top:12px;white-space:nowrap">${opcoes.map((o, i) => `<span class="${i === alvoIdx ? 'pm' : ''}">${H(o)}</span>`).join('')}</div></div>`, board) : null;

  const DAYS = (cfg.cartoes || []).slice(0, 4);
  const N = Math.max(1, DAYS.length), GAP = 24, CW = (1448 - GAP * (N - 1)) / N;
  const rowHTML = ([h, txt, price], cls = '') => `<div class="row ${cls}" style="display:flex;align-items:center;gap:12px;height:44px;font-size:20px">
    ${h ? `<span class="mono" style="font-size:16px;color:#8b8b93;width:50px;flex:none;white-space:nowrap">${H(h)}</span>` : ''}<span class="ell" style="flex:1;min-width:0">${H(txt)}</span>${price ? `<span style="font-size:16px;font-weight:600;color:${C.acao};background:${C.acaoClaro};border-radius:999px;padding:3px 10px;white-space:nowrap">${H(price)}</span>` : ''}</div>`;
  const dayEls = DAYS.map((D, i) => {
    const x = 56 + i * (CW + GAP);
    const c = el(`<div class="abs" style="left:${x}px;top:172px;width:${CW}px;height:470px;border-radius:26px;background:#fafaf8;box-shadow:inset 0 0 0 1px #ecece8;overflow:hidden">
      <div class="ph" style="position:absolute;left:0;top:0;width:${CW}px;height:178px;overflow:hidden"><div class="iri" style="position:absolute;inset:-30px;${iri}"></div>
        ${D.foto ? `<div class="img" style="position:absolute;inset:0;background:url(${M(D.foto)}) ${D.foco || 'center'}/cover;opacity:0"></div>` : '<div class="img"></div>'}</div>
      <div style="position:absolute;left:22px;top:196px;right:22px">
        <div class="ell" style="font-size:16px;font-weight:600;color:${C.acao};letter-spacing:.02em">${H(String(D.etiqueta || '').toUpperCase())}</div>
        <div class="tt" style="font-size:${K.fit(D.titulo || '', { size: 28, weight: 700, tracking: -.02, maxW: CW - 44, min: 18 })}px;font-weight:700;letter-spacing:-.02em;margin:4px 0 10px;white-space:nowrap">${H(D.titulo || '')}</div>
        <div class="rows">${(D.linhas || []).slice(0, 3).map(r => rowHTML(r)).join('')}${D.extra ? rowHTML(D.extra, 'xr') : ''}</div></div></div>`, board);
    return c;
  });
  const dst = cfg.destaque || {};
  const flight = el(`<div class="abs" style="left:56px;top:668px;width:740px;height:176px;border-radius:26px;background:#fafaf8;box-shadow:inset 0 0 0 1px #ecece8">
    <div style="position:absolute;left:28px;top:28px;width:56px;height:56px;border-radius:16px;background:${C.acaoClaro};display:grid;place-items:center">${K.icon(dst.icone || 'aviao', 30, C.acao)}</div>
    <div style="position:absolute;left:104px;top:26px;width:${dst.valor ? 400 : 600}px"><div class="ell" style="font-size:${K.fit(dst.titulo || '', { size: 30, weight: 700, maxW: dst.valor ? 400 : 600, min: 20 })}px;font-weight:700;letter-spacing:-.02em">${H(dst.titulo || '')}</div>
      <div class="ell" style="font-size:20px;color:#77777f;margin-top:4px">${H(dst.texto || '')}</div></div>
    ${dst.valor ? `<div style="position:absolute;right:30px;top:30px;text-align:right;max-width:220px"><div class="ell" style="font-size:17px;color:#8b8b93">${H(dst.rotulo || '')}</div><div style="font-size:${K.fit(dst.valor, { size: 34, weight: 700, maxW: 220, min: 20 })}px;font-weight:700;white-space:nowrap">${H(dst.valor)}</div></div>` : ''}
    <div style="position:absolute;left:104px;bottom:26px;display:flex;gap:10px;max-width:610px;overflow:hidden">${(dst.etiquetas || []).slice(0, 3).map(e => `<span class="chip" style="position:static;height:36px;font-size:17px;padding:0 14px">${H(e)}</span>`).join('')}</div></div>`, board);
  const lat = cfg.lateral || null;
  const hotel = lat ? el(`<div class="abs" style="left:820px;top:668px;width:684px;height:176px;border-radius:26px;background:#fafaf8;box-shadow:inset 0 0 0 1px #ecece8;overflow:hidden">
    <div style="position:absolute;left:0;top:0;width:200px;height:176px;overflow:hidden;${lat.foto ? `background:url(${M(lat.foto)}) ${lat.foco || 'center'}/cover` : lat.icone ? `background:${C.acaoClaro};display:grid;place-items:center` : ''}">${!lat.foto && lat.icone ? K.icon(lat.icone, 64, C.acao, 1.8) : !lat.foto ? `<div style="position:absolute;inset:-30px;${iri}"></div>` : ''}</div>
    <div style="position:absolute;left:226px;top:28px;width:${lat.valor ? 260 : 420}px"><div class="ell" style="font-size:${K.fit(lat.titulo || '', { size: 28, weight: 700, maxW: lat.valor ? 260 : 420, min: 18 })}px;font-weight:700;letter-spacing:-.02em">${H(lat.titulo || '')}</div>
      <div class="ell" style="font-size:20px;color:#77777f;margin-top:4px">${H(lat.texto || '')}</div><div class="ell" style="font-size:20px;margin-top:14px">${H(lat.nota || '')} <span style="color:#8b8b93">${H(lat.notaTexto || '')}</span></div></div>
    ${lat.valor ? `<div style="position:absolute;right:28px;top:30px;font-size:${K.fit(lat.valor, { size: 34, weight: 700, maxW: 180, min: 20 })}px;font-weight:700;white-space:nowrap">${H(lat.valor)}</div>` : ''}</div>`, board) : null;
  if (!lat) flight.style.width = '1448px';

  gsap.set(board, { opacity: 0 });
  tl.fromTo(board, { opacity: 0, y: 260, filter: 'blur(12px)' }, { opacity: 1, y: 0, filter: 'blur(0px)', duration: .8, ease: 'expo', immediateRender: false }, 29.45);
  cue(29.5, 'swoosh_short', 's9:board');
  dayEls.forEach((c, i) => {
    const t = 29.85 + i * .2;
    K.popIn(c, t, { dur: .5, y: 30, s: .95 });
    cue(t + .12, 'pop', `s9:day:${i}`, { step: i });
    const img = c.querySelector('.img'), iriEl = c.querySelector('.iri');
    apply(tt => { iriEl.style.transform = `rotate(${(tt - t) * 60}deg) scale(1.2)`; }, t, t + 1.4, true);
    tl.to(img, { opacity: 1, duration: .55, ease: 'none' }, t + .55);
    c.querySelectorAll('.row:not(.xr)').forEach((r, k) => K.popIn(r, t + .35 + k * .09, { dur: .35, y: 8, blur: 5 }));
    const xr = c.querySelector('.xr'); if (xr) gsap.set(xr, { display: 'none' });
  });
  K.popIn(head, 29.7, { dur: .5, y: 10 });
  if (budget) {
    K.popIn(budget, 29.9, { dur: .5, y: 10 });
    K.count(budget.querySelector('.bv'), 0, med.valor, 30.4, 31.5, v => NUM(v, med), E.out);
    tl.fromTo(budget.querySelector('.bf'), { width: '0%' }, { width: `${Math.min(100, med.valor / med.total * 100).toFixed(1)}%`, duration: 1.1, ease: 'out', immediateRender: false }, 30.4);
  }
  K.popIn(flight, 30.9, { dur: .5, y: 26 }); cue(31.0, 'pop', 's9:flight', { step: 4 });
  if (hotel) { K.popIn(hotel, 31.1, { dur: .5, y: 26 }); cue(31.2, 'pop', 's9:hotel', { step: 5 }); }
  gsap.set(C9, { rotationX: 26, rotationY: 18, rotationZ: -3, scale: 1.18, x: 380, y: 80 });
  tl.to(C9, { rotationX: 20, rotationY: -14, rotationZ: 2, scale: 1.08, x: -330, y: 30, duration: 2.6, ease: 'cam' }, 29.5);
  tl.to(C9, { rotationX: 14, rotationY: -4, rotationZ: 0, scale: .9, x: 0, y: 10, duration: .75, ease: 'inout' }, 32.1);
  const dof = el(`<div class="full" style="z-index:4;backdrop-filter:blur(7px);-webkit-mask-image:linear-gradient(100deg,transparent 52%,#000 92%);mask-image:linear-gradient(100deg,transparent 52%,#000 92%)"></div>`, s9);
  tl.fromTo(dof, { opacity: 1 }, { opacity: 0, duration: .6, immediateRender: false }, 32.1);

  // palavras gigantes
  const PAL = cfg.palavras || [];
  tl.to([W9, bub], { filter: 'blur(16px)', opacity: .22, duration: .3, ease: 'power2.in' }, 32.85);
  if (PAL[0]) K.word3d(s9, PAL[0], { tIn: 33.0, tOut: 33.72, size: 250, x: 960, y: 560, maxW: 1700, from: { ry: -78, z: -500, x: -260 }, to: { ry: 70, z: -300, x: 240 }, rest: { ry: -9, rz: -1.5, drift: 50, dry: 7 }, id: 's9:w1', soundIn: 'swing', z: 12 });
  if (PAL[1]) K.word3d(s9, PAL[1], { tIn: 34.0, tOut: 34.72, size: 250, x: 960, y: 560, maxW: 1700, from: { rx: 80, z: -400, y: 220 }, to: { rx: -70, z: -300, y: -200 }, rest: { rx: 7, ry: 6, drift: 50, dry: -6, drz: -1.5 }, id: 's9:w2', soundIn: 'swing', z: 12 });
  if (PAL[0]) cue(33.72 + .12, 'swing_out', 's9:w1:out');
  if (PAL[1]) cue(34.72 + .12, 'swing_out', 's9:w2:out');
  tl.to(W9, { filter: 'blur(0px)', opacity: 1, duration: .35, ease: 'out' }, 34.92);
  tl.to(bub, { opacity: 0, duration: .2 }, 34.92);
  tl.to(C9, { rotationX: 12, rotationY: -2, scale: 1.0, x: 120, y: 160, duration: .5, ease: 'inout' }, 34.95);

  // o controle: o cursor chega no botão (medido), segura, arrasta junto com ele e solta
  if (pace) {
    tl.to(pace, { opacity: 1, duration: .25 }, 35.0);
    const pk = pace.querySelector('.pk'), pf = pace.querySelector('.pf');
    const ms9 = K.mouse(s9, { size: 64, z: 30 });
    const botao = K.alvo(pk, .5, .5);
    ms9.caminho([{ t: 34.98, p: [1180, 760] }, { t: 35.30, p: botao, bow: .06, ease: F.bezier(.4, 0, .2, 1) }, { t: 36.4, p: botao }]);
    ms9.mostra(34.98, .1);
    ms9.press(35.34, 's9:grab', 'click_soft', { fundo: .88 });
    const dArr = Math.min(.62, Math.max(.4, .38 + .24 * pct));
    tl.to(pk, { left: pct * 330 - 14, duration: dArr, ease: 'inout' }, 35.38); tl.to(pf, { width: pct * 330, duration: dArr, ease: 'inout' }, 35.38);
    cue(35.55, 'tick', 's9:detent:0', { step: 2 }); cue(35.86, 'tick', 's9:detent:1', { step: 5 });
    const pm = pace.querySelector('.pm'); if (pm) tl.to(pm, { color: C.acao, fontWeight: 600, duration: .2 }, 35.86);
    ms9.hide(36.1);
  }
  dayEls.forEach((c, i) => { const xr = c.querySelector('.xr'); if (!xr) return; tl.set(xr, { display: 'flex' }, 35.9 + i * .07); K.popIn(xr, 35.9 + i * .07, { dur: .35, y: 10, blur: 6 }); cue(35.95 + i * .07, 'pop', `s9:extra:${i}`, { step: 6 + i, soft: true }); });
  if (budget && med.depois != null) {
    K.count(budget.querySelector('.bv'), med.valor, med.depois, 35.95, 36.5, v => NUM(v, med), E.out);
    tl.to(budget.querySelector('.bf'), { width: `${Math.min(100, med.depois / med.total * 100).toFixed(1)}%`, duration: .5, ease: 'out' }, 35.95);
  }
  // o cartão de destaque descola do quadro e vem para a câmera
  const tLift = 36.35;
  tl.to(board, { opacity: .0, filter: 'blur(14px)', duration: .55, ease: 'power2.in' }, tLift + .1);
  const fly = flight.cloneNode(true); fly.style.zIndex = 20; s9.appendChild(fly);
  const fw = flight.offsetWidth;
  gsap.set(fly, { opacity: 0 });
  tl.set(fly, { opacity: 1, left: 960 - fw / 2, top: 775 - 88, rotationX: 12, transformPerspective: 2000 }, tLift);
  tl.set(flight, { opacity: 0 }, tLift);
  tl.to(fly, { left: 960 - fw / 2, top: 540 - 88, scale: fw > 900 ? 1.0 : 1.32, rotationX: 0, boxShadow: `0 40px 90px -30px ${C.rgba(C.acao, .55)}`, duration: .62, ease: 'inout' }, tLift);
  cue(tLift + .2, 'swoosh_long', 's9:lift');
  X.fly = fly;
};
