"""folha.py <pasta com 00000.jpg…> <saida.jpg> [colunas] — folha de contato com o número do quadro e o tempo em cada imagem."""
import sys, os
from PIL import Image, ImageDraw, ImageFont
d, out = sys.argv[1], sys.argv[2]
cols = int(sys.argv[3]) if len(sys.argv) > 3 else 6
fs = sorted(f for f in os.listdir(d) if f.lower().endswith(('.jpg', '.png')))
ims = [Image.open(os.path.join(d, f)).convert('RGB') for f in fs]
w = 480; h = round(w * ims[0].height / ims[0].width); pad = 4
rows = (len(ims) + cols - 1) // cols
S = Image.new('RGB', (cols * (w + pad) + pad, rows * (h + pad) + pad), (20, 20, 20)); dr = ImageDraw.Draw(S)
try: font = ImageFont.truetype('DejaVuSans.ttf', 15)
except Exception:
    try: font = ImageFont.truetype('/System/Library/Fonts/Menlo.ttc', 15)
    except Exception: font = ImageFont.load_default()
for k, (im, f) in enumerate(zip(ims, fs)):
    x, y = pad + (k % cols) * (w + pad), pad + (k // cols) * (h + pad)
    S.paste(im.resize((w, h), Image.LANCZOS), (x, y))
    q = int(os.path.splitext(f)[0]); lab = f'q{q}  {q / 30:.2f}s'
    dr.rectangle([x, y, x + 8 + 9 * len(lab), y + 20], fill=(0, 0, 0)); dr.text((x + 4, y + 2), lab, fill=(255, 220, 0), font=font)
S.save(out, quality=86); print(out, S.size, len(ims), 'quadros')
