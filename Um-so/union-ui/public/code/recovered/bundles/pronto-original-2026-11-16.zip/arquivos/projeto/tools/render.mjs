// render.mjs — imagens do filme a partir do config.
//   node tools/render.mjs <filme> linha                        → os blocos (início e fim em segundos) e out/<filme>/linha.json
//   node tools/render.mjs <filme> quadros <lista> [--saida dir] → PNG 1920×1080 dos quadros (lista: "0,30,60" | "600-690" | "0-1949:15")
//   node tools/render.mjs <filme> folha [--passo 15] [--de 0 --ate N] [--colunas 6] → out/<filme>/folha.jpg (quadros numerados)
//   node tools/render.mjs <filme> filme [--abas 3] [--saida dir] → todos os quadros (PNG) para o MP4 (tools/filme.mjs usa)
//   node tools/render.mjs <filme> compara <video.mp4> [--passo 60] → out/<filme>/compara.jpg (pares: o vídeo | o render, no mesmo quadro)
// O filme roda a 30 quadros por segundo. Cada quadro é desenhado sozinho (seek), em qualquer ordem: abas paralelas
// dão o mesmo resultado que uma só.
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { RAIZ, args, quadros, servidor, navegador, abrir, foto, pad, python, ffmpeg } from './comum.mjs';

const { pos, opt } = args();
const [nome, modo = 'linha', lista] = pos;
if (!nome) { console.log('uso: node tools/render.mjs <filme> linha|quadros|folha|filme'); process.exit(1); }
const OUT = path.join(RAIZ, 'out', nome); fs.mkdirSync(OUT, { recursive: true });
const srv = await servidor(); const porta = srv.address().port;
const browser = await navegador();
const avisa = p => { const e = [...new Set(p.erros)], w = [...new Set(p.avisos)]; if (e.length) console.log('ERROS:\n' + e.join('\n')); if (w.length) console.log('avisos:\n' + w.join('\n')); };
try {
  const p = await abrir(browser, porta, nome);
  const L = p.linha;
  const linha = await p.page.evaluate(() => ({ ...window.LINHA, eventos: window.CUES.events }));
  fs.writeFileSync(path.join(OUT, 'linha.json'), JSON.stringify(linha, null, 1));
  if (modo === 'linha') {
    console.log(`${nome}: ${L.duracao} s, ${L.total} quadros`);
    for (const b of L.blocos) console.log(`  ${b.tipo.padEnd(12)} ${String(b.A).padStart(3)}–${String(b.B).padEnd(3)} s   quadros ${b.A * 30}–${b.B * 30 - 1}`);
  } else if (modo === 'quadros') {
    const dir = opt.saida ? path.resolve(RAIZ, opt.saida) : path.join(OUT, 'quadros'); fs.mkdirSync(dir, { recursive: true });
    for (const f of quadros(lista, L.total)) { await foto(p, f, path.join(dir, `${pad(f)}.${opt.jpg ? 'jpg' : 'png'}`)); }
    console.log('quadros →', path.relative(RAIZ, dir));
  } else if (modo === 'folha') {
    const passo = +(opt.passo || 15), de = +(opt.de || 0), ate = Math.min(+(opt.ate ?? L.total - 1), L.total - 1);
    const dir = path.join(OUT, 'folha-tmp'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
    for (let f = de; f <= ate; f += passo) await foto(p, f, path.join(dir, `${pad(f)}.jpg`), 85);
    const saida = opt.saida ? path.resolve(RAIZ, opt.saida) : path.join(OUT, 'folha.jpg');
    execFileSync(python(), [path.join(RAIZ, 'tools/folha.py'), dir, saida, String(opt.colunas || 6)], { stdio: 'inherit' });
    fs.rmSync(dir, { recursive: true, force: true });
  } else if (modo === 'compara') {
    const passo = +(opt.passo || 60), dir = path.join(OUT, 'compara-tmp'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
    for (let f = 15; f < L.total; f += passo) await foto(p, f, path.join(dir, `${pad(f)}.jpg`), 85);
    execFileSync(python(), [path.join(RAIZ, 'tools/compara.py'), dir, path.resolve(RAIZ, lista), path.join(OUT, 'compara.jpg'), ffmpeg()], { stdio: 'inherit' });
    fs.rmSync(dir, { recursive: true, force: true });
  } else if (modo === 'filme') {
    const dir = opt.saida ? path.resolve(RAIZ, opt.saida) : path.join(OUT, 'filme'); fs.mkdirSync(dir, { recursive: true });
    const W = Math.max(1, +(opt.abas || 3));
    const pages = [p, ...await Promise.all(Array.from({ length: W - 1 }, () => abrir(browser, porta, nome)))];
    const t0 = Date.now(); let feitos = 0;
    await Promise.all(pages.map(async (pg, k) => {
      for (let f = k; f < L.total; f += W) {
        const arq = path.join(dir, `${pad(f)}.png`);
        if (fs.existsSync(arq)) { feitos++; continue; }
        await foto(pg, f, arq);
        if (++feitos % 150 === 0) console.log(`  ${feitos}/${L.total} quadros, ${((Date.now() - t0) / 1000).toFixed(0)} s`);
      }
    }));
    console.log(`quadros: ${L.total} em ${((Date.now() - t0) / 1000).toFixed(0)} s → ${path.relative(RAIZ, dir)}`);
    pages.slice(1).forEach(avisa);
  } else throw new Error('modo desconhecido: ' + modo);
  avisa(p);
} finally { await browser.close(); srv.close(); }
