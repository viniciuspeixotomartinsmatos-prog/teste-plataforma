// filme.mjs — o filme inteiro de uma vez: quadros → trilha → mixagem → MP4.
//   node tools/filme.mjs <filme> [--sem-musica] [--abas 3] [--refaz]
// Saída: out/<filme>/<filme>.mp4 (1920×1080, 30 fps, H.264, áudio AAC). Os quadros já renderizados são reaproveitados
// (--refaz apaga e desenha de novo: use depois de mudar o config).
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { RAIZ, args, lerFilme, ffmpeg, python } from './comum.mjs';

const { pos, opt } = args();
const nome = pos[0];
if (!nome) { console.log('uso: node tools/filme.mjs <filme> [--sem-musica] [--abas 3] [--refaz]'); process.exit(1); }
lerFilme(nome);
const OUT = path.join(RAIZ, 'out', nome);
const run = (cmd, a) => execFileSync(cmd, a, { stdio: 'inherit', cwd: RAIZ });
const dir = path.join(OUT, 'filme');
if (opt.refaz) fs.rmSync(dir, { recursive: true, force: true });
console.log('— quadros');
run('node', ['tools/render.mjs', nome, 'filme', '--saida', path.relative(RAIZ, dir), '--abas', String(opt.abas || 3)]);
console.log('— trilha e mixagem');
const L = JSON.parse(fs.readFileSync(path.join(OUT, 'linha.json'), 'utf8'));
if (!opt['sem-musica']) run(python(), ['tools/trilha.py', nome]);
run(python(), ['tools/mix.py', nome, ...(opt['sem-musica'] ? ['--sem-musica'] : [])]);
console.log('— MP4');
const mp4 = path.join(OUT, `${nome}${opt['sem-musica'] ? '-sem-musica' : ''}.mp4`);
execFileSync(ffmpeg(), ['-v', 'error', '-y', '-framerate', '30', '-i', path.join(dir, '%05d.png'), '-i', path.join(OUT, 'mix.wav'),
  '-frames:v', String(L.total), '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p', '-c:v', 'libx264', '-preset', 'slow', '-crf', '16',
  '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv',
  '-c:a', 'aac', '-b:a', '256k', '-shortest', '-movflags', '+faststart', mp4], { stdio: 'inherit' });
console.log(`pronto → ${path.relative(RAIZ, mp4)} (${L.duracao} s)`);
