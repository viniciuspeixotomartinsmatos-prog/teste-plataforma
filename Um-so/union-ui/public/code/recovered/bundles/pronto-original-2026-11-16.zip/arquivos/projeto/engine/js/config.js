// Lê o config do filme (filmes/<nome>.json, ?filme=<nome>) antes de tudo, monta as cores e as fontes.
// Tudo o que é da marca e do conteúdo vem daqui: o código das cenas não tem texto, cor ou número fixo do produto.
window.CFG = (() => {
  const Q = new URLSearchParams(location.search);
  const nome = Q.get('filme') || 'demo';
  const x = new XMLHttpRequest();
  x.open('GET', `../filmes/${encodeURIComponent(nome)}.json?v=${Date.now()}`, false);
  x.send();
  if (x.status !== 200) throw new Error(`não achei filmes/${nome}.json`);
  const cfg = JSON.parse(x.responseText);
  cfg._nome = nome;
  return cfg;
})();

window.C = (() => {
  const c = CFG.cores || {};
  const hex = h => { h = String(h).trim().replace('#', ''); if (h.length === 3) h = [...h].map(k => k + k).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const toHex = a => '#' + a.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, p) => toHex(hex(a).map((v, i) => v + (hex(b)[i] - v) * p));
  const rgba = (h, a) => `rgba(${hex(h).join(',')},${a})`;
  // o gradiente da marca tem sempre 4 paradas (2 ou 3 cores do config são interpoladas)
  let g = (c.gradiente && c.gradiente.length ? c.gradiente : ['#2F7BFF', '#5B3DF5', '#FF4D9A', '#FF7A3D']).slice(0, 4);
  if (g.length === 1) g = [g[0], g[0], g[0], g[0]];
  if (g.length === 2) g = [g[0], mix(g[0], g[1], 1 / 3), mix(g[0], g[1], 2 / 3), g[1]];
  if (g.length === 3) g = [g[0], g[1], mix(g[1], g[2], .5), g[2]];
  const acao = c.acao || g[1];
  const paper = c.papel || '#F2F2F0', ink = c.tinta || '#111114';
  const out = {
    paper, ink, night: c.noite || '#07070C', link: c.link || '#1A3FD1',
    grad: g.map(s => s.toLowerCase()), acao: acao.toLowerCase(),
    // a cor da ação em versões claras (fundos de selo, trilho do controle) e escuras (texto sobre o tom claro)
    acaoClaro: mix(acao, '#ffffff', .89), acaoClaro2: mix(acao, '#ffffff', .86), acaoClaro3: mix(acao, '#ffffff', .82),
    acaoForte: mix(acao, '#000000', .1), acaoLuz: mix(acao, '#ffffff', .12),
    paperLight: c.papelLuz || mix(paper, '#ffffff', .4), paperDark: c.papelSombra || mix(paper, '#000000', .05),
    hex, mix, rgba, toHex,
  };
  // matiz de cada cor do gradiente (para os brilhos das telas no escuro)
  out.hues = out.grad.map(h => { const [r, gg, b] = hex(h).map(v => v / 255); const M = Math.max(r, gg, b), m = Math.min(r, gg, b), d = M - m;
    if (!d) return 0; let H = M === r ? ((gg - b) / d) % 6 : M === gg ? (b - r) / d + 2 : (r - gg) / d + 4; return Math.round((H * 60 + 360) % 360); });
  const root = document.documentElement.style;
  root.setProperty('--ink', ink); root.setProperty('--paper', paper); root.setProperty('--link', out.link); root.setProperty('--acao', out.acao);
  root.setProperty('--g0', g[0]); root.setProperty('--g1', g[1]); root.setProperty('--g2', g[2]); root.setProperty('--g3', g[3]);
  root.setProperty('--paperLight', out.paperLight); root.setProperty('--paperDark', out.paperDark);
  return out;
})();

// fontes do config: { "familia": "...", "arquivos": [{ "arquivo": "midia/x/f.woff2", "peso": "100 1000" }] }
// Sem config, DM Sans (variável, na pasta do motor). Mídia é sempre relativa à raiz do projeto.
window.M = p => p == null ? null : /^(https?:|data:|\.\.\/)/.test(p) ? p : '../' + String(p).replace(/^\/+/, '');
(() => {
  const f = CFG.fonte;
  const fam = (f && f.familia) || 'DM Sans';
  if (f && f.arquivos) {
    const css = f.arquivos.map(a => `@font-face{font-family:'${fam}';font-style:${a.estilo || 'normal'};font-weight:${a.peso || '100 1000'};font-display:block;src:url(${M(a.arquivo)})}`).join('\n');
    const s = document.createElement('style'); s.textContent = css; document.head.appendChild(s);
  }
  window.FONTE = fam;
  document.documentElement.style.setProperty('--font', `'${fam}'`);
})();

// cena do config por tipo (ou null). O filme tem só as cenas listadas em CFG.cenas, na ordem canônica.
window.CENA = tipo => (CFG.cenas || []).find(c => c.tipo === tipo) || null;
// texto seguro para innerHTML
window.H = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
// número formatado pelo config: { "formato": "brl" | "numero" | "porcento" | "prefixo/sufixo" }
window.NUM = (v, fmt) => {
  fmt = fmt || {};
  const tipo = typeof fmt === 'string' ? fmt : fmt.formato || 'numero';
  const loc = CFG.idioma || 'pt-BR';
  const n = Math.round(v).toLocaleString(loc);
  if (tipo === 'brl') return 'R$ ' + n;
  if (tipo === 'porcento') return n + '%';
  return (fmt.prefixo || '') + n + (fmt.sufixo || '');
};
