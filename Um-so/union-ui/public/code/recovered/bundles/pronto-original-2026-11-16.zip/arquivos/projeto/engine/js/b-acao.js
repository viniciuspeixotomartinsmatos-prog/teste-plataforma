// Bloco "ação" (43–49 s, opcional): a lista do que o produto está fazendo; cada linha gira e vira check; o total conta;
// duas palavras gigantes em 3D; as letras caem dentro do check grande, que sobe ao centro e a câmera atravessa o branco.
window.BLOCO_acao = () => {
  const { tl, el, scene, apply, cue, rng } = F;
  if (!F.bloco('acao')) return;
  const cfg = CENA('acao') || {};
  const s11 = scene('s11', 43.0, 49.2, 22);
  el(`<div class="paper"></div>`, s11);
  const W11 = el(`<div class="full" style="perspective:2100px;perspective-origin:960px 480px"></div>`, s11);
  const list = el(`<div class="abs card" style="left:${960 - 520}px;top:150px;width:1040px;height:790px;border-radius:44px"></div>`, W11);
  const hdr = el(`<div class="abs" style="left:56px;top:48px;display:flex;align-items:center;gap:18px">
    <div class="spin" style="width:44px;height:44px;border-radius:50%;border:5px solid ${C.acaoClaro3};border-top-color:${C.acao}"></div>
    <div class="ht" style="font-size:${K.fit(cfg.titulo || '', { size: 40, weight: 700, tracking: -.025, maxW: 860, min: 26 })}px;font-weight:700;letter-spacing:-.025em;white-space:nowrap">${H(cfg.titulo || '')}</div></div>`, list);
  const spinH = hdr.querySelector('.spin');
  const ITEMS = (cfg.itens || []).slice(0, 5);
  const n = ITEMS.length, pitch = n <= 5 ? 112 : 96;
  ITEMS.forEach((it, i) => {
    const y = 150 + i * pitch;
    const r = el(`<div class="abs" style="left:56px;top:${y}px;width:928px;height:96px;display:flex;align-items:center;gap:22px;border-bottom:1px solid #efefec">
      <div style="width:60px;height:60px;border-radius:18px;background:${C.acaoClaro2};display:grid;place-items:center;flex:none">${K.icon(it.icone, 30, C.acao)}</div>
      <div style="flex:1;min-width:0"><div class="ell" style="font-size:${K.fit(it.titulo || '', { size: 29, weight: 600, maxW: 560, min: 20 })}px;font-weight:600;letter-spacing:-.015em">${H(it.titulo || '')}</div><div class="ell" style="font-size:20px;color:#77777f;margin-top:2px">${H(it.texto || '')}</div></div>
      ${it.valor ? `<div style="font-size:26px;font-weight:600;margin-right:20px;white-space:nowrap">${H(it.valor)}</div>` : ''}
      <div style="position:relative;width:52px;height:52px;flex:none"><div class="sp" style="position:absolute;inset:4px;border-radius:50%;border:4px solid ${C.acaoClaro3};border-top-color:${C.acao}"></div>
        <svg class="ck" style="position:absolute;inset:0;opacity:0" width="52" height="52" viewBox="0 0 52 52"><circle cx="26" cy="26" r="24" fill="${C.acao}"/>
        <path class="cp" d="M15 27 L23 34.5 L37.5 19" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="40" stroke-dashoffset="40"/></svg></div></div>`, list);
    K.popIn(r, 43.08 + i * .1, { dur: .45, y: 18 });
    cue(43.1 + i * .1, 'pop', `s11:row:${i}`, { step: i, soft: true });
    const sp = r.querySelector('.sp'), ck = r.querySelector('.ck'), cp = r.querySelector('.cp');
    const tc = 43.5 + i * .25 * 5 / Math.max(5, n);
    apply(t => { sp.style.transform = `rotate(${(t - 43) * 540}deg)`; }, 43.0, tc, true);
    tl.set(sp, { opacity: 0 }, tc);
    tl.fromTo(ck, { opacity: 0, scale: .4 }, { opacity: 1, scale: 1, duration: .32, ease: 'expo', immediateRender: false, transformOrigin: '50% 50%' }, tc);
    tl.to(cp, { strokeDashoffset: 0, duration: .25, ease: 'out' }, tc + .05);
    cue(tc, 'check', `s11:check:${i}`, { step: i });
  });
  apply(t => { spinH.style.transform = `rotate(${(t - 43) * 540}deg)`; }, 43.0, 44.75, true);
  const tot = cfg.total || null;
  if (tot) {
    const totalRow = el(`<div class="abs" style="left:56px;top:${150 + n * pitch + 20}px;width:928px;display:flex;align-items:center;justify-content:space-between;gap:20px">
      <div class="ell" style="font-size:24px;color:#77777f">${H(tot.rotulo || '')}${tot.destaque ? ` · <span style="color:${C.acao};font-weight:600">${H(tot.destaque)}</span>` : ''}</div>
      <div class="tv" style="font-size:44px;font-weight:700;letter-spacing:-.03em;white-space:nowrap">${NUM(0, tot)}</div></div>`, list);
    K.popIn(totalRow, 44.55, { dur: .4, y: 10 });
    K.count(totalRow.querySelector('.tv'), 0, tot.valor, 44.6, 45.2, v => NUM(v, tot), F.E.out);
  }
  tl.set(spinH, { opacity: 0 }, 44.75);
  tl.to(hdr.querySelector('.ht'), { opacity: 0, duration: .1 }, 44.72);
  const doneT = el(`<div class="abs" style="left:56px;top:48px;display:flex;align-items:center;gap:18px;opacity:0">
    <svg width="44" height="44" viewBox="0 0 52 52"><circle cx="26" cy="26" r="24" fill="${C.acao}"/><path d="M15 27 L23 34.5 L37.5 19" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>
    <div style="font-size:${K.fit(cfg.feito || '', { size: 40, weight: 700, tracking: -.025, maxW: 860, min: 26 })}px;font-weight:700;letter-spacing:-.025em;white-space:nowrap">${H(cfg.feito || '')}</div></div>`, list);
  tl.to(doneT, { opacity: 1, duration: .2 }, 44.78);
  cue(44.8, 'success', 's11:done');
  tl.fromTo(list, { rotationX: 16, rotationY: -12, scale: .96 }, { rotationX: 8, rotationY: 6, scale: 1, duration: 2.2, ease: 'none', immediateRender: false }, 43.0);

  // as palavras gigantes, lado a lado e centradas; depois as letras caem dentro do check
  tl.to(W11, { filter: 'blur(16px)', opacity: .2, duration: .3, ease: 'power2.in' }, 44.88);
  const PAL = (cfg.palavras || []).slice(0, 2);
  const size = Math.min(230, ...PAL.map(() => K.fit(PAL.join(' '), { size: 230, weight: 700, tracking: -.045, maxW: 1680, min: 90 })));
  const ws = PAL.map(w => K.textW(w, size, 700, -.045)), gap = size * .22;
  const totW = ws.reduce((a, b) => a + b, 0) + gap * (ws.length - 1);
  let xx = 960 - totW / 2; const xs = ws.map(w => { const c = xx + w / 2; xx += w + gap; return c; });
  const fromP = [{ ry: -80, z: -400, x: -200 }, { rx: 82, z: -400, y: 240 }];
  PAL.forEach((w, i) => K.word3d(s11, w, { tIn: 45.0 + i * .5, tOut: 46.15, size, x: xs[i], y: 520, from: fromP[i], to: { o: 1 }, rest: { drift: 0 }, id: `s11:w${i + 1}`, z: 12, outDur: .01 }));
  const fallHost = el(`<div class="full" style="z-index:13"></div>`, s11);
  const big = el(`<div class="abs" style="left:${960 - 95}px;top:${820 - 95}px;width:190px;height:190px;z-index:14;opacity:0">
    <svg width="190" height="190" viewBox="0 0 52 52"><defs><linearGradient id="bg11" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="${C.grad[0]}"/><stop offset=".45" stop-color="${C.grad[1]}"/><stop offset="1" stop-color="${C.grad[2]}"/></linearGradient></defs>
    <circle cx="26" cy="26" r="25" fill="url(#bg11)"/><path class="bp" d="M15 27 L23 34.5 L37.5 19" fill="none" stroke="#fff" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="40" stroke-dashoffset="40"/></svg></div>`, s11);
  tl.fromTo(big, { opacity: 0, scale: .5, y: 40 }, { opacity: 1, scale: 1, y: 0, duration: .45, ease: 'expo', immediateRender: false }, 46.0);
  cue(46.05, 'pop', 's11:bigcheck', { step: 3 });
  const letters = [];
  const mkLetters = (text, cx, cy, sz) => {
    const probe = el(`<div class="abs" style="left:0;top:0;white-space:nowrap;font-size:${sz}px;font-weight:700;letter-spacing:-.045em;line-height:1;visibility:hidden">${[...text].map(c => `<span style="display:inline-block">${H(c)}</span>`).join('')}</div>`, fallHost);
    const w = probe.offsetWidth, h = probe.offsetHeight;
    [...probe.children].forEach(sp => letters.push({ ch: sp.textContent, x: cx - w / 2 + sp.offsetLeft, y: cy - h / 2, w: sp.offsetWidth, size: sz }));
    probe.remove();
  };
  PAL.forEach((w, i) => mkLetters(w, xs[i], 520, size));
  const rl = rng(46);
  const step = .032 * Math.min(1, 14 / Math.max(1, letters.length));
  letters.forEach((L0, i) => {
    const nd = el(`<div class="abs" style="left:${L0.x}px;top:${L0.y}px;font-size:${L0.size}px;font-weight:700;line-height:1;color:${C.ink};opacity:0;transform-origin:50% 60%">${H(L0.ch)}</div>`, fallHost);
    const t0 = 46.15 + i * step + rl() * .02, dur = .5 + rl() * .08;
    const tx = 960 - (L0.x + L0.w / 2), ty = 820 - (L0.y + L0.size * .55);
    tl.set(nd, { opacity: 1 }, 46.15);
    tl.to(nd, { x: tx, duration: dur, ease: 'power1.in' }, t0);
    tl.to(nd, { y: ty, duration: dur, ease: 'power3.in' }, t0);
    tl.to(nd, { rotation: (rl() - .5) * 140, scale: .18, duration: dur, ease: 'power2.in' }, t0);
    tl.to(nd, { opacity: 0, duration: .08 }, t0 + dur - .06);
  });
  cue(46.3, 'fall', 's11:fall', { dur: .8 });
  tl.to(big.querySelector('.bp'), { strokeDashoffset: 0, duration: .3, ease: 'out' }, 46.92);
  tl.fromTo(big, { scale: 1 }, { scale: 1.16, duration: .12, ease: 'out', immediateRender: false }, 46.95);
  tl.to(big, { scale: 1, duration: .4, ease: 'out' }, 47.07);
  cue(46.95, 'snap', 's11:check:big');
  tl.to(big, { y: -280, duration: .7, ease: 'inout' }, 47.5);
  tl.to(big, { scale: 26, duration: .9, ease: 'power3.in', transformOrigin: '47% 58%' }, 48.1);
  cue(48.55, 'swoosh_long', 's11:zoom');
  const white = el(`<div class="full" style="background:${C.paper};z-index:20;opacity:0"></div>`, s11);
  tl.to(white, { opacity: 1, duration: .18, ease: 'none' }, 48.82);
};
