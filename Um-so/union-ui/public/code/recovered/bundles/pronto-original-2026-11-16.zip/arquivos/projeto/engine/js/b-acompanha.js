// Bloco "acompanhamento" (37–43 s, opcional; sempre logo depois do resultado): "E fica de olho." digitado; o cartão do
// item acompanhado com a linha que se desenha e o último ponto (a mudança) mergulhando ou subindo; o celular entra com
// a notificação; o dedo toca no botão de confirmar (medido no quadro) e a onda do toque vira o próximo quadro.
window.BLOCO_acompanha = () => {
  const { tl, el, scene, apply, cue, clamp, lerp, E } = F;
  if (!F.bloco('acompanha')) return;
  const cfg = CENA('acompanha') || {};
  const it = cfg.item || {}, fmt = cfg.formato || 'numero';
  const s10 = scene('s10', 36.95, 43.25, 20);   // sem fundo próprio: o cartão de destaque (resultado) se dissolve por baixo
  const T10 = K.typeLine(s10, cfg.titulo || '', { t0: 37.1, cps: 17, size: 92, x: 960, y: 170, id: 's10:type', caretH: 102, caretW: 6, maxW: 1600, tmax: 38.2 });
  tl.to(T10.caret, { opacity: 0, duration: .1 }, 38.3);
  const vals = (cfg.serie || [1, 1]).map(Number), N = vals.length;
  const days = cfg.rotulos || [];
  const meta = cfg.meta || null;
  const all = vals.concat(meta ? [meta.valor] : []);
  let [lo, hi] = cfg.faixa || (() => { const a = Math.min(...all), b = Math.max(...all), p = Math.max(1, (b - a) * .25); return [a - p, b + p]; })();
  const watch = el(`<div class="abs card" style="left:${960 - 620}px;top:300px;width:1240px;height:620px;border-radius:40px;overflow:hidden">
    <div style="position:absolute;left:52px;top:44px;display:flex;align-items:center;gap:16px;max-width:${it.selo ? 760 : 1100}px">
      <div style="width:60px;height:60px;border-radius:18px;background:${C.acaoClaro};display:grid;place-items:center;flex:none">${K.icon(it.icone || 'aviao', 32, C.acao)}</div>
      <div style="min-width:0"><div class="ell" style="font-size:${K.fit(it.titulo || '', { size: 34, weight: 700, tracking: -.02, maxW: it.selo ? 680 : 1020, min: 22 })}px;font-weight:700;letter-spacing:-.02em">${H(it.titulo || '')}</div><div class="ell" style="font-size:21px;color:#77777f;margin-top:2px">${H(it.texto || '')}</div></div></div>
    ${it.selo ? `<div class="watching" style="position:absolute;right:52px;top:54px;display:flex;align-items:center;gap:10px;font-size:20px;color:${C.acao};background:${C.acaoClaro2};border-radius:999px;padding:10px 18px;white-space:nowrap;max-width:360px">
      <i class="dot" style="width:12px;height:12px;border-radius:50%;background:${C.acao};flex:none"></i><span class="ell">${H(it.selo)}</span></div>` : ''}
    <div style="position:absolute;left:52px;top:150px"><div style="font-size:20px;color:#8b8b93">${H(cfg.rotulo || '')}</div>
      <div style="display:flex;align-items:center;gap:18px"><div class="pr" style="font-size:78px;font-weight:700;letter-spacing:-.035em;white-space:nowrap">${NUM(cfg.valorInicial ?? vals[0], fmt)}</div>
      <div class="drop" style="font-size:26px;font-weight:700;color:#fff;background:linear-gradient(90deg,${C.grad[1]},${C.grad[2]});border-radius:999px;padding:8px 18px;opacity:0;white-space:nowrap">${H(cfg.variacao || '')}</div></div></div>
    <svg class="chart" style="position:absolute;left:52px;top:300px" width="1136" height="250" viewBox="0 0 1136 250"></svg></div>`, s10);
  const chart = watch.querySelector('.chart');
  const X_ = i => 40 + i * (1050 / Math.max(1, N - 1)), Y = v => 40 + (hi - v) / (hi - lo) * 170;
  const pts = vals.map((v, i) => [X_(i), Y(v)]);
  const dPath = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  chart.innerHTML = `<defs><linearGradient id="cl" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${C.grad[0]}"/><stop offset=".6" stop-color="${C.grad[1]}"/><stop offset="1" stop-color="${C.grad[2]}"/></linearGradient>
    <linearGradient id="cf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.grad[1]}" stop-opacity=".18"/><stop offset="1" stop-color="${C.grad[1]}" stop-opacity="0"/></linearGradient></defs>
    ${[0, 1, 2, 3].map(k => `<line x1="20" x2="1116" y1="${40 + k * 57}" y2="${40 + k * 57}" stroke="#efefec" stroke-width="2"/>`).join('')}
    ${meta ? `<line x1="20" x2="1116" y1="${Y(meta.valor)}" y2="${Y(meta.valor)}" stroke="${C.grad[2]}" stroke-width="2" stroke-dasharray="8 8" opacity=".6"/>
    <text x="1116" y="${Y(meta.valor) - 10}" text-anchor="end" font-family="${FONTE}" font-size="17" fill="${C.grad[2]}">${H(meta.rotulo || '')}</text>` : ''}
    <path class="area" d="${dPath} L ${X_(N - 1)} 230 L ${X_(0)} 230 Z" fill="url(#cf)" opacity="0"/>
    <path class="ln" d="${dPath}" fill="none" stroke="url(#cl)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
    <circle class="hd" r="11" fill="#fff" stroke="${C.grad[1]}" stroke-width="5" cx="${X_(0)}" cy="${Y(vals[0])}"/>
    ${days.slice(0, N).map((d, i) => `<text x="${X_(i)}" y="246" text-anchor="middle" font-family="${FONTE}" font-size="18" fill="#9a9aa2">${H(d)}</text>`).join('')}`;
  const ln = chart.querySelector('.ln'), hd = chart.querySelector('.hd'), area = chart.querySelector('.area');
  const total = ln.getTotalLength();
  ln.style.strokeDasharray = `${total} ${total}`;
  const segL = [0]; for (let i = 1; i < pts.length; i++) segL.push(segL[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const tDays0 = 37.85, tDrop = 39.0;
  apply(t => {
    let L;
    if (t < tDrop) { const p = clamp((t - tDays0) / (tDrop - tDays0)); L = lerp(0, segL[N - 2], E.sine(p)); }
    else { const p = E.expo(clamp((t - tDrop) / .32)); L = lerp(segL[N - 2], segL[N - 1], p); }
    ln.style.strokeDashoffset = total - L;
    const pt = ln.getPointAtLength(Math.max(0, L)); hd.setAttribute('cx', pt.x); hd.setAttribute('cy', pt.y);
  }, tDays0 - .2, tDrop + .5, true);
  K.popIn(watch, 37.02, { dur: .55, y: 40, s: .97 });
  tl.fromTo(watch, { rotationX: 14, transformPerspective: 2200 }, { rotationX: 4, duration: 2.4, ease: 'none', immediateRender: false }, 37.02);
  if (X.fly) tl.to(X.fly, { opacity: 0, scale: 1.45, filter: 'blur(10px)', duration: .3, ease: 'power2.in' }, 37.0);
  const dot = watch.querySelector('.dot');
  if (dot) apply(t => { dot.style.opacity = .35 + .65 * (.5 + .5 * Math.cos((t - 37.4) * Math.PI * 2)); }, 37.4, 40.0, true);
  K.count(watch.querySelector('.pr'), cfg.valorInicial ?? vals[0], vals[N - 1], tDrop, tDrop + .42, v => NUM(v, fmt), E.out);
  tl.to(area, { opacity: 1, duration: .4 }, tDrop + .1);
  K.popIn(watch.querySelector('.drop'), tDrop + .22, { dur: .4, y: 0, s: .7, blur: 4 });
  cue(tDrop, 'price_drop', 's10:drop', { sobe: vals[N - 1] > vals[N - 2] }); cue(tDrop + .24, 'pop', 's10:badge', { step: 7 });

  // o celular com a notificação
  const cel = cfg.celular || {};
  const phoneW = el(`<div class="full" style="perspective:1800px;perspective-origin:960px 540px;z-index:6"></div>`, s10);
  const phone = el(`<div class="abs" style="left:${960 - 250}px;top:120px;width:500px;height:1010px;border-radius:72px;background:#0d0d12;padding:14px;
    box-shadow:0 60px 120px -40px rgba(17,17,20,.55), inset 0 0 0 2px #2a2a33">
    <div style="position:relative;width:100%;height:100%;border-radius:60px;overflow:hidden;background:
      radial-gradient(70% 50% at 20% 85%,${C.grad[2]} 0%,transparent 60%),radial-gradient(70% 60% at 85% 20%,${C.grad[0]} 0%,transparent 60%),radial-gradient(80% 70% at 50% 50%,${C.grad[1]} 0%,${C.mix(C.grad[1], '#000000', .7)} 75%)">
      <div style="position:absolute;left:50%;top:20px;width:130px;height:38px;margin-left:-65px;border-radius:20px;background:#000"></div>
      <div style="position:absolute;left:0;right:0;top:92px;text-align:center;color:rgba(255,255,255,.85);font-size:24px;font-weight:500">${H(cel.data || '')}</div>
      <div style="position:absolute;left:0;right:0;top:118px;text-align:center;color:#fff;font-size:150px;font-weight:300;letter-spacing:-.03em">${H(cel.hora || '9:41')}</div>
      <div class="notif" style="position:absolute;left:18px;right:18px;top:330px;border-radius:34px;background:rgba(255,255,255,.86);backdrop-filter:blur(20px);padding:22px 22px 20px">
        <div style="display:flex;align-items:center;gap:12px"><div style="width:44px;height:44px;border-radius:12px;background:#fff;display:grid;place-items:center;box-shadow:0 1px 3px rgba(0,0,0,.15);flex:none">${B.mark(22)}</div>
          <span class="ell" style="font-size:20px;font-weight:600">${H(cel.app || B.nome)}</span><span style="margin-left:auto;font-size:18px;color:#77777f;white-space:nowrap">${H(cel.quando || '')}</span></div>
        <div style="font-size:${K.wrap(cel.titulo || '', { size: 25, weight: 700, maxW: 420, maxLines: 2, min: 19 }).size}px;font-weight:700;margin-top:14px;letter-spacing:-.01em;line-height:1.2">${H(cel.titulo || '')}</div>
        <div style="font-size:${K.wrap(cel.texto || '', { size: 21, weight: 400, maxW: 420, maxLines: 3, min: 16 }).size}px;color:#3d3d45;margin-top:6px;line-height:1.3">${H(cel.texto || '')}</div>
        <div style="display:flex;gap:12px;margin-top:18px"><div class="ok" style="flex:1;height:58px;border-radius:18px;background:${C.acao};color:#fff;display:grid;place-items:center;font-size:${K.fit(cel.sim || '', { size: 22, weight: 600, maxW: 180, min: 15 })}px;font-weight:600;white-space:nowrap">${H(cel.sim || '')}</div>
          <div style="flex:1;height:58px;border-radius:18px;background:rgba(17,17,20,.07);display:grid;place-items:center;font-size:${K.fit(cel.nao || '', { size: 22, weight: 600, maxW: 180, min: 15 })}px;font-weight:600;color:#3d3d45;white-space:nowrap">${H(cel.nao || '')}</div></div></div></div></div>`, phoneW);
  const notif = phone.querySelector('.notif'), okBtn = phone.querySelector('.ok');
  gsap.set(notif, { opacity: 0 });
  gsap.set(phone, { opacity: 0 });
  tl.to([watch], { scale: .5, y: 40, opacity: 0, filter: 'blur(8px)', duration: .32, ease: 'power2.in' }, 39.48);
  tl.to(T10.line, { opacity: 0, y: '-=40', filter: 'blur(8px)', duration: .4, ease: 'power2.in' }, 39.45);
  tl.fromTo(phone, { opacity: 0, y: 760, rotationX: 24, rotationY: -14 }, { opacity: 1, y: 0, rotationX: 10, rotationY: -10, duration: .72, ease: 'expo', immediateRender: false }, 39.58);
  cue(39.5, 'swoosh_short', 's10:phone');
  tl.fromTo(notif, { opacity: 0, y: -60, scale: .92 }, { opacity: 1, y: 0, scale: 1, duration: .55, ease: 'expo', immediateRender: false }, 40.0);
  cue(40.0, 'notify', 's10:notif');
  tl.to(phone, { scale: 1.55, y: 140, rotationX: 4, rotationY: -4, duration: 1.6, ease: 'inout' }, 40.5);
  // o toque: o dedo desce até o centro do botão medido no quadro, aperta e some
  const alvoOk = K.alvo(okBtn, .5, .5);
  const dedo = K.dedo(s10, { size: 96, z: 40 });
  dedo.caminho([{ t: 41.95, p: { de: alvoOk, dx: 60, dy: 120 } }, { t: 42.38, p: alvoOk, ease: E.out, bow: 0 }, { t: 43.3, p: alvoOk }]);
  tl.fromTo(dedo.el, { opacity: 0 }, { opacity: 1, duration: .3, ease: 'out', immediateRender: false }, 41.95);
  dedo.escala(t => t < 42.55 ? lerp(1.3, 1, E.out(F.prog(t, 41.95, 42.4))) : lerp(1, 1.4, E.out(F.prog(t, 42.55, 42.85))));
  dedo.press(42.47, 's10:tap', 'click_fav', { fundo: .78 });
  tl.to(dedo.el, { opacity: 0, duration: .3 }, 42.55);
  tl.to(okBtn, { scale: .95, filter: 'brightness(1.15)', duration: .08 }, 42.45); tl.to(okBtn, { scale: 1, duration: .25 }, 42.55);
  // a onda do toque cobre a tela (nasce no botão)
  const wave = el(`<div class="abs" style="left:0;top:0;width:10px;height:10px;margin:-5px 0 0 -5px;border-radius:50%;background:${C.paper};z-index:45;opacity:0"></div>`, s10);
  F.applyLate(() => { const [x, y] = alvoOk(); wave.style.left = x + 'px'; wave.style.top = y + 'px'; }, 42.5, 43.3, true);
  tl.fromTo(wave, { opacity: 1, scale: 0 }, { scale: 460, duration: .55, ease: 'inout', immediateRender: false }, 42.55);
  cue(42.6, 'whoosh_airy', 's10:wave');
};
