# Fotos dos cards

Todas de domínio público (CC0 ou Public Domain Mark), achadas pelo Openverse (api.openverse.org, filtro `license=cc0,pdm`).
Recortadas e reduzidas: 960×640 para os cards do roteiro, 1050×990 (`m_*`) para a montagem.

| Arquivo | Origem | Licença |
|---|---|---|
| tram.jpg | rawpixel, "Lisbon Tram" — https://images.rawpixel.com/editor_1024/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTAzL2lzMTI5MTctaW1hZ2UuanBn.jpg | CC0 |
| alfama.jpg | StockSnap, "City Architecture" — https://cdn.stocksnap.io/img-thumbs/960w/AFJ2YJAZUK.jpg | CC0 |
| oceanario.jpg | rawpixel, "People taking pictures sharks" — https://images.rawpixel.com/editor_1024/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvZnJhcXVhcml1bV9zaGFya19va2luYXdhX2phcGFuLWltYWdlLWt5YmVka3JyLmpwZw.jpg | CC0 |
| sintra.jpg | Wikimedia Commons, "Exterior, Palace of Pena, Sintra, Portugal" — https://upload.wikimedia.org/wikipedia/commons/2/27/Exterior%2C_Palace_of_Pena%2C_Sintra%2C_Portugal.jpg | CC0 |
| belem.jpg | Flickr, "Lisbon-Belem Tower 2" — https://live.staticflickr.com/514/19078901936_022318192d_b.jpg | Public Domain Mark |
| m_shoes.jpg | StockSnap, "Running Shoes" — https://cdn.stocksnap.io/img-thumbs/960w/645GI8G1W4.jpg | CC0 |
| m_omelette.jpg | Wikimedia Commons, "Chickpea Omelette in a Pan" — https://upload.wikimedia.org/wikipedia/commons/c/c9/Chickpea_Omelette_in_a_Pan.jpg | CC0 |
| m_apartment.jpg | rawpixel, "Modern apartment interior" — https://images.rawpixel.com/editor_1024/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvZmwxOTA3NTk1MzEwMy1pbWFnZS1reWJlbmtkbC5qcGc.jpg | CC0 |
| m_flowers.jpg | StockSnap, "Flower Arrangement" — https://cdn.stocksnap.io/img-thumbs/960w/FWM2QS9OXD.jpg | CC0 |
| m_car.jpg | StockSnap, "Car Street" — https://cdn.stocksnap.io/img-thumbs/960w/HXMLHIIKI4.jpg | CC0 |
