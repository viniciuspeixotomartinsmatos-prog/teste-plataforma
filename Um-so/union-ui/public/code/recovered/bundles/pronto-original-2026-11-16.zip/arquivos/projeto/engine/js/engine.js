// Motor do filme: uma linha do tempo GSAP pausada + "aplicadores" (funções puras do tempo, para canvas, câmera, cursor
// e tudo o que precisa ser amostrado em vários instantes). window.seek(t) leva o palco a qualquer instante, em qualquer
// ordem: renderizar o quadro N sozinho dá o mesmo resultado que chegar nele em sequência.
//
// Blocos. O filme é uma fila de blocos (abertura, problema, virada...). Cada cena é escrita no tempo do roteiro
// completo (o "tempo canônico", 0–65 s) e o motor desloca tudo o que ela agenda para o lugar do bloco no filme do
// config. Quando a vizinha de um bloco não é a do roteiro completo (uma cena foi tirada), as cenas dele são cortadas
// nas pontas: corte seco, sempre num tempo forte da música (todas as fronteiras caem num segundo ímpar).
window.F = (() => {
  const FPS = 30;
  gsap.registerPlugin(CustomEase);
  CustomEase.create('expo', '0.16,1,0.3,1');
  CustomEase.create('out', '0.23,1,0.32,1');
  CustomEase.create('inout', '0.77,0,0.175,1');
  CustomEase.create('cam', '0.65,0,0.35,1');
  CustomEase.create('soft', '0.45,0,0.15,1');
  CustomEase.create('snap', '0.5,0,0.1,1');
  gsap.defaults({ ease: 'out', duration: .5, lazy: false, overwrite: false });
  gsap.ticker.lagSmoothing(0);

  const stage = document.getElementById('stage');
  const TL = gsap.timeline({ paused: true });
  const appliers = [], late = [];
  const CUES = [];

  // ---------- blocos ----------
  // [tipo, início e fim no tempo canônico, obrigatório]
  const BLOCOS = [
    ['abertura', 0, 5, true], ['problema', 5, 11, false], ['virada', 11, 17, true], ['pedido', 17, 23, true],
    ['trabalhando', 23, 29, false], ['resultado', 29, 37, true], ['acompanha', 37, 43, false], ['acao', 43, 49, false],
    ['montagem', 49, 57, false], ['fecho', 57, 65, true]];
  const ORDEM = BLOCOS.map(b => b[0]);
  let PLANO = null, cur = { shift: 0, a: 0, b: 1e9, prevCanon: true, nextCanon: true, tipo: '-' };
  function plano(tipos) {
    const set = new Set(tipos);
    BLOCOS.forEach(([t, , , obr]) => { if (obr) set.add(t); });
    const lista = BLOCOS.filter(b => set.has(b[0]));
    let T = 0; const out = {};
    lista.forEach(([tipo, a, b], i) => {
      const prev = lista[i - 1], next = lista[i + 1];
      out[tipo] = { tipo, a, b, A: T, B: T + (b - a), shift: T - a, on: true,
        prevCanon: !prev ? a === 0 : prev[2] === a, nextCanon: !next ? b === 65 : next[1] === b,
        prev: prev ? prev[0] : null, next: next ? next[0] : null };
      T += b - a;
    });
    PLANO = { blocos: out, ordem: lista.map(b => b[0]), total: T };
    return PLANO;
  }
  // escolhe o bloco em que o código seguinte agenda (devolve null se o bloco não entra no filme)
  function bloco(tipo) { const b = PLANO.blocos[tipo]; if (!b) return null; cur = b; return b; }
  const tem = tipo => !!(PLANO && PLANO.blocos[tipo]);
  const S = v => typeof v === 'number' ? v + cur.shift : v;

  // a linha do tempo, com o deslocamento do bloco atual
  const tl = {
    to: (t, v, p) => TL.to(t, v, S(p)),
    fromTo: (t, a, b, p) => TL.fromTo(t, a, b, S(p)),
    set: (t, v, p) => TL.set(t, v, S(p)),
    call: (f, a, p) => TL.call(f, a, S(p)),
  };

  // ---------- DOM ----------
  function el(html, parent = stage) {
    const t = document.createElement('template'); t.innerHTML = html.trim();
    const n = t.content.firstElementChild; parent.appendChild(n); return n;
  }
  const q = (s, r = document) => r.querySelector(s), qa = (s, r = document) => [...r.querySelectorAll(s)];
  const css = (n, o) => { Object.assign(n.style, o); return n; };

  // cena: visível só dentro da janela [from, to), cortada nas pontas do bloco quando a vizinha não é a do roteiro
  function scene(id, from, to, z = 1, parent = stage) {
    if (!cur.prevCanon) from = Math.max(from, cur.a);
    if (!cur.nextCanon) to = Math.min(to, cur.b);
    const s = el(`<section class="scene" id="${id}" style="z-index:${z}"></section>`, parent);
    TL.set(s, { visibility: 'hidden' }, 0); TL.set(s, { visibility: 'visible' }, S(from)); TL.set(s, { visibility: 'hidden' }, S(to));
    s._from = from; s._to = to; return s;
  }
  // aplicador: fn(t, local) roda a cada seek dentro de [from, to]; t chega no tempo canônico do bloco
  const reg = (list, fn, from, to, hold) => list.push({ fn, from: from + cur.shift, to: to + cur.shift, hold, shift: cur.shift });
  const apply = (fn, from = -1e9, to = 1e9, hold = false) => reg(appliers, fn, from, to, hold);
  // aplicador tardio: roda depois de todos os outros (o cursor mede o alvo já posto no quadro)
  const applyLate = (fn, from = -1e9, to = 1e9, hold = false) => reg(late, fn, from, to, hold);

  // som: f = quadro em que o som pertence (cálculo da imagem); cues fora do bloco cortado não entram
  const cue = (t, kind, id, o = {}) => {
    if (!cur.nextCanon && t > cur.b - .02) return;
    if (!cur.prevCanon && t < cur.a) return;
    const T = t + cur.shift;
    CUES.push({ f: +(T * FPS).toFixed(2), t: +T.toFixed(4), kind, id, bloco: cur.tipo, ...o });
  };

  // ---------- matemática ----------
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, p) => a + (b - a) * p;
  const prog = (t, a, b) => clamp((t - a) / (b - a));
  function bezier(x1, y1, x2, y2) {
    const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx, cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
    const X = s => ((ax * s + bx) * s + cx) * s, Y = s => ((ay * s + by) * s + cy) * s, dX = s => (3 * ax * s + 2 * bx) * s + cx;
    return p => { if (p <= 0) return 0; if (p >= 1) return 1; let s = p;
      for (let i = 0; i < 8; i++) { const e = X(s) - p, d = dX(s); if (Math.abs(e) < 1e-6) break; if (Math.abs(d) < 1e-6) break; s -= e / d; }
      let lo = 0, hi = 1; for (let i = 0; i < 20 && Math.abs(X(s) - p) > 1e-5; i++) { if (X(s) < p) lo = s; else hi = s; s = (lo + hi) / 2; }
      return Y(s); };
  }
  const E = { out: bezier(.23, 1, .32, 1), expo: bezier(.16, 1, .3, 1), inout: bezier(.77, 0, .175, 1), cam: bezier(.65, 0, .35, 1),
    soft: bezier(.45, 0, .15, 1), in: bezier(.55, 0, 1, .45), lin: p => p, sine: p => .5 - .5 * Math.cos(Math.PI * p),
    p1io: p => p < .5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2 };
  // semente fixa: o mesmo quadro sempre sai igual
  function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  // ---------- seek ----------
  let last = -1;
  const run = (list, t) => { for (const a of list) { if (t >= a.from - 1e-6 && t <= a.to + 1e-6) a.fn(t - a.shift, t - a.from); else if (a.hold) { const c = clamp(t, a.from, a.to); a.fn(c - a.shift, c - a.from); } } };
  function seek(t) {
    t = clamp(t, 0, F.DUR);
    TL.time(t, false);
    run(appliers, t); run(late, t);
    last = t; return t;
  }

  return { FPS, DUR: 66, BLOCOS, ORDEM, plano, bloco, tem, get PLANO() { return PLANO; }, get cur() { return cur; },
    stage, tl, TL, el, q, qa, css, scene, apply, applyLate, cue, CUES, clamp, lerp, prog, bezier, E, rng, seek, get t() { return last; } };
})();
window.seek = t => F.seek(t);
