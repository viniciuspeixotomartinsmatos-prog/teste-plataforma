// A marca do filme. Dois modos:
//  - "monolinha": o logotipo monolinha da demo (o "p" é o cursor de texto + um anel em gradiente; "ronto" sai de trás).
//    Só serve para a demo (as letras são desenhadas à mão).
//  - "simbolo" (o padrão para qualquer marca): o símbolo do config (SVG/PNG) + o nome em texto na fonte do filme (ou o
//    logotipo em SVG, se houver). O cursor de texto vira o símbolo e o anel em gradiente passa em volta dele.
window.B = (() => {
  const { el } = F;
  const m = CFG.marca || {};
  const modo = m.logo === 'monolinha' ? 'monolinha' : 'simbolo';
  const nome = m.nome || 'Marca';
  const SW = 24, R = 38;
  let gid = 0;
  const gradStops = () => `<stop offset="0" stop-color="${C.grad[0]}"/><stop offset=".36" stop-color="${C.grad[1]}"/><stop offset=".7" stop-color="${C.grad[2]}"/><stop offset="1" stop-color="${C.grad[3]}"/>`;

  // símbolo pequeno para a interface (balão, cabeçalho, notificação, montagem): s = largura do desenho da demo
  function mark(s = 40, ink = C.ink, extra = '') {
    if (modo === 'monolinha') {
      const g = ++gid;
      return `<svg width="${s}" height="${s * 1.25}" viewBox="-14 -14 128 168" style="display:block;flex:none;${extra}">
      <defs><linearGradient id="mk${g}" gradientUnits="userSpaceOnUse" x1="0" y1="100" x2="100" y2="0">${gradStops()}</linearGradient></defs>
      <line x1="12" y1="12" x2="12" y2="138" stroke="${ink}" stroke-width="24" stroke-linecap="round"/><circle cx="50" cy="50" r="38" fill="none" stroke="url(#mk${g})" stroke-width="24"/></svg>`;
    }
    const h = s * 1.1, w = Math.min(s * 2.2, h * (B.aspect || 1));
    return `<img src="${M(m.simbolo)}" style="display:block;flex:none;width:${w}px;height:${h}px;object-fit:contain;${extra}">`;
  }

  // ---------- monolinha (demo) ----------
  // Unidades: altura-x = 100, haste = 24; topo da altura-x em y = 0, linha de base em y = 100.
  const REST = [
    { x: 118, d: `M12 12 L12 88 M12 50 A${R} ${R} 0 0 1 69 17.1`, w: 81 },
    { x: 211, circle: true, w: 100 },
    { x: 329, d: `M12 12 L12 88 M12 50 A${R} ${R} 0 0 1 88 50 L88 88`, w: 100 },
    { x: 443, d: `M32 -28 L32 88 M12 12 L68 12`, w: 80 },
    { x: 533, circle: true, w: 100 },
  ];
  const WIDTH = 633, RING_LEN = 2 * Math.PI * R;
  function create(parent, { cx = 960, cy = 540, u = 1.3, ink = C.ink, z = 20 } = {}) {
    const g = ++gid, W = WIDTH * u;
    const root = el(`<div class="abs" style="left:${cx - W / 2}px;top:${cy - 50 * u}px;width:${W}px;height:${100 * u}px;z-index:${z}"></div>`, parent);
    const pad = 40;
    const rest = el(`<svg class="abs" style="left:${(118 - pad) * u}px;top:${-pad * u}px;overflow:visible" width="${(WIDTH - 118 + 2 * pad) * u}" height="${(150 + 2 * pad) * u}"
      viewBox="${118 - pad} ${-pad} ${WIDTH - 118 + 2 * pad} ${150 + 2 * pad}">
      <g fill="none" stroke="${ink}" stroke-width="${SW}" stroke-linecap="round" stroke-linejoin="round">
      ${REST.map(r => r.circle ? `<circle cx="${r.x + 50}" cy="50" r="${R}"/>` : `<path transform="translate(${r.x} 0)" d="${r.d}"/>`).join('')}
      </g></svg>`, root);
    const p = el(`<svg class="abs" style="left:${-pad * u}px;top:${-pad * u}px;overflow:visible" width="${(100 + 2 * pad) * u}" height="${(150 + 2 * pad) * u}"
      viewBox="${-pad} ${-pad} ${100 + 2 * pad} ${150 + 2 * pad}">
      <defs><linearGradient id="lg${g}" gradientUnits="userSpaceOnUse" x1="0" y1="100" x2="100" y2="0">${gradStops()}</linearGradient></defs>
      <line class="stem" x1="12" y1="12" x2="12" y2="138" stroke="${ink}" stroke-width="${SW}" stroke-linecap="round"/>
      <g class="ringg" style="transform-origin:50px 50px"><circle class="ring" cx="50" cy="50" r="${R}" fill="none" stroke="url(#lg${g})" stroke-width="${SW}" stroke-linecap="round"
        stroke-dasharray="${RING_LEN} ${RING_LEN}" transform="rotate(-90 50 50)"/></g></svg>`, root);
    const stem = p.querySelector('.stem'), ring = p.querySelector('.ring'), ringg = p.querySelector('.ringg'), grad = p.querySelector('linearGradient');
    const geo = { u, W, x0: cx - W / 2, y0: cy - 50 * u,
      stemX: cx - W / 2 + 12 * u, stemTop: cy - 50 * u, stemBot: cy - 50 * u + 150 * u,
      ringCx: cx - W / 2 + 50 * u, ringCy: cy, ringR: R * u, sw: SW * u };
    return { root, p, rest, stem, ring, ringg, grad, geo, RING_LEN };
  }

  // ---------- símbolo + nome ----------
  // A assinatura no centro da tela: símbolo de altura h e o nome (ou o logotipo em SVG) à direita, o par centrado em
  // (cx, cy). O nome encolhe até caber em maxW. Devolve as peças e a geometria na tela (sem transformações).
  function lockup(parent, { cx = 960, cy = 540, h = 170, z = 20, maxW = 1500, ink = m.corNome || C.ink } = {}) {
    const sw = h * (B.aspect || 1), gap = h * .3;
    let nameW, nameH, nameHTML, size = 0;
    if (m.logotipo) {
      nameH = h * (m.logotipoAltura || .62); nameW = nameH * (B.aspectLogotipo || 3);
      if (sw + gap + nameW > maxW) { const k = (maxW - sw - gap) / nameW; nameW *= k; nameH *= k; }
      nameHTML = `<img src="${M(m.logotipo)}" style="display:block;width:${nameW}px;height:${nameH}px;object-fit:contain">`;
    } else {
      size = K.fit(nome, { size: h * .78, weight: 700, tracking: -.04, maxW: maxW - sw - gap, min: h * .3 });
      nameW = K.textW(nome, size, 700, -.04); nameH = size;
      nameHTML = `<div style="font-size:${size}px;font-weight:700;letter-spacing:-.04em;line-height:1;white-space:nowrap;color:${ink}">${H(nome)}</div>`;
    }
    const W = sw + gap + nameW, x0 = cx - W / 2;
    const root = el(`<div class="abs" style="left:${x0}px;top:${cy - h / 2}px;width:${W}px;height:${h}px;z-index:${z}"></div>`, parent);
    const sym = el(`<div class="abs" style="left:0;top:0;width:${sw}px;height:${h}px"><img src="${M(m.simbolo)}" style="display:block;width:100%;height:100%;object-fit:contain"></div>`, root);
    const name = el(`<div class="abs" style="left:${sw + gap}px;top:${(h - nameH) / 2 + (m.logotipo ? 0 : nameH * .04)}px;width:${nameW + 40}px;height:${nameH}px;display:flex;align-items:center">${nameHTML}</div>`, root);
    const ringR = Math.max(sw, h) * .66;
    const geo = { x0, W, h, sw, gap, symX: x0, symCx: x0 + sw / 2, symCy: cy, ringR, nameX: x0 + sw + gap, size };
    return { root, sym, name, geo };
  }
  // anel em gradiente solto (o "lente" que passa em volta do símbolo)
  function anel(parent, { cx, cy, r, sw = 18, z = 22 }) {
    const g = ++gid, L = 2 * Math.PI * r, pad = sw * 2;
    const svg = el(`<svg class="abs" style="left:${cx - r - pad}px;top:${cy - r - pad}px;overflow:visible;z-index:${z}" width="${2 * (r + pad)}" height="${2 * (r + pad)}" viewBox="${-r - pad} ${-r - pad} ${2 * (r + pad)} ${2 * (r + pad)}">
      <defs><linearGradient id="an${g}" gradientUnits="userSpaceOnUse" x1="${-r}" y1="${r}" x2="${r}" y2="${-r}">${gradStops()}</linearGradient></defs>
      <circle class="ring" cx="0" cy="0" r="${r}" fill="none" stroke="url(#an${g})" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${L} ${L}" stroke-dashoffset="${L}" transform="rotate(-90)"/></svg>`, parent);
    return { svg, ring: svg.querySelector('.ring'), grad: svg.querySelector('linearGradient'), L };
  }
  return { modo, nome, mark, create, lockup, anel, WIDTH, SW, R, aspect: 1, aspectLogotipo: 3 };
})();
// compatibilidade com o código da demo
window.L = { create: (...a) => B.create(...a) };
