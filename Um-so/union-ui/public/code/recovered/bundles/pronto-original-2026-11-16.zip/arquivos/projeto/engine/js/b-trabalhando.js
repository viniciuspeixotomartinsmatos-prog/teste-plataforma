// Bloco "trabalhando" (23–29 s, opcional): no escuro, a câmera recua e mostra o pedido inteiro; as palavras-chave
// acendem e viram chips; o contador sobe; as telas das fontes voam em 3D com os dados; as telas se desfazem em pontos que
// formam o anel e a câmera mergulha nele (túnel de luz). Sem este bloco, a onda escura do clique corta seco para o
// resultado no tempo forte.
window.BLOCO_trabalhando = () => {
  const { tl, el, apply, cue, clamp, lerp, prog, E, rng } = F;
  if (!F.bloco('trabalhando')) return;
  const cfg = CENA('trabalhando') || {};
  const s8 = X.s8, cams = X.cams;
  tl.to(cams, { rotationY: -3, rotationX: 4, rotationZ: 0, scale: .92, y: 30, duration: .7, ease: 'inout' }, 23.0);
  cue(23.05, 'swoosh_short', 's8:pull');
  const KC = X.KC;
  (X.kps || []).forEach((k, i) => { const t = 23.35 + i * .12, col = KC[i % KC.length];
    tl.fromTo(k, { color: '#ecebf5', textShadow: '0 0 0px rgba(0,0,0,0)' }, { color: col, textShadow: `0 0 26px ${col}`, duration: .2, immediateRender: false }, t);
    cue(t, 'scifi', `s8:kp:${i}`, { step: i }); });
  // chips do "entendi": saem do pedido e sobem para uma fileira
  const chipsHost = el(`<div class="full" style="z-index:5"></div>`, s8);
  const CH = (cfg.chips || []).slice(0, 5);
  const mkChip = (c, i, fs) => { const col = KC[i % KC.length];
    return el(`<div class="chip" style="left:0;top:0;background:rgba(22,22,32,.88);color:#f1f0fb;height:${Math.round(fs * 62 / 27)}px;font-size:${fs}px;padding:0 ${Math.round(fs * 26 / 27)}px 0 ${Math.round(fs * 18 / 27)}px;
    box-shadow:0 0 0 1.5px ${col}77, 0 0 30px -6px ${col}aa">${K.icon(c.icone, Math.round(fs * 30 / 27), col, 2)}${H(c.texto)}</div>`, chipsHost); };
  let fs = 27, chipEls = CH.map((c, i) => mkChip(c, i, fs));
  const gap = 18;
  const tot = () => chipEls.reduce((a, c) => a + c.offsetWidth, 0) + gap * (chipEls.length - 1);
  if (tot() > 1760) { fs = Math.max(18, Math.floor(fs * 1760 / tot())); chipEls.forEach(c => c.remove()); chipEls = CH.map((c, i) => mkChip(c, i, fs)); }
  const widths = chipEls.map(c => c.offsetWidth), total = tot();
  let cx0 = 960 - total / 2;
  chipEls.forEach((c, i) => { const fx = cx0, fy = 170; cx0 += widths[i] + gap;
    const t = 23.95 + i * .09;
    gsap.set(c, { x: fx, y: fy, opacity: 0 });
    tl.fromTo(c, { opacity: 0, x: 620 + i * 110, y: 520 + (i % 2) * 60, scale: .6, filter: 'blur(8px)' }, { opacity: 1, x: fx, y: fy, scale: 1, filter: 'blur(0px)', duration: .55, ease: 'expo', immediateRender: false }, t);
    cue(t + .2, 'pop', `s8:chip:${i}`, { step: i }); });
  tl.to(X.Wd.w, { opacity: 0, scale: .7, y: 120, filter: 'blur(10px)', duration: .6, ease: 'inout' }, 24.55);
  // contador
  const ct = cfg.contador || {};
  const reading = el(`<div class="abs" style="left:0;width:1920px;top:262px;text-align:center;z-index:6;color:#a9a8bb;font-size:30px;font-weight:500;white-space:nowrap">
    ${H(ct.antes || '')} <b class="n mono" style="color:#fff;font-weight:600;font-size:34px">0</b> ${H(ct.depois || '')}</div>`, s8);
  K.popIn(reading, 24.7, { dur: .4, y: 10 });
  K.count(reading.querySelector('.n'), 0, ct.ate ?? 0, 24.75, 27.0, v => String(Math.round(v)), p => p);
  cue(24.75, 'data_bed', 's8:data', { dur: 2.4 });

  // telas das fontes voando em 3D
  const fly = el(`<div class="full" style="perspective:1100px;perspective-origin:960px 600px;z-index:3"></div>`, s8);
  const flyW = el(`<div class="full" style="transform-style:preserve-3d"></div>`, fly);
  const FACTS = (cfg.fontes || []).map(f => Array.isArray(f) ? f : [f.fonte, f.dado]);
  if (!FACTS.length) FACTS.push(['', '']);
  const NP = 30, rp = rng(808), hues = C.hues;
  const panes = [];
  for (let i = 0; i < NP; i++) {
    const [site, fact] = FACTS[i % FACTS.length], hue = hues[i % 4];
    const pane = el(`<div class="abs" style="left:0;top:0;width:400px;height:250px;border-radius:20px;background:rgba(24,24,38,.92);overflow:hidden;
      box-shadow:0 0 0 1.5px hsla(${hue},90%,66%,.55), 0 0 42px -10px hsla(${hue},90%,60%,.6);opacity:0">
      <div style="display:flex;align-items:center;gap:10px;padding:16px 18px 10px"><i style="width:22px;height:22px;border-radius:7px;background:hsl(${hue} 80% 62%);flex:none"></i>
        <span class="ell" style="font:500 18px var(--font);color:#9d9cb2">${H(site)}</span></div>
      <div style="padding:0 18px"><div style="height:10px;width:86%;border-radius:5px;background:rgba(255,255,255,.12)"></div>
        <div style="height:10px;width:70%;border-radius:5px;background:rgba(255,255,255,.09);margin-top:9px"></div></div>
      <div style="margin:18px 18px 0;padding:12px 14px;border-radius:12px;background:hsla(${hue},90%,62%,.14);font:600 21px/1.25 var(--font);color:#fff;max-height:80px;overflow:hidden">${H(fact)}</div>
      <div style="padding:14px 18px"><div style="height:10px;width:60%;border-radius:5px;background:rgba(255,255,255,.08)"></div></div></div>`, flyW);
    const ang = (i * 2.399963) % (Math.PI * 2), rad = 430 + rp() * 330;
    const t0 = 24.82 + i * .062 + rp() * .03, dur = Math.min(1.05 + rp() * .3, 27.3 - (24.82 + i * .062) - .05);
    panes.push({ pane, ang, rad, t0, dur, spin: (rp() - .5) * 40 });
    if (i % 3 === 0) cue(t0 + dur * .72, 'scifi_tick', `s8:pane:${i}`, { pan: +(Math.cos(ang) * .6).toFixed(2) });
  }
  apply(t => {
    for (const P of panes) {
      const p = (t - P.t0) / P.dur;
      if (p <= 0 || p >= 1) { P.pane.style.opacity = 0; continue; }
      const z = lerp(-2600, 760, E.in(p) * .45 + p * .55), x = 960 - 200 + Math.cos(P.ang) * P.rad, y = 600 - 125 + Math.sin(P.ang) * P.rad * .74;
      const fadeIn = clamp(p / .18), fadeOut = clamp((1 - p) / .1);
      P.pane.style.opacity = fadeIn * fadeOut;
      P.pane.style.transform = `translate3d(${x}px,${y}px,${z}px) rotateY(${-Math.cos(P.ang) * 28}deg) rotateX(${Math.sin(P.ang) * 22}deg) rotateZ(${P.spin * p}deg)`;
    }
  }, 24.8, 27.4, true);
  cue(24.9, 'whoosh_fly', 's8:fly:0'); cue(25.9, 'whoosh_fly', 's8:fly:1');

  // pontos: as fontes viram o anel e a câmera mergulha nele
  const cv = el(`<canvas class="abs" width="1920" height="1080" style="left:0;top:0;z-index:7"></canvas>`, s8);
  const g = cv.getContext('2d');
  const NDOT = 1500, rd = rng(2025);
  const dots = Array.from({ length: NDOT }, (_, i) => {
    const a = rd() * Math.PI * 2, tube = rd() * Math.PI * 2;
    return { a, tube, sx: rd() * 1920, sy: rd() * 1080, d: rd() * .35, c: C.grad[i % 4], s: 1.4 + rd() * 2.2, zr: rd() };
  });
  const tRing = 27.0, tWarp = 27.95, tEnd = 28.97;
  const paper = C.hex(C.paper).join(',');
  const rh = rng(77), hyper = Array.from({ length: 520 }, (_, i) => ({ a: rh() * Math.PI * 2, r: 30 + rh() * 380, z0: rh(), k: rh(), c: C.grad[i % 4], w: .8 + rh() * 1.6 }));
  apply(t => {
    g.clearRect(0, 0, 1920, 1080);
    if (t < tRing - .05 || t > tEnd + .05) return;
    const form = E.inout(prog(t, tRing, tRing + .75));
    const warp = prog(t, tWarp, tEnd), wE = warp * warp;
    const rot = (t - tRing) * .9;
    const R0 = 250, r0 = 46;
    g.globalCompositeOperation = 'lighter';
    for (const d of dots) {
      const A = d.a + rot, cx = (R0 + r0 * Math.cos(d.tube)) * Math.cos(A), cy = (R0 + r0 * Math.cos(d.tube)) * Math.sin(A) * .9, cz = r0 * Math.sin(d.tube);
      const tilt = .35, y2 = cy * Math.cos(tilt) - cz * Math.sin(tilt), z2 = cy * Math.sin(tilt) + cz * Math.cos(tilt);
      const zoom = 1 + wE * 14 * (1 + d.zr), f = 900 / (900 + z2 * .6);
      const ringX = 960 + cx * f * zoom, ringY = 560 + y2 * f * zoom;
      const p = clamp((form - d.d) / (1 - d.d));
      const x = lerp(d.sx, ringX, p), y = lerp(d.sy, ringY, p);
      g.globalAlpha = (.25 + .75 * p); g.fillStyle = d.c; g.strokeStyle = d.c;
      g.globalAlpha *= (1 - clamp(warp * 1.6));
      if (warp > 0) {
        const vx = (x - 960) * wE * .22 * (1 + d.zr), vy = (y - 560) * wE * .22 * (1 + d.zr);
        g.lineCap = 'round'; g.lineWidth = 2 * d.s * (1 + wE); g.beginPath(); g.moveTo(x - vx, y - vy); g.lineTo(x + .01, y); g.stroke();
      } else { g.beginPath(); g.arc(x, y, d.s * (.6 + .4 * p), 0, Math.PI * 2); g.fill(); }
    }
    if (warp > 0) {
      const sp = .35 + 3.2 * wE, tt = (t - tWarp);
      for (const h of hyper) {
        const z = ((h.z0 - tt * sp * (1 + h.k * .5)) % 1 + 1) % 1 + .04, z2 = z + .02 + .18 * wE;
        const k = 420, x1 = 960 + Math.cos(h.a) * h.r / z * k / 400, y1 = 560 + Math.sin(h.a) * h.r / z * k / 400;
        const x0 = 960 + Math.cos(h.a) * h.r / z2 * k / 400, y0 = 560 + Math.sin(h.a) * h.r / z2 * k / 400;
        g.globalAlpha = clamp(warp * 3) * clamp((1.05 - z) * 1.4) * .9; g.strokeStyle = h.c; g.lineCap = 'round';
        g.lineWidth = h.w * (1 + 2.5 / (z * 6 + .5)); g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke();
      }
    }
    g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
    // clarão: uma bola de luz que nasce no centro e cobre a tela, chegando na cor do papel
    const fl = clamp((t - (tEnd - .24)) / .24);
    if (fl > 0) { const R = 60 + 2300 * fl * fl, gr = g.createRadialGradient(960, 560, 0, 960, 560, R);
      gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(.55, `rgba(246,244,255,${Math.min(1, .6 + fl)})`); gr.addColorStop(1, `rgba(${paper},0)`);
      g.fillStyle = gr; g.fillRect(0, 0, 1920, 1080); if (fl > .92) { g.fillStyle = `rgba(${paper},${(fl - .92) / .08})`; g.fillRect(0, 0, 1920, 1080); } }
  }, tRing - .1, tEnd + .1, true);
  tl.to([chipsHost, reading], { opacity: 0, filter: 'blur(10px)', duration: .45, ease: 'power2.in' }, 26.95);
  tl.to(X.dotsBg, { opacity: .3, duration: .6 }, 27.0);
  cue(27.02, 'granular', 's8:ring');
  cue(tWarp, 'warp', 's8:warp', { dur: tEnd - tWarp });
};
