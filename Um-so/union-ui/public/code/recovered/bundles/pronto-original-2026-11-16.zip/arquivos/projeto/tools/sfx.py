"""sfx.py — efeitos sonoros sintetizados em código (só numpy, sementes fixas): nada gravado de terceiros.
LIB[tipo](**args) devolve um estéreo float32 a 48 kHz normalizado no pico; o mix aplica o "db" de cada evento.
Os eventos vêm da imagem: cada cena registra um cue (kind) no instante em que anima (out/<filme>/linha.json), e
SONS (no fim deste arquivo) diz que som cada kind toca. Sons afinados em dó (a tonalidade da trilha)."""
import numpy as np

SR = 48000

def _rng(seed):
    return np.random.default_rng(seed)


def _db(g):
    return 10 ** (g / 20)


def _pan(y, p):
    """equal-power pan, p in [-1, 1] (scalar or per-sample array)"""
    a = (np.asarray(p) + 1) * np.pi / 4
    return np.stack([y * np.cos(a), y * np.sin(a)], 1)


def _bandnoise(n, fc_curve, q_curve, seed):
    """white noise through a time-varying gaussian band-pass (block FFT, overlap-add)"""
    rng = _rng(seed); x = rng.standard_normal(n + 2048)
    blk, hop = 1024, 256; win = np.hanning(blk)
    out = np.zeros(n + 2048); ws = np.zeros(n + 2048)
    fq = np.fft.rfftfreq(blk, 1 / SR)
    for s in range(0, n, hop):
        c = min(s + blk // 2, n - 1)
        fc = fc_curve[c]; bw = fc / q_curve[c]
        X = np.fft.rfft(x[s:s + blk] * win)
        X *= np.exp(-0.5 * ((fq - fc) / bw) ** 2)
        out[s:s + blk] += np.fft.irfft(X) * win; ws[s:s + blk] += win ** 2
    y = out[:n] / np.maximum(ws[:n], 1e-3)
    return y / (np.abs(y).max() + 1e-12)


def _norm(y):
    return y / (np.abs(y).max() + 1e-12)


def ui_click(release=False, seed=0):
    """soft UI click: short band-limited tick + small tonal 'tock'"""
    n = int(0.05 * SR); t = np.arange(n) / SR
    rng = _rng(seed)
    tick = rng.standard_normal(n) * np.exp(-t / 0.0012)
    X = np.fft.rfft(tick); fq = np.fft.rfftfreq(n, 1 / SR)
    X *= np.exp(-0.5 * ((np.log2(fq + 1) - np.log2(3800 if not release else 5200)) / 0.7) ** 2)
    tick = np.fft.irfft(X, n)
    f0 = 1650 if not release else 2300
    tock = np.sin(2 * np.pi * f0 * t) * np.exp(-t / 0.006)
    y = _norm(tick) * 0.8 + tock * 0.45
    return _norm(y) * (0.55 if release else 1.0)


def key_tap(seed):
    """keyboard key: click transient + low-mid 'thock' body, slightly varied per key"""
    rng = _rng(100 + seed)
    n = int(0.09 * SR); t = np.arange(n) / SR
    click = rng.standard_normal(n) * np.exp(-t / 0.0015)
    X = np.fft.rfft(click); fq = np.fft.rfftfreq(n, 1 / SR)
    X *= np.exp(-0.5 * ((np.log2(fq + 1) - np.log2(rng.uniform(2800, 4200))) / 0.8) ** 2)
    click = _norm(np.fft.irfft(X, n))
    fb = rng.uniform(260, 340)
    body = np.sin(2 * np.pi * fb * t * (1 - 0.15 * t / 0.09)) * np.exp(-t / 0.018)
    body2 = np.sin(2 * np.pi * 2.7 * fb * t) * np.exp(-t / 0.008) * 0.3
    y = click * 0.7 + body * 0.55 + body2
    return _norm(y) * rng.uniform(0.8, 1.0)


def whoosh(dur, peak_frac, style, seed):
    """band-passed noise whoosh; style sets the centre-frequency path"""
    n = int(dur * SR); u = np.arange(n) / n
    if style == 'zoom_out':           # falling
        fc = 3500 * (350 / 3500) ** u
    elif style == 'rise':
        fc = 500 * (4500 / 500) ** u
    elif style == 'sweep_in':          # converging: up then settle
        fc = np.where(u < peak_frac, 700 * (3200 / 700) ** (u / peak_frac), 3200 * (1200 / 3200) ** ((u - peak_frac) / (1 - peak_frac)))
    else:                              # swipe: up to the peak then down
        fc = np.where(u < peak_frac, 600 * (5000 / 600) ** (u / peak_frac), 5000 * (900 / 5000) ** ((u - peak_frac) / (1 - peak_frac)))
    q = np.full(n, 1.6)
    y = _bandnoise(n, fc, q, seed)
    # asymmetric envelope: slow swell to the peak, faster decay
    env = np.where(u < peak_frac, (u / peak_frac) ** 2.2, np.exp(-((u - peak_frac) / (1 - peak_frac)) * 4.0))
    y = y * env
    # low 'air' body so it reads under music
    lo = _bandnoise(n, np.full(n, 220.0), np.full(n, 1.0), seed + 1) * env * 0.35
    return _norm(y + lo)


def snare_tap(seed, bright=1.0):
    rng = _rng(300 + seed)
    n = int(0.12 * SR); t = np.arange(n) / SR
    nz = rng.standard_normal(n) * np.exp(-t / 0.035)
    X = np.fft.rfft(nz); fq = np.fft.rfftfreq(n, 1 / SR)
    X *= np.exp(-0.5 * ((np.log2(fq + 1) - np.log2(3000 * bright)) / 1.1) ** 2)
    nz = _norm(np.fft.irfft(X, n))
    body = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.03)
    return _norm(nz * 0.8 + body * 0.5)


def riser(dur, seed):
    n = int(dur * SR); u = np.arange(n) / n
    fc = 400 * (7000 / 400) ** (u ** 1.3)
    y = _bandnoise(n, fc, np.full(n, 1.3), seed)
    env = u ** 2.5
    k = int(0.006 * SR); env[-k:] *= np.linspace(1, 0, k)        # cut just before the drop
    return _norm(y * env)


def glide_up(seed):
    """short tonal up-glide 1.4 -> 2.6 kHz, ~0.2 s, plus a little air"""
    n = int(0.24 * SR); t = np.arange(n) / SR; u = t / t[-1]
    f = 1400 * (2600 / 1400) ** (u ** 0.8)
    ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) + 0.25 * np.sin(2 * ph)
    env = np.sin(np.pi * np.clip(u * 1.1, 0, 1)) ** 1.5
    air = _bandnoise(n, f * 2, np.full(n, 2.0), seed) * 0.25
    return _norm((tone + air) * env)


def pop(seed):
    n = int(0.25 * SR); t = np.arange(n) / SR
    f = 150 + 550 * np.exp(-t / 0.018)
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = np.sin(ph) * np.exp(-t / 0.07)
    cl = np.zeros(n); c = ui_click(seed=seed); cl[:len(c)] = c
    return _norm(y + 0.3 * cl)


def impact(seed):
    n = int(0.7 * SR); t = np.arange(n) / SR
    f = 42 + 60 * np.exp(-t / 0.05)
    boom = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.22)
    rng = _rng(seed); nz = rng.standard_normal(n) * np.exp(-t / 0.05)
    X = np.fft.rfft(nz); fq = np.fft.rfftfreq(n, 1 / SR); X *= 1 / (1 + (fq / 900) ** 2)
    nz = _norm(np.fft.irfft(X, n))
    return _norm(boom + 0.35 * nz)


def shimmer(seed):
    rng = _rng(seed)
    n = int(0.6 * SR); t = np.arange(n) / SR
    y = np.zeros(n)
    for k in range(9):
        f = rng.uniform(4200, 9500); d = rng.uniform(0, 0.25)
        e = np.clip((t - d) / 0.01, 0, 1) * np.exp(-np.maximum(t - d, 0) / rng.uniform(0.08, 0.18))
        y += np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) * e
    return _norm(y)




def _st(y, pan=0.0):
    p = np.linspace(pan[0], pan[1], len(y)) if isinstance(pan, (tuple, list)) else pan
    return (_pan(y, p) * np.sqrt(2)).astype(np.float32)


# ---------- sons afinados e texturas (dó menor pentatônica) ----------
ESCALA = [261.63, 311.13, 349.23, 392.00, 466.16]          # C4 Eb4 F4 G4 Bb4


def nota(step, base=2):
    """frequência do passo step na pentatônica, a partir da oitava base (2 = C6)"""
    o, k = divmod(int(step), len(ESCALA))
    return ESCALA[k] * 2 ** (base + o)


def ping(f, dur=0.35, seed=0, bright=1.0, decay=0.09):
    """tique de vidro afinado: senoide com parcial, ataque de 2 ms e cauda curta, mais um clique de ruído"""
    n = int(dur * SR); t = np.arange(n) / SR
    env = np.clip(t / 0.002, 0, 1) * np.exp(-t / decay)
    y = np.sin(2 * np.pi * f * t) + 0.35 * bright * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t / (decay * 0.4))
    c = np.zeros(n); k = ui_click(seed=seed); c[:len(k)] = k[:n]
    return _norm(y * env + 0.12 * c)


def bell(notas, gap=0.07, dur=0.9, decay=0.25):
    """notas em sequência (sininho de notificação / de "feito")"""
    n = int((dur + gap * len(notas)) * SR); y = np.zeros(n)
    for i, f in enumerate(notas):
        p = ping(f, dur, seed=900 + i, bright=0.8, decay=decay); i0 = int(i * gap * SR); y[i0:i0 + len(p)] += p[:n - i0] * (0.85 ** i)
    return _norm(y)


def glide(f0, f1, dur=0.3, seed=0):
    n = int(dur * SR); t = np.arange(n) / SR; u = t / t[-1]
    f = f0 * (f1 / f0) ** u; ph = 2 * np.pi * np.cumsum(f) / SR
    env = np.sin(np.pi * np.clip(u * 1.05, 0, 1)) ** 1.2
    return _norm((np.sin(ph) + 0.2 * np.sin(2 * ph)) * env)


def grains(dur=0.8, density=60, f_lo=2500, f_hi=9000, seed=0, fade=True):
    """chuva de grãos curtos (pixels, dados, abas que se multiplicam)"""
    rng = _rng(seed); n = int(dur * SR); y = np.zeros(n)
    for _ in range(int(density * dur)):
        i0 = rng.integers(0, max(1, n - 2000)); f = rng.uniform(f_lo, f_hi); m = int(rng.uniform(0.004, 0.02) * SR)
        tt = np.arange(m) / SR; y[i0:i0 + m] += np.sin(2 * np.pi * f * tt) * np.exp(-tt / 0.004) * rng.uniform(0.3, 1)
    if fade: y *= np.linspace(1, 0.25, n)
    return _norm(y)


def thunk(seed=0):
    """golpe grave macio"""
    n = int(0.6 * SR); t = np.arange(n) / SR
    f = 55 + 45 * np.exp(-t / 0.04)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.18) * np.clip(t / 0.004, 0, 1)
    return _norm(y + 0.1 * impact(seed)[:n])


LIB = {
    'clique': lambda seed=0, pan=0.15: _st(ui_click(False, seed), pan),
    'clique_solta': lambda seed=0, pan=0.15: _st(ui_click(True, seed), pan),
    'tecla': lambda seed=0, pan=0.1: _st(key_tap(seed), pan),
    'whoosh': lambda dur=0.6, pico=0.7, estilo='swipe', seed=200, pan0=0.0, pan1=0.0: _st(whoosh(dur, pico, estilo, seed), (pan0, pan1)),
    'batida': lambda seed=0, brilho=1.0, pan=0.0: _st(snare_tap(seed, brilho), pan),
    'subida': lambda dur=1.2, seed=400: _st(riser(dur, seed), 0.0),
    'glide': lambda seed=500: _st(glide_up(seed), 0.0),
    'impacto': lambda seed=501: _st(impact(seed), 0.0),
    'brilho': lambda seed=502: _st(shimmer(seed), 0.0),
    'pop': lambda seed=700, pan=0.0: _st(pop(seed), pan),
    'ping': lambda step=0, base=2, seed=0, pan=0.0, decay=0.09: _st(ping(nota(step, base), 0.35, seed, decay=decay), pan),
    'sino': lambda notas=(622.25, 783.99, 1046.5), gap=0.07: _st(bell(list(notas), gap), 0.0),
    'glide2': lambda f0=1400, f1=2600, dur=0.3: _st(glide(f0, f1, dur), 0.0),
    'graos': lambda dur=0.8, density=60, seed=0, f_lo=2500, f_hi=9000: _st(grains(dur, density, f_lo, f_hi, seed), 0.0),
    'grave': lambda seed=0: _st(thunk(seed), 0.0),
}


# ---------- o que cada cue da imagem toca ----------
# kind → função(cue) que devolve [(tipo, args, db, deslocamento_s)]. db é o nível de pico do som na mixagem.
def _k(c):
    v = c.get('variant')
    return [('tecla', {'seed': int(c['f'] * 7) % 97}, -17 if v == 'space' else -15 if v == 'word' else -16.5, 0)]


SONS = {
    'blink': lambda c: [('clique', {'seed': 3, 'pan': 0}, -27, 0)],
    'riser': lambda c: [('subida', {'dur': c.get('len', 1.4), 'seed': 400}, -17, -c.get('len', 1.4))],
    'flare': lambda c: [('whoosh', {'dur': 0.9, 'pico': 0.25, 'estilo': 'zoom_out', 'seed': 201}, -16, -0.05), ('ping', {'step': 5}, -21, 0)],
    'pulse': lambda c: [('ping', {'step': 5 + int(c['id'].split(':')[-1])}, -21, 0)],
    'key': _k,
    'enter': lambda c: [('tecla', {'seed': 41}, -12, 0), ('clique', {'seed': 9}, -20, 0)],
    'tick': lambda c: [('ping', {'step': c.get('step', 0), 'base': 2, 'decay': 0.05}, -23, 0)],
    'swoosh_long': lambda c: [('whoosh', {'dur': 0.9, 'pico': 0.6, 'estilo': 'swipe', 'seed': 210}, -15, -0.5)],
    'morph': lambda c: [('whoosh', {'dur': 0.8, 'pico': 0.55, 'estilo': 'sweep_in', 'seed': 211}, -16, -0.4)],
    'swoosh_short': lambda c: [('whoosh', {'dur': 0.45, 'pico': 0.55, 'estilo': 'swipe', 'seed': 212}, -16, -0.22)],
    'ring_in': lambda c: [('whoosh', {'dur': 0.5, 'pico': 0.7, 'estilo': 'sweep_in', 'seed': 213}, -16, -0.3)],
    'land': lambda c: [('whoosh', {'dur': 0.5, 'pico': 0.75, 'estilo': 'sweep_in', 'seed': 214}, -15, -0.32), ('pop', {'seed': 701}, -20, 0.05)],
    'whoosh_cold': lambda c: [('whoosh', {'dur': 0.9, 'pico': 0.35, 'estilo': 'zoom_out', 'seed': 215}, -15, -0.1)],
    'tabs_texture': lambda c: [('graos', {'dur': c.get('dur', 0.8), 'density': 45, 'seed': 31, 'f_lo': 1800, 'f_hi': 5000}, -21, 0)],
    'stop': lambda c: [],
    'swing': lambda c: [('whoosh', {'dur': 0.32, 'pico': 0.6, 'estilo': 'swipe', 'seed': 220 + int(c['f']) % 5}, -14, -0.18)],
    'swing_out': lambda c: [('whoosh', {'dur': 0.3, 'pico': 0.4, 'estilo': 'swipe', 'seed': 226}, -18, -0.1)],
    'drop': lambda c: [('impacto', {'seed': 501}, -9, 0), ('grave', {'seed': 3}, -12, 0)],
    'final_hit': lambda c: [('impacto', {'seed': 502}, -11, 0)],
    'snap': lambda c: [('clique', {'seed': 21, 'pan': 0}, -13, 0), ('ping', {'step': 7, 'decay': 0.06}, -22, 0)],
    'click_fav': lambda c: [('clique', {'seed': 22, 'pan': 0}, -11, 0), ('clique_solta', {'seed': 23, 'pan': 0}, -17, 0.09)],
    'attach': lambda c: [('pop', {'seed': 702}, -17, 0), ('clique', {'seed': 24}, -20, 0)],
    'click_soft': lambda c: [('clique', {'seed': 25, 'pan': 0}, -15, 0)],
    'dark_thunk': lambda c: [('grave', {'seed': 5}, -10, 0)],
    'whoosh_airy': lambda c: [('whoosh', {'dur': 1.0, 'pico': 0.35, 'estilo': 'zoom_out', 'seed': 230}, -15, -0.1)],
    'scifi': lambda c: [('ping', {'step': 5 + c.get('step', 0), 'base': 2, 'decay': 0.05}, -21, 0), ('glide2', {'f0': 1800, 'f1': 3200, 'dur': 0.12}, -27, 0)],
    'scifi_tick': lambda c: [('ping', {'step': (int(c['f']) * 3) % 8, 'base': 3, 'decay': 0.03, 'pan': c.get('pan', 0)}, -27, 0)],
    'pop': lambda c: [('pop', {'seed': 703 + c.get('step', 0)}, -21 if c.get('soft') else -18, 0), ('ping', {'step': c.get('step', 0)}, -27, 0)],
    'word': lambda c: [('pop', {'seed': 710}, -20, 0), ('whoosh', {'dur': 0.3, 'pico': 0.7, 'estilo': 'sweep_in', 'seed': 240}, -23, -0.2)],
    'data_bed': lambda c: [('graos', {'dur': c.get('dur', 2.4), 'density': 70, 'seed': 33, 'f_lo': 3000, 'f_hi': 9000}, -25, 0)],
    'whoosh_fly': lambda c: [('whoosh', {'dur': 0.9, 'pico': 0.5, 'estilo': 'swipe', 'seed': 250 + int(c['f']) % 3, 'pan0': -0.5, 'pan1': 0.5}, -16, -0.2)],
    'warp': lambda c: [('whoosh', {'dur': c.get('dur', 1.0) + 0.1, 'pico': 0.92, 'estilo': 'rise', 'seed': 260}, -12, 0), ('subida', {'dur': c.get('dur', 1.0), 'seed': 401}, -18, 0)],
    'granular': lambda c: [('graos', {'dur': 0.9, 'density': 90, 'seed': 35}, -20, 0), ('brilho', {'seed': 503}, -22, 0.2)],
    'pixels': lambda c: [('graos', {'dur': 0.7, 'density': 70, 'seed': 36, 'f_lo': 4000, 'f_hi': 10000}, -23, 0)],
    'name': lambda c: [('whoosh', {'dur': 0.6, 'pico': 0.3, 'estilo': 'zoom_out', 'seed': 270}, -21, 0)],
    'tagline': lambda c: [('brilho', {'seed': 504}, -27, 0)],
    'price_drop': lambda c: [('glide2', {'f0': 1600, 'f1': 700, 'dur': 0.35} if not c.get('sobe') else {'f0': 700, 'f1': 1600, 'dur': 0.35}, -18, 0)],
    'notify': lambda c: [('sino', {'notas': (622.25, 783.99), 'gap': 0.11}, -14, 0)],
    'check': lambda c: [('ping', {'step': 3 + c.get('step', 0), 'base': 2, 'decay': 0.08}, -19, 0), ('clique', {'seed': 40 + c.get('step', 0)}, -24, 0)],
    'success': lambda c: [('sino', {'notas': (523.25, 622.25, 783.99, 1046.5), 'gap': 0.06}, -15, 0)],
    'fall': lambda c: [('glide2', {'f0': 2200, 'f1': 500, 'dur': c.get('dur', 0.8)}, -23, 0), ('graos', {'dur': 0.8, 'density': 30, 'seed': 37, 'f_lo': 1500, 'f_hi': 4000}, -24, 0)],
    'cut': lambda c: [('whoosh', {'dur': 0.18, 'pico': 0.5, 'estilo': 'swipe', 'seed': 280 + int(c['f']) % 7}, -24 if c.get('fast') else -21, -0.08)],
}
