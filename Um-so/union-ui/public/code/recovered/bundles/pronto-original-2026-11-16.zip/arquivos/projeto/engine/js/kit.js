// Peças reutilizáveis: cursor de texto, digitação com "tinta fresca", palavras 3D com motion blur, cursor do mouse e
// toque que miram o alvo medido, ondas, borda de IA, contadores, texto que cabe. Tudo agenda na linha do tempo F.tl e
// registra os cues de som.
window.K = (() => {
  const { tl, el, cue, apply, applyLate, clamp, lerp, prog, E, rng } = F;
  const INK = C.ink, ACAO = C.acao, GRAD = C.grad;
  const [BLUE, VIOLET, PINK, CORAL] = GRAD;

  // grão fixo de filme (uma textura de ruído gerada uma vez)
  function grain(parent) {
    const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d'), d = g.createImageData(256, 256), r = rng(7);
    for (let i = 0; i < d.data.length; i += 4) { const v = 128 + (r() - .5) * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
    g.putImageData(d, 0, 0);
    return el(`<div class="grain" style="background-image:url(${c.toDataURL()});background-size:256px"></div>`, parent);
  }

  // ---------- texto que cabe ----------
  // mede numa sonda escondida, com a fonte já carregada; devolve o maior corpo (até size) que cabe em maxW
  let probe = null;
  function textW(text, size, weight = 500, tracking = 0) {
    if (!probe) probe = el(`<div style="position:absolute;left:-99999px;top:0;white-space:pre;visibility:hidden;line-height:1"></div>`, document.body);
    probe.style.fontFamily = `'${FONTE}', system-ui, sans-serif`; probe.style.fontSize = size + 'px'; probe.style.fontWeight = weight; probe.style.letterSpacing = tracking + 'em';
    probe.textContent = text; return probe.getBoundingClientRect().width;
  }
  function fit(text, { size, weight = 500, tracking = 0, maxW, min = size * .45 }) {
    if (!maxW) return size;
    const w = textW(text, size, weight, tracking);
    if (w <= maxW) return size;
    return Math.max(min, Math.floor(size * maxW / w * 10) / 10);
  }
  // quebra em linhas que cabem em maxW (por palavra); devolve { lines, size } com o corpo reduzido se precisar
  function wrap(text, { size, weight = 500, tracking = 0, maxW, maxLines = 3, min = size * .6 }) {
    const words = String(text).split(/\s+/).filter(Boolean);
    for (let s = size; s >= min; s = Math.floor(s * .94 * 10) / 10) {
      const lines = []; let line = '';
      for (const w of words) { const t = line ? line + ' ' + w : w; if (textW(t, s, weight, tracking) <= maxW || !line) line = t; else { lines.push(line); line = w; } }
      if (line) lines.push(line);
      if (lines.length <= maxLines && lines.every(l => textW(l, s, weight, tracking) <= maxW)) return { lines, size: s };
    }
    return { lines: [String(text)], size: min };
  }

  // ---------- cursor de texto ----------
  function caret(parent, { x = 0, y = 0, w = 8, h = 112, color = INK, z = 5 } = {}) {
    const c = el(`<div class="caret" style="left:${x}px;top:${y}px;width:${w}px;height:${h}px;background:${color};z-index:${z}"><i class="bloom"></i></div>`, parent);
    c.bloom = c.firstElementChild; return c;
  }
  // pisca no tempo da música: aceso [t, t+on), apagado até t+period
  function blink(c, from, to, { period = 1, on = .5, sound = null, id = 'caret' } = {}) {
    let k = 0;
    for (let t = from; t < to - 1e-6; t += period, k++) {
      tl.set(c, { opacity: 1 }, t); tl.set(c, { opacity: 0 }, Math.min(t + on, to));
      if (sound) cue(t, sound, `${id}:${k}`);
    }
    tl.set(c, { opacity: 1 }, to);
  }

  // ---------- digitação ----------
  // Uma linha: as letras nascem na cor da ação, borradas, e assentam em tinta; o cursor pula para o fim; com align
  // center a linha se recentra a cada letra. Os tempos de cada caractere têm um jitter fixo (mão humana).
  // maxW: a linha encolhe (corpo e cursor) até caber; tmax: a digitação acelera para terminar até esse instante.
  function typeLine(parent, text, o) {
    let { t0, cps = 16, size = 104, weight = 500, x = 960, y = 540, align = 'center', color = INK, tint = ACAO,
      tracking = -0.02, id = 'type', caretW, caretH, caretColor = ACAO, caretGap, sound = 'key', jitter = .35, recenter = true, z = 5,
      glow = true, times = null, settle = .42, lh = 1, soundEvery = 1, maxW = null, tmax = null } = o;
    const size0 = size;
    size = fit(text, { size, weight, tracking, maxW });
    const k = size / size0;
    caretW = caretW != null ? Math.max(2, Math.round(caretW * Math.sqrt(k))) : Math.max(4, Math.round(size * .06));
    caretH = caretH != null ? Math.round(caretH * k) : Math.round(size * 1.12);
    caretGap = caretGap != null ? caretGap : Math.round(size * .06);
    if (tmax && !times) { const n = [...text].length; if (t0 + n / cps > tmax) cps = n / Math.max(.2, tmax - t0); }
    const glowCol = C.rgba(tint, .55), glow0 = C.rgba(tint, 0);
    const line = el(`<div class="tl" style="left:${x}px;top:${y}px;font-size:${size}px;font-weight:${weight};letter-spacing:${tracking}em;color:${color};z-index:${z};line-height:${lh}"></div>`, parent);
    const chars = [...text].map(ch => el(`<span class="ch">${ch === ' ' ? '&nbsp;' : H(ch)}</span>`, line));
    const W = line.offsetWidth, Hh = line.offsetHeight;
    const cx = caret(line, { x: 0, y: (Hh - caretH) / 2, w: caretW, h: caretH, color: caretColor, z: 6 });
    const r = rng(text.length * 131 + Math.round(t0 * 1000));
    const ts = times || (() => { const a = []; let t = t0; for (let i = 0; i < chars.length; i++) { a.push(t); const base = 1 / cps;
      t += base * (1 + (r() - .5) * 2 * jitter) * (text[i] === ' ' ? 1.25 : 1); } return a; })();
    const ends = chars.map(c => c.offsetLeft + c.offsetWidth);
    const offX = v => align === 'center' ? -v / 2 : align === 'right' ? -v : 0;
    gsap.set(line, { x: offX(recenter ? 0 : W), y: -Hh / 2 });
    gsap.set(chars, { opacity: 0 });
    gsap.set(cx, { x: 0 });
    const tch = [...text];
    chars.forEach((c, i) => {
      const t = ts[i];
      tl.fromTo(c, { opacity: 0, filter: 'blur(9px)', color: tint, textShadow: glow ? `0 0 ${size * .28}px ${glowCol}` : 'none' },
        { opacity: 1, filter: 'blur(0px)', duration: .16, ease: 'out', immediateRender: false }, t);
      tl.fromTo(c, { color: tint, textShadow: glow ? `0 0 ${size * .28}px ${glowCol}` : 'none' },
        { color, textShadow: glow ? `0 0 0px ${glow0}` : 'none', duration: settle, ease: 'power1.out', immediateRender: false }, t + .09);
      tl.set(cx, { x: ends[i] + caretGap }, t);
      if (recenter && align !== 'left') tl.fromTo(line, { x: offX(i ? ends[i - 1] : 0) }, { x: offX(ends[i]), duration: .14, ease: 'out', immediateRender: false }, t);
      const wordStart = i === 0 || tch[i - 1] === ' ';
      if (sound && tch[i] !== ' ' && (wordStart || i % soundEvery === 0)) cue(t, sound, `${id}:${i}`, { variant: wordStart ? 'word' : 'char' });
      if (sound && tch[i] === ' ' && soundEvery === 1) cue(t, sound, `${id}:${i}`, { variant: 'space' });
    });
    const end = ts[ts.length - 1] + 1 / cps;
    return { line, chars, caret: cx, ts, end, W, H: Hh, ends, x, y, size };
  }
  // apaga da direita para a esquerda (backspace)
  function erase(T, t0, { cps = 30, keep = 0, sound = 'key', id = 'erase' } = {}) {
    const { chars, caret: cx, line, ends } = T; let t = t0;
    for (let i = chars.length - 1; i >= keep; i--) {
      tl.to(chars[i], { opacity: 0, filter: 'blur(6px)', duration: .08, ease: 'none' }, t);
      tl.set(cx, { x: i ? ends[i - 1] + T.size * .06 : 0 }, t);
      tl.to(line, { x: -(i ? ends[i - 1] : 0) / 2, duration: .1, ease: 'out' }, t);
      if (sound && i % 2 === 0) cue(t, sound, `${id}:${i}`, { variant: 'erase' });
      t += 1 / cps;
    }
    return t;
  }

  // ---------- palavras gigantes em 3D com motion blur ----------
  // A pose é uma função pura do tempo; o rastro de cópias amostra a mesma função alguns ms antes (obturador).
  // maxW: a palavra encolhe até caber na largura (centrada em x).
  function word3d(parent, text, o) {
    let { tIn, tOut, size = 300, weight = 700, color = INK, x = 960, y = 540, from = {}, to = {}, rest = {}, inDur = .32,
      outDur = .26, ghosts = 7, shutter = .045, id = 'w3', soundIn = 'swing', soundOut = null, z = 10, tracking = -.045, persp = 1400, maxW = null } = o;
    size = fit(text, { size, weight, tracking, maxW });
    const wrap = el(`<div class="abs" style="left:0;top:0;width:1920px;height:1080px;perspective:${persp}px;perspective-origin:${x}px ${y}px;z-index:${z};pointer-events:none"></div>`, parent);
    const make = op => el(`<div class="w3" style="font-size:${size}px;font-weight:${weight};color:${color};letter-spacing:${tracking}em;opacity:${op}">${H(text)}</div>`, wrap);
    const main = make(0), copies = Array.from({ length: ghosts }, () => make(0));
    const w = main.offsetWidth, h = main.offsetHeight;
    const P0 = { x: 0, y: 0, z: -300, rx: 0, ry: -70, rz: 0, s: 1, o: 0, ...from };
    const P1 = { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, s: 1, o: 1, ...rest };
    const P2 = { x: 0, y: 0, z: -200, rx: 0, ry: 75, rz: 0, s: 1, o: 0, ...to };
    const keys = ['x', 'y', 'z', 'rx', 'ry', 'rz', 's', 'o'];
    const pose = t => {
      if (t < tIn) return null;
      if (t >= tOut + outDur) return null;
      if (t < tIn + inDur) { const p = E.expo(prog(t, tIn, tIn + inDur)); const r = {}; keys.forEach(k => r[k] = lerp(P0[k], P1[k], p)); r.o = lerp(P0.o, P1.o, clamp(p * 2.2)); return r; }
      if (t < tOut) { const p = (t - tIn - inDur) / Math.max(.001, tOut - tIn - inDur); const r = { ...P1 }; r.z += p * (rest.drift ?? 40); r.ry += p * (rest.dry ?? 0); r.rz += p * (rest.drz ?? 0); return r; }
      const p = E.in(prog(t, tOut, tOut + outDur)); const r = {}; keys.forEach(k => r[k] = lerp(P1[k], P2[k], p)); r.o = lerp(1, P2.o, clamp((p - .35) / .65)); r.z += rest.drift ?? 40; return r;
    };
    const put = (n, P, op) => {
      if (!P) { n.style.opacity = 0; return; }
      n.style.opacity = op * P.o;
      n.style.transform = `translate3d(${x - w / 2 + P.x}px, ${y - h / 2 + P.y}px, ${P.z}px) rotateX(${P.rx}deg) rotateY(${P.ry}deg) rotateZ(${P.rz}deg) scale(${P.s})`;
    };
    apply(t => {
      const P = pose(t); put(main, P, 1);
      const Pp = pose(t - .02); let v = 0; if (P && Pp) v = Math.abs(P.ry - Pp.ry) + Math.abs(P.rx - Pp.rx) + Math.abs(P.rz - Pp.rz) + Math.abs(P.x - Pp.x) / 20 + Math.abs(P.z - Pp.z) / 30;
      const amt = clamp(v / 6);
      copies.forEach((c, i) => { const k = (i + 1) / ghosts; put(c, pose(t - k * shutter * (0.4 + amt)), amt * .42 * (1 - k)); c.style.filter = `blur(${(2 + 8 * k) * amt}px)`; });
      main.style.filter = amt > .05 ? `blur(${amt * 2.2}px)` : 'none';
    }, tIn - .1, tOut + outDur + .1, true);
    if (soundIn) cue(tIn + inDur * .35, soundIn, `${id}:in`);
    if (soundOut) cue(tOut + outDur * .45, soundOut, `${id}:out`);
    return { wrap, main, w, h, size };
  }

  // ---------- alvos medidos ----------
  // alvo(el, fx, fy): devolve uma função que mede, no quadro atual, onde o ponto (fx, fy) do elemento está NA TELA
  // (com toda a câmera, perspectiva e 3D por cima). É uma sonda sem tamanho dentro do elemento: o navegador projeta.
  function alvo(node, fx = .5, fy = .5) {
    if (getComputedStyle(node).position === 'static') node.style.position = 'relative';
    const p = document.createElement('i');
    p.className = 'sonda';
    p.style.cssText = `position:absolute;left:${fx * 100}%;top:${fy * 100}%;width:0;height:0;margin:0;padding:0;border:0;pointer-events:none`;
    node.appendChild(p);
    const f = () => { const r = p.getBoundingClientRect(), s = F.stage.getBoundingClientRect(), k = s.width / 1920; return [(r.left - s.left) / k, (r.top - s.top) / k]; };
    f.node = node; return f;
  }
  const val = (P, t) => typeof P === 'function' ? P(t) : P.de ? (([x, y]) => [x + (P.dx || 0), y + (P.dy || 0)])(val(P.de, t)) : P;

  // ---------- ponteiro: cursor do mouse ou dedo ----------
  // A posição é uma função pura do tempo, calculada num aplicador tardio (depois que câmera e alvos já estão no
  // quadro), em todo o trecho em que ele existe. caminho([{t, p}, ...]): p = [x, y] (tela), alvo(...) ou
  // {de: alvo, dx, dy}. Entre duas chaves: sai da primeira e chega na segunda medida AGORA, com aceleração e frenagem
  // (velocidade zero nas pontas) e um arco leve; quando as duas chaves são o mesmo alvo, ele fica colado no alvo
  // (arrasto, ou alvo que anda com a câmera). Nada depende do quadro anterior.
  const HUMANO = F.bezier(.32, 0, .14, 1);
  function ponteiro(parent, html, hot, { z = 800, cls = 'mouse', w, h } = {}) {
    const m = el(`<div class="${cls}" style="width:${w}px;height:${h}px;z-index:${z}">${html}</div>`, parent);
    gsap.set(m, { opacity: 0, x: 0, y: 0 });
    const api = {
      el: m, hot,
      caminho(keys) {
        keys = keys.map(k => ({ bow: .07, ease: HUMANO, ...k }));
        const pos = t => {
          if (t <= keys[0].t) return val(keys[0].p, t);
          for (let i = 0; i < keys.length - 1; i++) {
            const a = keys[i], b = keys[i + 1];
            if (t < b.t) {
              const A = val(a.p, t), B = val(b.p, t);
              if (a.p === b.p) return B;
              const s = b.ease(prog(t, a.t, b.t)), dx = B[0] - A[0], dy = B[1] - A[1], bw = Math.sin(Math.PI * s) * b.bow;
              return [A[0] + dx * s - dy * bw, A[1] + dy * s + dx * bw];
            }
          }
          return val(keys[keys.length - 1].p, t);
        };
        api.pos = pos;
        applyLate(t => {
          const [x, y] = pos(t);
          const pr = parent.getBoundingClientRect(), s = F.stage.getBoundingClientRect(), k = s.width / 1920;
          const lx = x - (pr.left - s.left) / k, ly = y - (pr.top - s.top) / k;
          m.style.transform = `translate(${(lx - hot[0]).toFixed(3)}px, ${(ly - hot[1]).toFixed(3)}px) scale(${m._s ?? 1})`;
        }, keys[0].t - .3, keys[keys.length - 1].t + 3, true);
        return api;
      },
      mostra(t, d = .12) { tl.fromTo(m, { opacity: 0 }, { opacity: 1, duration: d, ease: 'none', immediateRender: false }, t); },
      // escala do clique em volta da ponta (o transform é escrito pelo aplicador; a escala vem daqui)
      press(t, id = 'click', sound = 'click', { fundo = .86 } = {}) {
        const um = tt => tt < t - .06 || tt > t + .4 ? 1 : tt < t + .1 ? lerp(1, fundo, E.out(prog(tt, t - .06, t + .06))) : lerp(fundo, 1, E.out(prog(tt, t + .1, t + .4)));
        api.escala(um);
        if (sound) cue(t, sound, id);
      },
      // fator de escala extra, função pura do tempo (multiplica com os cliques)
      escala(f) {
        if (!api._press) { api._press = []; apply(tt => { m._s = api._press.reduce((v, g) => v * g(tt), 1); }, -1e9, 1e9, true); }
        api._press.push(f);
      },
      hide(t, d = .2) { tl.to(m, { opacity: 0, duration: d }, t); },
    };
    gsap.set(m, { transformOrigin: `${hot[0]}px ${hot[1]}px` });
    return api;
  }
  const ARROW = `<svg viewBox="0 0 32 32" width="100%" height="100%"><defs><filter id="ms" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="1.2" stdDeviation="1.2" flood-opacity=".35"/></filter></defs>
    <path filter="url(#ms)" d="M8.2 4.6 L8.2 26.2 L13.2 21.4 L16.6 29.2 L20.4 27.6 L17.1 20 L24 20 Z" fill="#111" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>`;
  const mouse = (parent, { size = 54, z = 800 } = {}) => ponteiro(parent, ARROW, [8.2 / 32 * size, 4.6 / 32 * size], { z, w: size, h: size });
  // dedo: um disco claro; a "ponta" é o centro
  const dedo = (parent, { size = 96, z = 40 } = {}) => ponteiro(parent, '', [size / 2, size / 2], { z, w: size, h: size, cls: 'dedo' });

  // onda de clique / toque
  function ripple(parent, x, y, t, { color = C.rgba(ACAO, .35), r = 70, dur = .7, rings = 2, z = 790 } = {}) {
    const disc = el(`<div class="ripple" style="left:${x - r}px;top:${y - r}px;width:${r * 2}px;height:${r * 2}px;background:${color};z-index:${z}"></div>`, parent);
    tl.fromTo(disc, { scale: .2, opacity: 0 }, { scale: 1, opacity: 1, duration: .14, ease: 'out', immediateRender: false }, t);
    tl.to(disc, { scale: 1.3, opacity: 0, duration: dur * .7, ease: 'out' }, t + .14);
    gsap.set(disc, { opacity: 0 });
    for (let k = 0; k < rings; k++) {
      const ring = el(`<div class="ripple" style="left:${x - r}px;top:${y - r}px;width:${r * 2}px;height:${r * 2}px;border:2px solid ${color.replace(/[\d.]+\)$/, '.6)')};z-index:${z}"></div>`, parent);
      gsap.set(ring, { opacity: 0 });
      tl.fromTo(ring, { scale: .5, opacity: .9 }, { scale: 2.4 + k * .8, opacity: 0, duration: dur + k * .15, ease: 'out', immediateRender: false }, t + .04 + k * .07);
    }
  }

  // ---------- borda de IA: gradiente cônico que gira ----------
  function glowRing(host, { width = 3, halo = .55, speed = 90, from = 0, to = 66, blur = 22, spread = 18, face = null } = {}) {
    const g = document.createElement('div'); g.className = 'glowring';
    g.innerHTML = `<div class="halo" style="inset:-${spread}px;filter:blur(${blur}px);opacity:${halo}"></div>${face ? `<div class="face" style="position:absolute;inset:0;border-radius:inherit;background:${face}"></div>` : ''}<div class="edge" style="padding:${width}px"></div>`;
    host.insertBefore(g, host.firstChild);
    apply(t => g.style.setProperty('--a', `${(t * speed) % 360}deg`), from, to);
    return g;
  }

  // ---------- números ----------
  const brl = v => NUM(v, 'brl');
  function count(node, a, b, t0, t1, fmt = v => Math.round(v).toLocaleString(CFG.idioma || 'pt-BR'), ease = E.out) {
    apply(t => { node.textContent = fmt(lerp(a, b, ease(prog(t, t0, t1)))); }, t0 - .5, t1 + .5, true);
  }

  // entrada padrão: sai do blur subindo poucos pixels
  function popIn(n, t, { dur = .5, y = 14, x = 0, s = .96, blur = 8, ease = 'out', o = 1 } = {}) {
    gsap.set(n, { opacity: 0 });
    tl.fromTo(n, { opacity: 0, y, x, scale: s, filter: `blur(${blur}px)` }, { opacity: o, y: 0, x: 0, scale: 1, filter: 'blur(0px)', duration: dur, ease, immediateRender: false }, t);
  }
  const popOut = (n, t, { dur = .3, y = -10, x = 0, blur = 8, s = 1 } = {}) => tl.to(n, { opacity: 0, y, x, scale: s, filter: `blur(${blur}px)`, duration: dur, ease: 'power2.in' }, t);

  // ---------- ícones ----------
  // nome de ícone lucide (kebab-case, engine/js/lucide.js) ou um dos desenhos próprios do filme; caminho de imagem → <img>
  const PROPRIOS = {
    'aviao': { fill: true, d: '<path d="M21 15.5v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V8.5l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/>' },
    'cama': { d: '<path d="M3 18V7M3 13h18v5M21 13a3 3 0 0 0-3-3h-7v3"/><circle cx="7" cy="10.5" r="1.8"/>' },
    'peixe': { d: '<path d="M3 12c3-4 7-5 11-3l4-3v12l-4-3c-4 2-8 1-11-3z"/><circle cx="8" cy="11" r=".9" fill="currentColor"/>' },
    'bonde': { d: '<rect x="6" y="6" width="12" height="12" rx="3"/><path d="M6 12h12M9 18l-2 3M15 18l2 3M10 3h4M12 3v3"/>' },
    'talheres': { d: '<path d="M7 3v8a2 2 0 0 0 4 0V3M9 11v10M17 3c-2 2-2 6 0 8v10"/>' },
    'pino': { d: '<path d="M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11z"/><circle cx="12" cy="10" r="2.2"/>' },
    'calendario': { d: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M9 3v4M15 3v4"/>' },
    'pessoas': { d: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.3"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5M14.5 15.2c.8-.5 1.6-.7 2.5-.7 2 0 3.6 1.4 4 4"/>' },
    'moeda': { d: '<circle cx="12" cy="12" r="8"/><path d="M14.5 9.5c-.5-.9-1.5-1.4-2.6-1.4-1.5 0-2.6.8-2.6 1.9 0 2.6 5.4 1.4 5.4 4 0 1.1-1.2 2-2.8 2-1.2 0-2.3-.5-2.8-1.4M12 6.5v1.6M12 16v1.6"/>' },
    'seta-cima': { d: '<path d="M12 19V5M5.5 11.5 12 5l6.5 6.5"/>' },
    'lupa': { d: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 L20 20"/>' },
    'abas': { d: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 9h18"/>' },
  };
  const avisos = new Set();
  function icon(name, size = 30, color = 'currentColor', sw = 2) {
    if (!name) return '';
    if (/[./]/.test(name)) return `<img src="${M(name)}" style="width:${size}px;height:${size}px;object-fit:contain;display:block">`;
    const p = PROPRIOS[name];
    if (p) return p.fill ? `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="${color}" style="color:${color}">${p.d}</svg>`
      : `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" style="color:${color}">${p.d}</svg>`;
    const inner = (window.LUCIDE_ALL || {})[name];
    if (!inner) { if (!avisos.has(name)) { avisos.add(name); console.warn(`ícone "${name}" não existe (lucide ou próprio): usei "circle"`); } }
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" style="color:${color}">${inner || '<circle cx="12" cy="12" r="8"/>'}</svg>`;
  }

  return { INK, ACAO, VIOLET, BLUE, PINK, CORAL, GRAD, grain, textW, fit, wrap, caret, blink, typeLine, erase, word3d, alvo, ponteiro, mouse, dedo, ripple, glowRing, brl, count, popIn, popOut, icon };
})();
