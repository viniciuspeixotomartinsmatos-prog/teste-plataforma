# Créditos e licenças

- **Trilha** (`audio/trilha/your-call.mp3`): "Your Call", Kevin MacLeod (incompetech.com), licença Creative Commons Attribution 4.0 (https://creativecommons.org/licenses/by/4.0/). Uso comercial e sincronização com vídeo liberados **com crédito obrigatório**. O filme usa a faixa editada (cortada nos compassos, filtrada em trechos, mixada com efeitos e com um acorde final sintetizado). Ao postar, ponha na legenda, na descrição ou nos créditos:

  > "Your Call" Kevin MacLeod (incompetech.com)
  > Licensed under Creative Commons: By Attribution 4.0 License
  > http://creativecommons.org/licenses/by/4.0/
  > Editada do original (cortada e mixada com efeitos sonoros).

  Sem crédito: gere o filme com `--sem-musica` e use uma música da biblioteca do Instagram ou do TikTok.
- **Acorde final e efeitos sonoros**: sintetizados em código (`tools/trilha.py`, `tools/sfx.py`), sem amostras de terceiros. Livres.
- **Fotos da demonstração** (`midia/demo/`): domínio público (CC0 ou Public Domain Mark), origens em `midia/demo/CREDITOS-FOTOS.md`. Servem para ver a demonstração funcionando; no filme da sua marca, use as suas.
- **Fontes**: DM Sans (SIL Open Font License), no motor; Inter (SIL Open Font License), no exemplo da clínica.
- **Ícones**: lucide (ISC).
- **Bibliotecas**: GSAP e CustomEase (licença padrão sem custo da GreenSock/Webflow, que permite uso comercial), Playwright (Apache 2.0), ffmpeg pelo pacote @ffmpeg-installer (LGPL), numpy, scipy, soundfile, pyloudnorm, Pillow.
- **Demonstração**: o pronto e a Agendu (o exemplo da clínica) são marcas fictícias.
