// Bloco "pedido" (17–23 s, obrigatório): a pílula do logo vira a barra do produto; a mídia anexada entra (opcional) e a
// barra abre numa caixa; o pedido é digitado com a câmera seguindo o cursor de texto; close no botão de enviar; o
// cursor do mouse chega no botão (medido no quadro, com a câmera 3D) e clica; a onda escura sai do clique.
// O gêmeo escuro da caixa (cena s8) também nasce aqui: é o mundo que a onda revela (o bloco "trabalhando" continua nele).
window.BLOCO_pedido = () => {
  const { tl, el, scene, apply, cue, clamp, lerp, prog, E } = F;
  F.bloco('pedido');
  const cfg = CENA('pedido') || {};
  const anexo = cfg.anexo || null;
  const PILL = X.BAR || { x: 400, y: 476, w: 1120, h: 128 };
  const BOX = { x: 360, y: 330, w: 1200, h: 420 };
  const textTop = anexo ? 214 : 52;
  // o texto do pedido: linhas do config (lista) ou quebradas pela largura; até 2 linhas com anexo, 3 sem
  const maxLines = anexo ? 2 : 3;
  let LINES, SIZE = 46;
  if (Array.isArray(cfg.texto) && cfg.texto.every(l => K.textW(l, 46, 500, -.012) <= 1112) && cfg.texto.length <= maxLines) LINES = cfg.texto;
  else { const w = K.wrap([].concat(cfg.texto || '').join(' '), { size: 46, weight: 500, tracking: -.012, maxW: 1100, maxLines, min: 30 }); LINES = w.lines; SIZE = w.size; }
  const PITCH = Math.round(SIZE * 64 / 46);
  const DEST = cfg.destaques || [];

  function makeBox(parent, dark) {
    const fg = dark ? '#ecebf5' : C.ink, bg = dark ? '#121219' : '#ffffff', sub = dark ? '#8d8c9c' : '#8b8b93';
    const box = el(`<div class="abs" style="left:${PILL.x}px;top:${PILL.y}px;width:${PILL.w}px;height:${PILL.h}px;border-radius:64px"></div>`, parent);
    el(`<div class="full" style="border-radius:inherit;box-shadow:${dark ? `0 30px 80px -30px ${C.rgba(C.acao, .55)}` : '0 30px 70px -34px rgba(17,17,20,.35), 0 2px 10px rgba(17,17,20,.05)'}"></div>`, box);
    K.glowRing(box, { width: dark ? 2 : 3, halo: dark ? .75 : .5, speed: 110, blur: dark ? 34 : 26, spread: dark ? 22 : 16, face: bg });
    const thumb = el(`<div class="abs" style="left:44px;top:40px;width:150px;height:150px;border-radius:24px;${anexo ? `background:url(${M(anexo)}) ${cfg.anexoFoco || '46% 50%'}/cover;` : 'display:none;'}
      box-shadow:0 10px 24px -12px rgba(0,0,0,.45)"><div class="abs" style="right:-10px;top:-10px;width:34px;height:34px;border-radius:50%;background:${dark ? '#2a2a36' : '#fff'};
      box-shadow:0 2px 8px rgba(0,0,0,.2);display:grid;place-items:center;font:600 18px var(--font);color:${sub}">×</div></div>`, box);
    const text = el(`<div class="abs" style="left:44px;top:${textTop}px;width:1112px;height:${PITCH * 3}px;color:${fg}"></div>`, box);
    const plus = el(`<div class="abs" style="left:36px;top:${PILL.h / 2 - 34}px;width:68px;height:68px;border-radius:50%;background:${dark ? '#1f1f2a' : '#f1f1ee'};display:grid;place-items:center">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke-width="2.6" stroke-linecap="round"><path class="pl" d="M12 5v14M5 12h14" stroke="${C.acao}"/></svg></div>`, box);
    const ph = el(`<div class="abs ui ell" style="left:128px;top:${PILL.h / 2 - 20}px;font-size:34px;font-weight:400;color:${sub};max-width:${PILL.w - 330}px">${H(cfg.placeholder || '')}</div>`, box);
    const mic = el(`<svg class="abs" style="left:${PILL.w - 178}px;top:${PILL.h / 2 - 20}px" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="${sub}" stroke-width="2" stroke-linecap="round">
      <rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/></svg>`, box);
    const send = el(`<div class="abs enviar" style="left:${PILL.w - 112}px;top:${PILL.h / 2 - 36}px;width:72px;height:72px;border-radius:50%;
      background:linear-gradient(135deg,${C.acaoLuz},${C.acaoForte});display:grid;place-items:center;box-shadow:0 10px 26px -8px ${C.rgba(C.acao, .7)}">
      ${K.icon(cfg.iconeEnviar || 'seta-cima', 34, '#fff', 2.6)}</div>`, box);
    return { box, thumb, text, plus, ph, mic, send };
  }

  const s7 = scene('s7', 17.15, 23.05, 14);
  const s8 = X.s8 = scene('s8', 22.45, 29.0, 16);
  const mkWorld = parent => { const w = el(`<div class="full" style="perspective:1700px;perspective-origin:960px 540px"></div>`, parent);
    const c = el(`<div class="full" style="transform-style:preserve-3d;transform-origin:960px 540px"></div>`, w); return { w, c }; };
  el(`<div class="full" style="background:${C.night}"></div>`, s8);
  el(`<div class="full" style="background:radial-gradient(40% 50% at 18% 85%,${C.rgba(C.grad[1], .38)},transparent 70%),radial-gradient(38% 45% at 85% 12%,${C.rgba(C.grad[0], .28)},transparent 70%),radial-gradient(30% 30% at 70% 80%,${C.rgba(C.grad[2], .14)},transparent 70%)"></div>`, s8);
  X.dotsBg = el(`<div class="full" style="background-image:radial-gradient(rgba(255,255,255,.085) 1.2px,transparent 1.7px);background-size:30px 30px;opacity:.9"></div>`, s8);
  const Wl = mkWorld(s7), Wd = X.Wd = mkWorld(s8);
  const Lb = makeBox(Wl.c, false), D = makeBox(Wd.c, true);
  const cams = X.cams = [Wl.c, Wd.c];
  // a câmera: rotação, escala e y pela linha do tempo; x por uma função do tempo (segue o cursor de texto)
  const cam = (t, vars, dur, ease = 'inout') => tl.to(cams, { ...vars, duration: dur, ease }, t);
  gsap.set(cams, { x: 0, y: 0, z: 0, rotationX: 0, rotationY: 0, rotationZ: 0, scale: 1 });

  if (X.ring2) tl.set(X.ring2, { opacity: 0 }, 17.3);
  K.popIn(Lb.ph, 17.2, { dur: .4, y: 0, blur: 6 });
  K.popIn(Lb.plus, 17.2, { dur: .4, y: 0, s: .8 });
  K.popIn(Lb.mic, 17.25, { dur: .4, y: 0 });
  K.popIn(Lb.send, 17.28, { dur: .4, y: 0, s: .8 });
  gsap.set(Lb.thumb, { opacity: 0 }); gsap.set(D.ph, { opacity: 0 });
  const plC = Lb.plus.querySelector('.pl');
  [[17.3, C.grad[0]], [17.5, C.grad[2]], [17.7, C.grad[3]], [17.9, C.acao]].forEach(([t, c]) => tl.set(plC, { attr: { stroke: c } }, t));
  const tOpen = 17.62;
  tl.to(Lb.box, { left: BOX.x, top: BOX.y, width: BOX.w, height: BOX.h, borderRadius: 48, duration: .55, ease: 'expo' }, tOpen);
  tl.to(Lb.ph, { opacity: 0, duration: .15 }, tOpen);
  tl.to(Lb.plus, { top: BOX.h - 92, duration: .55, ease: 'expo' }, tOpen);
  tl.to(Lb.mic, { left: BOX.w - 178, top: BOX.h - 78, duration: .55, ease: 'expo' }, tOpen);
  tl.to(Lb.send, { left: BOX.w - 112, top: BOX.h - 94, duration: .55, ease: 'expo' }, tOpen);
  if (anexo) {
    tl.fromTo(Lb.thumb, { opacity: 0, x: -260, y: 220, rotation: -14, scale: .55 }, { opacity: 1, x: 0, y: 0, rotation: 0, scale: 1, duration: .6, ease: 'expo', immediateRender: false }, tOpen + .04);
    cue(tOpen + .18, 'attach', 's7:photo');
  }
  gsap.set(D.box, { left: BOX.x, top: BOX.y, width: BOX.w, height: BOX.h, borderRadius: 48 });
  gsap.set(D.plus, { top: BOX.h - 92 }); gsap.set(D.mic, { left: BOX.w - 178, top: BOX.h - 78 }); gsap.set(D.send, { left: BOX.w - 112, top: BOX.h - 94 });

  // digitação, uma linha depois da outra, terminando até 20,72 s
  const nch = LINES.reduce((a, l) => a + [...l].length, 0);
  const avail = 20.72 - 18.02 - .12 * (LINES.length - 1);
  const k = Math.max(1, nch / 28.2 / avail);
  const T = []; let t0 = 18.02;
  LINES.forEach((ln, i) => {
    const Ti = K.typeLine(Lb.text, ln, { t0, cps: (i ? 27 : 29) * k, size: SIZE, weight: 500, x: 0, y: Math.round(26 * SIZE / 46) + i * PITCH, align: 'left', recenter: false, id: `s7:l${i + 1}`,
      caretH: Math.round(54 * SIZE / 46), caretW: 4, tracking: -.012, soundEvery: 3 });
    T.push(Ti); t0 = Ti.end + .12;
  });
  gsap.set(T.map(x => x.caret), { opacity: 0 });
  tl.set(T[0].caret, { opacity: 1 }, 18.0);
  for (let i = 1; i < T.length; i++) { tl.set(T[i - 1].caret, { opacity: 0 }, T[i].ts[0]); tl.set(T[i].caret, { opacity: 1 }, T[i].ts[0]); }
  const TL_ = T[T.length - 1];
  K.blink(TL_.caret, TL_.end + .05, 21.2, { period: .5, on: .25 });
  tl.set(TL_.caret, { opacity: 0 }, 21.2);
  // gêmeo escuro: o texto final, com as palavras-chave em destaque (spans)
  const KC = [C.grad[0], C.grad[1], C.grad[2], C.grad[3], C.mix(C.grad[1], '#ffffff', .25)];
  const usados = new Set();
  const mark = s => { let h = H(s); DEST.forEach((w, i) => { const hw = H(w); if (!usados.has(i) && h.includes(hw)) { usados.add(i); h = h.replace(hw, `<span class="kp" data-i="${i}">${hw}</span>`); } }); return h; };
  D.text.innerHTML = `<div style="font-size:${SIZE}px;font-weight:500;letter-spacing:-.012em;line-height:${PITCH}px;white-space:pre;margin-top:${-Math.round(6 * SIZE / 46)}px">${LINES.map(mark).join('\n')}</div>`;
  X.kps = F.qa('.kp', D.text).sort((a, b) => a.dataset.i - b.dataset.i); X.KC = KC;

  // ---- câmera ----
  // x(t) é uma função pura do tempo (antes, o "seguir o cursor" escrevia x e as transições seguintes partiam de onde
  // o quadro anterior tinha deixado: o resultado dependia da ordem do render). O seguir usa a posição contínua do cursor
  // de texto (interpolada entre as letras), sem degraus.
  const caretPx = (Ti, t) => { const i = Ti.ts.findIndex(x => x > t); if (i === 0) return 0; if (i < 0) return Ti.ends[Ti.ends.length - 1];
    const a = Ti.ends[i - 2] ?? 0, b = Ti.ends[i - 1]; return lerp(a, b, E.out(prog(t, Ti.ts[i - 1], Ti.ts[i - 1] + .07))); };
  const yOff = (214 - textTop) * 1.25;
  const segs = []; // [t0, t1, fn(t)]
  segs.push([17.35, 18.25, t => lerp(0, 300, E.inout(prog(t, 17.35, 18.25)))]);
  const follows = T.map((Ti, i) => {
    const W = Ti.ends[Ti.ends.length - 1];
    const x0 = i ? 260 : 300, px0 = i ? 300 : 380, kk = i ? .76 : 1.13;
    const px1 = Math.max(px0 + 1, W);
    const a = i ? Ti.ts[0] + .36 : 18.26, b = Ti.end + .02;
    const f = t => lerp(x0, x0 - kk * (px1 - px0), E.sine(clamp((caretPx(Ti, t) - px0) / (px1 - px0))));
    return { a, b, f, x0 };
  });
  follows.forEach((fo, i) => {
    segs.push([fo.a, fo.b, fo.f]);
    const nx = follows[i + 1];
    const xe = fo.f(fo.b);
    if (nx) {
      const tt = T[i].end + .04;
      segs.push([tt, tt + .32, t => lerp(xe, nx.x0, E.inout(prog(t, tt, tt + .32)))]);
      cam(tt, { y: 40 - 80 * (i + 1) + yOff }, .32, 'inout');
    } else segs.push([20.78, 21.40, t => lerp(xe, 0, E.inout(prog(t, 20.78, 21.40)))]);
  });
  segs.push([21.45, 22.15, t => lerp(0, -1180, E.inout(prog(t, 21.45, 22.15)))]);
  segs.push([22.15, 22.75, t => lerp(-1180, -1235, E.p1io(prog(t, 22.15, 22.75)))]);
  segs.push([23.0, 23.7, t => lerp(-1235, 0, E.inout(prog(t, 23.0, 23.7)))]);
  segs.sort((p, q) => p[0] - q[0]);
  const camX = t => { let v = 0; for (const [a, b, f] of segs) { if (t < a) break; v = f(Math.min(t, b)); } return v; };
  X.camX = camX;
  apply(t => { const v = camX(t); cams.forEach(c => gsap.set(c, { x: v })); }, 17.0, 29.0, true);
  cam(17.35, { rotationY: -15, rotationX: 11, scale: 1.3, y: 40 + yOff }, .9, 'inout');
  cam(20.78, { rotationY: -6, rotationX: 7, scale: .96, y: 10 }, .62, 'inout');
  cue(20.95, 'swoosh_short', 's7:pull');
  cam(21.45, { rotationY: -24, rotationX: 15, rotationZ: -2, scale: 2.55, y: -330 }, .7, 'inout');
  cue(21.7, 'swoosh_long', 's7:push');
  cam(22.15, { scale: 2.68, y: -350 }, .6, 'power1.inOut');

  // ---- o cursor do mouse clica no enviar ----
  // a ponta mira o centro do botão medido no quadro (o botão anda com a câmera 3D); chega em 22,36 s, para, clica
  // em 22,5 s e fica colado no botão até sumir
  const alvoEnviar = K.alvo(Lb.send, .5, .5);
  const ms = K.mouse(s7, { size: 118 });
  ms.caminho([{ t: 21.82, p: [1700, 1040] }, { t: 22.36, p: alvoEnviar, bow: .08 }, { t: 23.2, p: alvoEnviar }]);
  ms.mostra(21.82, .08);
  ms.press(22.5, 's7:send', 'click_fav');
  tl.to(Lb.send, { scale: .9, duration: .08, ease: 'none' }, 22.46); tl.to(Lb.send, { scale: 1, duration: .3 }, 22.56);
  ms.hide(22.75, .15);

  // ---- 22,5: a onda escura sai do clique (o centro do botão, medido) ----
  const edgeRing = el(`<div class="abs" style="left:0;top:0;width:10px;height:10px;border-radius:50%;z-index:17;pointer-events:none;opacity:0;
    box-shadow:0 0 60px 18px ${C.rgba(C.mix(C.grad[1], '#ffffff', .2), .55)}, inset 0 0 50px 10px ${C.rgba(C.grad[2], .35)}"></div>`, F.stage);
  X.edgeRing = edgeRing;
  F.applyLate(t => {
    const [wx, wy] = alvoEnviar(); const p = E.inout(prog(t, 22.5, 23.02)); const r = p * 2300;
    s8.style.clipPath = p >= 1 ? 'none' : `circle(${r}px at ${wx}px ${wy}px)`;
    const rr = Math.max(1, r);
    edgeRing.style.opacity = (p > 0 && p < 1) ? String(1 - p * .6) : '0';
    edgeRing.style.transform = `translate(${wx - rr}px, ${wy - rr}px)`; edgeRing.style.width = edgeRing.style.height = `${2 * rr}px`;
  }, 22.45, 23.1, true);
  cue(22.52, 'dark_thunk', 's8:wave'); cue(22.6, 'whoosh_airy', 's8:wave:air');
  X.alvoEnviar = alvoEnviar;
};
