"""trilha.py <filme> [outra.mp3] — corta a trilha na linha do tempo do filme (out/<filme>/linha.json → out/<filme>/trilha.wav).

A trilha do pacote é "Your Call" (Kevin MacLeod, incompetech.com, CC BY 4.0: o crédito é obrigatório, ver CREDITS.md),
120 BPM, em dó. O filme também é a 120 BPM: os tempos fortes caem nos segundos ímpares e toda fronteira de bloco cai
num deles, então a música é cortada sempre no compasso. O corte, por bloco (no tempo do roteiro completo):
  abertura    silêncio até 2,925 s; o começo da faixa, abafado (filtro passa-baixa que vai abrindo); para seco em 5,0
  problema    silêncio na digitação (5–6,9); dois compassos da quebra do baixo (a faixa em 1:56–2:00), filtrados; para em 11,0
  virada      silêncio na pergunta; o DROP: a faixa volta cheia em 2:00 no quadro do drop (13,0)
  pedido…     a faixa segue sem emenda pelos blocos seguintes, só abafada no "trabalhando" (o mundo escuro)
  fecho       a faixa para no tempo forte do logo (61,0) e um acorde de dó sintetizado esvazia até o silêncio
Sem um bloco opcional, a música dos outros não muda: o trecho dele simplesmente não entra.
Outra faixa a 120 BPM serve com --drop <s> (o tempo forte da faixa que cai no drop) e --fase <s> (o primeiro tempo forte).
"""
import json, os, sys, shutil, platform, subprocess
import numpy as np, soundfile as sf, pyloudnorm as pyln

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 48000
nome = sys.argv[1]
args = sys.argv[2:]
opt = lambda k, d: float(args[args.index('--' + k) + 1]) if '--' + k in args else d
src_path = next((a for a in args if a.endswith(('.mp3', '.wav', '.m4a'))), os.path.join(RAIZ, 'audio/trilha/your-call.mp3'))
L = json.load(open(os.path.join(RAIZ, 'out', nome, 'linha.json')))
total_t = L['duracao']
B = {b['tipo']: b for b in L['blocos']}

plat = {'darwin': 'darwin', 'linux': 'linux', 'win32': 'win32'}.get(sys.platform, sys.platform) + '-' + \
    {'arm64': 'arm64', 'aarch64': 'arm64', 'x86_64': 'x64', 'AMD64': 'x64'}.get(platform.machine(), 'x64')
ff = os.path.join(RAIZ, 'node_modules/@ffmpeg-installer', plat, 'ffmpeg.exe' if sys.platform == 'win32' else 'ffmpeg')
if not os.path.exists(ff): ff = shutil.which('ffmpeg') or 'ffmpeg'
raw = subprocess.run([ff, '-v', 'error', '-i', src_path, '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
src = np.frombuffer(raw, np.float32).reshape(-1, 2).astype(np.float64)

FASE = opt('fase', 0.01)          # primeiro tempo forte da faixa (Your Call: 0,01 s)
DROP = opt('drop', 120.01)        # o tempo forte da faixa que cai no drop do filme (Your Call: 2:00, depois da quebra do baixo)
N = int(round((total_t + 0.05) * SR))
music = np.zeros((N, 2))


def nt(tipo, t):
    """tempo do roteiro completo → tempo do filme"""
    b = B[tipo]; return b['A'] + (t - b['a'])


def filtro_lp(x, fc0, fc1, hp=0.0):
    """passa-baixa com corte variando no tempo (blocos FFT com sobreposição), passa-alta opcional"""
    n = len(x); blk, hop = 4096, 1024; win = np.hanning(blk)
    out = np.zeros((n + blk, 2)); ws = np.zeros(n + blk); fq = np.fft.rfftfreq(blk, 1 / SR)
    xp = np.vstack([x, np.zeros((blk, 2))])
    for s in range(0, n, hop):
        u = min(1.0, s / max(1, n)); fc = fc0 * (fc1 / fc0) ** u
        H = 1 / np.sqrt(1 + (fq / fc) ** 8)
        if hp: H = H * (1 / np.sqrt(1 + (hp / np.maximum(fq, 1)) ** 4))
        for c in range(2):
            out[s:s + blk, c] += np.fft.irfft(np.fft.rfft(xp[s:s + blk, c] * win) * H) * win
        ws[s:s + blk] += win ** 2
    return out[:n] / np.maximum(ws[:n], 1e-3)[:, None]


def trecho(t0, t1, s0, gain_db=0.0, fade_in=0.008, fade_out=0.012, lp=None):
    """copia a faixa a partir de s0 (s) para o filme em [t0, t1) (s), com rampas curtas nas pontas"""
    i0, i1 = max(0, int(round(t0 * SR))), min(N, int(round(t1 * SR)))
    if i1 <= i0: return
    j0 = int(round(s0 * SR)) + (i0 - int(round(t0 * SR)))
    idx = np.arange(j0, j0 + (i1 - i0))
    while (idx >= len(src)).any(): idx = np.where(idx >= len(src), idx - int(64 * SR), idx)   # a faixa acabou: volta 32 compassos
    seg = src[np.clip(idx, 0, len(src) - 1)].copy()
    if lp: seg = filtro_lp(seg, *lp)
    w = np.ones(len(seg))
    a = min(len(w), int(fade_in * SR)); w[:a] *= np.sin(0.5 * np.pi * (np.arange(a) + .5) / max(1, a))
    b = min(len(w), int(fade_out * SR)); w[len(w) - b:] *= np.cos(0.5 * np.pi * (np.arange(b) + .5) / max(1, b))
    music[i0:i1] += seg * w[:, None] * 10 ** (gain_db / 20)


s_de = lambda t: FASE + (t - 1.0) % 2.0  # posição na faixa com a mesma fase de compasso do filme (forte em 1, 3, 5…)
# abertura: o começo da faixa, abafado, abrindo devagar
trecho(nt('abertura', 2.925), nt('abertura', 5.0), s_de(2.925) + 2.0, -5.0, fade_in=0.35, fade_out=0.02, lp=(320, 1500))
# problema: a quebra do baixo, filtrada, crescendo até parar seco em 11,0
if 'problema' in B:
    trecho(nt('problema', 6.925), nt('problema', 11.0), DROP - (11.0 - 6.925), -3.0, fade_in=0.05, fade_out=0.01, lp=(700, 2800, 110))
# do drop em diante: a faixa segue contínua; o "trabalhando" abafado
t_drop = nt('virada', 13.0)
t_fim = nt('fecho', 61.0)
cortes = [t_drop - 0.075]
if 'trabalhando' in B: cortes += [B['trabalhando']['A'], B['trabalhando']['B']]
cortes += [t_fim]
for k in range(len(cortes) - 1):
    a, b = cortes[k], cortes[k + 1]
    escuro = 'trabalhando' in B and abs(a - B['trabalhando']['A']) < 1e-6
    trecho(a, b, DROP + (a - t_drop), 0.0, fade_in=0.008 if k == 0 else 0.004, fade_out=0.012 if b == t_fim else 0.004, lp=(520, 650, 40) if escuro else None)

# o acorde final (dó), que esvazia em ~3,7 s
NOTAS = [65.41, 130.81, 196.00, 261.63, 392.00]
ENV = [(0, -80), (0.008, 0), (0.8, -3), (1.4, -9), (2.2, -17), (3.0, -28), (3.6, -45), (3.85, -120)]


def acorde(i0):
    rng = np.random.default_rng(7)
    n = min(N - i0, int(3.9 * SR))
    out = np.zeros((N, 2))
    if n <= 0: return out
    tt = np.arange(n) / SR
    for ch, det in enumerate((-1, 1)):
        y = 0.9 * np.sin(2 * np.pi * NOTAS[0] * tt)
        for kk, f in enumerate(NOTAS[1:]):
            for c in (-7, 0, 7):
                fr = f * 2 ** ((c + det * 3) / 1200)
                y += (2 * ((fr * tt + rng.uniform(0, 1)) % 1.0) - 1) * (0.28 / (1 + 0.5 * kk)) / 3
        blk, hop = 4096, 1024; win = np.hanning(blk); acc = np.zeros(n + blk); ws = np.zeros_like(acc)
        yp = np.concatenate([y, np.zeros(blk)]); fq = np.fft.rfftfreq(blk, 1 / SR)
        for s in range(0, n, hop):
            fc = 1100 * (240 / 1100) ** min(1.0, s / SR / 2.6)
            X = np.fft.rfft(yp[s:s + blk] * win) / np.sqrt(1 + (fq / fc) ** 4)
            acc[s:s + blk] += np.fft.irfft(X) * win; ws[s:s + blk] += win ** 2
        y = acc[:n] / np.maximum(ws[:n], 1e-3)
        y *= 1 + 0.06 * np.sin(2 * np.pi * 4.5 * tt + ch)
        y *= 10 ** (np.interp(tt, [e[0] for e in ENV], [e[1] for e in ENV]) / 20)
        out[i0:i0 + n, ch] = y
    return out / (np.abs(out).max() + 1e-12)


i_fim = int(round(t_fim * SR))
ch = acorde(i_fim)
meter = pyln.Meter(SR, block_size=0.4)
g0, g1 = t_drop + 0.2, t_fim - 0.2
alvo = meter.integrated_loudness(music[int(g0 * SR):int(g1 * SR)]) - 1.0
cur = meter.integrated_loudness(ch[i_fim + int(0.03 * SR):i_fim + int(0.78 * SR)])
music += ch * 10 ** ((alvo - cur) / 20)
music *= 10 ** (-3 / 20) / (np.abs(music).max() + 1e-12)
music = music[:int(round(total_t * SR))]
dst = os.path.join(RAIZ, 'out', nome, 'trilha.wav')
sf.write(dst, music.astype(np.float32), SR, subtype='FLOAT')
print(f"trilha → out/{nome}/trilha.wav  {len(music)/SR:.2f} s; drop em {t_drop:.2f} s; acorde final em {t_fim:.2f} s")
