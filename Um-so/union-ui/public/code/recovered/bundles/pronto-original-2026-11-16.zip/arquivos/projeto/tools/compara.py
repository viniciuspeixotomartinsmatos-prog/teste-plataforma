"""compara.py <pasta com 00000.png…> <referencia.mp4> <saida.jpg> <ffmpeg> — pares lado a lado: referência | render, mesmo quadro."""
import sys, os, subprocess
from PIL import Image, ImageDraw, ImageFont
d, mp4, out, ff = sys.argv[1:5]
fs = sorted(f for f in os.listdir(d) if f.endswith(('.jpg', '.png')))
w, h, pad, cols = 400, 225, 4, 3
try: font = ImageFont.truetype('DejaVuSans.ttf', 13)
except Exception:
    try: font = ImageFont.truetype('/System/Library/Fonts/Menlo.ttc', 13)
    except Exception: font = ImageFont.load_default()
rows = (len(fs) + cols - 1) // cols
S = Image.new('RGB', (cols * (2 * w + pad * 3), rows * (h + pad) + pad), (30, 30, 30)); dr = ImageDraw.Draw(S)
for k, f in enumerate(fs):
    q = int(os.path.splitext(f)[0]); a = max(0, q - 30)
    raw = subprocess.run([ff, '-v', 'error', '-ss', f'{a / 30:.4f}', '-i', mp4, '-frames:v', '1', '-vf', f"select='gte(n\\,{q - a})',scale={w}:{h}",
                          '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], capture_output=True).stdout
    o = Image.frombytes('RGB', (w, h), raw[:w * h * 3]) if len(raw) >= w * h * 3 else Image.new('RGB', (w, h))
    n = Image.open(os.path.join(d, f)).convert('RGB').resize((w, h), Image.LANCZOS)
    x, y = pad + (k % cols) * (2 * w + pad * 3), pad + (k // cols) * (h + pad)
    S.paste(o, (x, y)); S.paste(n, (x + w + pad, y))
    lab = f'q{q} {q / 30:.2f}s  referência | render'
    dr.rectangle([x, y, x + 8 + 8 * len(lab), y + 17], fill=(0, 0, 0)); dr.text((x + 4, y + 2), lab, fill=(255, 220, 0), font=font)
S.save(out, quality=85); print(out, S.size, len(fs), 'pares')
