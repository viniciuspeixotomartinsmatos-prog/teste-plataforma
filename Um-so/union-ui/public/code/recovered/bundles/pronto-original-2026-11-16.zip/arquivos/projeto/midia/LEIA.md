# Mídia

Uma pasta por filme (`midia/<nome>/`), com o caminho a partir da raiz do projeto no config (`"midia/<nome>/foto.jpg"`).

- `demo/`: as fotos da demonstração (domínio público, origens em `CREDITOS-FOTOS.md`).
- `exemplo-clinica/`: o símbolo e a fonte do exemplo curto (`filmes/exemplo-clinica.json`).

O que vai na pasta do seu filme: o símbolo (`simbolo.svg`, sem retângulo de fundo), a fonte (`.woff2`, gratuita) e as
fotos (JPG de até ~1600 px). Tamanhos e cortes de cada foto: guia, seção Mídia.
