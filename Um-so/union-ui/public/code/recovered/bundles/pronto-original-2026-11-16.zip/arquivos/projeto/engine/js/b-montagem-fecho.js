// Bloco "montagem" (49–57 s, opcional): outros usos do produto em cortes no tempo da música (0,5 s até 53 s, depois
// 0,25 s), com as palavras numa pílula de vidro; a câmera recua e mostra a parede de respostas.
// Bloco "fecho" (57–65 s, obrigatório): a frase final digitada; a linha se apaga; o cursor digita a palavra que vira o
// logo no acorde final; slogan e chamada.
window.BLOCO_montagem = () => {
  const { tl, el, scene, cue, rng } = F;
  if (!F.bloco('montagem')) return;
  const cfg = CENA('montagem') || {};
  const s12 = scene('s12', 48.95, 57.02, 24);
  el(`<div class="paper"></div>`, s12);
  const chip = (t, primary = true) => t ? `<span style="display:inline-flex;align-items:center;height:56px;padding:0 26px;border-radius:999px;font-size:24px;font-weight:600;white-space:nowrap;
    ${primary ? `background:${C.acao};color:#fff` : `background:${C.acaoClaro2};color:${C.acao}`}">${H(t)}</span>` : '';
  const q = s => `<div style="position:absolute;left:44px;right:44px;top:36px;height:84px;border-radius:999px;background:#f6f6f4;display:flex;align-items:center;gap:18px;padding:0 30px;font-size:${K.fit(s, { size: 30, weight: 400, maxW: 1340, min: 20 })}px;color:#3d3d45">
    ${B.mark(26)}<span style="white-space:nowrap">${H(s)}</span></div>`;
  const row = (a, b, hi) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:16px;height:66px;border-bottom:1px solid #efefec;font-size:26px">
    <span class="ell">${H(a)}</span><span style="font-weight:600;white-space:nowrap;${hi ? `color:${C.acao}` : ''}">${H(b)}</span></div>`;
  const CARDS = (cfg.cartoes || []).slice(0, 8);
  const mkCard = C_ => {
    const wrap = el(`<div class="full" style="perspective:2200px;perspective-origin:960px 540px;opacity:0"></div>`, s12);
    const card = el(`<div class="abs card" style="left:${960 - 760}px;top:${540 - 430}px;width:1520px;height:860px;border-radius:48px;overflow:hidden"></div>`, wrap);
    let inner = q(C_.pergunta || '');
    const body = (C_.linhas || []).slice(0, 3).map(([a, b, hi]) => row(a, b, hi)).join('');
    const box = 'position:absolute;left:44px;top:156px;width:700px;height:660px;border-radius:32px;';
    const tipo = C_.foto ? 'foto' : C_.tipo || (C_.numero ? 'numero' : C_.barras ? 'barras' : C_.horarios ? 'horarios' : 'cor');
    const leftHTML = tipo === 'foto' ? `<div style="${box}background:url(${M(C_.foto)}) ${C_.foco || 'center'}/cover"></div>`
      : tipo === 'numero' ? `<div style="${box}background:linear-gradient(160deg,${C.acaoClaro2},${C.mix(C.grad[2], '#ffffff', .88)});display:flex;flex-direction:column;justify-content:center;padding:0 56px">
          <div style="font-size:${K.fit(C_.numero.grande || '', { size: 96, weight: 700, tracking: -.04, maxW: 588, min: 48 })}px;font-weight:700;letter-spacing:-.04em;color:${C.acao};white-space:nowrap">${H(C_.numero.grande || '')}</div><div style="font-size:32px;margin-top:6px">${H(C_.numero.texto || '')}</div></div>`
      : tipo === 'barras' ? `<div style="${box}background:#f8f8f6;padding:70px 56px">${C_.barras.map(([v, a, b, hi]) => `<div style="font-size:24px;display:flex;justify-content:space-between;margin-top:34px"><span>${H(a)}</span><b style="${hi ? `color:${C.acao}` : ''}">${H(b)}</b></div>
          <div style="height:34px;border-radius:17px;margin-top:12px;width:${v * 100}%;background:${hi ? `linear-gradient(90deg,${C.grad[0]},${C.grad[1]},${C.grad[2]})` : '#e3e3df'}"></div>`).join('')}</div>`
      : tipo === 'horarios' ? `<div style="${box}background:#f8f8f6;display:grid;grid-template-columns:1fr 1fr;gap:22px;padding:70px 56px;align-content:center">
          ${C_.horarios.slice(0, 4).map((s, k) => `<div style="height:120px;border-radius:26px;display:grid;place-items:center;font-size:40px;font-weight:700;${k === (C_.escolhido ?? 1) ? `background:${C.acao};color:#fff` : 'background:#fff;box-shadow:inset 0 0 0 2px #ececea;color:#3d3d45'}">${H(s)}${k === (C_.escolhido ?? 1) ? ' ✓' : ''}</div>`).join('')}</div>`
      : `<div style="${box}background:linear-gradient(160deg,${C.acaoClaro2},${C.mix(C.grad[2], '#ffffff', .88)});display:grid;place-items:center">${K.icon(C_.icone || 'sparkles', 220, C.acao, 1.4)}</div>`;
    inner += leftHTML;
    inner += `<div style="position:absolute;left:790px;top:170px;right:56px">
      <div style="display:flex;align-items:center;gap:12px;font-size:21px;color:${C.acao};font-weight:600">${B.mark(20)}${H(cfg.rotulo || '')}</div>
      <div style="font-size:${K.wrap(C_.titulo || '', { size: 46, weight: 700, tracking: -.03, maxW: 670, maxLines: 2, min: 30 }).size}px;font-weight:700;letter-spacing:-.03em;line-height:1.08;margin:16px 0 26px">${H(C_.titulo || '')}</div>${body}
      <div style="margin-top:40px;display:flex;gap:14px">${chip(C_.botao)}${chip(cfg.botao2, false)}</div></div>`;
    card.innerHTML = inner;
    return { wrap, card };
  };
  const cards = CARDS.map(mkCard);
  const cuts = []; for (let t = 49.0; t < 53.0 - 1e-6; t += .5) cuts.push([t, .5]); for (let t = 53.0; t < 56.0 - 1e-6; t += .25) cuts.push([t, .25]);
  const rc = rng(512);
  cuts.forEach(([t, d], k) => {
    const C_ = cards[k % cards.length];
    const rx = (rc() - .5) * 16, ry = (rc() - .5) * 22, rz = (rc() - .5) * 5, s0 = 1.02 + rc() * .1;
    tl.set(C_.wrap, { opacity: 1, zIndex: 2 }, t); tl.set(C_.wrap, { opacity: 0 }, t + d);
    tl.fromTo(C_.card, { rotationX: rx, rotationY: ry, rotationZ: rz, scale: s0 }, { rotationX: rx * .7, rotationY: ry * .7, scale: s0 + .045, duration: d, ease: 'none', immediateRender: false }, t);
    cue(t, 'cut', `s12:cut:${k}`, { fast: d < .5 });
  });
  const wall = el(`<div class="full" style="opacity:0;z-index:3"></div>`, s12);
  const wallIn = el(`<div class="abs" style="left:0;top:0;width:1920px;height:1080px;transform-origin:960px 540px"></div>`, wall);
  const COLS = 4, ROWS = 3, cw = 1520 * .26, ch = 860 * .26, gx = 40, gy = 40;
  const totalW = COLS * cw + (COLS - 1) * gx, totalH = ROWS * ch + (ROWS - 1) * gy;
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
    const k = (r * COLS + c) % CARDS.length;
    const m = cards[k].card.cloneNode(true);
    m.style.left = `${960 - totalW / 2 + c * (cw + gx) - (1520 - cw) / 2}px`; m.style.top = `${540 - totalH / 2 + r * (ch + gy) - (860 - ch) / 2}px`;
    m.style.transform = 'scale(.26)'; wallIn.appendChild(m);
  }
  tl.set(wall, { opacity: 1 }, 56.0);
  tl.fromTo(wallIn, { scale: 3.9 }, { scale: 1, duration: .8, ease: 'expo', immediateRender: false }, 56.0);
  tl.to(wallIn, { scale: .94, duration: .2, ease: 'none' }, 56.8);
  cue(56.02, 'swoosh_long', 's12:wall');
  const plate = el(`<div class="abs pill" style="left:0;top:0;height:230px;z-index:10;background:rgba(255,255,255,.62);backdrop-filter:blur(26px) saturate(1.4);
    box-shadow:0 30px 80px -30px rgba(17,17,20,.35), inset 0 0 0 1.5px rgba(255,255,255,.8)"></div>`, s12);
  const WORDS = (cfg.palavras || []).slice(0, 4).map((w, i) => [49.0 + i * 2, w]);
  const wsz = Math.min(...WORDS.map(([, w]) => K.fit(w, { size: 150, weight: 700, tracking: -.045, maxW: 1560, min: 80 })), 150);
  const wEls = WORDS.map(([, w]) => el(`<div class="abs" style="left:0;top:0;font-size:${wsz}px;font-weight:700;letter-spacing:-.045em;line-height:1;z-index:11;white-space:nowrap;opacity:0">${H(w)}</div>`, s12));
  wEls.forEach((n, i) => {
    const [t] = WORDS[i], w = n.offsetWidth, h = n.offsetHeight;
    gsap.set(n, { x: 960 - w / 2, y: 540 - h / 2 - 8 });
    tl.fromTo(n, { opacity: 0, filter: 'blur(14px)', scale: .92 }, { opacity: 1, filter: 'blur(0px)', scale: 1, duration: .3, ease: 'expo', immediateRender: false }, t);
    tl.to(n, { opacity: 0, filter: 'blur(10px)', scale: 1.04, duration: .18, ease: 'power2.in' }, t + 1.82);
    const pw = w + 140;
    tl.to(plate, { width: pw, x: 960 - pw / 2, y: 540 - 115, duration: i ? .28 : .01, ease: 'expo' }, t - (i ? .1 : 0));
    cue(t, 'word', `s12:word:${i}`);
  });
  gsap.set(plate, { opacity: 0 });
  if (WORDS.length) {
    tl.fromTo(plate, { opacity: 0, scale: .9 }, { opacity: 1, scale: 1, duration: .3, ease: 'expo', immediateRender: false }, 49.0);
    tl.to(plate, { opacity: 0, scale: .96, duration: .2 }, Math.min(56.82, 49.0 + WORDS.length * 2 - .18));
  }
};

window.BLOCO_fecho = () => {
  const { tl, el, scene, apply, cue, prog, E } = F;
  F.bloco('fecho');
  const cfg = CENA('fecho') || {};
  const s13 = scene('s13', 57.0, 61.3, 26);
  el(`<div class="paper"></div>`, s13);
  const T = K.typeLine(s13, cfg.frase || '', { t0: 57.08, cps: 15, size: 112, x: 960, y: 540, id: 's13:type', caretH: 124, caretW: 7, maxW: 1640, tmax: 58.85 });
  K.blink(T.caret, T.end + .05, 59.0, { period: .5, on: .25 });
  const tE = K.erase(T, 59.0, { cps: Math.max(32, T.chars.length / .9), id: 's13:erase' });
  K.blink(T.caret, tE + .02, 60.0, { period: .5, on: .25 });
  tl.set(T.caret, { opacity: 0 }, 60.0);
  const palavra = cfg.palavra || B.nome;
  const P = K.typeLine(s13, palavra, { t0: 60.02, cps: 15.5, size: 112, x: 960, y: 520, id: 's13:palavra', caretH: 124, caretW: 7, maxW: 1640, tmax: 60.85 });
  gsap.set(P.caret, { opacity: 0 }); tl.set(P.caret, { opacity: 1 }, 60.0);
  K.blink(P.caret, P.end + .02, 61.0, { period: .5, on: .25 });
  tl.set(P.caret, { opacity: 0 }, 61.0);

  const s14 = scene('s14', 60.9, 66.01, 28);
  const tH = 61.0;
  cue(tH, 'final_hit', 's14:hit');
  tl.to(P.line, { scale: 2.0, opacity: 0, filter: 'blur(10px)', duration: .2, ease: 'power1.out', transformOrigin: '50% 50%' }, tH - .03);
  let root, ringCx, ringCy, ringR, gradEl = null, gradRot = null;
  if (B.modo === 'monolinha') {
    const lg = B.create(s14, { cx: 960, cy: 520, u: 1.35, z: 20 });
    gsap.set(lg.root, { opacity: 0 });
    lg.ring.style.strokeDashoffset = lg.RING_LEN;
    tl.fromTo(lg.root, { opacity: 0, scale: .5, filter: 'blur(10px)' }, { opacity: 1, scale: 1, filter: 'blur(0px)', duration: .5, ease: 'power3.out', immediateRender: false, transformOrigin: '50% 50%' }, tH - .03);
    apply(t => { const a = -160 * (1 - E.expo(prog(t, tH + .02, tH + .92))); lg.ring.setAttribute('transform', `rotate(${-90 + a} 50 50)`); }, tH - .2, tH + 1, true);
    tl.fromTo(lg.ring, { strokeDashoffset: lg.RING_LEN }, { strokeDashoffset: 0, duration: .75, ease: 'power3.out', immediateRender: false }, tH + .06);
    root = lg.root; ringCx = lg.geo.ringCx; ringCy = lg.geo.ringCy; ringR = lg.geo.ringR; gradEl = lg.grad;
    gradRot = t => `rotate(${(t - tH) * 18} 50 50)`;
  } else {
    const lk = B.lockup(s14, { cx: 960, cy: 520, h: 170, z: 20, maxW: 1560 });
    gsap.set(lk.root, { opacity: 0 });
    tl.fromTo(lk.root, { opacity: 0, scale: .5, filter: 'blur(10px)' }, { opacity: 1, scale: 1, filter: 'blur(0px)', duration: .5, ease: 'power3.out', immediateRender: false, transformOrigin: '50% 50%' }, tH - .03);
    const an = B.anel(s14, { cx: lk.geo.symCx, cy: 520, r: lk.geo.ringR, sw: 14, z: 21 });
    tl.fromTo(an.svg, { rotation: -160, opacity: 1 }, { rotation: 0, duration: .9, ease: 'expo', immediateRender: false, transformOrigin: '50% 50%' }, tH + .02);
    tl.fromTo(an.ring, { strokeDashoffset: an.L }, { strokeDashoffset: 0, duration: .75, ease: 'power3.out', immediateRender: false }, tH + .06);
    tl.to(an.svg, { opacity: 0, scale: 1.1, duration: .5, ease: 'power2.out' }, tH + .5);
    root = lk.root; ringCx = lk.geo.symCx; ringCy = 520; ringR = lk.geo.ringR;
  }
  cue(tH + .1, 'ring_in', 's14:ring');
  const burst = el(`<canvas class="abs" width="1000" height="1000" style="left:${ringCx - 500}px;top:${ringCy - 500}px;z-index:19"></canvas>`, s14);
  const bctx = burst.getContext('2d');
  const dots = Array.from({ length: 180 }, (_, i) => ({ a: i / 180 * Math.PI * 2, sp: .5 + (i * 37 % 13) / 13, s: 3 + (i * 17 % 5) }));
  apply(t => {
    const p = prog(t, tH + .45, tH + 1.35); bctx.clearRect(0, 0, 1000, 1000); if (p <= 0 || p >= 1) return;
    dots.forEach(d => { const rr = ringR + 24 + 300 * d.sp * E.out(p); const x = 500 + Math.cos(d.a) * rr, y = 500 + Math.sin(d.a) * rr;
      bctx.globalAlpha = (1 - p) * .8; bctx.fillStyle = C.grad[Math.floor(d.a / (Math.PI * 2) * 4) % 4]; const s = d.s * (1 - p * .6); bctx.fillRect(x - s / 2, y - s / 2, s, s); });
  }, tH + .4, tH + 1.4, true);
  cue(tH + .45, 'pixels', 's14:pixels');
  if (gradEl) apply(t => { gradEl.setAttribute('gradientTransform', gradRot(t)); }, tH, 66, true);
  const slogan = cfg.slogan || '';
  const tag = el(`<div class="abs" style="left:0;width:1920px;top:${520 + 128}px;text-align:center;font-size:${K.fit(slogan, { size: 48, weight: 500, tracking: -.015, maxW: 1600 })}px;font-weight:500;letter-spacing:-.015em;color:#2b2b33;z-index:21;white-space:nowrap"></div>`, s14);
  tag.innerHTML = slogan.split(' ').filter(Boolean).map(w => `<span style="display:inline-block;margin:0 .14em">${H(w)}</span>`).join('');
  [...tag.children].forEach((w, i) => K.popIn(w, 61.9 + i * .07, { dur: .6, y: 12, blur: 10 }));
  if (slogan) cue(61.92, 'tagline', 's14:tag');
  const els = [root, tag];
  if (cfg.chamada) {
    const avail = el(`<div class="abs" style="left:0;width:1920px;top:${520 + 230}px;text-align:center;z-index:21">
      <span style="display:inline-flex;align-items:center;gap:14px;height:62px;padding:0 30px;border-radius:999px;background:#fff;font-size:${K.fit(cfg.chamada, { size: 24, weight: 500, maxW: 1500, min: 16 })}px;font-weight:500;color:#3d3d45;white-space:nowrap;
        box-shadow:0 10px 30px -14px rgba(17,17,20,.3), inset 0 0 0 1px #ececea"><i style="width:10px;height:10px;border-radius:50%;background:${C.acao}"></i>${H(cfg.chamada)}</span></div>`, s14);
    K.popIn(avail, 62.7, { dur: .6, y: 14, blur: 8 });
    cue(62.75, 'pop', 's14:avail', { step: 2, soft: true });
    els.push(avail);
  }
  tl.fromTo(els, { y: 0 }, { y: -6, duration: 4.6, ease: 'none', immediateRender: false }, 61.4);
};
