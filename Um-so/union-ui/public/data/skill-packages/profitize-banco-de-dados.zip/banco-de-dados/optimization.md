# Otimização de consultas

> Problema N+1, EXPLAIN ANALYZE, prioridades de otimização.

## Problema N+1

```
O que é N+1?
├── 1 consulta para buscar os registros pai
├── N consultas para buscar os registros relacionados
└── Muito lento!

Soluções:
├── JOIN → uma consulta só com todos os dados
├── Eager loading → o ORM cuida do JOIN
├── DataLoader → agrupa e guarda em cache (GraphQL)
└── Subconsulta → busca os relacionados numa consulta só
```

## Mentalidade de análise de consultas

```
Antes de otimizar:
├── Rode EXPLAIN ANALYZE na consulta
├── Procure Seq Scan (varredura da tabela inteira)
├── Compare as linhas reais com as estimadas
└── Identifique os índices que faltam
```

## Prioridades de otimização

1. **Adicione os índices que faltam** (o problema mais comum)
2. **Selecione só as colunas necessárias** (nada de SELECT *)
3. **Use JOINs adequados** (evite subconsultas quando possível)
4. **Limite cedo** (paginação no próprio banco)
5. **Cache** (quando fizer sentido)
