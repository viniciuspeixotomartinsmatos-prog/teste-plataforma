# Escolha do banco de dados (2025)

> Escolha o banco pelo contexto, não pelo padrão.

## Árvore de decisão

```
Quais são os seus requisitos?
│
├── Precisa de todos os recursos relacionais
│   ├── Hospedagem própria → PostgreSQL
│   └── Serverless → Neon, Supabase
│
├── Deploy na edge / latência baixíssima
│   └── Turso (SQLite na edge)
│
├── IA / busca vetorial
│   └── PostgreSQL + pgvector
│
├── Simples / embarcado / local
│   └── SQLite
│
└── Distribuição global
    └── PlanetScale, CockroachDB, Turso
```

## Comparação

| Banco | Ideal para | Prós e contras |
|----------|----------|------------|
| **PostgreSQL** | Recursos completos, consultas complexas | Precisa de hospedagem |
| **Neon** | PG serverless (sem servidor para administrar), branching | A complexidade do PG |
| **Turso** | Edge (servidores perto do usuário), baixa latência | As limitações do SQLite |
| **SQLite** | Simples, embarcado, local | Um único escritor por vez |
| **PlanetScale** | MySQL, escala global | Sem chaves estrangeiras |

## Perguntas a fazer

1. Qual é o ambiente de deploy?
2. Quão complexas são as consultas?
3. Edge ou serverless é importante?
4. Precisa de busca vetorial?
5. Precisa de distribuição global?
