# Princípios de modelagem do schema

> Normalização, chaves primárias, timestamps, relacionamentos.

## Decisão de normalização

```
Quando normalizar (tabelas separadas):
├── O dado se repete entre linhas
├── Uma atualização exigiria várias mudanças
├── Os relacionamentos são claros
└── Os padrões de consulta se beneficiam

Quando desnormalizar (embutir/duplicar):
├── O desempenho de leitura é crítico
├── O dado quase nunca muda
├── Sempre é buscado junto
└── Precisa de consultas mais simples
```

## Escolha da chave primária

| Tipo | Quando usar |
|------|----------|
| **UUID** | Sistemas distribuídos, segurança |
| **ULID** | UUID + ordenável por tempo |
| **Auto-incremento** | Apps simples, um banco só |
| **Chave natural** | Raramente (significado de negócio) |

## Estratégia de timestamps

```
Em toda tabela:
├── created_at → quando foi criado
├── updated_at → última alteração
└── deleted_at → soft delete (se precisar)

Use TIMESTAMPTZ (com fuso horário), não TIMESTAMP
```

## Tipos de relacionamento

| Tipo | Quando | Implementação |
|------|------|----------------|
| **Um para um** | Dados de extensão | Tabela separada com FK |
| **Um para muitos** | Pai e filhos | FK na tabela filha |
| **Muitos para muitos** | Os dois lados têm vários | Tabela associativa |

## ON DELETE da chave estrangeira

```
├── CASCADE → apaga os filhos junto com o pai
├── SET NULL → os filhos ficam órfãos
├── RESTRICT → impede a exclusão se houver filhos
└── SET DEFAULT → os filhos recebem o valor padrão
```
