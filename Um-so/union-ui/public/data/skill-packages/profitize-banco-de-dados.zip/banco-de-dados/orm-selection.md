# Escolha do ORM (2025)

> Escolha o ORM pelo deploy e pelas necessidades de DX (experiência de quem desenvolve).

## Árvore de decisão

```
Qual é o contexto?
│
├── Deploy na edge / o tamanho do bundle importa
│   └── Drizzle (o menor, parecido com SQL)
│
├── Melhor DX / schema primeiro
│   └── Prisma (migrações, studio)
│
├── Controle máximo
│   └── SQL puro com query builder
│
└── Ecossistema Python
    └── SQLAlchemy 2.0 (suporte a async)
```

## Comparação

| ORM | Ideal para | Prós e contras |
|-----|----------|------------|
| **Drizzle** | Edge, TypeScript | Mais novo, menos exemplos |
| **Prisma** | DX, gestão do schema | Mais pesado, não pronto para edge |
| **Kysely** | Query builder de SQL com tipos | Migrações manuais |
| **SQL puro** | Consultas complexas, controle | Tipagem manual |
