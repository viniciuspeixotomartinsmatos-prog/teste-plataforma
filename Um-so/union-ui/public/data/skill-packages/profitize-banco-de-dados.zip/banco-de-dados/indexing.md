# Princípios de indexação

> Quando e como criar índices de forma eficaz.

## Quando criar índices

```
Indexe estas:
├── Colunas em cláusulas WHERE
├── Colunas em condições de JOIN
├── Colunas em ORDER BY
├── Colunas de chave estrangeira
└── Restrições de unicidade

Não exagere nos índices:
├── Tabelas com muita escrita (inserts mais lentos)
├── Colunas de baixa cardinalidade
├── Colunas raramente consultadas
```

## Escolha do tipo de índice

| Tipo | Use para |
|------|---------|
| **B-tree** | Uso geral, igualdade e intervalo |
| **Hash** | Só igualdade, mais rápido |
| **GIN** | JSONB, arrays, busca textual (full-text) |
| **GiST** | Tipos geométricos e de intervalo |
| **HNSW/IVFFlat** | Similaridade vetorial (pgvector) |

## Princípios do índice composto

```
A ordem importa no índice composto:
├── Colunas de igualdade primeiro
├── Colunas de intervalo por último
├── As mais seletivas primeiro
└── Siga o padrão da consulta
```
