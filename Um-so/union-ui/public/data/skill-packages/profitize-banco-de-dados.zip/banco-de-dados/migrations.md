# Princípios de migração

> Estratégia segura de migração para mudanças sem downtime.

## Estratégia segura de migração

```
Para mudanças sem downtime:
│
├── Adicionar coluna
│   └── Adicione como nullable → backfill → adicione o NOT NULL
│
├── Remover coluna
│   └── Pare de usar → deploy → remova a coluna
│
├── Adicionar índice
│   └── CREATE INDEX CONCURRENTLY (sem bloquear)
│
└── Renomear coluna
    └── Adicione a nova → migre os dados → deploy → apague a antiga
```

## Filosofia de migração

- Nunca faça uma breaking change (mudança que quebra o que já funciona) num passo só
- Teste as migrações antes numa cópia dos dados
- Tenha um plano de rollback
- Execute numa transação quando possível

## Bancos serverless

### Neon (PostgreSQL serverless)

| Recurso | Vantagem |
|---------|---------|
| Escala até zero | Economia |
| Branching instantâneo | Dev/preview |
| PostgreSQL completo | Compatibilidade |
| Escala automática | Aguenta o tráfego |

### Turso (SQLite na edge)

| Recurso | Vantagem |
|---------|---------|
| Servidores na edge | Latência baixíssima |
| Compatível com SQLite | Simplicidade |
| Plano gratuito generoso | Custo |
| Distribuição global | Desempenho |
