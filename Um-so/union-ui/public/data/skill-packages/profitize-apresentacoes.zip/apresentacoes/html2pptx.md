# Guia de HTML para PowerPoint

Converta slides em HTML em apresentações do PowerPoint, com o posicionamento exato, usando a biblioteca `html2pptx.js`.

## Sumário

1. [Criar slides em HTML](#criar-slides-em-html)
2. [Usar a biblioteca html2pptx](#usar-a-biblioteca-html2pptx)
3. [Usar o PptxGenJS](#usar-o-pptxgenjs)

---

## Criar slides em HTML

Todo slide em HTML tem de ter as dimensões certas no body:

### Dimensões do layout

- **16:9** (padrão): `width: 720pt; height: 405pt`
- **4:3**: `width: 720pt; height: 540pt`
- **16:10**: `width: 720pt; height: 450pt`

### Elementos aceitos

- `<p>`, `<h1>`-`<h6>`: texto com estilo
- `<ul>`, `<ol>`: listas (nunca use marcadores digitados à mão •, -, *)
- `<b>`, `<strong>`: texto em negrito (formatação em linha)
- `<i>`, `<em>`: texto em itálico (formatação em linha)
- `<u>`: texto sublinhado (formatação em linha)
- `<span>`: formatação em linha com estilos CSS (negrito, itálico, sublinhado, cor)
- `<br>`: quebras de linha
- `<div>` com fundo/borda: vira forma
- `<img>`: imagens
- `class="placeholder"`: espaço reservado para gráficos (devolve `{ id, x, y, w, h }`)

### Regras críticas de texto

**TODO texto TEM DE estar dentro das tags `<p>`, `<h1>`-`<h6>`, `<ul>` ou `<ol>`:**
- ✅ CORRETO: `<div><p>Text here</p></div>`
- ❌ ERRADO: `<div>Text here</div>`: **o texto NÃO vai aparecer no PowerPoint**
- ❌ ERRADO: `<span>Text</span>`: **o texto NÃO vai aparecer no PowerPoint**
- Texto em `<div>` ou `<span>` sem uma tag de texto é ignorado sem aviso

**NUNCA use símbolos de marcador digitados à mão (•, -, * etc.)**: use listas `<ul>` ou `<ol>`

**Use SÓ fontes web-safe (seguras para a web), disponíveis em qualquer sistema:**
- ✅ Fontes web-safe: `Arial`, `Helvetica`, `Times New Roman`, `Georgia`, `Courier New`, `Verdana`, `Tahoma`, `Trebuchet MS`, `Impact`, `Comic Sans MS`
- ❌ ERRADO: `'Segoe UI'`, `'SF Pro'`, `'Roboto'`, fontes personalizadas: **podem dar problema na renderização**

### Estilo

- Use `display: flex` no body para evitar que o colapso de margens quebre a validação de transbordamento
- Use `margin` para espaçamento (o padding entra no tamanho)
- Formatação em linha: use as tags `<b>`, `<i>`, `<u>` OU `<span>` com estilos CSS
  - O `<span>` aceita: `font-weight: bold`, `font-style: italic`, `text-decoration: underline`, `color: #rrggbb`
  - O `<span>` NÃO aceita: `margin`, `padding` (o PowerPoint não os aceita nos runs de texto)
  - Exemplo: `<span style="font-weight: bold; color: #667eea;">Texto azul em negrito</span>`
- O flexbox funciona: as posições são calculadas a partir do layout renderizado
- Use cores hex com o prefixo `#` no CSS
- **Alinhamento do texto**: use o `text-align` do CSS (`center`, `right` etc.) quando precisar, como dica para o PptxGenJS formatar o texto se o comprimento dele sair um pouco diferente

### Estilo das formas (só elementos DIV)

**IMPORTANTE: fundos, bordas e sombras só funcionam em elementos `<div>`, NÃO em elementos de texto (`<p>`, `<h1>`-`<h6>`, `<ul>`, `<ol>`)**

- **Fundos**: `background` ou `background-color` do CSS só em elementos `<div>`
  - Exemplo: `<div style="background: #f0f0f0;">`: cria uma forma com fundo
- **Bordas**: o `border` do CSS em elementos `<div>` vira borda de forma no PowerPoint
  - Aceita bordas uniformes: `border: 2px solid #333333`
  - Aceita bordas parciais: `border-left`, `border-right`, `border-top`, `border-bottom` (renderizadas como formas de linha)
  - Exemplo: `<div style="border-left: 8pt solid #E76F51;">`
- **Raio da borda**: `border-radius` do CSS em elementos `<div>` para cantos arredondados
  - `border-radius: 50%` ou mais cria uma forma circular
  - Porcentagens abaixo de 50% são calculadas sobre a menor dimensão da forma
  - Aceita as unidades px e pt (ex.: `border-radius: 8pt;`, `border-radius: 12px;`)
  - Exemplo: `<div style="border-radius: 25%;">` numa caixa de 100x200px = 25% de 100px = raio de 25px
- **Sombras**: o `box-shadow` do CSS em elementos `<div>` vira sombra no PowerPoint
  - Só aceita sombras externas (as internas, inset, são ignoradas para não corromper o arquivo)
  - Exemplo: `<div style="box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);">`
  - Observação: o PowerPoint não aceita sombras inset/internas, e elas são puladas

### Ícones e gradientes

- **CRÍTICO: nunca use gradientes do CSS (`linear-gradient`, `radial-gradient`)**: eles não são convertidos para o PowerPoint
- **SEMPRE crie ANTES os PNGs de gradiente e de ícone com o Sharp, e depois referencie no HTML**
- Para gradientes: rasterize um SVG em imagens de fundo PNG
- Para ícones: rasterize o SVG do react-icons em imagens PNG
- Todo efeito visual tem de ser pré-renderizado como imagem rasterizada antes da renderização do HTML

**Rasterizar ícones com o Sharp:**

```javascript
const React = require('react');
const ReactDOMServer = require('react-dom/server');
const sharp = require('sharp');
const { FaHome } = require('react-icons/fa');

async function rasterizeIconPng(IconComponent, color, size = "256", filename) {
  const svgString = ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color: `#${color}`, size: size })
  );

  // Converte o SVG em PNG com o Sharp
  await sharp(Buffer.from(svgString))
    .png()
    .toFile(filename);

  return filename;
}

// Uso: rasterize o ícone antes de usá-lo no HTML
const iconPath = await rasterizeIconPng(FaHome, "4472c4", "256", "home-icon.png");
// Depois referencie no HTML: <img src="home-icon.png" style="width: 40pt; height: 40pt;">
```

**Rasterizar gradientes com o Sharp:**

```javascript
const sharp = require('sharp');

async function createGradientBackground(filename) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="562.5">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#COLOR1"/>
        <stop offset="100%" style="stop-color:#COLOR2"/>
      </linearGradient>
    </defs>
    <rect width="100%" height="100%" fill="url(#g)"/>
  </svg>`;

  await sharp(Buffer.from(svg))
    .png()
    .toFile(filename);

  return filename;
}

// Uso: crie o fundo em gradiente antes do HTML
const bgPath = await createGradientBackground("gradient-bg.png");
// Depois, no HTML: <body style="background-image: url('gradient-bg.png');">
```

### Exemplo

```html
<!DOCTYPE html>
<html>
<head>
<style>
html { background: #ffffff; }
body {
  width: 720pt; height: 405pt; margin: 0; padding: 0;
  background: #f5f5f5; font-family: Arial, sans-serif;
  display: flex;
}
.content { margin: 30pt; padding: 40pt; background: #ffffff; border-radius: 8pt; }
h1 { color: #2d3748; font-size: 32pt; }
.box {
  background: #70ad47; padding: 20pt; border: 3px solid #5a8f37;
  border-radius: 12pt; box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.25);
}
</style>
</head>
<body>
<div class="content">
  <h1>Título da receita</h1>
  <ul>
    <li><b>Item:</b> Descrição</li>
  </ul>
  <p>Texto com <b>negrito</b>, <i>itálico</i>, <u>sublinhado</u>.</p>
  <div id="chart" class="placeholder" style="width: 350pt; height: 200pt;"></div>

  <!-- O texto TEM DE estar em tags <p> -->
  <div class="box">
    <p>5</p>
  </div>
</div>
</body>
</html>
```

## Usar a biblioteca html2pptx

### Dependências

Estas bibliotecas já estão instaladas globalmente e prontas para uso:
- `pptxgenjs`
- `playwright`
- `sharp`

### Uso básico

```javascript
const pptxgen = require('pptxgenjs');
const html2pptx = require('./html2pptx');

const pptx = new pptxgen();
pptx.layout = 'LAYOUT_16x9';  // Tem de bater com as dimensões do body no HTML

const { slide, placeholders } = await html2pptx('slide1.html', pptx);

// Adiciona o gráfico na área do placeholder
if (placeholders.length > 0) {
    slide.addChart(pptx.charts.LINE, chartData, placeholders[0]);
}

await pptx.writeFile('output.pptx');
```

### Referência da API

#### Assinatura da função
```javascript
await html2pptx(htmlFile, pres, options)
```

#### Parâmetros
- `htmlFile` (string): caminho do arquivo HTML (absoluto ou relativo)
- `pres` (pptxgen): instância de apresentação do PptxGenJS com o layout já definido
- `options` (object, opcional):
  - `tmpDir` (string): pasta temporária para os arquivos gerados (padrão: `process.env.TMPDIR || '/tmp'`)
  - `slide` (object): slide existente a reaproveitar (padrão: cria um slide novo)

#### Retorno
```javascript
{
    slide: pptxgenSlide,           // O slide criado/atualizado
    placeholders: [                 // Array com as posições dos placeholders
        { id: string, x: number, y: number, w: number, h: number },
        ...
    ]
}
```

### Validação

A biblioteca valida automaticamente e junta todos os erros antes de lançar a exceção:

1. **As dimensões do HTML têm de bater com o layout da apresentação**: aponta as dimensões que não batem
2. **O conteúdo não pode transbordar o body**: aponta o transbordamento com as medidas exatas
3. **Gradientes do CSS**: aponta o uso de gradiente, que não é aceito
4. **Estilo de elementos de texto**: aponta fundos/bordas/sombras em elementos de texto (só são permitidos em divs)

**Todos os erros de validação são juntados e apontados de uma vez** numa única mensagem de erro, para você corrigir todos os problemas juntos, e não um por vez.

### Trabalhar com placeholders

```javascript
const { slide, placeholders } = await html2pptx('slide.html', pptx);

// Usa o primeiro placeholder
slide.addChart(pptx.charts.BAR, data, placeholders[0]);

// Procura pelo ID
const chartArea = placeholders.find(p => p.id === 'chart-area');
slide.addChart(pptx.charts.LINE, data, chartArea);
```

### Exemplo completo

```javascript
const pptxgen = require('pptxgenjs');
const html2pptx = require('./html2pptx');

async function createPresentation() {
    const pptx = new pptxgen();
    pptx.layout = 'LAYOUT_16x9';
    pptx.author = 'Seu Nome';
    pptx.title = 'Minha apresentação';

    // Slide 1: título
    const { slide: slide1 } = await html2pptx('slides/title.html', pptx);

    // Slide 2: conteúdo com gráfico
    const { slide: slide2, placeholders } = await html2pptx('slides/data.html', pptx);

    const chartData = [{
        name: 'Vendas',
        labels: ['T1', 'T2', 'T3', 'T4'],
        values: [4500, 5500, 6200, 7100]
    }];

    slide2.addChart(pptx.charts.BAR, chartData, {
        ...placeholders[0],
        showTitle: true,
        title: 'Vendas por trimestre',
        showCatAxisTitle: true,
        catAxisTitle: 'Trimestre',
        showValAxisTitle: true,
        valAxisTitle: 'Vendas (R$ mil)'
    });

    // Salva
    await pptx.writeFile({ fileName: 'presentation.pptx' });
    console.log('Apresentação criada com sucesso!');
}

createPresentation().catch(console.error);
```

## Usar o PptxGenJS

Depois de converter o HTML em slides com o `html2pptx`, use o PptxGenJS para acrescentar conteúdo dinâmico, como gráficos, imagens e outros elementos.

### ⚠️ Regras críticas

#### Cores
- **NUNCA use o prefixo `#`** nas cores hex no PptxGenJS: corrompe o arquivo
- ✅ CORRETO: `color: "FF0000"`, `fill: { color: "0066CC" }`
- ❌ ERRADO: `color: "#FF0000"` (quebra o documento)

### Adicionar imagens

Sempre calcule a proporção a partir das dimensões reais da imagem:

```javascript
// Pegue as dimensões da imagem: identify image.png | grep -o '[0-9]* x [0-9]*'
const imgWidth = 1860, imgHeight = 1519;  // Do arquivo real
const aspectRatio = imgWidth / imgHeight;

const h = 3;  // Altura máxima
const w = h * aspectRatio;
const x = (10 - w) / 2;  // Centraliza no slide 16:9

slide.addImage({ path: "chart.png", x, y: 1.5, w, h });
```

### Adicionar texto

```javascript
// Texto rico com formatação
slide.addText([
    { text: "Negrito ", options: { bold: true } },
    { text: "Itálico ", options: { italic: true } },
    { text: "Normal" }
], {
    x: 1, y: 2, w: 8, h: 1
});
```

### Adicionar formas

```javascript
// Retângulo
slide.addShape(pptx.shapes.RECTANGLE, {
    x: 1, y: 1, w: 3, h: 2,
    fill: { color: "4472C4" },
    line: { color: "000000", width: 2 }
});

// Círculo
slide.addShape(pptx.shapes.OVAL, {
    x: 5, y: 1, w: 2, h: 2,
    fill: { color: "ED7D31" }
});

// Retângulo arredondado
slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: 1, y: 4, w: 3, h: 1.5,
    fill: { color: "70AD47" },
    rectRadius: 0.2
});
```

### Adicionar gráficos

**Obrigatório na maioria dos gráficos:** títulos dos eixos com `catAxisTitle` (categoria) e `valAxisTitle` (valor).

**Formato dos dados do gráfico:**
- Use **uma série só com todos os rótulos** em gráficos simples de barras/linhas
- Cada série cria uma entrada separada na legenda
- O array de labels define os valores do eixo X

**Dados de série temporal: escolha a granularidade certa:**
- **< 30 dias**: agrupe por dia (ex.: "01/10", "02/10"); evite agrupar por mês, o que gera gráfico de um ponto só
- **30-365 dias**: agrupe por mês (ex.: "01/2024", "02/2024")
- **> 365 dias**: agrupe por ano (ex.: "2023", "2024")
- **Confira**: gráfico com só 1 ponto de dados provavelmente indica um agrupamento errado para o período

```javascript
const { slide, placeholders } = await html2pptx('slide.html', pptx);

// CORRETO: uma série só com todos os rótulos
slide.addChart(pptx.charts.BAR, [{
    name: "Vendas 2024",
    labels: ["T1", "T2", "T3", "T4"],
    values: [4500, 5500, 6200, 7100]
}], {
    ...placeholders[0],  // Usa a posição do placeholder
    barDir: 'col',       // 'col' = barras verticais, 'bar' = horizontais
    showTitle: true,
    title: 'Vendas por trimestre',
    showLegend: false,   // Série única não precisa de legenda
    // Títulos dos eixos obrigatórios
    showCatAxisTitle: true,
    catAxisTitle: 'Trimestre',
    showValAxisTitle: true,
    valAxisTitle: 'Vendas (R$ mil)',
    // Opcional: controla a escala (ajuste o mínimo pela faixa dos dados, para visualizar melhor)
    valAxisMaxVal: 8000,
    valAxisMinVal: 0,  // Use 0 para contagens/valores; para dados agrupados (ex.: 4500-7100), considere começar mais perto do mínimo
    valAxisMajorUnit: 2000,  // Controla o espaçamento dos rótulos do eixo Y para não amontoar
    catAxisLabelRotate: 45,  // Gira os rótulos se estiverem amontoados
    dataLabelPosition: 'outEnd',
    dataLabelColor: '000000',
    // Use uma cor só em gráficos de série única
    chartColors: ["4472C4"]  // Todas as barras na mesma cor
});
```

#### Gráfico de dispersão

**IMPORTANTE**: o formato dos dados do gráfico de dispersão é incomum: a primeira série traz os valores do eixo X, e as seguintes, os valores de Y:

```javascript
// Prepara os dados
const data1 = [{ x: 10, y: 20 }, { x: 15, y: 25 }, { x: 20, y: 30 }];
const data2 = [{ x: 12, y: 18 }, { x: 18, y: 22 }];

const allXValues = [...data1.map(d => d.x), ...data2.map(d => d.x)];

slide.addChart(pptx.charts.SCATTER, [
    { name: 'Eixo X', values: allXValues },  // Primeira série = valores de X
    { name: 'Série 1', values: data1.map(d => d.y) },  // Só valores de Y
    { name: 'Série 2', values: data2.map(d => d.y) }   // Só valores de Y
], {
    x: 1, y: 1, w: 8, h: 4,
    lineSize: 0,  // 0 = sem linhas ligando os pontos
    lineDataSymbol: 'circle',
    lineDataSymbolSize: 6,
    showCatAxisTitle: true,
    catAxisTitle: 'Eixo X',
    showValAxisTitle: true,
    valAxisTitle: 'Eixo Y',
    chartColors: ["4472C4", "ED7D31"]
});
```

#### Gráfico de linhas

```javascript
slide.addChart(pptx.charts.LINE, [{
    name: "Temperatura",
    labels: ["Jan", "Fev", "Mar", "Abr"],
    values: [32, 35, 42, 55]
}], {
    x: 1, y: 1, w: 8, h: 4,
    lineSize: 4,
    lineSmooth: true,
    // Títulos dos eixos obrigatórios
    showCatAxisTitle: true,
    catAxisTitle: 'Mês',
    showValAxisTitle: true,
    valAxisTitle: 'Temperatura (°F)',
    // Opcional: faixa do eixo Y (defina o mínimo pela faixa dos dados, para visualizar melhor)
    valAxisMinVal: 0,     // Para faixas que começam em 0 (contagens, porcentagens etc.)
    valAxisMaxVal: 60,
    valAxisMajorUnit: 20,  // Controla o espaçamento dos rótulos do eixo Y para não amontoar (ex.: 10, 20, 25)
    // valAxisMinVal: 30,  // PREFERÍVEL: para dados concentrados numa faixa (ex.: 32-55 ou notas de 3 a 5), comece o eixo perto do mínimo para mostrar a variação
    // Opcional: cores do gráfico
    chartColors: ["4472C4", "ED7D31", "A5A5A5"]
});
```

#### Gráfico de pizza (sem títulos de eixo)

**CRÍTICO**: gráficos de pizza exigem **uma série de dados só**, com todas as categorias no array `labels` e os valores correspondentes no array `values`.

```javascript
slide.addChart(pptx.charts.PIE, [{
    name: "Participação de mercado",
    labels: ["Produto A", "Produto B", "Outros"],  // Todas as categorias num array só
    values: [35, 45, 20]  // Todos os valores num array só
}], {
    x: 2, y: 1, w: 6, h: 4,
    showPercent: true,
    showLegend: true,
    legendPos: 'r',  // direita
    chartColors: ["4472C4", "ED7D31", "A5A5A5"]
});
```

#### Várias séries de dados

```javascript
slide.addChart(pptx.charts.LINE, [
    {
        name: "Produto A",
        labels: ["T1", "T2", "T3", "T4"],
        values: [10, 20, 30, 40]
    },
    {
        name: "Produto B",
        labels: ["T1", "T2", "T3", "T4"],
        values: [15, 25, 20, 35]
    }
], {
    x: 1, y: 1, w: 8, h: 4,
    showCatAxisTitle: true,
    catAxisTitle: 'Trimestre',
    showValAxisTitle: true,
    valAxisTitle: 'Receita (R$ mi)'
});
```

### Cores dos gráficos

**CRÍTICO**: use cores hex **sem** o prefixo `#`: incluir o `#` corrompe o arquivo.

**Alinhe as cores do gráfico com a paleta de design escolhida**, garantindo contraste e distinção suficientes para a visualização dos dados. Ajuste as cores para ter:
- Contraste forte entre séries vizinhas
- Leitura fácil sobre o fundo do slide
- Acessibilidade (evite combinações só de vermelho e verde)

```javascript
// Exemplo: cores de gráfico inspiradas na paleta Oceano (ajustadas para contraste)
const chartColors = ["16A085", "FF6B9D", "2C3E50", "F39C12", "9B59B6"];

// Gráfico de série única: uma cor para todas as barras/pontos
slide.addChart(pptx.charts.BAR, [{
    name: "Vendas",
    labels: ["T1", "T2", "T3", "T4"],
    values: [4500, 5500, 6200, 7100]
}], {
    ...placeholders[0],
    chartColors: ["16A085"],  // Todas as barras na mesma cor
    showLegend: false
});

// Gráfico de várias séries: cada série ganha uma cor diferente
slide.addChart(pptx.charts.LINE, [
    { name: "Produto A", labels: ["T1", "T2", "T3"], values: [10, 20, 30] },
    { name: "Produto B", labels: ["T1", "T2", "T3"], values: [15, 25, 20] }
], {
    ...placeholders[0],
    chartColors: ["16A085", "FF6B9D"]  // Uma cor por série
});
```

### Adicionar tabelas

As tabelas podem levar formatação básica ou avançada:

#### Tabela básica

```javascript
slide.addTable([
    ["Cabeçalho 1", "Cabeçalho 2", "Cabeçalho 3"],
    ["Linha 1, Col 1", "Linha 1, Col 2", "Linha 1, Col 3"],
    ["Linha 2, Col 1", "Linha 2, Col 2", "Linha 2, Col 3"]
], {
    x: 0.5,
    y: 1,
    w: 9,
    h: 3,
    border: { pt: 1, color: "999999" },
    fill: { color: "F1F1F1" }
});
```

#### Tabela com formatação personalizada

```javascript
const tableData = [
    // Linha de cabeçalho com estilo próprio
    [
        { text: "Produto", options: { fill: { color: "4472C4" }, color: "FFFFFF", bold: true } },
        { text: "Receita", options: { fill: { color: "4472C4" }, color: "FFFFFF", bold: true } },
        { text: "Crescimento", options: { fill: { color: "4472C4" }, color: "FFFFFF", bold: true } }
    ],
    // Linhas de dados
    ["Produto A", "R$ 50 mi", "+15%"],
    ["Produto B", "R$ 35 mi", "+22%"],
    ["Produto C", "R$ 28 mi", "+8%"]
];

slide.addTable(tableData, {
    x: 1,
    y: 1.5,
    w: 8,
    h: 3,
    colW: [3, 2.5, 2.5],  // Larguras das colunas
    rowH: [0.5, 0.6, 0.6, 0.6],  // Alturas das linhas
    border: { pt: 1, color: "CCCCCC" },
    align: "center",
    valign: "middle",
    fontSize: 14
});
```

#### Tabela com células mescladas

```javascript
const mergedTableData = [
    [
        { text: "Resultados do T1", options: { colspan: 3, fill: { color: "4472C4" }, color: "FFFFFF", bold: true } }
    ],
    ["Produto", "Vendas", "Participação de mercado"],
    ["Produto A", "R$ 25 mi", "35%"],
    ["Produto B", "R$ 18 mi", "25%"]
];

slide.addTable(mergedTableData, {
    x: 1,
    y: 1,
    w: 8,
    h: 2.5,
    colW: [3, 2.5, 2.5],
    border: { pt: 1, color: "DDDDDD" }
});
```

### Opções de tabela

Opções de tabela mais usadas:
- `x, y, w, h`: posição e tamanho
- `colW`: array com as larguras das colunas (em polegadas; 1 polegada = 2,54 cm)
- `rowH`: array com as alturas das linhas (em polegadas)
- `border`: estilo da borda: `{ pt: 1, color: "999999" }`
- `fill`: cor de fundo (sem o prefixo #)
- `align`: alinhamento do texto: "left", "center", "right"
- `valign`: alinhamento vertical: "top", "middle", "bottom"
- `fontSize`: tamanho do texto
- `autoPage`: cria slides novos sozinho se o conteúdo transbordar
