# Referência técnica do Office Open XML para o PowerPoint

**Importante: leia este documento inteiro antes de começar.** Regras críticas do schema XML e requisitos de formatação aparecem do começo ao fim. Uma implementação incorreta pode gerar arquivos PPTX inválidos, que o PowerPoint não consegue abrir.

## Diretrizes técnicas

### Conformidade com o schema
- **Ordem dos elementos em `<p:txBody>`**: `<a:bodyPr>`, `<a:lstStyle>`, `<a:p>`
- **Espaços em branco**: acrescente `xml:space='preserve'` aos elementos `<a:t>` com espaços no início ou no fim
- **Unicode**: escape os caracteres no conteúdo ASCII: `"` vira `&#8220;`
- **Imagens**: acrescente em `ppt/media/`, referencie no XML do slide e defina as dimensões para caber nos limites do slide
- **Relacionamentos**: atualize o `ppt/slides/_rels/slideN.xml.rels` com os recursos de cada slide
- **Atributo dirty**: acrescente `dirty="0"` aos elementos `<a:rPr>` e `<a:endParaRPr>` para indicar estado limpo

## Estrutura da apresentação

### Estrutura básica do slide
```xml
<!-- ppt/slides/slide1.xml -->
<p:sld>
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr>...</p:nvGrpSpPr>
      <p:grpSpPr>...</p:grpSpPr>
      <!-- As formas vão aqui -->
    </p:spTree>
  </p:cSld>
</p:sld>
```

### Caixa de texto / forma com texto
```xml
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="2" name="Title"/>
    <p:cNvSpPr>
      <a:spLocks noGrp="1"/>
    </p:cNvSpPr>
    <p:nvPr>
      <p:ph type="ctrTitle"/>
    </p:nvPr>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm>
      <a:off x="838200" y="365125"/>
      <a:ext cx="7772400" cy="1470025"/>
    </a:xfrm>
  </p:spPr>
  <p:txBody>
    <a:bodyPr/>
    <a:lstStyle/>
    <a:p>
      <a:r>
        <a:t>Título do slide</a:t>
      </a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

### Formatação de texto
```xml
<!-- Negrito -->
<a:r>
  <a:rPr b="1"/>
  <a:t>Texto em negrito</a:t>
</a:r>

<!-- Itálico -->
<a:r>
  <a:rPr i="1"/>
  <a:t>Texto em itálico</a:t>
</a:r>

<!-- Sublinhado -->
<a:r>
  <a:rPr u="sng"/>
  <a:t>Sublinhado</a:t>
</a:r>

<!-- Realce -->
<a:r>
  <a:rPr>
    <a:highlight>
      <a:srgbClr val="FFFF00"/>
    </a:highlight>
  </a:rPr>
  <a:t>Texto realçado</a:t>
</a:r>

<!-- Fonte e tamanho -->
<a:r>
  <a:rPr sz="2400" typeface="Arial">
    <a:solidFill>
      <a:srgbClr val="FF0000"/>
    </a:solidFill>
  </a:rPr>
  <a:t>Arial colorida 24 pt</a:t>
</a:r>

<!-- Exemplo de formatação completa -->
<a:r>
  <a:rPr lang="en-US" sz="1400" b="1" dirty="0">
    <a:solidFill>
      <a:srgbClr val="FAFAFA"/>
    </a:solidFill>
  </a:rPr>
  <a:t>Texto formatado</a:t>
</a:r>
```

### Listas
```xml
<!-- Lista com marcadores -->
<a:p>
  <a:pPr lvl="0">
    <a:buChar char="•"/>
  </a:pPr>
  <a:r>
    <a:t>Primeiro tópico</a:t>
  </a:r>
</a:p>

<!-- Lista numerada -->
<a:p>
  <a:pPr lvl="0">
    <a:buAutoNum type="arabicPeriod"/>
  </a:pPr>
  <a:r>
    <a:t>Primeiro item numerado</a:t>
  </a:r>
</a:p>

<!-- Recuo de segundo nível -->
<a:p>
  <a:pPr lvl="1">
    <a:buChar char="•"/>
  </a:pPr>
  <a:r>
    <a:t>Tópico recuado</a:t>
  </a:r>
</a:p>
```

### Formas
```xml
<!-- Retângulo -->
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="3" name="Rectangle"/>
    <p:cNvSpPr/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm>
      <a:off x="1000000" y="1000000"/>
      <a:ext cx="3000000" cy="2000000"/>
    </a:xfrm>
    <a:prstGeom prst="rect">
      <a:avLst/>
    </a:prstGeom>
    <a:solidFill>
      <a:srgbClr val="FF0000"/>
    </a:solidFill>
    <a:ln w="25400">
      <a:solidFill>
        <a:srgbClr val="000000"/>
      </a:solidFill>
    </a:ln>
  </p:spPr>
</p:sp>

<!-- Retângulo arredondado -->
<p:sp>
  <p:spPr>
    <a:prstGeom prst="roundRect">
      <a:avLst/>
    </a:prstGeom>
  </p:spPr>
</p:sp>

<!-- Círculo/elipse -->
<p:sp>
  <p:spPr>
    <a:prstGeom prst="ellipse">
      <a:avLst/>
    </a:prstGeom>
  </p:spPr>
</p:sp>
```

### Imagens
```xml
<p:pic>
  <p:nvPicPr>
    <p:cNvPr id="4" name="Picture">
      <a:hlinkClick r:id="" action="ppaction://media"/>
    </p:cNvPr>
    <p:cNvPicPr>
      <a:picLocks noChangeAspect="1"/>
    </p:cNvPicPr>
    <p:nvPr/>
  </p:nvPicPr>
  <p:blipFill>
    <a:blip r:embed="rId2"/>
    <a:stretch>
      <a:fillRect/>
    </a:stretch>
  </p:blipFill>
  <p:spPr>
    <a:xfrm>
      <a:off x="1000000" y="1000000"/>
      <a:ext cx="3000000" cy="2000000"/>
    </a:xfrm>
    <a:prstGeom prst="rect">
      <a:avLst/>
    </a:prstGeom>
  </p:spPr>
</p:pic>
```

### Tabelas
```xml
<p:graphicFrame>
  <p:nvGraphicFramePr>
    <p:cNvPr id="5" name="Table"/>
    <p:cNvGraphicFramePr>
      <a:graphicFrameLocks noGrp="1"/>
    </p:cNvGraphicFramePr>
    <p:nvPr/>
  </p:nvGraphicFramePr>
  <p:xfrm>
    <a:off x="1000000" y="1000000"/>
    <a:ext cx="6000000" cy="2000000"/>
  </p:xfrm>
  <a:graphic>
    <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">
      <a:tbl>
        <a:tblGrid>
          <a:gridCol w="3000000"/>
          <a:gridCol w="3000000"/>
        </a:tblGrid>
        <a:tr h="500000">
          <a:tc>
            <a:txBody>
              <a:bodyPr/>
              <a:lstStyle/>
              <a:p>
                <a:r>
                  <a:t>Célula 1</a:t>
                </a:r>
              </a:p>
            </a:txBody>
          </a:tc>
          <a:tc>
            <a:txBody>
              <a:bodyPr/>
              <a:lstStyle/>
              <a:p>
                <a:r>
                  <a:t>Célula 2</a:t>
                </a:r>
              </a:p>
            </a:txBody>
          </a:tc>
        </a:tr>
      </a:tbl>
    </a:graphicData>
  </a:graphic>
</p:graphicFrame>
```

### Layouts de slide

```xml
<!-- Layout do slide de título -->
<p:sp>
  <p:nvSpPr>
    <p:nvPr>
      <p:ph type="ctrTitle"/>
    </p:nvPr>
  </p:nvSpPr>
  <!-- Conteúdo do título -->
</p:sp>

<p:sp>
  <p:nvSpPr>
    <p:nvPr>
      <p:ph type="subTitle" idx="1"/>
    </p:nvPr>
  </p:nvSpPr>
  <!-- Conteúdo do subtítulo -->
</p:sp>

<!-- Layout do slide de conteúdo -->
<p:sp>
  <p:nvSpPr>
    <p:nvPr>
      <p:ph type="title"/>
    </p:nvPr>
  </p:nvSpPr>
  <!-- Título do slide -->
</p:sp>

<p:sp>
  <p:nvSpPr>
    <p:nvPr>
      <p:ph type="body" idx="1"/>
    </p:nvPr>
  </p:nvSpPr>
  <!-- Corpo do conteúdo -->
</p:sp>
```

## Arquivos a atualizar

Ao acrescentar conteúdo, atualize estes arquivos:

**`ppt/_rels/presentation.xml.rels`:**
```xml
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>
```

**`ppt/slides/_rels/slide1.xml.rels`:**
```xml
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/>
```

**`[Content_Types].xml`:**
```xml
<Default Extension="png" ContentType="image/png"/>
<Default Extension="jpg" ContentType="image/jpeg"/>
<Override PartName="/ppt/slides/slide1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
```

**`ppt/presentation.xml`:**
```xml
<p:sldIdLst>
  <p:sldId id="256" r:id="rId1"/>
  <p:sldId id="257" r:id="rId2"/>
</p:sldIdLst>
```

**`docProps/app.xml`:** atualize a contagem de slides e as estatísticas
```xml
<Slides>2</Slides>
<Paragraphs>10</Paragraphs>
<Words>50</Words>
```

## Operações com slides

### Acrescentar um slide novo
Ao acrescentar um slide no fim da apresentação:

1. **Crie o arquivo do slide** (`ppt/slides/slideN.xml`)
2. **Atualize o `[Content_Types].xml`**: acrescente o Override do slide novo
3. **Atualize o `ppt/_rels/presentation.xml.rels`**: acrescente o relacionamento do slide novo
4. **Atualize o `ppt/presentation.xml`**: acrescente o ID do slide em `<p:sldIdLst>`
5. **Crie os relacionamentos do slide** (`ppt/slides/_rels/slideN.xml.rels`), se precisar
6. **Atualize o `docProps/app.xml`**: aumente a contagem de slides e atualize as estatísticas (se existir)

### Duplicar um slide
1. Copie o arquivo XML do slide de origem com um nome novo
2. Atualize todos os IDs do slide novo para que sejam únicos
3. Siga as etapas de "Acrescentar um slide novo" acima
4. **CRÍTICO**: remova ou atualize toda referência a slide de anotações nos arquivos `_rels`
5. Remova as referências a arquivos de mídia não usados

### Reordenar slides
1. **Atualize o `ppt/presentation.xml`**: reordene os elementos `<p:sldId>` em `<p:sldIdLst>`
2. A ordem dos elementos `<p:sldId>` determina a ordem dos slides
3. Mantenha os IDs dos slides e os IDs de relacionamento sem mudança

Exemplo:
```xml
<!-- Ordem original -->
<p:sldIdLst>
  <p:sldId id="256" r:id="rId2"/>
  <p:sldId id="257" r:id="rId3"/>
  <p:sldId id="258" r:id="rId4"/>
</p:sldIdLst>

<!-- Depois de mover o slide 3 para a posição 2 -->
<p:sldIdLst>
  <p:sldId id="256" r:id="rId2"/>
  <p:sldId id="258" r:id="rId4"/>
  <p:sldId id="257" r:id="rId3"/>
</p:sldIdLst>
```

### Excluir um slide
1. **Remova do `ppt/presentation.xml`**: exclua a entrada `<p:sldId>`
2. **Remova do `ppt/_rels/presentation.xml.rels`**: exclua o relacionamento
3. **Remova do `[Content_Types].xml`**: exclua a entrada Override
4. **Exclua os arquivos**: remova `ppt/slides/slideN.xml` e `ppt/slides/_rels/slideN.xml.rels`
5. **Atualize o `docProps/app.xml`**: diminua a contagem de slides e atualize as estatísticas
6. **Limpe as mídias não usadas**: remova as imagens órfãs de `ppt/media/`

Observação: não renumere os slides que sobraram; mantenha os IDs e os nomes de arquivo originais.


## Erros comuns a evitar

- **Codificações**: escape os caracteres Unicode no conteúdo ASCII: `"` vira `&#8220;`
- **Imagens**: acrescente em `ppt/media/` e atualize os arquivos de relacionamento
- **Listas**: tire os marcadores dos títulos de lista
- **IDs**: use valores hexadecimais válidos nos UUIDs
- **Temas**: confira as cores em todos os temas da pasta `theme`

## Checklist de validação para apresentações baseadas em template

### Antes de empacotar, sempre:
- **Limpe os recursos não usados**: remova mídias, fontes e pastas de anotações sem referência
- **Corrija o Content_Types.xml**: declare TODOS os slides, layouts e temas presentes no pacote
- **Corrija os IDs de relacionamento**: 
   - Remova as referências a fontes incorporadas se não usar fontes incorporadas
- **Remova as referências quebradas**: confira em todos os arquivos `_rels` se há referências a recursos excluídos

### Armadilhas comuns ao duplicar slides do template:
- Vários slides apontando para o mesmo slide de anotações depois da duplicação
- Referências a imagens/mídias de slides do template que não existem mais
- Referências a fontes incorporadas quando as fontes não foram incluídas
- Faltam declarações de slideLayout para os layouts 12–25
- A pasta docProps pode não ser desempacotada: ela é opcional