# Tutorial do PptxGenJS

## Configuração e estrutura básica

```javascript
const pptxgen = require("pptxgenjs");

let pres = new pptxgen();
pres.layout = 'LAYOUT_16x9';  // ou 'LAYOUT_16x10', 'LAYOUT_4x3', 'LAYOUT_WIDE'
pres.author = 'Seu Nome';
pres.title = 'Título da apresentação';

let slide = pres.addSlide();
slide.addText("Olá, mundo!", { x: 0.5, y: 0.5, fontSize: 36, color: "363636" });

pres.writeFile({ fileName: "Presentation.pptx" });
```

## Dimensões do layout

Dimensões do slide (coordenadas em polegadas; 1 polegada = 2,54 cm):
- `LAYOUT_16x9`: 10" × 5,625" (padrão)
- `LAYOUT_16x10`: 10" × 6,25"
- `LAYOUT_4x3`: 10" × 7,5"
- `LAYOUT_WIDE`: 13,3" × 7,5"

---

## Texto e formatação

```javascript
// Texto básico
slide.addText("Texto simples", {
  x: 1, y: 1, w: 8, h: 2, fontSize: 24, fontFace: "Arial",
  color: "363636", bold: true, align: "center", valign: "middle"
});

// Espaçamento entre caracteres (use charSpacing, não letterSpacing, que é ignorado sem aviso)
slide.addText("TEXTO ESPAÇADO", { x: 1, y: 1, w: 8, h: 1, charSpacing: 6 });

// Arrays de texto rico
slide.addText([
  { text: "Negrito ", options: { bold: true } },
  { text: "Itálico ", options: { italic: true } }
], { x: 1, y: 3, w: 8, h: 1 });

// Texto em várias linhas (exige breakLine: true)
slide.addText([
  { text: "Linha 1", options: { breakLine: true } },
  { text: "Linha 2", options: { breakLine: true } },
  { text: "Linha 3" }  // O último item não precisa de breakLine
], { x: 0.5, y: 0.5, w: 8, h: 2 });

// Margem da caixa de texto (margem interna)
slide.addText("Título", {
  x: 0.5, y: 0.3, w: 9, h: 0.6,
  margin: 0  // Use 0 ao alinhar o texto com outros elementos, como formas ou ícones
});
```

**Dica:** as caixas de texto têm margem interna por padrão. Defina `margin: 0` quando precisar que o texto se alinhe com precisão a formas, linhas ou ícones na mesma posição x.

---

## Listas e marcadores

```javascript
// ✅ CORRETO: vários marcadores
slide.addText([
  { text: "Primeiro item", options: { bullet: true, breakLine: true } },
  { text: "Segundo item", options: { bullet: true, breakLine: true } },
  { text: "Terceiro item", options: { bullet: true } }
], { x: 0.5, y: 0.5, w: 8, h: 3 });

// ❌ ERRADO: nunca use marcadores Unicode
slide.addText("• Primeiro item", { ... });  // Cria marcadores duplicados

// Subitens e listas numeradas
{ text: "Subitem", options: { bullet: true, indentLevel: 1 } }
{ text: "Primeiro", options: { bullet: { type: "number" }, breakLine: true } }
```

---

## Formas

```javascript
slide.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 0.8, w: 1.5, h: 3.0,
  fill: { color: "FF0000" }, line: { color: "000000", width: 2 }
});

slide.addShape(pres.shapes.OVAL, { x: 4, y: 1, w: 2, h: 2, fill: { color: "0000FF" } });

slide.addShape(pres.shapes.LINE, {
  x: 1, y: 3, w: 5, h: 0, line: { color: "FF0000", width: 3, dashType: "dash" }
});

// Com transparência
slide.addShape(pres.shapes.RECTANGLE, {
  x: 1, y: 1, w: 3, h: 2,
  fill: { color: "0088CC", transparency: 50 }
});

// Retângulo arredondado (rectRadius só funciona com ROUNDED_RECTANGLE, não com RECTANGLE)
// ⚠️ Não combine com sobreposições retangulares de destaque: elas não cobrem os cantos arredondados. Use RECTANGLE.
slide.addShape(pres.shapes.ROUNDED_RECTANGLE, {
  x: 1, y: 1, w: 3, h: 2,
  fill: { color: "FFFFFF" }, rectRadius: 0.1
});

// Com sombra
slide.addShape(pres.shapes.RECTANGLE, {
  x: 1, y: 1, w: 3, h: 2,
  fill: { color: "FFFFFF" },
  shadow: { type: "outer", color: "000000", blur: 6, offset: 2, angle: 135, opacity: 0.15 }
});
```

Opções de sombra:

| Propriedade | Tipo | Faixa | Observações |
|----------|------|-------|-------|
| `type` | string | `"outer"`, `"inner"` | |
| `color` | string | hex de 6 caracteres (ex.: `"000000"`) | Sem o prefixo `#` e sem hex de 8 caracteres: veja Armadilhas comuns |
| `blur` | number | 0-100 pt | |
| `offset` | number | 0-200 pt | **Não pode ser negativo**: valores negativos corrompem o arquivo |
| `angle` | number | 0-359 graus | Direção para onde a sombra cai (135 = embaixo à direita, 270 = para cima) |
| `opacity` | number | 0.0-1.0 | Use isto para a transparência; nunca a codifique na string da cor |

Para projetar a sombra para cima (ex.: numa barra de rodapé), use `angle: 270` com offset positivo; **não** use offset negativo.

**Observação**: preenchimentos em gradiente não são aceitos de forma nativa. Use uma imagem em gradiente como fundo.

---

## Imagens

### Origens da imagem

```javascript
// De um caminho de arquivo
slide.addImage({ path: "images/chart.png", x: 1, y: 1, w: 5, h: 3 });

// De uma URL
slide.addImage({ path: "https://example.com/image.jpg", x: 1, y: 1, w: 5, h: 3 });

// De base64 (mais rápido, sem leitura de arquivo)
slide.addImage({ data: "image/png;base64,iVBORw0KGgo...", x: 1, y: 1, w: 5, h: 3 });
```

### Opções de imagem

```javascript
slide.addImage({
  path: "image.png",
  x: 1, y: 1, w: 5, h: 3,
  rotate: 45,              // 0-359 graus
  rounding: true,          // Recorte circular
  transparency: 50,        // 0-100
  flipH: true,             // Espelhamento horizontal
  flipV: false,            // Espelhamento vertical
  altText: "Descrição",  // Acessibilidade
  hyperlink: { url: "https://example.com" }
});
```

### Modos de dimensionamento da imagem

```javascript
// Contain: cabe dentro, mantém a proporção
{ sizing: { type: 'contain', w: 4, h: 3 } }

// Cover: preenche a área, mantém a proporção (pode cortar)
{ sizing: { type: 'cover', w: 4, h: 3 } }

// Crop: recorta um trecho específico
{ sizing: { type: 'crop', x: 0.5, y: 0.5, w: 2, h: 2 } }
```

### Calcular as dimensões (mantendo a proporção)

```javascript
const origWidth = 1978, origHeight = 923, maxHeight = 3.0;
const calcWidth = maxHeight * (origWidth / origHeight);
const centerX = (10 - calcWidth) / 2;

slide.addImage({ path: "image.png", x: centerX, y: 1.2, w: calcWidth, h: maxHeight });
```

### Formatos aceitos

- **Padrão**: PNG, JPG, GIF (GIFs animados funcionam no Microsoft 365)
- **SVG**: funciona no PowerPoint moderno/Microsoft 365

---

## Ícones

Use o react-icons para gerar ícones em SVG e depois rasterize em PNG, para funcionar em qualquer lugar.

### Configuração

```javascript
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const { FaCheckCircle, FaChartLine } = require("react-icons/fa");

function renderIconSvg(IconComponent, color = "#000000", size = 256) {
  return ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color, size: String(size) })
  );
}

async function iconToBase64Png(IconComponent, color, size = 256) {
  const svg = renderIconSvg(IconComponent, color, size);
  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}
```

### Adicionar o ícone ao slide

```javascript
const iconData = await iconToBase64Png(FaCheckCircle, "#4472C4", 256);

slide.addImage({
  data: iconData,
  x: 1, y: 1, w: 0.5, h: 0.5  // Tamanho em polegadas
});
```

**Observação**: use tamanho 256 ou maior para ícones nítidos. O parâmetro size controla a resolução da rasterização, não o tamanho exibido no slide (que é definido por `w` e `h`, em polegadas).

### Bibliotecas de ícones

Instale: `npm install -g react-icons react react-dom sharp`

Conjuntos de ícones populares no react-icons:
- `react-icons/fa`: Font Awesome
- `react-icons/md`: Material Design
- `react-icons/hi`: Heroicons
- `react-icons/bi`: Bootstrap Icons

---

## Fundos do slide

```javascript
// Cor sólida
slide.background = { color: "F1F1F1" };

// Cor com transparência
slide.background = { color: "FF3399", transparency: 50 };

// Imagem de uma URL
slide.background = { path: "https://example.com/bg.jpg" };

// Imagem em base64
slide.background = { data: "image/png;base64,iVBORw0KGgo..." };
```

---

## Tabelas

```javascript
slide.addTable([
  ["Cabeçalho 1", "Cabeçalho 2"],
  ["Célula 1", "Célula 2"]
], {
  x: 1, y: 1, w: 8, h: 2,
  border: { pt: 1, color: "999999" }, fill: { color: "F1F1F1" }
});

// Avançada, com células mescladas
let tableData = [
  [{ text: "Cabeçalho", options: { fill: { color: "6699CC" }, color: "FFFFFF", bold: true } }, "Célula"],
  [{ text: "Mesclada", options: { colspan: 2 } }]
];
slide.addTable(tableData, { x: 1, y: 3.5, w: 8, colW: [4, 4] });
```

---

## Gráficos

```javascript
// Gráfico de barras
slide.addChart(pres.charts.BAR, [{
  name: "Vendas", labels: ["T1", "T2", "T3", "T4"], values: [4500, 5500, 6200, 7100]
}], {
  x: 0.5, y: 0.6, w: 6, h: 3, barDir: 'col',
  showTitle: true, title: 'Vendas por trimestre'
});

// Gráfico de linhas
slide.addChart(pres.charts.LINE, [{
  name: "Temp", labels: ["Jan", "Fev", "Mar"], values: [32, 35, 42]
}], { x: 0.5, y: 4, w: 6, h: 3, lineSize: 3, lineSmooth: true });

// Gráfico de pizza
slide.addChart(pres.charts.PIE, [{
  name: "Participação", labels: ["A", "B", "Outros"], values: [35, 45, 20]
}], { x: 7, y: 1, w: 5, h: 4, showPercent: true });
```

### Gráficos com visual melhor

Os gráficos padrão parecem datados. Aplique estas opções para um visual moderno e limpo:

```javascript
slide.addChart(pres.charts.BAR, chartData, {
  x: 0.5, y: 1, w: 9, h: 4, barDir: "col",

  // Cores próprias (combine com a paleta da apresentação)
  chartColors: ["0D9488", "14B8A6", "5EEAD4"],

  // Fundo limpo
  chartArea: { fill: { color: "FFFFFF" }, roundedCorners: true },

  // Rótulos dos eixos discretos
  catAxisLabelColor: "64748B",
  valAxisLabelColor: "64748B",

  // Grade sutil (só no eixo de valores)
  valGridLine: { color: "E2E8F0", size: 0.5 },
  catGridLine: { style: "none" },

  // Rótulos de dados nas barras
  showValue: true,
  dataLabelPosition: "outEnd",
  dataLabelColor: "1E293B",

  // Esconde a legenda em série única
  showLegend: false,
});
```

**Principais opções de estilo:**
- `chartColors: [...]`: cores hex das séries/fatias
- `chartArea: { fill, border, roundedCorners }`: fundo do gráfico
- `catGridLine/valGridLine: { color, style, size }`: linhas de grade (`style: "none"` para esconder)
- `lineSmooth: true`: linhas curvas (gráficos de linhas)
- `legendPos: "r"`: posição da legenda: "b", "t", "l", "r", "tr"

---

## Slides mestres

```javascript
pres.defineSlideMaster({
  title: 'TITLE_SLIDE', background: { color: '283A5E' },
  objects: [{
    placeholder: { options: { name: 'title', type: 'title', x: 1, y: 2, w: 8, h: 2 } }
  }]
});

let titleSlide = pres.addSlide({ masterName: "TITLE_SLIDE" });
titleSlide.addText("Meu título", { placeholder: "title" });
```

---

## Armadilhas comuns

⚠️ Estes problemas corrompem o arquivo, causam bugs visuais ou estragam o resultado. Evite-os.

1. **NUNCA use "#" nas cores hex**: corrompe o arquivo
   ```javascript
   color: "FF0000"      // ✅ CORRETO
   color: "#FF0000"     // ❌ ERRADO
   ```

2. **NUNCA codifique a opacidade na string da cor hex**: cores de 8 caracteres (ex.: `"00000020"`) corrompem o arquivo. Use a propriedade `opacity`.
   ```javascript
   shadow: { type: "outer", blur: 6, offset: 2, color: "00000020" }          // ❌ CORROMPE O ARQUIVO
   shadow: { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.12 }  // ✅ CORRETO
   ```

3. **Use `bullet: true`**: NUNCA símbolos Unicode como "•" (cria marcadores duplicados)

4. **Use `breakLine: true`** entre os itens do array ou entre runs de texto

5. **Evite `lineSpacing` com marcadores**: cria espaços excessivos; use `paraSpaceAfter`

6. **Cada apresentação precisa de uma instância nova**: não reaproveite objetos `pptxgen()`

7. **NUNCA reaproveite objetos de opções entre chamadas**: o PptxGenJS altera os objetos no lugar (ex.: converte os valores da sombra em EMU). Compartilhar um objeto entre várias chamadas corrompe a segunda forma.
   ```javascript
   const shadow = { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 };
   slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });  // ❌ a segunda chamada recebe valores já convertidos
   slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });

   const makeShadow = () => ({ type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 });
   slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });  // ✅ objeto novo a cada vez
   slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });
   ```

8. **Não use `ROUNDED_RECTANGLE` com bordas de destaque**: barras retangulares sobrepostas não cobrem os cantos arredondados. Use `RECTANGLE`.
   ```javascript
   // ❌ ERRADO: a barra de destaque não cobre os cantos arredondados
   slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 1, y: 1, w: 3, h: 1.5, fill: { color: "FFFFFF" } });
   slide.addShape(pres.shapes.RECTANGLE, { x: 1, y: 1, w: 0.08, h: 1.5, fill: { color: "0891B2" } });

   // ✅ CORRETO: use RECTANGLE para um alinhamento limpo
   slide.addShape(pres.shapes.RECTANGLE, { x: 1, y: 1, w: 3, h: 1.5, fill: { color: "FFFFFF" } });
   slide.addShape(pres.shapes.RECTANGLE, { x: 1, y: 1, w: 0.08, h: 1.5, fill: { color: "0891B2" } });
   ```

---

## Referência rápida

- **Formas**: RECTANGLE, OVAL, LINE, ROUNDED_RECTANGLE
- **Gráficos**: BAR, LINE, PIE, DOUGHNUT, SCATTER, BUBBLE, RADAR
- **Layouts**: LAYOUT_16x9 (10"×5,625"), LAYOUT_16x10, LAYOUT_4x3, LAYOUT_WIDE
- **Alinhamento**: "left", "center", "right"
- **Rótulos de dados do gráfico**: "outEnd", "inEnd", "center"
