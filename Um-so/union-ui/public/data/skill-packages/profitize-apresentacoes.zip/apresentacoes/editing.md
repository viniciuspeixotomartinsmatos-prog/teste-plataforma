# Editar apresentações

## Fluxo baseado em template

Ao usar uma apresentação existente como template:

1. **Analise os slides existentes**:
   ```bash
   python scripts/thumbnail.py template.pptx
   python -m markitdown template.pptx
   ```
   Veja o `thumbnails.jpg` para conhecer os layouts e a saída do markitdown para ver o texto de placeholder (o "espaço reservado" do PowerPoint).

2. **Planeje o mapeamento dos slides**: para cada seção de conteúdo, escolha um slide do template.

   ⚠️ **USE LAYOUTS VARIADOS**: apresentações monótonas são um erro comum. Não caia no básico título + tópicos por padrão. Procure ativamente:
   - Layouts com várias colunas (2 colunas, 3 colunas)
   - Combinações de imagem + texto
   - Imagens sangradas com texto por cima
   - Slides de citação ou de destaque
   - Divisórias de seção
   - Números em destaque
   - Grades de ícones ou linhas de ícone + texto

   **Evite:** repetir o mesmo layout cheio de texto em todos os slides.

   Combine o tipo de conteúdo com o estilo do layout (ex.: pontos-chave → slide de tópicos, informações da equipe → várias colunas, depoimentos → slide de citação).

3. **Desempacote**: `python scripts/office/unpack.py template.pptx unpacked/`

4. **Monte a apresentação** (faça isso você mesmo, não com subagentes):
   - Exclua os slides indesejados (tire de `<p:sldIdLst>`)
   - Duplique os slides que quer reaproveitar (`add_slide.py`)
   - Reordene os slides em `<p:sldIdLst>`
   - **Conclua todas as mudanças estruturais antes da etapa 5**

5. **Edite o conteúdo**: atualize o texto em cada `slide{N}.xml`.
   **Use subagentes aqui, se houver**: os slides são arquivos XML separados, então os subagentes podem editar em paralelo.

6. **Limpe**: `python scripts/clean.py unpacked/`

7. **Empacote**: `python scripts/office/pack.py unpacked/ output.pptx --original template.pptx`

---

## Scripts

| Script | Finalidade |
|--------|---------|
| `unpack.py` | Extrai o PPTX e formata com indentação |
| `add_slide.py` | Duplica um slide ou cria a partir de um layout |
| `clean.py` | Remove arquivos órfãos |
| `pack.py` | Reempacota com validação |
| `thumbnail.py` | Cria uma grade visual dos slides |

### unpack.py

```bash
python scripts/office/unpack.py input.pptx unpacked/
```

Extrai o PPTX, formata o XML com indentação e escapa as aspas curvas (as "aspas inteligentes" do Word).

### add_slide.py

```bash
python scripts/add_slide.py unpacked/ slide2.xml      # Duplica o slide
python scripts/add_slide.py unpacked/ slideLayout2.xml # A partir do layout
```

Imprime o `<p:sldId>` a acrescentar em `<p:sldIdLst>` na posição desejada.

### clean.py

```bash
python scripts/clean.py unpacked/
```

Remove os slides que não estão em `<p:sldIdLst>`, as mídias sem referência e os rels órfãos.

### pack.py

```bash
python scripts/office/pack.py unpacked/ output.pptx --original input.pptx
```

Valida, repara, compacta o XML e recodifica as aspas curvas.

### thumbnail.py

```bash
python scripts/thumbnail.py input.pptx [output_prefix] [--cols N]
```

Cria o `thumbnails.jpg` com os nomes dos arquivos dos slides como rótulos. Por padrão, 3 colunas e no máximo 12 por grade.

**Use só para analisar o template** (escolher layouts). Para o QA visual, use `soffice` + `pdftoppm` para criar imagens individuais dos slides em resolução cheia: veja o SKILL.md.

---

## Operações com slides

A ordem dos slides fica em `ppt/presentation.xml` → `<p:sldIdLst>`.

**Reordenar**: reorganize os elementos `<p:sldId>`.

**Excluir**: remova o `<p:sldId>` e depois execute o `clean.py`.

**Acrescentar**: use o `add_slide.py`. Nunca copie arquivos de slide à mão: o script cuida das referências às anotações, do Content_Types.xml e dos IDs de relacionamento, que a cópia manual deixa passar.

---

## Editar o conteúdo

**Subagentes:** se houver, use-os aqui (depois de concluir a etapa 4). Cada slide é um arquivo XML separado, então os subagentes podem editar em paralelo. No seu prompt para os subagentes, inclua:
- O(s) caminho(s) do(s) arquivo(s) de slide a editar
- **"Use a ferramenta Edit para todas as mudanças"**
- As regras de formatação e as armadilhas comuns abaixo

Para cada slide:
1. Leia o XML do slide
2. Identifique TODO o conteúdo de placeholder: texto, imagens, gráficos, ícones, legendas
3. Troque cada placeholder pelo conteúdo final

**Use a ferramenta Edit, não sed nem scripts Python.** A ferramenta Edit obriga a dizer exatamente o que trocar e onde, o que dá mais confiabilidade.

### Regras de formatação

- **Ponha em negrito todos os títulos, subtítulos e rótulos no meio do texto**: use `b="1"` no `<a:rPr>`. Isso inclui:
  - Títulos dos slides
  - Títulos de seção dentro de um slide
  - Rótulos no início de uma linha, como (ex.: "Status:", "Descrição:")
- **Nunca use marcadores Unicode (•)**: use a formatação de lista correta com `<a:buChar>` ou `<a:buAutoNum>`
- **Consistência dos marcadores**: deixe os marcadores herdarem do layout. Especifique só `<a:buChar>` ou `<a:buNone>`.

---

## Armadilhas comuns

### Adaptar o template

Quando o conteúdo de origem tem menos itens que o template:
- **Remova os elementos a mais por inteiro** (imagens, formas, caixas de texto), não só limpe o texto
- Confira se sobraram elementos visuais órfãos depois de limpar o texto
- Faça o QA visual para pegar contagens que não batem

Ao trocar um texto por outro de tamanho diferente:
- **Trocas mais curtas**: costumam ser seguras
- **Trocas mais longas**: podem transbordar ou quebrar a linha de forma inesperada
- Teste com o QA visual depois de mudar o texto
- Considere encurtar ou dividir o conteúdo para caber nas restrições de design do template

**Espaços do template ≠ itens da origem**: se o template tem 4 membros da equipe e a origem tem 3 pessoas, exclua o grupo inteiro do 4º membro (imagem + caixas de texto), não só o texto.

### Conteúdo com vários itens

Se a origem tem vários itens (listas numeradas, várias seções), crie um elemento `<a:p>` separado para cada um: **nunca junte tudo numa string só**.

**❌ ERRADO**: todos os itens num parágrafo só:
```xml
<a:p>
  <a:r><a:rPr .../><a:t>Etapa 1: Faça a primeira coisa. Etapa 2: Faça a segunda coisa.</a:t></a:r>
</a:p>
```

**✅ CORRETO**: parágrafos separados com títulos em negrito:
```xml
<a:p>
  <a:pPr algn="l"><a:lnSpc><a:spcPts val="3919"/></a:lnSpc></a:pPr>
  <a:r><a:rPr lang="en-US" sz="2799" b="1" .../><a:t>Etapa 1</a:t></a:r>
</a:p>
<a:p>
  <a:pPr algn="l"><a:lnSpc><a:spcPts val="3919"/></a:lnSpc></a:pPr>
  <a:r><a:rPr lang="en-US" sz="2799" .../><a:t>Faça a primeira coisa.</a:t></a:r>
</a:p>
<a:p>
  <a:pPr algn="l"><a:lnSpc><a:spcPts val="3919"/></a:lnSpc></a:pPr>
  <a:r><a:rPr lang="en-US" sz="2799" b="1" .../><a:t>Etapa 2</a:t></a:r>
</a:p>
<!-- continue o padrão -->
```

Copie o `<a:pPr>` do parágrafo original para manter o espaçamento entre linhas. Use `b="1"` nos títulos.

### Aspas curvas

O unpack/pack cuida delas automaticamente. Mas a ferramenta Edit converte as aspas curvas em ASCII.

**Ao acrescentar texto novo com aspas, use entidades XML:**

```xml
<a:t>o &#x201C;Contrato&#x201D;</a:t>
```

| Caractere | Nome | Unicode | Entidade XML |
|-----------|------|---------|------------|
| `“` | Aspas duplas de abertura | U+201C | `&#x201C;` |
| `”` | Aspas duplas de fechamento | U+201D | `&#x201D;` |
| `‘` | Aspas simples de abertura | U+2018 | `&#x2018;` |
| `’` | Aspas simples de fechamento | U+2019 | `&#x2019;` |

### Outros

- **Espaços em branco**: use `xml:space="preserve"` no `<a:t>` com espaços no início ou no fim
- **Análise de XML**: use `defusedxml.minidom`, não `xml.etree.ElementTree` (corrompe os namespaces)
