# Tutorial da biblioteca DOCX

Gere arquivos .docx com JavaScript/TypeScript.

**Importante: leia este documento inteiro antes de começar.** As regras críticas de formatação e as armadilhas comuns aparecem ao longo de todo o texto; pular seções pode gerar arquivos corrompidos ou problemas de renderização.

## Configuração
Parte do princípio de que o docx já está instalado globalmente
Se não estiver: `npm install -g docx`

```javascript
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, Media, 
        Header, Footer, AlignmentType, PageOrientation, LevelFormat, ExternalHyperlink, 
        InternalHyperlink, TableOfContents, HeadingLevel, BorderStyle, WidthType, TabStopType, 
        TabStopPosition, UnderlineType, ShadingType, VerticalAlign, SymbolRun, PageNumber,
        FootnoteReferenceRun, Footnote, PageBreak } = require('docx');

// Criar e salvar
const doc = new Document({ sections: [{ children: [/* conteúdo */] }] });
Packer.toBuffer(doc).then(buffer => fs.writeFileSync("doc.docx", buffer)); // Node.js
Packer.toBlob(doc).then(blob => { /* lógica de download */ }); // Navegador
```

## Texto e formatação
```javascript
// IMPORTANTE: nunca use \n para quebrar linha; sempre use elementos Paragraph separados
// ❌ ERRADO: new TextRun("Linha 1\nLinha 2")
// ✅ CORRETO: new Paragraph({ children: [new TextRun("Linha 1")] }), new Paragraph({ children: [new TextRun("Linha 2")] })

// Texto básico com todas as opções de formatação
new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { before: 200, after: 200 },
  indent: { left: 720, right: 720 },
  children: [
    new TextRun({ text: "Negrito", bold: true }),
    new TextRun({ text: "Itálico", italics: true }),
    new TextRun({ text: "Sublinhado", underline: { type: UnderlineType.DOUBLE, color: "FF0000" } }),
    new TextRun({ text: "Colorido", color: "FF0000", size: 28, font: "Arial" }), // Arial como padrão
    new TextRun({ text: "Realçado", highlight: "yellow" }),
    new TextRun({ text: "Tachado", strike: true }),
    new TextRun({ text: "x2", superScript: true }),
    new TextRun({ text: "H2O", subScript: true }),
    new TextRun({ text: "VERSALETE", smallCaps: true }),
    new SymbolRun({ char: "2022", font: "Symbol" }), // Marcador •
    new SymbolRun({ char: "00A9", font: "Arial" })   // Copyright ©: Arial para símbolos
  ]
})
```

## Estilos e formatação profissional

```javascript
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 24 } } }, // 12 pt como padrão
    paragraphStyles: [
      // Estilo do título do documento: sobrescreve o estilo nativo Title
      { id: "Title", name: "Title", basedOn: "Normal",
        run: { size: 56, bold: true, color: "000000", font: "Arial" },
        paragraph: { spacing: { before: 240, after: 120 }, alignment: AlignmentType.CENTER } },
      // IMPORTANTE: sobrescreva os estilos de título nativos usando os IDs exatos deles
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, color: "000000", font: "Arial" }, // 16 pt
        paragraph: { spacing: { before: 240, after: 240 }, outlineLevel: 0 } }, // Obrigatório para o sumário
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, color: "000000", font: "Arial" }, // 14 pt
        paragraph: { spacing: { before: 180, after: 180 }, outlineLevel: 1 } },
      // Estilos personalizados usam IDs próprios
      { id: "myStyle", name: "My Style", basedOn: "Normal",
        run: { size: 28, bold: true, color: "000000" },
        paragraph: { spacing: { after: 120 }, alignment: AlignmentType.CENTER } }
    ],
    characterStyles: [{ id: "myCharStyle", name: "My Char Style",
      run: { color: "FF0000", bold: true, underline: { type: UnderlineType.SINGLE } } }]
  },
  sections: [{
    properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    children: [
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("Título do documento")] }), // Usa o estilo Title sobrescrito
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Título 1")] }), // Usa o estilo Heading1 sobrescrito
      new Paragraph({ style: "myStyle", children: [new TextRun("Estilo de parágrafo personalizado")] }),
      new Paragraph({ children: [
        new TextRun("Normal com "),
        new TextRun({ text: "estilo de caractere personalizado", style: "myCharStyle" })
      ]})
    ]
  }]
});
```

**Combinações de fontes profissionais:**
- **Arial (títulos) + Arial (corpo)**: a mais aceita em todo lugar, limpa e profissional
- **Times New Roman (títulos) + Arial (corpo)**: títulos clássicos com serifa e corpo moderno sem serifa
- **Georgia (títulos) + Verdana (corpo)**: otimizada para leitura na tela, com contraste elegante

**Princípios de estilo:**
- **Sobrescreva os estilos nativos**: use os IDs exatos, como "Heading1", "Heading2", "Heading3", para sobrescrever os estilos de título nativos do Word (Título 1, Título 2 e Título 3 no Word em português)
- **Constantes HeadingLevel**: `HeadingLevel.HEADING_1` usa o estilo "Heading1", `HeadingLevel.HEADING_2` usa o estilo "Heading2" etc.
- **Inclua o outlineLevel**: defina `outlineLevel: 0` no H1, `outlineLevel: 1` no H2 etc. para o sumário (TOC) funcionar direito
- **Use estilos personalizados** em vez de formatação direta, para manter a consistência
- **Defina uma fonte padrão** com `styles.default.document.run.font`: a Arial é aceita em todo lugar
- **Crie hierarquia visual** com tamanhos de fonte diferentes (título do documento > títulos > corpo)
- **Adicione o espaçamento certo** com o espaçamento de parágrafo `before` e `after`
- **Use cores com moderação**: prefira preto (000000) e tons de cinza no título do documento e nos títulos (heading 1, heading 2 etc.)
- **Use margens consistentes** (1440 = 1 polegada (2,54 cm) é o padrão)


## Listas (SEMPRE USE LISTAS DE VERDADE: NUNCA USE MARCADORES UNICODE)
```javascript
// Marcadores: SEMPRE use a configuração de numeração, NÃO símbolos Unicode
// CRÍTICO: use a constante LevelFormat.BULLET, NÃO a string "bullet"
const doc = new Document({
  numbering: {
    config: [
      { reference: "bullet-list",
        levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "first-numbered-list",
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "second-numbered-list", // Outra reference = recomeça em 1
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }
    ]
  },
  sections: [{
    children: [
      // Itens da lista com marcadores
      new Paragraph({ numbering: { reference: "bullet-list", level: 0 },
        children: [new TextRun("Primeiro tópico")] }),
      new Paragraph({ numbering: { reference: "bullet-list", level: 0 },
        children: [new TextRun("Segundo tópico")] }),
      // Itens da lista numerada
      new Paragraph({ numbering: { reference: "first-numbered-list", level: 0 },
        children: [new TextRun("Primeiro item numerado")] }),
      new Paragraph({ numbering: { reference: "first-numbered-list", level: 0 },
        children: [new TextRun("Segundo item numerado")] }),
      // ⚠️ CRÍTICO: outra reference = lista INDEPENDENTE, que recomeça em 1
      // A mesma reference = CONTINUA a numeração anterior
      new Paragraph({ numbering: { reference: "second-numbered-list", level: 0 },
        children: [new TextRun("Começa em 1 de novo (porque a reference é outra)")] })
    ]
  }]
});

// ⚠️ REGRA CRÍTICA DE NUMERAÇÃO: cada reference cria uma lista numerada INDEPENDENTE
// - A mesma reference = continua a numeração (1, 2, 3... depois 4, 5, 6...)
// - Outra reference = recomeça em 1 (1, 2, 3... depois 1, 2, 3...)
// Use um nome de reference único para cada seção numerada separada!

// ⚠️ CRÍTICO: NUNCA use marcadores Unicode: eles criam listas falsas que não funcionam direito
// new TextRun("• Item")           // ERRADO
// new SymbolRun({ char: "2022" }) // ERRADO
// ✅ SEMPRE use a configuração de numeração com LevelFormat.BULLET para listas de verdade do Word
```

## Tabelas
```javascript
// Tabela completa com margens, bordas, linha de cabeçalho e marcadores
const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };

new Table({
  columnWidths: [4680, 4680], // ⚠️ CRÍTICO: defina a largura das colunas na tabela; valores em DXA (vigésimos de ponto)
  margins: { top: 100, bottom: 100, left: 180, right: 180 }, // Definido uma vez para todas as células
  rows: [
    new TableRow({
      tableHeader: true,
      children: [
        new TableCell({
          borders: cellBorders,
          width: { size: 4680, type: WidthType.DXA }, // Defina TAMBÉM a largura em cada célula
          // ⚠️ CRÍTICO: sempre use ShadingType.CLEAR para evitar fundo preto no Word.
          shading: { fill: "D5E8F0", type: ShadingType.CLEAR }, 
          verticalAlign: VerticalAlign.CENTER,
          children: [new Paragraph({ 
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: "Cabeçalho", bold: true, size: 22 })]
          })]
        }),
        new TableCell({
          borders: cellBorders,
          width: { size: 4680, type: WidthType.DXA }, // Defina TAMBÉM a largura em cada célula
          shading: { fill: "D5E8F0", type: ShadingType.CLEAR },
          children: [new Paragraph({ 
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: "Tópicos", bold: true, size: 22 })]
          })]
        })
      ]
    }),
    new TableRow({
      children: [
        new TableCell({
          borders: cellBorders,
          width: { size: 4680, type: WidthType.DXA }, // Defina TAMBÉM a largura em cada célula
          children: [new Paragraph({ children: [new TextRun("Dado comum")] })]
        }),
        new TableCell({
          borders: cellBorders,
          width: { size: 4680, type: WidthType.DXA }, // Defina TAMBÉM a largura em cada célula
          children: [
            new Paragraph({ 
              numbering: { reference: "bullet-list", level: 0 },
              children: [new TextRun("Primeiro tópico")] 
            }),
            new Paragraph({ 
              numbering: { reference: "bullet-list", level: 0 },
              children: [new TextRun("Segundo tópico")] 
            })
          ]
        })
      ]
    })
  ]
})
```

**IMPORTANTE: largura e bordas da tabela**
- Use TANTO o array `columnWidths: [width1, width2, ...]` QUANTO `width: { size: X, type: WidthType.DXA }` em cada célula
- Valores em DXA (vigésimos de ponto): 1440 = 1 polegada; a largura útil do US Letter (o Carta do Word) = 9360 DXA (com margens de 1")
- Aplique as bordas a cada elemento `TableCell`, NÃO à `Table` em si

**Larguras de coluna pré-calculadas (tamanho Letter com margens de 1" = 9360 DXA no total):**
- **2 colunas:** `columnWidths: [4680, 4680]` (larguras iguais)
- **3 colunas:** `columnWidths: [3120, 3120, 3120]` (larguras iguais)

## Links e navegação
```javascript
// Sumário (exige títulos); CRÍTICO: use só HeadingLevel, NÃO estilos personalizados
// ❌ ERRADO: new Paragraph({ heading: HeadingLevel.HEADING_1, style: "customHeader", children: [new TextRun("Título")] })
// ✅ CORRETO: new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Título")] })
new TableOfContents("Sumário", { hyperlink: true, headingStyleRange: "1-3" }),

// Link externo
new Paragraph({
  children: [new ExternalHyperlink({
    children: [new TextRun({ text: "Google", style: "Hyperlink" })],
    link: "https://www.google.com"
  })]
}),

// Link interno e indicador
new Paragraph({
  children: [new InternalHyperlink({
    children: [new TextRun({ text: "Ir para a seção", style: "Hyperlink" })],
    anchor: "section1"
  })]
}),
new Paragraph({
  children: [new TextRun("Conteúdo da seção")],
  bookmark: { id: "section1", name: "section1" }
}),
```

## Imagens e mídia
```javascript
// Imagem básica com tamanho e posição
// CRÍTICO: sempre informe o parâmetro 'type': ele é OBRIGATÓRIO no ImageRun
new Paragraph({
  alignment: AlignmentType.CENTER,
  children: [new ImageRun({
    type: "png", // REQUISITO NOVO: informe o tipo da imagem (png, jpg, jpeg, gif, bmp, svg)
    data: fs.readFileSync("image.png"),
    transformation: { width: 200, height: 150, rotation: 0 }, // rotação em graus
    altText: { title: "Logo", description: "Logo da empresa", name: "Nome" } // IMPORTANTE: os três campos são obrigatórios
  })]
})
```

## Quebras de página
```javascript
// Quebra de página manual
new Paragraph({ children: [new PageBreak()] }),

// Quebra de página antes do parágrafo
new Paragraph({
  pageBreakBefore: true,
  children: [new TextRun("Isto começa numa página nova")]
})

// ⚠️ CRÍTICO: NUNCA use PageBreak solto: ele gera um XML inválido que o Word não abre
// ❌ ERRADO: new PageBreak() 
// ✅ CORRETO: new Paragraph({ children: [new PageBreak()] })
```

## Cabeçalhos, rodapés e configuração da página
```javascript
const doc = new Document({
  sections: [{
    properties: {
      page: {
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }, // 1440 = 1 polegada
        size: { orientation: PageOrientation.LANDSCAPE },
        pageNumbers: { start: 1, formatType: "decimal" } // "upperRoman", "lowerRoman", "upperLetter", "lowerLetter"
      }
    },
    headers: {
      default: new Header({ children: [new Paragraph({ 
        alignment: AlignmentType.RIGHT,
        children: [new TextRun("Texto do cabeçalho")]
      })] })
    },
    footers: {
      default: new Footer({ children: [new Paragraph({ 
        alignment: AlignmentType.CENTER,
        children: [new TextRun("Página "), new TextRun({ children: [PageNumber.CURRENT] }), new TextRun(" de "), new TextRun({ children: [PageNumber.TOTAL_PAGES] })]
      })] })
    },
    children: [/* conteúdo */]
  }]
});
```

## Tabulações
```javascript
new Paragraph({
  tabStops: [
    { type: TabStopType.LEFT, position: TabStopPosition.MAX / 4 },
    { type: TabStopType.CENTER, position: TabStopPosition.MAX / 2 },
    { type: TabStopType.RIGHT, position: TabStopPosition.MAX * 3 / 4 }
  ],
  children: [new TextRun("Esquerda\tCentro\tDireita")]
})
```

## Constantes e referência rápida
- **Sublinhados:** `SINGLE`, `DOUBLE`, `WAVY`, `DASH`
- **Bordas:** `SINGLE`, `DOUBLE`, `DASHED`, `DOTTED`  
- **Numeração:** `DECIMAL` (1,2,3), `UPPER_ROMAN` (I,II,III), `LOWER_LETTER` (a,b,c)
- **Tabulações:** `LEFT`, `CENTER`, `RIGHT`, `DECIMAL`
- **Símbolos:** `"2022"` (•), `"00A9"` (©), `"00AE"` (®), `"2122"` (™), `"00B0"` (°), `"F070"` (✓), `"F0FC"` (✗)

## Problemas críticos e erros comuns
- **CRÍTICO: o PageBreak tem de estar SEMPRE dentro de um Paragraph**: um PageBreak solto gera um XML inválido que o Word não abre
- **SEMPRE use ShadingType.CLEAR na sombra das células da tabela**: nunca use ShadingType.SOLID (deixa o fundo preto).
- Medidas em DXA (1440 = 1 polegada) | Toda célula de tabela precisa de ≥1 Paragraph | O sumário exige só os estilos HeadingLevel
- **SEMPRE use estilos personalizados** com a fonte Arial, para uma aparência profissional e a hierarquia visual certa
- **SEMPRE defina uma fonte padrão** com `styles.default.document.run.font`: a Arial é a recomendada
- **SEMPRE use o array columnWidths nas tabelas** + a largura de cada célula, para compatibilidade
- **NUNCA use símbolos Unicode como marcadores**: sempre use a configuração de numeração certa com a constante `LevelFormat.BULLET` (NÃO a string "bullet")
- **NUNCA use \n para quebrar linha em lugar nenhum**: sempre use um elemento Paragraph separado para cada linha
- **SEMPRE use objetos TextRun dentro dos children do Paragraph**: nunca use a propriedade text direto no Paragraph
- **CRÍTICO nas imagens**: o ImageRun EXIGE o parâmetro `type`; sempre informe "png", "jpg", "jpeg", "gif", "bmp" ou "svg"
- **CRÍTICO nos marcadores**: use a constante `LevelFormat.BULLET`, não a string "bullet", e inclua `text: "•"` como caractere do marcador
- **CRÍTICO na numeração**: cada reference de numeração cria uma lista INDEPENDENTE. A mesma reference = continua a numeração (1,2,3 depois 4,5,6). Outra reference = recomeça em 1 (1,2,3 depois 1,2,3). Use um nome de reference único para cada seção numerada separada!
- **CRÍTICO no sumário**: ao usar TableOfContents, os títulos têm de usar SÓ HeadingLevel; NÃO adicione estilos personalizados aos parágrafos de título, ou o sumário quebra
- **Tabelas**: defina o array `columnWidths` + a largura de cada célula, e aplique as bordas às células, não à tabela
- **Defina as margens da tabela no nível da TABELA** para ter margem interna consistente nas células (evita repetir em cada célula)
