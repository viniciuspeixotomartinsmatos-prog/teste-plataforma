# Referência técnica do Office Open XML

**Importante: leia este documento inteiro antes de começar.** Ele cobre:
- [Diretrizes técnicas](#diretrizes-técnicas): regras de conformidade com o schema e requisitos de validação
- [Padrões de conteúdo do documento](#padrões-de-conteúdo-do-documento): padrões de XML para títulos, listas, tabelas, formatação etc.
- [Biblioteca Document (Python)](#biblioteca-document-python): a abordagem recomendada para manipular OOXML, com a infraestrutura configurada automaticamente
- [Alterações controladas (redlining)](#alterações-controladas-redlining): padrões de XML para implementar alterações controladas

## Diretrizes técnicas

### Conformidade com o schema
- **Ordem dos elementos em `<w:pPr>`**: `<w:pStyle>`, `<w:numPr>`, `<w:spacing>`, `<w:ind>`, `<w:jc>`
- **Espaços em branco**: adicione `xml:space='preserve'` aos elementos `<w:t>` com espaços no início ou no fim
- **Unicode**: escape os caracteres em conteúdo ASCII: `"` vira `&#8220;`
  - **Referência de codificação de caracteres**: aspas curvas (as "aspas inteligentes" do Word) `""` viram `&#8220;&#8221;`, o apóstrofo `'` vira `&#8217;`, o travessão `—` vira `&#8212;`
- **Alterações controladas**: use as tags `<w:del>` e `<w:ins>` com `w:author="Claude"` fora dos elementos `<w:r>`
  - **Crítico**: `<w:ins>` fecha com `</w:ins>`, `<w:del>` fecha com `</w:del>`; nunca misture
  - **Os RSIDs têm de ser hexadecimais de 8 dígitos**: use valores como `00AB1234` (só os caracteres 0-9 e A-F)
  - **Posição do trackRevisions**: adicione `<w:trackRevisions/>` depois de `<w:proofState>` no settings.xml
- **Imagens**: adicione em `word/media/`, referencie no `document.xml` e defina as dimensões para não transbordar

## Padrões de conteúdo do documento

### Estrutura básica
```xml
<w:p>
  <w:r><w:t>Conteúdo do texto</w:t></w:r>
</w:p>
```

### Títulos e estilos
```xml
<w:p>
  <w:pPr>
    <w:pStyle w:val="Title"/>
    <w:jc w:val="center"/>
  </w:pPr>
  <w:r><w:t>Título do documento</w:t></w:r>
</w:p>

<w:p>
  <w:pPr><w:pStyle w:val="Heading2"/></w:pPr>
  <w:r><w:t>Título da seção</w:t></w:r>
</w:p>
```

### Formatação de texto
```xml
<!-- Negrito -->
<w:r><w:rPr><w:b/><w:bCs/></w:rPr><w:t>Negrito</w:t></w:r>
<!-- Itálico -->
<w:r><w:rPr><w:i/><w:iCs/></w:rPr><w:t>Itálico</w:t></w:r>
<!-- Sublinhado -->
<w:r><w:rPr><w:u w:val="single"/></w:rPr><w:t>Sublinhado</w:t></w:r>
<!-- Realce -->
<w:r><w:rPr><w:highlight w:val="yellow"/></w:rPr><w:t>Realçado</w:t></w:r>
```

### Listas
```xml
<!-- Lista numerada -->
<w:p>
  <w:pPr>
    <w:pStyle w:val="ListParagraph"/>
    <w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr>
    <w:spacing w:before="240"/>
  </w:pPr>
  <w:r><w:t>Primeiro item</w:t></w:r>
</w:p>

<!-- Recomeçar a lista numerada em 1: use outro numId -->
<w:p>
  <w:pPr>
    <w:pStyle w:val="ListParagraph"/>
    <w:numPr><w:ilvl w:val="0"/><w:numId w:val="2"/></w:numPr>
    <w:spacing w:before="240"/>
  </w:pPr>
  <w:r><w:t>Item 1 da nova lista</w:t></w:r>
</w:p>

<!-- Lista com marcadores (nível 2) -->
<w:p>
  <w:pPr>
    <w:pStyle w:val="ListParagraph"/>
    <w:numPr><w:ilvl w:val="1"/><w:numId w:val="1"/></w:numPr>
    <w:spacing w:before="240"/>
    <w:ind w:left="900"/>
  </w:pPr>
  <w:r><w:t>Item com marcador</w:t></w:r>
</w:p>
```

### Tabelas
```xml
<w:tbl>
  <w:tblPr>
    <w:tblStyle w:val="TableGrid"/>
    <w:tblW w:w="0" w:type="auto"/>
  </w:tblPr>
  <w:tblGrid>
    <w:gridCol w:w="4675"/><w:gridCol w:w="4675"/>
  </w:tblGrid>
  <w:tr>
    <w:tc>
      <w:tcPr><w:tcW w:w="4675" w:type="dxa"/></w:tcPr>
      <w:p><w:r><w:t>Célula 1</w:t></w:r></w:p>
    </w:tc>
    <w:tc>
      <w:tcPr><w:tcW w:w="4675" w:type="dxa"/></w:tcPr>
      <w:p><w:r><w:t>Célula 2</w:t></w:r></w:p>
    </w:tc>
  </w:tr>
</w:tbl>
```

### Layout
```xml
<!-- Quebra de página antes de uma nova seção (padrão comum) -->
<w:p>
  <w:r>
    <w:br w:type="page"/>
  </w:r>
</w:p>
<w:p>
  <w:pPr>
    <w:pStyle w:val="Heading1"/>
  </w:pPr>
  <w:r>
    <w:t>Título da nova seção</w:t>
  </w:r>
</w:p>

<!-- Parágrafo centralizado -->
<w:p>
  <w:pPr>
    <w:spacing w:before="240" w:after="0"/>
    <w:jc w:val="center"/>
  </w:pPr>
  <w:r><w:t>Texto centralizado</w:t></w:r>
</w:p>

<!-- Troca de fonte no nível do parágrafo (vale para todos os runs) -->
<w:p>
  <w:pPr>
    <w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/></w:rPr>
  </w:pPr>
  <w:r><w:t>Texto monoespaçado</w:t></w:r>
</w:p>

<!-- Troca de fonte no nível do run (só neste trecho) -->
<w:p>
  <w:r>
    <w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/></w:rPr>
    <w:t>Este texto está em Courier New</w:t>
  </w:r>
  <w:r><w:t> e este usa a fonte padrão</w:t></w:r>
</w:p>
```

## Arquivos a atualizar

Ao adicionar conteúdo, atualize estes arquivos:

**`word/_rels/document.xml.rels`:**
```xml
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>
<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>
```

**`[Content_Types].xml`:**
```xml
<Default Extension="png" ContentType="image/png"/>
<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>
```

### Imagens
**CRÍTICO**: calcule as dimensões para a imagem não transbordar da página e manter a proporção.

```xml
<!-- Estrutura mínima obrigatória -->
<w:p>
  <w:r>
    <w:drawing>
      <wp:inline>
        <wp:extent cx="2743200" cy="1828800"/>
        <wp:docPr id="1" name="Picture 1"/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr>
                <pic:cNvPr id="0" name="image1.png"/>
                <pic:cNvPicPr/>
              </pic:nvPicPr>
              <pic:blipFill>
                <a:blip r:embed="rId5"/>
                <!-- Adicione para esticar o preenchimento mantendo a proporção -->
                <a:stretch>
                  <a:fillRect/>
                </a:stretch>
              </pic:blipFill>
              <pic:spPr>
                <a:xfrm>
                  <a:ext cx="2743200" cy="1828800"/>
                </a:xfrm>
                <a:prstGeom prst="rect"/>
              </pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing>
  </w:r>
</w:p>
```

### Links (hyperlinks)

**IMPORTANTE**: todo link (interno ou externo) exige o estilo Hyperlink definido no styles.xml. Sem esse estilo, os links aparecem como texto comum, em vez de links azuis sublinhados e clicáveis.

**Links externos:**
```xml
<!-- No document.xml -->
<w:hyperlink r:id="rId5">
  <w:r>
    <w:rPr><w:rStyle w:val="Hyperlink"/></w:rPr>
    <w:t>Texto do link</w:t>
  </w:r>
</w:hyperlink>

<!-- No word/_rels/document.xml.rels -->
<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" 
              Target="https://www.example.com/" TargetMode="External"/>
```

**Links internos:**

```xml
<!-- Link para um indicador -->
<w:hyperlink w:anchor="myBookmark">
  <w:r>
    <w:rPr><w:rStyle w:val="Hyperlink"/></w:rPr>
    <w:t>Texto do link</w:t>
  </w:r>
</w:hyperlink>

<!-- Destino do indicador -->
<w:bookmarkStart w:id="0" w:name="myBookmark"/>
<w:r><w:t>Conteúdo de destino</w:t></w:r>
<w:bookmarkEnd w:id="0"/>
```

**Estilo Hyperlink (obrigatório no styles.xml):**
```xml
<w:style w:type="character" w:styleId="Hyperlink">
  <w:name w:val="Hyperlink"/>
  <w:basedOn w:val="DefaultParagraphFont"/>
  <w:uiPriority w:val="99"/>
  <w:unhideWhenUsed/>
  <w:rPr>
    <w:color w:val="467886" w:themeColor="hyperlink"/>
    <w:u w:val="single"/>
  </w:rPr>
</w:style>
```

## Biblioteca Document (Python)

Use a classe Document de `scripts/document.py` para todas as alterações controladas e todos os comentários. Ela cuida sozinha da infraestrutura (people.xml, RSIDs, settings.xml, arquivos de comentários, relacionamentos, tipos de conteúdo). Só manipule o XML diretamente em cenários complexos que a biblioteca não cobre.

**Trabalhar com Unicode e entidades:**
- **Buscar**: tanto a notação de entidade quanto os caracteres Unicode funcionam: `contains="&#8220;Company"` e `contains="\u201cCompany"` acham o mesmo texto
- **Substituir**: use entidades (`&#8220;`) ou Unicode (`\u201c`); os dois funcionam e são convertidos conforme a codificação do arquivo (ascii → entidades, utf-8 → Unicode)

### Inicialização

**Encontre a raiz da skill documentos** (a pasta que contém `scripts/` e `ooxml/`):
```bash
# Procure o document.py para localizar a raiz da skill
# Observação: /mnt/skills é só um exemplo; confira no seu contexto o local real
find /mnt/skills -name "document.py" -path "*/documentos/scripts/*" 2>/dev/null | head -1
# Exemplo de saída: /mnt/skills/documentos/scripts/document.py
# A raiz da skill é: /mnt/skills/documentos
```

**Execute seu script com o PYTHONPATH** apontando para a raiz da skill documentos:
```bash
PYTHONPATH=/mnt/skills/documentos python your_script.py
```

**No seu script**, importe a partir da raiz da skill:
```python
from scripts.document import Document, DocxXMLEditor

# Inicialização básica (cria sozinha uma cópia temporária e configura a infraestrutura)
doc = Document('unpacked')

# Personalizar o autor e as iniciais
doc = Document('unpacked', author="João Silva", initials="JS")

# Ligar o modo de controle de alterações
doc = Document('unpacked', track_revisions=True)

# Definir um RSID próprio (gerado automaticamente se não for informado)
doc = Document('unpacked', rsid="07DC5ECB")
```

### Criar alterações controladas

**CRÍTICO**: marque só o texto que realmente muda. Mantenha TODO o texto que não muda fora das tags `<w:del>`/`<w:ins>`. Marcar texto que não mudou deixa a revisão amadora e mais difícil de conferir.

**Tratamento dos atributos**: a classe Document injeta sozinha os atributos (w:id, w:date, w:rsidR, w:rsidDel, w16du:dateUtc, xml:space) nos elementos novos. Ao manter texto que não mudou do documento original, copie o elemento `<w:r>` original com os atributos que ele já tem, para preservar a integridade do documento.

**Guia de escolha do método**:
- **Adicionar suas próprias alterações a texto comum**: use `replace_node()` com as tags `<w:del>`/`<w:ins>`, ou `suggest_deletion()` para remover elementos `<w:r>` ou `<w:p>` inteiros
- **Modificar em parte a alteração controlada de outro autor**: use `replace_node()` para aninhar suas alterações dentro do `<w:ins>`/`<w:del>` dele
- **Rejeitar por inteiro a inserção de outro autor**: use `revert_insertion()` no elemento `<w:ins>` (NÃO `suggest_deletion()`)
- **Rejeitar por inteiro a exclusão de outro autor**: use `revert_deletion()` no elemento `<w:del>` para restaurar o conteúdo excluído com alterações controladas

```python
# Edição mínima, trocar uma palavra: "O relatório é mensal" → "O relatório é trimestral"
# Original: <w:r w:rsidR="00AB12CD"><w:rPr><w:rFonts w:ascii="Calibri"/></w:rPr><w:t>O relatório é mensal</w:t></w:r>
node = doc["word/document.xml"].get_node(tag="w:r", contains="O relatório é mensal")
rpr = tags[0].toxml() if (tags := node.getElementsByTagName("w:rPr")) else ""
replacement = f'<w:r w:rsidR="00AB12CD">{rpr}<w:t>O relatório é </w:t></w:r><w:del><w:r>{rpr}<w:delText>mensal</w:delText></w:r></w:del><w:ins><w:r>{rpr}<w:t>trimestral</w:t></w:r></w:ins>'
doc["word/document.xml"].replace_node(node, replacement)

# Edição mínima, trocar um número: "em até 30 dias" → "em até 45 dias"
# Original: <w:r w:rsidR="00XYZ789"><w:rPr><w:rFonts w:ascii="Calibri"/></w:rPr><w:t>em até 30 dias</w:t></w:r>
node = doc["word/document.xml"].get_node(tag="w:r", contains="em até 30 dias")
rpr = tags[0].toxml() if (tags := node.getElementsByTagName("w:rPr")) else ""
replacement = f'<w:r w:rsidR="00XYZ789">{rpr}<w:t>em até </w:t></w:r><w:del><w:r>{rpr}<w:delText>30</w:delText></w:r></w:del><w:ins><w:r>{rpr}<w:t>45</w:t></w:r></w:ins><w:r w:rsidR="00XYZ789">{rpr}<w:t> dias</w:t></w:r>'
doc["word/document.xml"].replace_node(node, replacement)

# Substituição completa: preserve a formatação mesmo trocando o texto inteiro
node = doc["word/document.xml"].get_node(tag="w:r", contains="maçã")
rpr = tags[0].toxml() if (tags := node.getElementsByTagName("w:rPr")) else ""
replacement = f'<w:del><w:r>{rpr}<w:delText>maçã</w:delText></w:r></w:del><w:ins><w:r>{rpr}<w:t>banana laranja</w:t></w:r></w:ins>'
doc["word/document.xml"].replace_node(node, replacement)

# Inserir conteúdo novo (sem atributos: são injetados sozinhos)
node = doc["word/document.xml"].get_node(tag="w:r", contains="texto existente")
doc["word/document.xml"].insert_after(node, '<w:ins><w:r><w:t>texto novo</w:t></w:r></w:ins>')

# Excluir em parte a inserção de outro autor
# Original: <w:ins w:author="Ana Souza" w:date="..."><w:r><w:t>relatório financeiro trimestral</w:t></w:r></w:ins>
# Objetivo: excluir só "financeiro" para ficar "relatório trimestral"
node = doc["word/document.xml"].get_node(tag="w:ins", attrs={"w:id": "5"})
# IMPORTANTE: mantenha w:author="Ana Souza" no <w:ins> externo para preservar a autoria
replacement = '''<w:ins w:author="Ana Souza" w:date="2025-01-15T10:00:00Z">
  <w:r><w:t>relatório </w:t></w:r>
  <w:del><w:r><w:delText>financeiro </w:delText></w:r></w:del>
  <w:r><w:t>trimestral</w:t></w:r>
</w:ins>'''
doc["word/document.xml"].replace_node(node, replacement)

# Mudar parte da inserção de outro autor
# Original: <w:ins w:author="Ana Souza"><w:r><w:t>em silêncio, são e salvo</w:t></w:r></w:ins>
# Objetivo: trocar "são e salvo" por "leve e livre"
node = doc["word/document.xml"].get_node(tag="w:ins", attrs={"w:id": "8"})
replacement = f'''<w:ins w:author="Ana Souza" w:date="2025-01-15T10:00:00Z">
  <w:r><w:t>em silêncio, </w:t></w:r>
</w:ins>
<w:ins>
  <w:r><w:t>leve e livre</w:t></w:r>
</w:ins>
<w:ins w:author="Ana Souza" w:date="2025-01-15T10:00:00Z">
  <w:del><w:r><w:delText>são e salvo</w:delText></w:r></w:del>
</w:ins>'''
doc["word/document.xml"].replace_node(node, replacement)

# Excluir o run inteiro (só quando todo o conteúdo sai; para exclusões parciais, use replace_node)
node = doc["word/document.xml"].get_node(tag="w:r", contains="texto a excluir")
doc["word/document.xml"].suggest_deletion(node)

# Excluir o parágrafo inteiro (no lugar; trata parágrafos comuns e de lista numerada)
para = doc["word/document.xml"].get_node(tag="w:p", contains="parágrafo a excluir")
doc["word/document.xml"].suggest_deletion(para)

# Adicionar um item novo à lista numerada
target_para = doc["word/document.xml"].get_node(tag="w:p", contains="item de lista existente")
pPr = tags[0].toxml() if (tags := target_para.getElementsByTagName("w:pPr")) else ""
new_item = f'<w:p>{pPr}<w:r><w:t>Item novo</w:t></w:r></w:p>'
tracked_para = DocxXMLEditor.suggest_paragraph(new_item)
doc["word/document.xml"].insert_after(target_para, tracked_para)
# Opcional: adicione um parágrafo de espaçamento antes do conteúdo para separar melhor
# spacing = DocxXMLEditor.suggest_paragraph('<w:p><w:pPr><w:pStyle w:val="ListParagraph"/></w:pPr></w:p>')
# doc["word/document.xml"].insert_after(target_para, spacing + tracked_para)
```

### Adicionar comentários

```python
# Adicionar um comentário que abrange duas alterações controladas existentes
# Observação: o w:id é gerado sozinho. Só busque por w:id se você o conhece por ter inspecionado o XML
start_node = doc["word/document.xml"].get_node(tag="w:del", attrs={"w:id": "1"})
end_node = doc["word/document.xml"].get_node(tag="w:ins", attrs={"w:id": "2"})
doc.add_comment(start=start_node, end=end_node, text="Explicação desta alteração")

# Adicionar um comentário a um parágrafo
para = doc["word/document.xml"].get_node(tag="w:p", contains="texto do parágrafo")
doc.add_comment(start=para, end=para, text="Comentário sobre este parágrafo")

# Adicionar um comentário a uma alteração controlada recém-criada
# Primeiro crie a alteração controlada
node = doc["word/document.xml"].get_node(tag="w:r", contains="antigo")
new_nodes = doc["word/document.xml"].replace_node(
    node,
    '<w:del><w:r><w:delText>antigo</w:delText></w:r></w:del><w:ins><w:r><w:t>novo</w:t></w:r></w:ins>'
)
# Depois adicione o comentário aos elementos recém-criados
# new_nodes[0] é o <w:del>, new_nodes[1] é o <w:ins>
doc.add_comment(start=new_nodes[0], end=new_nodes[1], text="Troquei antigo por novo conforme os requisitos")

# Responder a um comentário existente
doc.reply_to_comment(parent_comment_id=0, text="Concordo com esta alteração")
```

### Rejeitar alterações controladas

**IMPORTANTE**: use `revert_insertion()` para rejeitar inserções e `revert_deletion()` para restaurar exclusões com alterações controladas. Use `suggest_deletion()` só em conteúdo comum, sem marcação.

```python
# Rejeitar uma inserção (envolve-a numa exclusão)
# Use quando outro autor inseriu um texto que você quer excluir
ins = doc["word/document.xml"].get_node(tag="w:ins", attrs={"w:id": "5"})
nodes = doc["word/document.xml"].revert_insertion(ins)  # Retorna [ins]

# Rejeitar uma exclusão (cria uma inserção para restaurar o conteúdo excluído)
# Use quando outro autor excluiu um texto que você quer restaurar
del_elem = doc["word/document.xml"].get_node(tag="w:del", attrs={"w:id": "3"})
nodes = doc["word/document.xml"].revert_deletion(del_elem)  # Retorna [del_elem, new_ins]

# Rejeitar todas as inserções de um parágrafo
para = doc["word/document.xml"].get_node(tag="w:p", contains="texto do parágrafo")
nodes = doc["word/document.xml"].revert_insertion(para)  # Retorna [para]

# Rejeitar todas as exclusões de um parágrafo
para = doc["word/document.xml"].get_node(tag="w:p", contains="texto do parágrafo")
nodes = doc["word/document.xml"].revert_deletion(para)  # Retorna [para]
```

### Inserir imagens

**CRÍTICO**: a classe Document trabalha numa cópia temporária em `doc.unpacked_path`. Sempre copie as imagens para essa pasta temporária, não para a pasta desempacotada original.

```python
from PIL import Image
import shutil, os

# Inicialize o documento primeiro
doc = Document('unpacked')

# Copie a imagem e calcule as dimensões na largura total, mantendo a proporção
media_dir = os.path.join(doc.unpacked_path, 'word/media')
os.makedirs(media_dir, exist_ok=True)
shutil.copy('image.png', os.path.join(media_dir, 'image1.png'))
img = Image.open(os.path.join(media_dir, 'image1.png'))
width_emus = int(6.5 * 914400)  # largura útil de 6,5", 914400 EMUs por polegada
height_emus = int(width_emus * img.size[1] / img.size[0])

# Adicione o relacionamento e o tipo de conteúdo
rels_editor = doc['word/_rels/document.xml.rels']
next_rid = rels_editor.get_next_rid()
rels_editor.append_to(rels_editor.dom.documentElement,
    f'<Relationship Id="{next_rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>')
doc['[Content_Types].xml'].append_to(doc['[Content_Types].xml'].dom.documentElement,
    '<Default Extension="png" ContentType="image/png"/>')

# Insira a imagem
node = doc["word/document.xml"].get_node(tag="w:p", line_number=100)
doc["word/document.xml"].insert_after(node, f'''<w:p>
  <w:r>
    <w:drawing>
      <wp:inline distT="0" distB="0" distL="0" distR="0">
        <wp:extent cx="{width_emus}" cy="{height_emus}"/>
        <wp:docPr id="1" name="Picture 1"/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr><pic:cNvPr id="1" name="image1.png"/><pic:cNvPicPr/></pic:nvPicPr>
              <pic:blipFill><a:blip r:embed="{next_rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
              <pic:spPr><a:xfrm><a:ext cx="{width_emus}" cy="{height_emus}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing>
  </w:r>
</w:p>''')
```

### Obter nós

```python
# Pelo conteúdo do texto
node = doc["word/document.xml"].get_node(tag="w:p", contains="texto específico")

# Por um intervalo de linhas
para = doc["word/document.xml"].get_node(tag="w:p", line_number=range(100, 150))

# Pelos atributos
node = doc["word/document.xml"].get_node(tag="w:del", attrs={"w:id": "1"})

# Pelo número exato da linha (tem de ser a linha onde a tag abre)
para = doc["word/document.xml"].get_node(tag="w:p", line_number=42)

# Combinar filtros
node = doc["word/document.xml"].get_node(tag="w:r", line_number=range(40, 60), contains="texto")

# Desambiguar quando o texto aparece várias vezes: adicione um intervalo de line_number
node = doc["word/document.xml"].get_node(tag="w:r", contains="Seção", line_number=range(2400, 2500))
```

### Salvar

```python
# Salvar com validação automática (copia de volta para a pasta original)
doc.save()  # Valida por padrão e levanta um erro se a validação falhar

# Salvar em outro local
doc.save('modified-unpacked')

# Pular a validação (só para depurar; precisar disso em produção indica problemas no XML)
doc.save(validate=False)
```

### Manipulação direta do DOM

Para cenários complexos que a biblioteca não cobre:

```python
# Acessar qualquer arquivo XML
editor = doc["word/document.xml"]
editor = doc["word/comments.xml"]

# Acesso direto ao DOM (defusedxml.minidom.Document)
node = doc["word/document.xml"].get_node(tag="w:p", line_number=5)
parent = node.parentNode
parent.removeChild(node)
parent.appendChild(node)  # Move para o fim

# Manipulação geral do documento (sem alterações controladas)
old_node = doc["word/document.xml"].get_node(tag="w:p", contains="texto original")
doc["word/document.xml"].replace_node(old_node, "<w:p><w:r><w:t>texto substituto</w:t></w:r></w:p>")

# Várias inserções: use o valor retornado para manter a ordem
node = doc["word/document.xml"].get_node(tag="w:r", line_number=100)
nodes = doc["word/document.xml"].insert_after(node, "<w:r><w:t>A</w:t></w:r>")
nodes = doc["word/document.xml"].insert_after(nodes[-1], "<w:r><w:t>B</w:t></w:r>")
nodes = doc["word/document.xml"].insert_after(nodes[-1], "<w:r><w:t>C</w:t></w:r>")
# Resultado: original_node, A, B, C
```

## Alterações controladas (redlining)

**Use a classe Document acima para todas as alterações controladas.** Os padrões abaixo servem de referência ao montar as strings de XML de substituição.

### Regras de validação
O validador confere se o texto do documento bate com o original depois de reverter as alterações do Claude. Ou seja:
- **NUNCA modifique o texto dentro das tags `<w:ins>` ou `<w:del>` de outro autor**
- **SEMPRE use exclusões aninhadas** para remover as inserções de outro autor
- **Toda edição tem de ser controlada** com as tags `<w:ins>` ou `<w:del>`

### Padrões de alterações controladas

**REGRAS CRÍTICAS**:
1. Nunca modifique o conteúdo dentro das alterações controladas de outro autor. Sempre use exclusões aninhadas.
2. **Estrutura do XML**: sempre coloque `<w:del>` e `<w:ins>` no nível do parágrafo, contendo elementos `<w:r>` completos. Nunca os aninhe dentro de elementos `<w:r>`: isso gera um XML inválido que quebra o processamento do documento.

**Inserção de texto:**
```xml
<w:ins w:id="1" w:author="Claude" w:date="2025-07-30T23:05:00Z" w16du:dateUtc="2025-07-31T06:05:00Z">
  <w:r w:rsidR="00792858">
    <w:t>texto inserido</w:t>
  </w:r>
</w:ins>
```

**Exclusão de texto:**
```xml
<w:del w:id="2" w:author="Claude" w:date="2025-07-30T23:05:00Z" w16du:dateUtc="2025-07-31T06:05:00Z">
  <w:r w:rsidDel="00792858">
    <w:delText>texto excluído</w:delText>
  </w:r>
</w:del>
```

**Excluir a inserção de outro autor (TEM DE usar a estrutura aninhada):**
```xml
<!-- Aninhe a exclusão dentro da inserção original -->
<w:ins w:author="Ana Souza" w:id="16">
  <w:del w:author="Claude" w:id="40">
    <w:r><w:delText>mensal</w:delText></w:r>
  </w:del>
</w:ins>
<w:ins w:author="Claude" w:id="41">
  <w:r><w:t>semanal</w:t></w:r>
</w:ins>
```

**Restaurar a exclusão de outro autor:**
```xml
<!-- Deixe a exclusão dele intacta e adicione uma nova inserção depois dela -->
<w:del w:author="Ana Souza" w:id="50">
  <w:r><w:delText>em até 30 dias</w:delText></w:r>
</w:del>
<w:ins w:author="Claude" w:id="51">
  <w:r><w:t>em até 30 dias</w:t></w:r>
</w:ins>
```
