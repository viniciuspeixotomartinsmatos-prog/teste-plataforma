# Crítica: julgar o que foi renderizado

O `inspect.mjs` passar significa só que nada proibido ou quebrado foi medido. Ele não diz se a
página é boa. Este arquivo é como você descobre. Use-o nas capturas de tela, nunca no código: foi você que escreveu
o código, então vai ler nele as suas intenções. As capturas só mostram o que está lá.

## Sumário

1. Como olhar (quatorze leituras, poucos minutos)
2. A nota
3. Tetos
4. Escrever a crítica
5. O que corrigir primeiro
6. Quando parar

## 1. Como olhar

Abra `desktop-fold.jpg`, depois as folhas `desktop-page-*.jpg`, depois `mobile-fold.jpg` e as folhas
do celular. Faça cada leitura separada; não misture.

1. **Um segundo, depois cinco.** Dê uma olhada e desvie. O que você viu? Deve haver exatamente uma
   resposta: uma palavra, uma imagem, um objeto. Se a resposta for "um site", não há ponto focal. Depois
   dê à primeira dobra cinco segundos, como um desconhecido: dá para dizer o que é isto, para quem é e
   o que fazer em seguida? Se o título só faz sentido depois de rolar, ele não é um título.
2. **Aperte os olhos.** Desfoque a atenção até o texto virar barras cinza. A página deve se reduzir a duas ou
   três massas grandes, com diferenças claras de tamanho. Muitas massas pequenas e parecidas querem dizer que tudo é
   médio e nada lidera.
3. **Cubra o logo.** Esta primeira dobra poderia ser de um concorrente, ou de outro setor?
   Se trocar o nome e o substantivo da headline der uma página igualmente válida, a página não tem
   ideia. Volte à ficha da direção; a ideia está escrita lá. Depois role: a ideia chega
   aos preços, ao FAQ e ao rodapé, ou a página vira blocos de prateleira depois da primeira dobra?
4. **Bordas.** Siga a borda esquerda de cada bloco de texto página abaixo. Conte as posições x diferentes.
   Uma página composta tem duas ou três, reusadas de propósito. Seis quer dizer que as coisas foram postas uma de cada vez.
5. **Espaço e moldura.** O que é relacionado está perto e o que não é está longe? O espaço entre seções
   é claramente maior que qualquer espaço dentro de uma seção? Alguma região está vazia por acaso (um buraco) em vez
   de por decisão (uma pausa)? O buraco costuma ficar ao lado de uma coluna curta ou embaixo de um enfeite removido.
   Depois olhe a moldura: as margens esquerda e direita da página são iguais? Alguma seção mantém
   o texto numa metade e deixa a outra vazia? Há um trecho de nada mais alto que meia
   tela? Os leitores apontam isso primeiro ("está empurrado para a esquerda", "espaço vazio aleatório"), antes de qualquer
   detalhe; no estudo de 100 Sites of the Day, cerca de 1 seção em 100 deixava metade da largura vazia.
6. **Tipografia.** O salto do texto corrido para a headline é decidido (três vezes ou mais)? Você vê mais
   de cinco tamanhos? Alguma headline com uma palavra órfã na última linha? Algum parágrafo mais largo que uns
   75 caracteres ou centralizado em mais de três linhas?
7. **Cor.** Diga as proporções: que cor ocupa a maior parte da superfície, qual apoia, onde está
   a cor de destaque? Um destaque que aparece em dez lugares não quer dizer nada. Um que aparece na única
   ação e num detalhe quer dizer "aqui".
8. **Imagens.** Conte as imagens reais: há pelo menos quatro, e há uma em movimento? Uma página só de
   desenhos, ou só de tipo, parece inacabada ao lado de uma com fotografias e vídeos reais.
   Cada imagem cumpre uma função (mostrar a coisa, situar o lugar, provar a afirmação)?
   Os recortes compartilham proporções? Algo é uma caixa cinza, uma foto esticada, uma tela falsa feita de barras?
   As fotografias compartilham uma luz e um tratamento de cor, ou são uma mistura de banco de imagens?
9. **Mesmice.** Escreva uma palavra para o layout de cada seção (dividida, lista, sangrada, grid, frase de destaque,
   índice …). A mesma palavra duas vezes seguidas, ou três vezes na página, é o template aparecendo.
10. **Celular.** A tela do celular é uma composição própria, com recorte próprio e quebras de linha
    próprias, ou a página do desktop espremida? A primeira dobra ainda é uma coisa clara?
11. **Plenitude.** Passe pelas folhas do desktop tela a tela. Cada tela é um cartaz composto, ou
    é uma coluna estreita de texto pequeno com terreno morto dos dois lados? Alguma frase de destaque fica parada na tela
    por três telas? Página austera não é página contida: se a página puder ser confundida com um
    wireframe inacabado (formas cinza, texto cinza, uma coluna pequena), ela está subconstruída. Um único motivo ou
    desenho ampliado para encher uma tela inteira sem nada para ler também é um buraco, por mais ousado que pareça.
12. **Substância.** Cada seção pedida no briefing entrega a sua informação completa e num
    tamanho legível (o cardápio inteiro, cada quarto, cada palestrante, o preço e o que inclui)? O
    visitante sairia sabendo o que veio descobrir? A ação principal é um botão de verdade na primeira
    dobra?
13. **Colisões.** Há algo por cima de uma headline, de uma frase de destaque ou de um botão em alguma posição
    de rolagem? Algum elemento passa da borda da tela do celular? Uma fileira que rola para o lado no
    celular parece cortada numa captura e para a maioria dos visitantes; quebre-a em linhas, a menos que o corte seja
    claramente proposital (um card parcial aparecendo na borda).
14. **O concorrente e o elemento vivo.** Ponha o nome do concorrente mais próximo na página: a
    ideia ainda funciona? Depois diga qual é o elemento vivo (o que o visitante pode fazer ou o que muda a cada visita).
    Se alguma das respostas for fraca, esse é o primeiro problema da rodada, antes de qualquer detalhe.

Uma observação dos testes: nas comparações às cegas, uma página mais rica, cheia de recursos de template, venceu uma página mais limpa
mas rala, todas as vezes. As regras da casa tiram os recursos; as leituras 11–13 são onde você garante que a
página não perdeu a substância junto com eles.

## 2. A nota

Dê a nota como um jurado do Awwwards: quatro critérios, de 1 a 10 cada, com pesos **design 40%, usabilidade 30%,
criatividade 20%, conteúdo 10%**.

**Design (40%)**: composição, tipografia, cor, imagem, acabamento.
- 9–10: cada tela se sustenta como cartaz. Nada poderia ser tirado ou mudado de lugar.
- 8: confiante e coerente; um ou dois pontos fracos que um designer notaria.
- 7: limpo e profissional, um sistema claro, pouca tensão.
- 6: arrumado mas anônimo. Parece um kit.
- 5 ou menos: hierarquia fraca, espaçamento acidental, tipo padrão, imagens que não combinam.

**Usabilidade (30%)**: orientação em três segundos, texto legível, ações óbvias, celular honesto.
- 9–10: você sabe o que é, para quem é e o que fazer sem rolar; impecável no celular.
- 8: claro e confortável; atrito pequeno (uma seção longa, uma área de toque pequena).
- 7: funciona, com um problema real (contraste fraco em algum lugar, um layout apertado no celular).
- 6 ou menos: você tem de procurar, ou algo quebra.

**Criatividade (20%)**: uma ideia que dá para dizer numa frase, levada até o fim.
- 9–10: um conceito específico deste assunto que você nunca viu aplicado desse jeito.
- 8: uma ideia clara com um movimento memorável.
- 7: uma execução de bom gosto de uma abordagem conhecida.
- 6 ou menos: o padrão da categoria.

**Conteúdo (10%)**: palavras e imagens específicas, com cara de verdade e editadas.
- 9–10: cada linha só poderia ser sobre este assunto; as imagens são o assunto.
- 7–8: claro e concreto, algumas linhas genéricas.
- 6 ou menos: slogans, enchimento, banco de imagens.

`overall = 0.4·design + 0.3·usability + 0.2·creativity + 0.1·content`

Para calibrar: os Sites of the Day reais ficam por volta de 7,5–8,0 de nota geral do júri. Um 8,5 honesto é
raro. Se a sua primeira nota para o seu próprio trabalho for 9, dê a nota de novo como o jurado que não o construiu.

## 3. Tetos

Eles se sobrepõem à conta.

- Qualquer `FAIL` ainda apontado pelo `inspect.mjs`: a nota geral não passa de **6,0**.
- Uma headline de três linhas ou mais em qualquer viewport, um rótulo de chapéu (eyebrow, o rótulo pequeno acima do título), rótulos em mono, numeração
  01/02/03, um gradiente decorativo, uma sombra num elemento em repouso, ou um fio finíssimo decorativo visível numa
  captura: a nota geral não passa de **6,5**, seja o que for o resto.
- A leitura 3 reprova (a página poderia ser de qualquer um): a criatividade não passa de **6**.
- A ideia serve para o concorrente mais próximo (leitura 14): a criatividade não passa de **7**.
- Menos de quatro imagens reais (fotografias, imagens de arquivo, vídeos; desenhos não contam):
  o design não passa de **6,5**.
- Uma página que quase não se mexe (o `still-page` do inspetor), ou um movimento que é um fade idêntico em
  todo bloco: o design não passa de **7**.
- Nenhum elemento vivo (leitura 14): a criatividade não passa de **7,5**.
- Qualquer placeholder (conteúdo provisório: caixa cinza, lorem, "Imagem aqui"): o conteúdo não passa de **5**.
- Duas ou mais telas do desktop quase só de fundo vazio, ou uma página cujo texto corrido é pequeno e
  cinza: o design não passa de **6,5**.
- Uma seção pedida no briefing que falta ou foi reduzida a poucas palavras: o conteúdo não passa de **6**.
- Nenhum botão de verdade para a ação principal na primeira dobra: a usabilidade não passa de **7**.
- A leitura dos cinco segundos reprova (nenhum título claro dizendo o que é isto na primeira dobra): a usabilidade
  não passa de **6**.
- Margens desiguais na página, uma seção encolhida num lado com a outra metade vazia, ou um trecho em branco
  mais alto que meia tela: o design não passa de **6,5**.
- Uma seção de texto corrido sem um título que a nomeie: a usabilidade não passa de **7**.
- Qualquer coisa cobrindo uma headline em alguma posição de rolagem: a usabilidade não passa de **6**.
- Uma faixa em branco onde uma revelação não disparou, ou conteúdo cortado fora da tela: a usabilidade não passa de **5**.

## 4. Escrever a crítica

Escreva; não fique só pensando. Use exatamente este formato, para as rodadas poderem ser comparadas:

```
RODADA n
Visto em um segundo: …
Ideia (uma frase): …
Elemento vivo: …
Palavras de layout por seção: hero=… / …=… / …
Notas: design _ · usabilidade _ · criatividade _ · conteúdo _ → geral _._
Tetos aplicados: …
Os três maiores problemas (o mais visível primeiro), cada um com a captura em que aparece e a correção:
1. …
2. …
3. …
```

Nomeie os problemas como um designer falaria com um colega: "o parágrafo de apoio começa 40 px à esquerda
da borda da headline", "a seção de depoimentos é o terceiro layout dividido seguido", "o hero do celular
corta a garrafa para fora do quadro". "Poderia estar mais polido" não é uma constatação.

## 5. O que corrigir primeiro

Corrija nesta ordem; os itens de baixo não salvam os de cima.

1. **A ideia.** Se a leitura 3 reprovar, mude o conceito do hero, não os detalhes.
2. **Hierarquia.** Um elemento dominante por tela. Deixe a coisa grande maior e as coisas pequenas
   em menor número antes de mexer em qualquer outra coisa.
3. **Composição.** Bordas compartilhadas, espaçamento entre seções, variedade de layout entre seções, buracos.
4. **Tipografia.** Contraste de escala, quebras de linha, largura da linha, entrelinha.
5. **Imagens.** Troque as imagens fracas, unifique recortes e tratamento de cor.
6. **Cor.** Proporção e disciplina com a cor de destaque.
7. **Detalhe.** Estados, foco, pequenos alinhamentos, ajustes finos no celular.
8. **Movimento.** Por último.

Quando tirar algo deixar um vazio, não o preencha com um enfeite. Feche o vazio, aumente o que
sobrou, ou deixe uma imagem ou um campo de cor ocupar o espaço.

## 6. Quando parar

Faça no máximo três rodadas: crítica → corrigir os três maiores → inspecionar de novo → crítica. Pare antes quando uma rodada
não achar nenhum problema que um desconhecido notaria. Se a rodada três ainda der nota abaixo de 7,5, diga isso claramente no
seu relatório, com os problemas restantes listados; não arredonde para cima.
