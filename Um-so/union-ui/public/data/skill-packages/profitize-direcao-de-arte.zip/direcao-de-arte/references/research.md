# O estudo

Todo número desta skill sai daqui. Cite estes valores; não os arredonde para cima nem invente
outros.

## Sumário

1. O método e seus limites
2. Notas
3. De onde vem a ideia
4. Headlines
5. Tipografia
6. Recursos: o que separa os fortes dos fracos, e o que não separa
7. Cor e forma
8. Imagem e estrutura da página
9. O que o inspetor diz da própria galeria
10. Os 25 sites de nota mais alta e suas ideias
11. Como a skill foi testada
12. O estudo de outubro de 2026: 100 Sites of the Day
13. O estudo das telas de app

## 1. O método e seus limites

- **Amostra.** 248 sites coletados em 5 de outubro de 2026: 156 do One Page Love (as páginas mais
  recentes da galeria e as listas por categoria) e 92 Sites of the Day do Awwwards (as três páginas de
  lista mais recentes). 247 carregaram; 246 foram medidos de novo com a sonda final.
- **Captura.** Chrome headless a 1440×900 e 390×844. Para cada site: a primeira dobra, mais cinco
  quadros durante a rolagem com a roda do mouse de verdade, a primeira dobra no celular e uma passada de
  medição na página (estilos computados, geometria do texto, cores, as fontes que de fato carregaram).
- **Painel.** 21 revisores (modelos) estudaram cerca de 12 sites cada um a partir das capturas e das
  medições, os descreveram (ideia, hero, tipografia, cor, imagem, layout, seções) e deram a nota do
  jeito do Awwwards: design 40%, usabilidade 30%, criatividade 20%, conteúdo 10%. São julgamentos de
  modelos sobre quadros parados, não de jurados humanos, e não são as notas reais do Awwwards. Os lotes
  misturavam as duas fontes, para cada revisor ver um pouco de tudo.
- **Conjuntos aproveitáveis.** 235 sites serviram para o painel (12 mostravam só um preloader *(tela de
  carregamento)*, uma barreira de entrada ou uma barreira anti-robô). 202 puderam ser medidos na
  tipografia (página com pelo menos 25 palavras e uma headline detectável). Abaixo, "de nota alta" quer
  dizer nota do painel de 7,5 ou mais (82 sites medidos); "fracos", abaixo de 6,5 (23 sites medidos).
- **Limites.** Uma captura por site, num dia só. Alguns heros foram pegos no meio da animação ou atrás
  de um aviso de cookies. Sites carregados de WebGL ficam mal descritos pelas medições de texto. O
  detector de chapéu (eyebrow) conta qualquer rótulo pequeno e curto logo acima de um título grande, então
  conta a mais em relação à leitura mais rigorosa do painel (60% medidos contra 35% observados). O
  movimento foi deduzido dos quadros, não assistido. A amostra é o que as duas galerias tinham destacado
  havia pouco; é tanto moda quanto qualidade.

## 2. Notas

| | Todos os 235 | One Page Love (151) | Awwwards (84) |
| --- | --- | --- | --- |
| Nota geral, mediana | 7,2 | 7,1 | 7,5 |
| Metade do meio | 6,8–7,6 | | |
| 8,0 ou mais | 25 sites (11%) | | |
| 7,5 ou mais | 90 sites (38%) | | |
| Abaixo de 6,5 | 29 sites | | |

Mediana por critério: design 8, usabilidade 7, criatividade 7, conteúdo 7. Entre os 25 de nota mais
alta: design 9, usabilidade 7, criatividade 8, conteúdo 8. A usabilidade é a única linha que não sobe
com as outras: os melhores sites não são mais fáceis de usar que o site médio. Não copie as barreiras,
os preloaders, o texto minúsculo nem a navegação escondida deles.

## 3. De onde vem a ideia

O padrão mais claro nas anotações do painel: notas altas andam com um conceito tirado do assunto, e
notas baixas, com a falta dele. As ideias dos mais fracos foram registradas com palavras como "nada além
da fórmula padrão de lançamento SaaS escuro", "nenhuma ideia visual além da clareza", "nenhuma ideia
forte". As dos mais fortes eram frases que só aquele assunto poderia ter (seção 10).

Motores recorrentes entre os sites de 7,3 ou mais, cada um a base de uma direção da biblioteca:

- **O produto demonstra a si mesmo.** A lupa de um seletor de cores lê o fundo da própria página; uma
  ferramenta de listas é vendida com listinhas que funcionam; a página de um app de fotos é um mural do
  que ele produz.
- **A página é um objeto do mundo do assunto.** Um site de casamento que é o convite; um arquivo como
  pastas com abas; um cupom com linha de corte; um portfólio como folha de contato.
- **O nome é o hero.** Logotipos da largura da tela, uma fotografia posta dentro do nome como uma letra,
  um nome dividido entre cantos opostos com a página no meio.
- **Um motivo do assunto conduz tudo.** O perfil octogonal de uma ferramenta como botão, máscara e
  carregador; dois círculos para duas contas; as listras de um café.
- **Vestido de outra categoria.** Um app de dinheiro como lançamento de streetwear; uma torrefação
  industrial como objeto de design; um serviço de encomendas como parque de diversões.
- **O lugar sustenta.** Uma vista sangrada (full-bleed) e um nome ao longo da borda de baixo.
- **Um palco fixo.** Um título ou objeto fica parado enquanto o conteúdo troca por baixo dele.
- **Uma seção, uma cor.** Campos de cor chapados como capítulos.
- **Discrição radical.** Uma headline de 27 px e demonstrações ao vivo minúsculas, levadas até o fim.

Tipos de hero, pela classificação do painel (sites de nota alta contra fracos): mídia sangrada com texto
por cima 16% / 10%; logotipo gigante 14% / 0%; cartaz tipográfico 13% / 7%; texto ao lado da mídia
10% / 3%; **frase de destaque centralizada com mídia embaixo 7% / 24%**. A headline centralizada sobre
uma captura de tela é o layout que assina os sites fracos.

## 4. Headlines

| Headline do hero | Todos | De nota alta | Fracos |
| --- | --- | --- | --- |
| Palavras, mediana | 5 | 5 | 5 |
| Palavras, metade do meio | 3–9 | 2–8 | 3–8 |
| Caracteres, mediana | 32 | | |
| Uma linha a 1440 | 47% | | |
| Duas linhas ou menos a 1440 | 70% | 71% | 83% |
| Duas linhas ou menos a 390 | 57% | | |
| Três linhas ou menos a 390 | 82% | | |

Os heros do Awwwards são mais curtos (mediana de 4 palavras, 76% em até duas linhas) que os do One Page
Love (6 palavras, 66%). Os títulos de seção têm mediana de 3 palavras. O tamanho não separa os fortes
dos fracos; quase todo mundo na galeria escreve headlines curtas. O limite de duas linhas desta skill é
uma regra da casa que a maior parte da galeria já cumpre no desktop e que dá trabalho cumprir no
celular.

## 5. Tipografia

| | Todos | De nota alta | Fracos |
| --- | --- | --- | --- |
| Tamanho do hero, mediana | 72 px (5,0vw) | 6,0vw | 4,7vw |
| Tamanho do hero, metade do meio | 3,0–7,6vw | 2,5–9,7vw | 2,7–6,1vw |
| Maior texto da página, mediana | 6,4vw | 8,4vw | 5,0vw |
| Maior texto, o quartil de cima começa em | 10,4vw | 12,5vw | 6,7vw |
| Hero no celular, mediana | 40 px | | |
| Tracking *(espaço entre letras)* do hero, mediana (metade do meio) | -0,01em (-0,03 a 0) | | |
| Entrelinha do hero, mediana (metade do meio) | 1,0 (0,95–1,1) | | |
| Tamanho do texto corrido, mediana (metade do meio) | 16 px (14–18) | | |
| Headline ÷ texto corrido, mediana | 4,3 | 4,7 | 4,0 |
| Fontes com 3% ou mais do texto | uma 31%, duas 45%, três 22% | | |
| Tamanhos de fonte distintos, mediana | 8 | | |

Peso do hero: regular 48%, medium 18%, semibold 6%, bold ou mais pesado 22%, light 6%. Caixa-alta 24%.
Centralizado em 39% no geral, 52% nos sites fracos. Classes de display segundo o painel: neogrotesca
48%, serifada transicional 11%, sem serifa geométrica 10%, condensada 6%, expandida 6%, serifada
humanista (old-style) 4%, letreiramento próprio 4%.

Os sites fortes levam aos extremos: o maior texto deles é maior e a faixa de tamanhos, mais larga. Os
sites fracos se amontoam no meio.

## 6. Recursos: o que separa os fortes dos fracos, e o que não separa

Medido na página, salvo quando marcado (painel).

**Mais comuns nos sites fracos (os dados apoiam evitá-los):**

| Recurso | De nota alta | Fracos |
| --- | --- | --- |
| Cards de funcionalidade com ícone no topo (painel) | 1% | 28% |
| Fileiras de cards idênticos com um ícone pequeno (medido) | 7% | 26% |
| Selos em pílula (painel) | 14% | 34% |
| Rótulo em pílula acima de um título (medido) | 5% | 26% |
| Rótulos minúsculos em caixa-alta espaçada, qualquer um | 16% | 57% |
| Rótulos minúsculos em caixa-alta espaçada, três ou mais | 6% | 43% |
| Preenchimentos em gradiente (sem contar véus) | 22% | 52% |
| Texto em gradiente | 2% | 13% |
| Sombras em elementos parados, qualquer uma | 24% | 48% |
| Sombras, cinco ou mais | 10% | 30% |
| Emoji na página | 10% | 26% |
| Rótulos de chapéu (painel) | 32% | 45% |

**Sem diferença real:**

| Recurso | De nota alta | Fracos |
| --- | --- | --- |
| Desfoque de fundo em qualquer lugar | 32% | 39% |
| Palavra de destaque em serifada itálica (painel) | 4% | 7% |
| Fios finos, qualquer um | 61% | 52% |

**Mais comuns nos sites fortes (proibidos aqui mesmo assim, como estilo da casa):**

| Recurso | De nota alta | Fracos |
| --- | --- | --- |
| Rótulos em monoespaçada (painel) | 44% | 24% |
| Monoespaçada em qualquer lugar fora de código (medido) | 45% | 26% |
| Numeração de índice (painel) | 38% | 21% |

Legendas em monoespaçada, números de índice e grids com fios são a moda atual dos sites premiados.
Ficam fora desta skill por escolha do autor, não pelos dados: são os recursos que os geradores copiam
primeiro, e uma página que não pode se apoiar neles tem de achar estrutura no espaço, no tom e na
escala.

## 7. Cor e forma

- Fundo de página escuro 41%; branco puro 25%; preto puro 12%; um off-white quente 13%.
- Esquema (painel): monocromático com uma cor de destaque 23%, neutro claro 22%, neutro escuro 14%,
  várias cores chapadas 13%, duas cores 12%, fotográfico 9%, um campo de cor só 6%.
- Os botões principais são neutros (preto, branco, cinza) em 52% dos sites. Um site em 246 tem botão
  terracota; nenhum tem botão violeta.
- Número mediano de fundos de seção distintos: 2 nos sites de nota alta, 1 nos fracos.
- Forma do botão: nos sites de nota alta, quadrado (0–2 px) 52%, todo arredondado 23%, raio pequeno
  19%, médio (9–16 px) 6%. Nos fracos, todo arredondado 59%, médio 24%, quadrado 18%.
- Os cantos da mídia são retos em 73% dos sites; onde são arredondados, o raio mediano é 12 px.
- Botões na primeira dobra: nenhum em 55% dos sites de nota alta e em 39% dos fracos.

## 8. Imagem e estrutura da página

- A mídia do hero cobre pelo menos metade da primeira dobra em 60% dos sites (de nota alta 68%, fracos
  48%) e quase toda ela em 50% (de nota alta 56%, fracos 39%). Sem mídia no hero: 15%.
- Há vídeo em 49% dos sites e um elemento canvas em 49% (de nota alta 62%, fracos 35%).
- Imagens por página, mediana: 24 no geral, 37 nos sites de nota alta, 5 nos fracos.
- Tipo de imagem (painel): misto 32%, fotografia 14%, generativa ou WebGL 13%, interface do produto
  12%, render 3D 11%, ilustração 9%, vídeo 6%, só tipografia 3%. A nota mediana do painel é a mais baixa
  nas páginas puxadas por ilustração (6,9) e por interface do produto (7,1), e a mais alta nas de vídeo e
  só tipografia (7,5).
- Comprimento da página, mediana: 8,7 telas e 575 palavras (metade do meio 1,6–14,4 telas, 250–956
  palavras). Um quarto dos sites tem uma tela só ou duas.
- Navegação: mediana de 3 links; fixa ou sticky *(gruda na tela enquanto a página rola)* em 66%.
- Densidade (painel): arejada 46%, equilibrada 45%, densa 9%. Alinhamento: centralizado 33%, misto 31%,
  ancorado à esquerda 17%, grid modular 13%, livre 6%.
- Quando pediram ao painel que descrevesse as seções mais interessantes de cada site, ele escolheu uma
  seção de preços, de depoimentos ou de perguntas frequentes só 7, 12 e 9 vezes em 235 sites. Onde os
  sites fortes chegam a tê-las, não é ali que vai o esforço de design, e elas fogem do formato de
  prateleira.

**Das anotações escritas do painel sobre os 114 sites com nota 7,3 ou mais** (contagens à mão,
aproximadas; o `layout.md` transforma isso em prática):

- Margens externas de 32 px ou menos em cerca de 45; de 80 px ou mais em cerca de 8. Um contêiner
  centralizado de 700–1300 px em cerca de 15, vários deles as páginas que o painel chamou de prateleira.
- Texto ancorado numa linha fixa fora do centro em cerca de 22. Texto encostado nos cantos ou nas pontas
  opostas de uma linha de base em cerca de 25 e 15.
- Dois ou três tamanhos de fonte, sem nada entre eles, em cerca de 30; nenhuma anotação descreve uma
  escala graduada de cinco degraus.
- Uma coisa por tela em cerca de 20. Uma cor de fundo inteira por seção em cerca de 20; claro e escuro
  alternados em cerca de 12.
- Cada seção composta de novo em cerca de 14; uma exceção planejada ao próprio sistema da página em
  cerca de 14.
- Nenhuma barra de navegação convencional no topo em cerca de 45; links pequenos nos cantos em cerca de
  22; um único link ou botão em cerca de 10.
- Finais: o nome na largura toda em cerca de 18, o hero repetido invertido em cerca de 12, uma cena de
  fechamento própria em cerca de 14, sem rodapé ou com uma linha só em cerca de 22. Rodapés com colunas
  de links só aparecem como crítica.
- Movimento (deduzido dos quadros): vídeo em reprodução automática em cerca de 50; palcos fixados ou
  fixos em cerca de 40; revelações de texto em cerca de 30 (entrada com desfoque 10, linhas que sobem
  por máscara 8, palavras que ganham cor com a rolagem 7); faixas horizontais em cerca de 27; marquees
  *(faixa de texto que corre sozinha)* em cerca de 26; mídia trocada atrás de um elemento fixo em cerca
  de 15; escala atrelada à rolagem em cerca de 12. Raros: efeitos de hover (4 menções), parallax (6),
  acordeões (5), movimento com quique ou mola (nenhum). Cerca de 10 sites fortes têm pouco ou nenhum
  movimento.
- Como os sites fracos falham (54 sites abaixo de 6,8): o template de prateleira da categoria em cerca
  de 20; headline centralizada, selo em pílula, dois botões e uma captura de tela em cerca de 9; módulos
  de prateleira depois de um hero marcante em cerca de 8, mais uns 17 na faixa do meio; uma fonte padrão
  sem personalidade em cerca de 13; texto pequeno ou apagado demais em cerca de 13; nunca dizer do que
  se trata em cerca de 12.
- Defeitos dos melhores sites (90 com 7,5 ou mais), que não se devem copiar: texto de 9–13 px em cerca
  de 24; informação escondida atrás do conceito em cerca de 20; a ideia se esgotando no meio da página
  em cerca de 15; texto sobre vídeo sem véu em cerca de 12; barreiras, preloaders e primeiras pinturas
  em branco em cerca de 12.

## 9. O que o inspetor diz da própria galeria

Executando as regras do próprio `inspect.mjs` desta skill nos 202 sites medidos da galeria: o site
mediano tem 4 `FAIL` e só 4% não têm nenhum. As regras que mais disparam: headline com mais de duas
linhas em algum lugar da página 60%, rótulo parecido com chapéu 60%, fios finos 50%, monoespaçada 37%,
sombras 32%, gradientes 29%, numeração de índice 29%.

Ou seja, o estilo da casa é de propósito mais rigoroso que a galeria. Ele não descreve os sites
premiados; é um alvo mais estreito dentro do que eles fazem: a escala, as ideias, a imagem e a
contenção deles, sem os enfeites que desde então viraram uniforme.

## 10. Os 25 sites de nota mais alta e suas ideias

A leitura de uma frase do painel para cada um. Repare que todos nomeiam algo que só aquele assunto
poderia ter. (Vários usam recursos que esta skill proíbe; pegue a ideia, não o enfeite.)

| Site | Fonte | Nota | Ideia |
| --- | --- | --- | --- |
| PP Neue Montreal | Awwwards | 8,6 | Um mostruário de fonte vestido de guia de viagem antigo de uma cidade: a fonte que leva o nome de Montreal é vendida com títulos de guia, cartões-postais e filmagens turísticas antigas. |
| Seasats | Awwwards | 8,4 | Paisagens marinhas calmas, na luz do entardecer, vendem barcos autônomos como instrumentos serenos, e a navegação é uma coluna de amostras de cor empilhadas, tiradas daquela paleta de mar e areia. |
| AI in Design Report 2026 | Awwwards | 8,4 | Um relatório de pesquisa diagramado como um anuário impresso em blocos de cor: uma colagem de vídeo no topo, um título enorme em grotesca apertada e blocos chapados laranja, lilás, verde-sálvia e preto com números, citações e capítulos. |
| House of Honey | Awwwards | 8,4 | Um logotipo de letras pesadas atravessado por uma letra cursiva fina: o contraste entre o pesado e o delicado se repete em todas as escalas, com uma cursiva rosa gigante atrás de frases discretas em serifada. |
| White Desert | Awwwards | 8,4 | Uma palavra, o destino, com um terço da altura da tela, sobre o vídeo como a cartela de um filme; a escala sozinha faz as vezes da distância. |
| Applied Imagination | One Page Love | 8,3 | Um ensaio pensado durante um voo é lido como uma descida: um altímetro vai de 30.000 pés a zero enquanto você rola para baixo pelas nuvens até as montanhas, no chão. |
| Cursor Compile | One Page Love | 8,3 | O nome do evento desenhado como sete curvas de traço único em loop, em sete cores, mais assinatura que logotipo, numa página off-white que no resto é quase silenciosa. |
| The New Industrials | One Page Love | 8,3 | Um ensaio longo diagramado dentro de uma grade de desenho técnico, em que os campos de cor mudam enquanto você lê e peças de máquina flutuam pelas margens até se montarem nas iniciais da editora. |
| Wild | One Page Love | 8,3 | Um ensaio de estúdio em que tudo o que é decorativo é desenhado numa mesma grade de pixels quadrados: o mapa de calor do hero, os ícones, os diagramas, as letras e o rodapé. |
| Hildén & Kaira | Awwwards | 8,3 | O nome da agência fundido em cromo líquido na largura toda, e o mesmo cromo vira os objetos que flutuam pela página, prendendo a apresentação a um único material. |
| PX Push | Awwwards | 8,2 | Uma assinatura de design apresentada como uma transmissão retrô: o site inteiro é visto através de uma tela de tubo (CRT), com uma ficha cromada do logo como mascote. |
| Illoca | Awwwards | 8,2 | Um software para arquitetos vendido como prancheta: um estúdio ilustrado em duas cores sobre papel milimetrado, em que a rolagem avança até o desenho encher a tela. |
| Aspen Search | Awwwards | 8,2 | A página é um sistema de blocos sem margens: o nome de duas palavras se divide em células que alternam texto, imagem com pontilhado, preto e um único verde-menta. |
| Dragonfly Redux | Awwwards | 8,2 | Um fundo de cripto apresentado como objeto de terminal: toda imagem é desenhada em caracteres, emoldurada por quatro letras do nome fixadas nos cantos da tela. |
| Monolog | Awwwards | 8,2 | A apresentação de um estúdio montada como uma folha assimétrica: uma coluna estreita à esquerda leva o discurso de venda, e uma coluna larga à direita empilha uma headline muito pesada e as provas. |
| The Queue | One Page Love | 8,1 | Um ensaio sobre filas em que a fila é o enfeite: uma fileira de figuras desenhadas fica ao longo da base do hero e volta entre os capítulos com roupas de épocas diferentes. |
| Paul Kalkbrenner | Awwwards | 8,1 | Tipografia de cartaz suíço para um artista de techno: o nome como uma linha preta com uma foto dentro, como se fosse uma letra, e depois cada capítulo ganha a sua cor chapada. |
| Vero New York | Awwwards | 8,1 | Uma lembrança tratada como alta-costura: um filme lento em close abre a página, e depois a escultura branca de um vestido fica fixada no centro enquanto uma frase passa por cima dela. |
| Depo Luxe | Awwwards | 8,1 | O elenco de uma produtora de filmes mostrado como um reel em tela cheia, em que cada passo é um filme só com o título, o diretor e o cliente, compostos como créditos no tamanho do texto corrido. |
| Longbow | Awwwards | 8,1 | A página se apoia num grid de construção visível de quatro colunas, e carros, cards e um marquee condensado gigante se encaixam nas células dele como objetos numa prancheta. |
| Mosby's Files | Awwwards | 8,0 | Um arquivo de arquitetos apresentado como uma pilha física de pastas coloridas com abas de índice, que você folheia. |
| Sarah & Matt Wedding | One Page Love | 8,0 | O site é o convite: um cartão no estilo de impressão tipográfica abre a página, e os enfeites e os pequenos elementos tipográficos dele viram os componentes de tudo o que vem depois. |
| Zara Webb | One Page Love | 8,0 | Um atendimento de cuidados com recém-nascidos, tocado por uma mulher só, apresentado como uma lembrança feita à mão: um coelho mascote, recortes em forma de onda e de flor, fotos espontâneas em filme. |
| Noho | Awwwards | 8,0 | Móveis vendidos por pessoas que os usam do jeito errado (vestindo cadeiras, equilibrando-se nelas, escondendo-se atrás delas, sobre fundos de cor chapada) enquanto a interface fica discreta. |
| Juggle | One Page Love | 8,0 | A headline se afoga de verdade: um campo azul chapado sobe até a metade da altura, e as linhas abaixo da linha d'água mudam de cor. |

Anotações completas de qualquer site estudado: `node scripts/draw.mjs --site <id>` (os ids aparecem nas
fichas da direção).

## 11. Como a skill foi testada

Seis briefings de clientes (uma ferramenta de faturamento, um restaurante, o portfólio de um designer,
um produto de cerâmica, uma pousada, uma conferência de design), todos sem fotografias. Para cada
briefing, um agente novo construiu a página de três jeitos: sem skill (linha de base), com outra skill
de design publicada (atelier, três briefings) e com esta skill. Cada build foi fotografado pelo
`inspect.mjs` do mesmo jeito e julgado às cegas por um agente separado, com o briefing de jurado (pesos
do Awwwards, pastas anônimas A/B/C, só capturas de tela). A skill foi revisada depois de cada rodada
com os motivos dos jurados e as anotações de quem construiu.

| Rodada | Briefings | Esta skill | Linha de base | Atelier | Vitórias |
| --- | --- | --- | --- | --- | --- |
| 1 | 4 | 6,6 | 7,7 | 6,8 | 1 de 4 |
| 2 | 3 | 7,1 | 8,0 | | 0 de 3 |
| 3 | 3 | 7,5 | 7,5 | | 1 de 3 |
| 4 (briefings inéditos) | 3 | 6,9 | 7,9 | 7,5 | 0 de 3 |
| 5 (os mesmos três) | 3 | 7,7 | 7,8 | 7,2 | 2 de 3 |

No inspetor, os builds finais mediram 0 FAIL cada um; as linhas de base mediram de 8 a 13 FAIL cada
uma (chapéus, rótulos em monoespaçada, numeração 01/02/03, fios finíssimos, gradientes, sombras,
headlines de três linhas, texto abaixo de 13 px).

O que os jurados premiaram, na ordem em que citaram: uma ideia que pertence a este cliente e não à
categoria (o teste do concorrente); um elemento vivo na página; o conteúdo inteiro num tamanho legível;
uma primeira dobra com um elemento dominante e um botão de verdade; desenhos do assunto, com detalhe. O
que puniram: uma página discreta que parecia vazia, uma headline pequena, texto deslizando sobre as
imagens ou cortado no topo, uma página que muda de cor no meio da seção, fileiras cortadas na borda
direita, uma frase grande em três linhas ou mais (lida como headline longa, qualquer que fosse o
markup), navegação que tomava conta da primeira dobra. Cada um desses virou uma regra no SKILL.md ou
uma checagem no inspetor.

Limites: um jurado por briefing por rodada, então cada nota isolada traz cerca de meio ponto de ruído;
os briefings da rodada 5 já tinham sido vistos na rodada 4; os jurados são modelos, não pessoas.

## 12. O estudo de outubro de 2026: 100 Sites of the Day

Um segundo estudo, feito para a v2.1, dos 100 Sites of the Day mais recentes do Awwwards (de 10 de
julho a 17 de outubro de 2026), com um objetivo diferente do primeiro: onde ficam as imagens e os
vídeos, como as páginas se movem e a moldura (margens, equilíbrio, espaço vazio, títulos). Cerca de três
em cada quatro desses sites também estavam no primeiro estudo.

- **Captura.** Chrome headless a 1440×900 e 390×844 em 18 de outubro de 2026: quatro quadros dos
  primeiros 4,5 segundos depois do carregamento, cada tela durante a rolagem com a roda do mouse de
  verdade (um quadro parado por passo; os quadros do meio de cada passo foram recortados a partir do
  topo do documento, e não da área visível, então não foram usados), cinco telas de celular e uma
  passada de medição na página: cada imagem e vídeo curto com a caixa, a proporção, o encaixe e os
  cantos; as bordas do conteúdo e as imagens de cada seção; os trechos em branco; o CSS que carregou
  (curvas, durações, keyframes, breakpoints, contagem de recursos); as animações, transições e
  movimentos por script que de fato rodaram; os tweens e scroll triggers do GSAP, onde a página os
  expunha. Nada que pertença a um site (código, copy *(o texto da página)*, imagens) é reproduzido na
  skill; só medições e descrições com as nossas palavras.
- **Painel.** Um leitor (modelo) por site estudou os quadros e as medições, descreveu a ideia, a
  primeira dobra, a moldura, cada seção, onde fica cada imagem, o movimento e o que não copiar, e deu a
  nota do jeito do Awwwards. 91 de 99 capturas serviram (as outras mostravam uma barreira, uma barreira
  anti-robô ou uma página de firewall). As notas foram de 6,7 a 7,9 (mediana 7,45); "de nota alta" quer
  dizer 7,5 ou mais (36 sites), "os mais baixos", abaixo de 7,3 (16).
- **O que ele mudou.** Onde vão as imagens e os vídeos: `imagery.md` §12. O que as páginas fortes fazem
  com o movimento, tokens novos, receitas e os truques a evitar: `motion.md` §2, §4–6 e §9–10. Espaço
  vazio e a moldura: `layout.md` §4–5. Composições novas em `library/heroes.json` e `sections.json` e
  anotações sobre mídia e movimento em `library/sites.json` (`draw.mjs --site <id>`).
- **Os números principais.** As imagens ocupam, na mediana, 16% de uma tela rolada, mas em telas
  inteiras: 42% das telas não têm nenhuma e 19% são 90% imagem ou mais. A página mediana leva 7 imagens
  (as de nota alta 8, as mais baixas 2) e 42% levam vídeo (metade dos sites de nota alta, um dos 16 mais
  baixos). 94% das imagens têm cantos retos. Os ease-outs fortes são as curvas que rodaram (expo e quint
  out); a mediana de todas as que rodaram num site é 420 ms. 60 de 99 abrem com uma tela de
  carregamento, e um terço das páginas aproveitáveis ainda estava ilegível 4,5 segundos depois do
  carregamento, sem ganho nenhum nas notas de design. Cerca de 1 seção de texto em 100 deixa metade da
  largura vazia; as margens externas das páginas fortes batem com diferença de poucos pixels; 82% das
  seções de texto abrem com um título; 15 de 97 primeiras dobras nunca dizem do que se trata, e essas
  perdem pontos de usabilidade.
- **Limites.** Uma captura por site, num dia só; uma cena WebGL pode sair em branco num navegador
  headless; os quadros atrelados à rolagem são em parte um efeito das bibliotecas de rolagem suave; um
  leitor por site, então cada nota isolada traz cerca de meio ponto de ruído.

## 13. O estudo das telas de app

Para dashboards e telas de app (v2.1), um estudo separado de 23 telas de produtos reais escolhidas pelo
autor (17 produtos, 17 claras e 6 escuras, a 1440–1512 px): cada tela medida a partir dos pixels por um
leitor com recortes em resolução cheia, seis relatórios transversais (estrutura, dados e gráficos,
tabelas e formulários, linguagem visual, gosto, estilos) e uma síntese em `references/app-screens.md` e
`library/app.json` (sete estilos, cinco estruturas, padrões de tela). As capturas de tela continuam
privadas; a skill traz só as medições e as regras. Rodadas de teste às cegas de telas de app feitas com
e sem a skill moldaram depois os avisos no começo desse arquivo.
