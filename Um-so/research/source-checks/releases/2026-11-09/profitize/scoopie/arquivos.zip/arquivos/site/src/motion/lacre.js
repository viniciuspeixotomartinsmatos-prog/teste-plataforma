// O lacre: a aba puxada desce o menu (papel creme com a borda picotada). Fecha na aba, no Esc ou num link.
import { gsap } from 'gsap';
import { rolaPara } from './smooth.js';

export function lacre({ aba, menu, lenis, reduzido }) {
  const txt = aba.querySelector('.lacre__txt');
  const links = [...menu.querySelectorAll('a')];
  let aberto = false;

  function abre() {
    aberto = true;
    menu.hidden = false;
    aba.setAttribute('aria-expanded', 'true');
    txt.textContent = 'FECHAR';
    lenis?.stop();
    gsap.killTweensOf([menu, ...links]);
    gsap.to(menu, { y: 0, yPercent: 0, duration: reduzido ? 0 : 0.7, ease: 'back.out(1.2)' });
    gsap.fromTo(links, { y: -30, opacity: 0 }, { y: 0, opacity: 1, duration: reduzido ? 0 : 0.5, ease: 'power3.out', stagger: 0.06, delay: reduzido ? 0 : 0.15 });
    links[0]?.focus({ preventScroll: true });
  }
  function fecha(depois) {
    aberto = false;
    aba.setAttribute('aria-expanded', 'false');
    txt.textContent = 'PUXE O LACRE';
    gsap.killTweensOf([menu, ...links]);
    gsap.to(menu, {
      yPercent: -104, duration: reduzido ? 0 : 0.45, ease: 'power3.in',
      onComplete: () => { menu.hidden = true; lenis?.start(); depois?.(); },
    });
  }
  gsap.set(menu, { yPercent: -104 });
  aba.addEventListener('click', () => (aberto ? fecha(() => aba.focus()) : abre()));
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && aberto) fecha(() => aba.focus()); });
  links.forEach((a) => a.addEventListener('click', (e) => {
    e.preventDefault();
    const alvo = a.getAttribute('href');
    fecha(() => rolaPara(lenis, alvo));
  }));
}
