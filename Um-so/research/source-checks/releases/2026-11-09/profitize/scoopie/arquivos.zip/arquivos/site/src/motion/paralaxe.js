// Paralaxe presa à rolagem: cada [data-v] anda v telas para cima ou para baixo enquanto a seção passa.
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { animaLetras } from './letras.js';

export function paralaxe(el) {
  el.querySelectorAll('[data-v]').forEach((o) => {
    const v = parseFloat(o.dataset.v);
    gsap.fromTo(o, { y: () => -v * innerHeight }, {
      y: () => v * innerHeight, ease: 'none',
      scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true, invalidateOnRefresh: true },
    });
  });
}

// letras que entram em ordem aleatória, por marco (tempo fixo); ao sair, ficam
export function letrasAleatorias(letras, gatilho, { inicio = 'top 72%', espalha = 0.85 } = {}) {
  gsap.set(letras, { opacity: 0 });
  ScrollTrigger.create({
    trigger: gatilho, start: inicio, once: true,
    onEnter: () => animaLetras(letras, {
      de: () => ({ s: 0.4, r: gsap.utils.random(-25, 25), a: 0 }),
      duracao: 0.28, atraso: () => Math.random() * espalha, ease: 'back.out(3)',
    }).catch(() => {}),
  });
}
