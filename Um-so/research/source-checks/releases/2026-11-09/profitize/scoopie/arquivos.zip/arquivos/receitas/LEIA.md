# Receitas da Scoopie

Na Scoopie, as imagens foram geradas por IA (o gerador de imagens do ChatGPT), a partir dos prompts desta pasta. O resto é código:

- **o pote 3D** (corpo, tampa, rótulo enrolado, a faixa que ele vira), feito no Three.js, sem modelo baixado;
- **o logo, o selo do sabor, a tampa e a faixa**, desenhados em canvas a partir do nome e dos textos de `src/config.js`;
- **os potinhos** do seletor, dos adesivos e do rodapé, desenhados pelo próprio 3D quando a página abre;
- **os ícones das redes** (Simple Icons, CC0) e o resto (curvas, onda, botões, menu), em CSS e SVG.

## As imagens e onde aparecem

Todas ficam em `public/img/`, em WebP. Para trocar qualquer uma, use o conversor (ele corta e grava no tamanho certo):

```
npm run imagens -- rotulo <id-do-sabor> <arquivo>
npm run imagens -- foto <nome> <arquivo>
npm run imagens -- chamada <arquivo>
npm run imagens -- objeto <nome> <arquivo>
```

| arquivo | onde aparece | formato | receita |
|---|---|---|---|
| `rotulo-<sabor>.webp` (5) | a arte do rótulo, em volta do pote 3D e na faixa | 3:2, 1536 × 1024 (e a de 1024 do celular) | `rotulo-<sabor>.txt` |
| `foto-colher`, `foto-crianca`, `foto-casquinha`, `foto-brinde` | as fotos em adesivo do palco do sabor | quadrada, 760 × 760 | `foto-<nome>.txt` + `_foto.txt` + `_pote.txt` |
| `foto-comemorar`, `foto-dividir`, `foto-esquecer` | as fotos das linhas gigantes dos momentos | quadrada, 760 × 760 | idem |
| `foto-maos` | a chamada "Bora pedir?" | em pé, 2:3, 900 × 1350 | `foto-maos.txt` |
| `lista`, `ingresso`, `polaroide`, `convite`, `desenho`, `kraft` | os objetos da porta da geladeira | recortados, fundo transparente | `<nome>.txt` + `_objeto.txt` |
| `ima-1` a `ima-5` | os ímãs | uma folha com os cinco, recortados | `imas.txt` |
| `colher-1` a `colher-3` | as colheres da física do rodapé | uma folha com as três, fundo magenta | `colheres.txt` |
| `papel` e `papel-alfa` | o papel amassado por cima de tudo | quadrada, 1024 × 1024 | `papel.txt` |

Os arquivos que começam com `_` são o estilo da série: um parágrafo que se repete em todo prompt daquele tipo, para as imagens saírem com a mesma cara.

## A ordem

1. **Os rótulos primeiro.** Eles são a cara do produto. A arte dá a volta inteira no pote: as laterais emendam uma na outra, e o motivo mais forte fica no meio, que é a frente. Sem letras e sem logo (o selo com o sabor é desenhado por cima, pelo código).
2. **Com os rótulos no site, o pote 3D já mostra a embalagem nova.** Salve um dos potinhos do seletor de sabores (botão direito, "salvar imagem"): ele é a referência das fotos.
3. **As fotos**, com o potinho salvo anexado como imagem de referência. O parágrafo `_pote.txt` diz ao gerador que o pote da foto tem de ser exatamente aquele.
4. **Os objetos do mural e as colheres**, com fundo transparente. Se o gerador não der transparência, peça um fundo chapado verde `#00FF00` (magenta `#FF00FF` para objeto verde, como a colher de menta): o conversor recorta sozinho.

## Que ferramenta usar

Qualquer gerador de imagem que aceite uma imagem de referência: o do ChatGPT, o Gemini, o Midjourney, o Ideogram e outros. Cole o prompt inteiro (o assunto e o parágrafo de estilo) e anexe o potinho nas fotos.

**Custo:** a série inteira tem umas 20 imagens. Com a assinatura do ChatGPT, sai sem custo extra; nos geradores pagos por imagem, fica em poucos reais.

## Para outro produto

- **O rótulo:** troque os motivos do prompt pelos ingredientes do produto (café: grãos, folhas, xícaras; açaí: frutas, granola, folhas de palmeira; doce de leite: vacas, colheres, potes de vidro). Mantenha o resto do prompt: sem letras, até a borda, três tintas sobre papel creme, laterais que emendam, motivo forte no meio.
- **As fotos:** os mesmos momentos (alguém comendo, um aniversário, dividindo, a pilha de embalagens na mão), com o potinho da embalagem nova anexado.
- **Os objetos do mural:** servem para quase toda marca. Só a lista de compras fala de sorvete: gere de novo pela receita `lista.txt`, trocando o item riscado.

## Sem imagem nova

As fotos da demo mostram o pote da Scoopie (com os rótulos de pistache, morango...), sem o nome da marca. Elas servem de rascunho enquanto as fotos de verdade não chegam. Antes de publicar, ou entram fotos do produto da pessoa, ou os adesivos saem (o guia diz onde).
