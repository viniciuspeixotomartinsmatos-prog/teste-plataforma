// Lenis + ScrollTrigger num relógio só (o do GSAP). Sem Lenis com movimento reduzido.
// No toque a rolagem é a nativa (sem syncTouch): o Lenis só suaviza a roda e o trackpad.
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';

export const toque = matchMedia('(hover: none)').matches;

export function criaScroll({ reduzido }) {
  ScrollTrigger.config({ ignoreMobileResize: true });
  if (reduzido) return null;
  const lenis = new Lenis({ lerp: 0.1, wheelMultiplier: 1, smoothWheel: true, syncTouch: false });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((t) => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);
  return lenis;
}

/**
 * Leva a página até um alvo (seletor, elemento ou y). Com o mouse, pelo Lenis (o mesmo teto da roda); no toque,
 * pela rolagem nativa do navegador, que não briga com o dedo.
 */
export function rolaPara(lenis, alvo, { duracao = 1.4 } = {}) {
  const el = typeof alvo === 'string' ? document.querySelector(alvo) : alvo;
  const y = typeof alvo === 'number' ? alvo : el ? el.getBoundingClientRect().top + scrollY : null;
  if (y === null) return;
  if (lenis && !toque) lenis.scrollTo(y, { duration: duracao });
  else scrollTo({ top: y, behavior: lenis ? 'smooth' : 'auto' });
}
