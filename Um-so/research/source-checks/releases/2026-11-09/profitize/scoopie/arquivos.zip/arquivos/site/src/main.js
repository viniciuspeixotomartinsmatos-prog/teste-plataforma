import '@fontsource-variable/bricolage-grotesque/standard.css';

import './styles/tokens.css';
import './styles/base.css';
import './sections/abertura.css';
import './sections/lacre.css';
import './sections/hero.css';
import './sections/mural.css';
import './sections/sabores.css';
import './sections/momentos.css';
import './sections/pedir.css';
import './sections/rodape.css';
import './sections/papel.css';

import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MARCA, SABORES, FRASE_FAIXA } from './config.js';
import { criaScroll, rolaPara, toque } from './motion/smooth.js';
import { criarGuia } from './motion/guia.js';
import { scrollbar } from './motion/scrollbar.js';
import { rolando } from './motion/rolando.js';
import { abertura } from './motion/abertura.js';
import { hero } from './motion/hero.js';
import { mural } from './motion/mural.js';
import { sabores } from './motion/sabores.js';
import { momentos } from './motion/momentos.js';
import { pedir } from './motion/pedir.js';
import { lacre } from './motion/lacre.js';
import { canvasMarca } from './three/marca.js';
import { criaPalco } from './three/palco.js';
import { criaRetratos } from './three/retratos.js';

gsap.registerPlugin(ScrollTrigger);
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
scrollTo(0, 0);

const $ = (q) => document.querySelector(q);
const reduzido = document.documentElement.classList.contains('is-reduced');

const lenis = criaScroll({ reduzido });
criarGuia({ lenis });
lenis?.stop();
scrollbar({ lenis });
rolando();

const ab = abertura({ el: $('.abertura'), marca: MARCA, reduzido });
const he = hero({ el: $('.hero'), marca: MARCA, reduzido });
mural({ el: $('.mural'), reduzido });
momentos({ el: $('.momentos'), reduzido });
pedir({ el: $('.pedir'), reduzido });
lacre({ aba: $('.lacre'), menu: $('#menu'), lenis, reduzido });

// links internos: com o mouse passam pelo Lenis (o mesmo teto da roda); no toque, rolagem nativa
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href^="#"]');
  if (!a || e.defaultPrevented || a.closest('.menu')) return;
  const alvo = document.querySelector(a.getAttribute('href'));
  if (!alvo) return;
  e.preventDefault();
  rolaPara(lenis, alvo);
});

// o logo do rodapé: o tamanho vem do CSS (font-size de .rodape__marca), que já muda no celular
document.fonts.load('100px "Bagel Fat One"').then(() => {
  const lugar = $('.rodape__marca');
  lugar.append(canvasMarca(MARCA, { px: Math.round(parseFloat(getComputedStyle(lugar).fontSize)), recheio: '#ff6db8', contorno: '#fff1de' }));
});

// o palco lê estas seções: a onda da borda do sabor e, no celular, o espaço livre onde o pote encaixa
const secoes = {
  hero: $('.hero'), heroTitulo: $('.hero__titulo'),
  sabores: $('.sabores'), saboresFundo: $('.sabores__fundo'), saboresInfo: $('.sabores__info'), saboresO: $('.sabores__o'),
};
const minimo = new Promise((ok) => setTimeout(ok, 750)); // o logo tem tempo de entrar inteiro
const palco = criaPalco({ canvas: $('.palco'), marca: MARCA, sabores: SABORES, frase: FRASE_FAIXA, secoes });

// Trabalho pesado depois da abertura (as texturas dos outros sabores, os retratos do pote) só roda num respiro do
// navegador e longe de rolagem recente: nunca no meio do gesto, que é onde um tranco aparece.
let ultimaRolagem = 0;
addEventListener('scroll', () => { ultimaRolagem = performance.now(); }, { passive: true });
const ocioso = window.requestIdleCallback || ((f) => setTimeout(() => f({ timeRemaining: () => 20, didTimeout: false }), 60));
const folga = () => new Promise((ok) => {
  const tenta = () => ocioso((d) => {
    if (performance.now() - ultimaRolagem < 350 || d.timeRemaining() < 12) { setTimeout(tenta, 120); return; }
    ok();
  }, { timeout: 1200 });
  tenta();
});

// os retratos do pote (seletor, adesivos dos momentos, física do rodapé) saem do mesmo 3D; as imagens de
// public/img ficam de reserva
const retratos = {};
let retratosProntos = Promise.resolve();
function geraRetratos() {
  retratosProntos = (async () => {
    await folga();
    const r = await criaRetratos({ marca: MARCA, frase: FRASE_FAIXA });
    try {
      for (const s of SABORES) {
        await folga();
        retratos[s.id] = await r.retratos(s);
        for (const tipo of ['pote', 'tampa']) {
          document.querySelectorAll(`img[data-retrato="${tipo}-${s.id}"]`).forEach((im) => { im.src = retratos[s.id][tipo]; });
        }
      }
    } finally {
      r.descarta();
    }
  })().catch((erro) => console.warn('retratos do pote: ficam as imagens de reserva', erro));
}

palco.then((p) => {
  const sab = sabores({ el: $('.sabores'), lista: SABORES, lenis, palco: p, reduzido });
  // a física do rodapé (e o Matter.js) só carrega quando o rodapé chega perto
  const rodape = $('.rodape');
  const perto = new IntersectionObserver(async ([en]) => {
    if (!en.isIntersecting) return;
    perto.disconnect();
    await Promise.race([retratosProntos, new Promise((ok) => setTimeout(ok, 3000))]);
    import('./motion/fisica.js').then(({ fisica }) => fisica({
      el: rodape, canvas: $('.rodape__fisica'), reduzido,
      potes: SABORES.map((s) => retratos[s.id]?.pote || `/img/pote-${s.id}.webp`),
      colheres: ['/img/colher-1.webp', '/img/colher-2.webp', '/img/colher-3.webp'],
      redes: [
        { nome: 'Instagram', icone: 'instagram', href: '#rodape' },
        { nome: 'TikTok', icone: 'tiktok', href: '#rodape' },
        { nome: 'WhatsApp', icone: 'whatsapp', href: '#rodape' },
        { nome: 'YouTube', icone: 'youtube', href: '#rodape' },
      ],
      irParaSabor: (i) => sab.vai(i),
    }));
  }, { rootMargin: '150% 0px' });
  perto.observe(rodape);
  gsap.ticker.add(() => p.atualiza(scrollY));
  // no toque, a barra do navegador some e volta rolando: mudança só de altura pequena não refaz o palco
  let rt, ultW = innerWidth, ultH = innerHeight;
  addEventListener('resize', () => {
    if (toque && innerWidth === ultW && Math.abs(innerHeight - ultH) < 120) return;
    ultW = innerWidth;
    ultH = innerHeight;
    clearTimeout(rt);
    rt = setTimeout(() => { ScrollTrigger.refresh(); p.layout(); }, 150);
  });
  document.fonts.ready.then(() => { ScrollTrigger.refresh(); p.layout(); });
});

Promise.all([palco, minimo]).then(([p]) => ab.revela({
  aoDescobrir: () => he.entra(),
  aoFim: () => {
    lenis?.start();
    document.body.dataset.pronto = '1';
    // primeiro as texturas dos outros sabores (o palco precisa delas), depois os retratos
    p.aquece(folga).then(geraRetratos);
  },
})).catch((erro) => {
  console.error(erro);
  ab.revela({ aoDescobrir: () => he.entra(), aoFim: () => lenis?.start() });
});

if (import.meta.env.DEV) Object.assign(window, { __lenis: lenis, __palco: palco, __retratos: retratos, __retratosProntos: () => retratosProntos, gsap, ScrollTrigger });
