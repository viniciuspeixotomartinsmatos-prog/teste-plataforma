// Quebra um texto em letras (spans) sem perder a leitura: o texto inteiro fica num rótulo para leitor de tela.
// E anima as letras pelo próprio navegador (Web Animations), não pelo GSAP: transform e opacidade rodam no
// compositor, sem trabalho por quadro na thread principal e sem repintar o texto a cada quadro (era o que derrubava
// os quadros quando muitas letras entravam juntas, como no kraft e no nome do sabor).
import { gsap } from 'gsap';

export function quebraLetras(el, classe = 'letra') {
  const texto = el.textContent;
  el.setAttribute('aria-label', texto.trim().replace(/\s+/g, ' '));
  el.textContent = '';
  const letras = [];
  // palavra por palavra, para a quebra de linha não separar letras de uma palavra
  texto.trim().split(/(\s+)/).forEach((parte) => {
    if (/^\s+$/.test(parte)) { el.append(' '); return; }
    const palavra = document.createElement('span');
    palavra.className = 'palavra';
    palavra.setAttribute('aria-hidden', 'true');
    for (const ch of parte) {
      const s = document.createElement('span');
      s.className = classe;
      s.textContent = ch;
      palavra.append(s);
      letras.push(s);
    }
    el.append(palavra);
  });
  return letras;
}

// a curva do GSAP copiada ponto a ponto para o linear() do CSS: a mesma curva, rodando no navegador
const curvas = {};
const temLinear = typeof CSS !== 'undefined' && CSS.supports?.('animation-timing-function', 'linear(0, 0.5, 1)');
export function curva(nome) {
  if (!curvas[nome]) {
    const f = gsap.parseEase(nome);
    curvas[nome] = temLinear
      ? `linear(${Array.from({ length: 49 }, (_, i) => +f(i / 48).toFixed(4)).join(', ')})`
      : nome.includes('back') ? 'cubic-bezier(0.34, 1.56, 0.64, 1)' : 'cubic-bezier(0.55, 0, 1, 0.45)';
  }
  return curvas[nome];
}

const tf = ({ y = 0, r = 0, s = 1 } = {}) => `translateY(${y}%) rotate(${r}deg) scale(${s})`;

/**
 * Anima letras de um estado para outro: y em % da altura da letra, r em graus, s escala, a opacidade.
 * de e para podem ser funções da letra (i), para um giro diferente em cada uma; atraso(i) em segundos.
 * Devolve uma promessa que resolve quando a última termina (e é rejeitada se alguma for cancelada).
 * No fim, o estado final fica gravado na letra e a animação sai (a letra deixa de ser camada).
 */
export function animaLetras(letras, { de, para = { y: 0, r: 0, s: 1, a: 1 }, duracao, atraso = () => 0, ease, guarda = true }) {
  const easing = curva(ease);
  const fins = letras.map((l, i) => {
    l.getAnimations().forEach((an) => an.cancel());
    const a = typeof de === 'function' ? de(i) : de;
    const b = typeof para === 'function' ? para(i) : para;
    const an = l.animate(
      [{ transform: tf(a), opacity: a.a ?? 1 }, { transform: tf(b), opacity: b.a ?? 1 }],
      { duration: duracao * 1000, delay: atraso(i) * 1000, easing, fill: 'both' },
    );
    return an.finished.then(() => {
      if (!guarda) return;
      try { an.commitStyles(); } catch { /* a letra saiu da página */ }
      an.cancel();
    });
  });
  return Promise.all(fins);
}
