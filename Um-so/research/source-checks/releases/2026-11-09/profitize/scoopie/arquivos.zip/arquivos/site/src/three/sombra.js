// A sombra do pote e da faixa, feita no próprio WebGL: o palco é desenhado de novo numa resolução baixa (só o alfa
// importa), desfocado em duas passadas e posto por baixo do desenho, deslocado para baixo. É o mesmo drop-shadow
// (0 10u 14u, rgba(20, 6, 2, 0.4)) que um filtro CSS faria, sem refazer um desfoque na tela cheia a cada quadro.
import * as THREE from 'three';

const SIGMA = 3; // o desfoque, em px da resolução baixa (o tamanho dela é escolhido para dar o desfoque pedido)
const RAIO = 6;
const pesos = Array.from({ length: RAIO + 1 }, (_, i) => Math.exp(-(i * i) / (2 * SIGMA * SIGMA)));
const soma = pesos.reduce((s, p, i) => s + (i ? 2 * p : p), 0);
const PESOS = pesos.map((p) => (p / soma).toFixed(6));

const VERTICE = 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
// desfoque gaussiano separável, só no alfa
const DESFOCA = `
uniform sampler2D tMapa;
uniform vec2 uPasso;
varying vec2 vUv;
void main() {
  float a = texture2D(tMapa, vUv).a * ${PESOS[0]};
  ${PESOS.slice(1).map((p, k) => `a += (texture2D(tMapa, vUv + uPasso * ${k + 1}.0).a + texture2D(tMapa, vUv - uPasso * ${k + 1}.0).a) * ${p};`).join('\n  ')}
  gl_FragColor = vec4(0.0, 0.0, 0.0, a);
}`;
// a sombra na cor e na força do drop-shadow, deslocada para baixo
const COMPOE = `
uniform sampler2D tMapa;
uniform float uDesloca;
uniform vec3 uCor;
uniform float uForca;
varying vec2 vUv;
void main() {
  float a = texture2D(tMapa, vUv + vec2(0.0, uDesloca)).a;
  gl_FragColor = vec4(uCor, a * uForca);
}`;

export function criaSombra(renderer, { cor = [20, 6, 2], forca = 0.4, deslocaU = 10, desfocaU = 14 } = {}) {
  const rtCena = new THREE.WebGLRenderTarget(16, 16);
  const rtA = new THREE.WebGLRenderTarget(16, 16, { depthBuffer: false });
  const rtB = new THREE.WebGLRenderTarget(16, 16, { depthBuffer: false });
  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const desfoca = new THREE.ShaderMaterial({
    uniforms: { tMapa: { value: null }, uPasso: { value: new THREE.Vector2() } },
    vertexShader: VERTICE, fragmentShader: DESFOCA, depthTest: false, depthWrite: false,
  });
  const compoe = new THREE.ShaderMaterial({
    uniforms: {
      tMapa: { value: rtB.texture }, uDesloca: { value: 0 },
      uCor: { value: new THREE.Vector3(cor[0] / 255, cor[1] / 255, cor[2] / 255) }, uForca: { value: forca },
    },
    vertexShader: VERTICE, fragmentShader: COMPOE, transparent: true, depthTest: false, depthWrite: false,
  });
  const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), desfoca);
  quad.frustumCulled = false;
  const cena = new THREE.Scene();
  cena.add(quad);
  let rw = 16, rh = 16;

  /** w e h: o canvas em px CSS; u: a escala de cena (--u) */
  function tamanho(w, h, u) {
    // o desfoque do CSS (raio desfocaU·u, sigma metade disso) cai em SIGMA px nesta resolução
    const f = Math.min(1, SIGMA / ((desfocaU / 2) * u));
    rw = Math.max(16, Math.round(w * f));
    rh = Math.max(16, Math.round(h * f));
    rtCena.setSize(rw, rh);
    rtA.setSize(rw, rh);
    rtB.setSize(rw, rh);
    compoe.uniforms.uDesloca.value = (deslocaU * u) / h; // em uv: a sombra cai para baixo na tela
  }

  /** desenha a sombra no canvas (limpando antes); o palco vem por cima, sem limpar */
  function desenha(scene, cam) {
    renderer.setRenderTarget(rtCena);
    renderer.render(scene, cam);
    quad.material = desfoca;
    desfoca.uniforms.tMapa.value = rtCena.texture;
    desfoca.uniforms.uPasso.value.set(1 / rw, 0);
    renderer.setRenderTarget(rtA);
    renderer.render(cena, camera);
    desfoca.uniforms.tMapa.value = rtA.texture;
    desfoca.uniforms.uPasso.value.set(0, 1 / rh);
    renderer.setRenderTarget(rtB);
    renderer.render(cena, camera);
    renderer.setRenderTarget(null);
    quad.material = compoe;
    renderer.render(cena, camera);
  }

  /**
   * Os shaders compilam em paralelo, sem travar a página: o desfoque, a composição e a variante dos materiais do
   * palco para a resolução baixa (desenhar num alvo fora da tela pede outro programa que o da tela).
   */
  function compila(scene, cam) {
    const prontos = [];
    renderer.setRenderTarget(rtCena);
    prontos.push(renderer.compileAsync(scene, cam));
    renderer.setRenderTarget(rtA);
    quad.material = desfoca;
    prontos.push(renderer.compileAsync(cena, camera));
    renderer.setRenderTarget(null);
    quad.material = compoe;
    prontos.push(renderer.compileAsync(cena, camera));
    quad.material = desfoca;
    return Promise.all(prontos);
  }

  return { tamanho, desenha, compila };
}
