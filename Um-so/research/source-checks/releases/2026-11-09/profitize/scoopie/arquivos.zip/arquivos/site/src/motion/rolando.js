// .is-scrolling: rolando com o cursor parado, o hover não acende embaixo dele (é assim que a prévia é gravada).
// Sai no primeiro movimento real do mouse (o Safari zera movementX, então compara a posição).
export function rolando() {
  const html = document.documentElement;
  let px = -1, py = -1;
  addEventListener('scroll', () => html.classList.add('is-scrolling'), { passive: true });
  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse') return;
    if (px >= 0 && Math.abs(e.clientX - px) + Math.abs(e.clientY - py) > 2) html.classList.remove('is-scrolling');
    px = e.clientX;
    py = e.clientY;
  }, { passive: true });
}
