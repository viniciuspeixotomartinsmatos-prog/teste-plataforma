// Sabor em destaque: a seção fica presa enquanto a página rola; a cada marco o sabor troca (cor, título, texto,
// seletor e o pote no 3D, que dá uma volta). O seletor leva a rolagem até o sabor escolhido.
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { quebraLetras, animaLetras } from './letras.js';
import { rolaPara } from './smooth.js';

export function sabores({ el, lista, lenis, palco, reduzido }) {
  const nome = el.querySelector('.sabores__nome');
  const desc = el.querySelector('.sabores__desc');
  const botoes = [...el.querySelectorAll('.seletor__pote')];
  const fotos = [...el.querySelectorAll('.adesivo')];
  const tinta = el.querySelector('.sabores__tinta');
  let atual = 0, emCurso = null, vezNome = 0;

  const fundo = (i) => el.style.setProperty('--cor', lista[i].cor);
  const letra = (i) => { el.style.setProperty('--cor-titulo', lista[i].titulo); el.style.setProperty('--tinta', lista[i].tinta); };

  function aplica(i) {
    if (i === atual) return;
    const s = lista[i];
    atual = i;
    botoes.forEach((b, k) => { b.classList.toggle('is-ativo', k === i); b.setAttribute('aria-pressed', String(k === i)); });
    palco?.trocaSabor(i);
    if (reduzido) { fundo(i); letra(i); nome.textContent = s.nome; desc.textContent = s.desc; return; }
    // a cor nova se abre em círculo a partir do pote; no fim ela vira o fundo da seção inteira
    gsap.killTweensOf(tinta);
    if (emCurso !== null) fundo(emCurso); // a tinta que estava abrindo vira fundo antes da próxima
    emCurso = i;
    tinta.style.background = s.cor;
    gsap.fromTo(tinta, { clipPath: 'circle(0% at 50% 50%)' }, {
      clipPath: 'circle(76% at 50% 50%)', duration: 0.62, ease: 'power2.inOut',
      onComplete: () => { fundo(i); emCurso = null; gsap.set(tinta, { clipPath: 'circle(0% at 50% 50%)' }); },
    });
    // o nome sai pulando e o novo entra letra por letra (rolando rápido, só a última troca termina)
    const vez = ++vezNome;
    const velhas = [...nome.querySelectorAll('.letra')];
    animaLetras(velhas, {
      de: { a: 1 }, para: () => ({ y: -60, r: gsap.utils.random(-14, 14), a: 0 }),
      duracao: 0.22, atraso: (k) => k * 0.02, ease: 'power2.in', guarda: false,
    }).then(() => {
      if (vez !== vezNome) return;
      nome.textContent = s.nome;
      letra(i);
      animaLetras(quebraLetras(nome), {
        de: () => ({ y: 70, r: gsap.utils.random(-16, 16), s: 0.7, a: 0 }),
        duracao: 0.55, atraso: (k) => k * 0.035, ease: 'back.out(2.2)',
      }).catch(() => {});
    }).catch(() => {});
    gsap.to(desc, { opacity: 0, y: -8, duration: 0.18, onComplete: () => {
      desc.textContent = s.desc;
      gsap.fromTo(desc, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.35, ease: 'power2.out' });
    } });
    // as fotos dão um tremidinho, como adesivo batido na mesa
    gsap.fromTo(fotos, { scale: 1 }, { scale: 1.06, duration: 0.14, yoyo: true, repeat: 1, ease: 'power1.out', stagger: 0.04 });
  }

  quebraLetras(nome);
  fundo(0);
  letra(0);

  // marcos: a seção presa é dividida em cinco faixas iguais da rolagem
  const st = ScrollTrigger.create({
    trigger: el, start: 'top top', end: 'bottom bottom',
    onUpdate: (self) => aplica(Math.min(lista.length - 1, Math.floor(self.progress * lista.length))),
  });

  // as fotos flutuam presas à rolagem, cada uma num ritmo
  if (!reduzido) {
    fotos.forEach((f, k) => gsap.fromTo(f, { y: (k % 2 ? 40 : -30) }, {
      y: (k % 2 ? -50 : 40), ease: 'none', scrollTrigger: { trigger: el, start: 'top top', end: 'bottom bottom', scrub: true },
    }));
  }

  // leva a rolagem até o marco do sabor (o estado sempre segue a rolagem)
  function vai(i) {
    rolaPara(lenis, st.start + ((i + 0.5) / lista.length) * (st.end - st.start), { duracao: 1.1 });
  }
  botoes.forEach((b, i) => b.addEventListener('click', () => vai(i)));
  return { vai };
}
