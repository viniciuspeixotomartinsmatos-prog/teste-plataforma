// Rodapé com física (Matter.js): quando ele chega, os potes, as colheres e os ícones das redes caem, batem e se
// empilham. Dá para pegar e jogar com o mouse ou o dedo (no toque, só de lado: o gesto vertical rola a página).
// Clicar num pote leva ao sabor dele; clicar num ícone abre a rede.
import Matter from 'matter-js';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { carregaImagem } from '../three/artes.js';

const { Engine, Bodies, Body, Composite, Constraint, Query } = Matter;

// ícones das redes: desenhos do Simple Icons (CC0 1.0, simpleicons.org), caixa de 24 × 24
const ICONES = {
  instagram: new Path2D('M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077'),
  tiktok: new Path2D('M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z'),
  whatsapp: new Path2D('M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z'),
  youtube: new Path2D('M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z'),
};

export function fisica({ el, canvas, potes, colheres, redes, irParaSabor, reduzido }) {
  const ctx = canvas.getContext('2d');
  const engine = Engine.create({ gravity: { x: 0, y: 1.15 } });
  const mundo = engine.world;
  let W = 0, H = 0, dpr = 1, u = 1, paredes = [], corpos = [], jogou = false, visivel = false, sujo = true;
  const noMundo = new Set();
  let imgsPotes = [], imgsColheres = [];
  const prontas = Promise.all([
    Promise.all(potes.map((p) => carregaImagem(p))).then((l) => { imgsPotes = l; }),
    Promise.all(colheres.map((p) => carregaImagem(p).catch(() => null))).then((l) => { imgsColheres = l.filter(Boolean); }),
  ]);

  function tamanho() {
    W = el.clientWidth;
    H = el.clientHeight;
    dpr = Math.min(devicePixelRatio || 1, 2);
    u = W < 760 ? (W / 390) * 0.52 : Math.min(W / 1440, H / 900); // no celular, pela largura
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    Composite.remove(mundo, paredes);
    const g = 200;
    // no celular o chão fica acima da linha de baixo (redes e ©), para a pilha não cobrir os links
    const piso = W < 760 ? H - (el.querySelector('.rodape__base')?.offsetHeight || 0) - 18 : H;
    paredes = [
      Bodies.rectangle(W / 2, piso + g / 2, W * 3, g, { isStatic: true }),
      Bodies.rectangle(-g / 2, -H, g, H * 5, { isStatic: true }),
      Bodies.rectangle(W + g / 2, -H, g, H * 5, { isStatic: true }),
    ];
    Composite.add(mundo, paredes);
    corpos.forEach((b) => { if (b.position.x < 0 || b.position.x > W) Body.setPosition(b, { x: W / 2, y: b.position.y }); });
    desenha();
  }

  function cria() {
    const lista = [];
    const x = () => W * (0.12 + Math.random() * 0.76);
    imgsPotes.forEach((img, i) => {
      const h = 165 * u, w = (h * img.width) / img.height;
      const b = Bodies.rectangle(x(), -120 - i * 70, w * 0.9, h * 0.94, {
        chamfer: { radius: w * 0.14 }, restitution: 0.25, friction: 0.7, density: 0.0018, angle: (Math.random() - 0.5) * 1.2,
      });
      b.plugin = { tipo: 'pote', img, w, h, sabor: i };
      lista.push(b);
    });
    imgsColheres.slice(0, W < 760 ? 2 : 3).forEach((img, i) => { // no celular, menos corpos
      const comp = 190 * u, larg = (comp * Math.min(img.width, img.height)) / Math.max(img.width, img.height);
      const deitada = img.width > img.height;
      const b = Bodies.rectangle(x(), -500 - i * 60, deitada ? comp : larg, deitada ? larg : comp, {
        chamfer: { radius: larg * 0.45 }, restitution: 0.35, friction: 0.5, density: 0.0012, angle: Math.random() * Math.PI,
      });
      b.plugin = { tipo: 'colher', img, w: deitada ? comp : larg, h: deitada ? larg : comp };
      lista.push(b);
    });
    redes.forEach((r, i) => {
      const raio = 48 * u;
      const b = Bodies.circle(x(), -760 - i * 70, raio, { restitution: 0.5, friction: 0.4, density: 0.0016 });
      b.plugin = { tipo: 'rede', raio, ...r };
      lista.push(b);
    });
    return lista;
  }

  function solta() {
    if (jogou) return;
    jogou = true;
    prontas.then(() => {
      corpos = cria();
      if (reduzido) {
        Composite.add(mundo, corpos);
        corpos.forEach((b) => noMundo.add(b));
        for (let i = 0; i < 360; i++) Engine.update(engine, 1000 / 60);
        desenha();
        return;
      }
      // um de cada vez, como quem vira a sacola na mesa
      corpos.forEach((b, i) => gsap.delayedCall(i * 0.09, () => { Composite.add(mundo, b); noMundo.add(b); sujo = true; }));
    });
  }

  // A sombra de cada corpo, pronta: a forma desenhada fora do canvas, só a sombra dela cai dentro (o mesmo desfoque
  // da sombra do canvas, feito uma vez em vez de a cada quadro). Como no canvas a sombra não gira com o desenho, ela
  // é desenhada girando em volta do próprio meio e deslocada para baixo na tela.
  function sombraDe(b) {
    const p = b.plugin;
    if (p.sombra && p.sombra.dpr === dpr) return p.sombra;
    const w = (p.tipo === 'rede' ? p.raio * 2 : p.w) * dpr, h = (p.tipo === 'rede' ? p.raio * 2 : p.h) * dpr;
    const blur = 14 * u, pad = Math.ceil(blur * 1.6);
    const c = document.createElement('canvas');
    c.width = Math.ceil(w + pad * 2);
    c.height = Math.ceil(h + pad * 2);
    const g = c.getContext('2d');
    const longe = c.width + 200;
    g.shadowColor = 'rgba(10, 3, 1, 0.45)';
    g.shadowBlur = blur;
    g.shadowOffsetX = longe;
    g.translate(pad - longe, pad);
    if (p.tipo === 'rede') { g.beginPath(); g.arc(w / 2, h / 2, w / 2, 0, Math.PI * 2); g.fill(); }
    else g.drawImage(p.img, 0, 0, w, h);
    p.sombra = { c, pad, w, h, dpr, desce: (8 * u) / dpr };
    return p.sombra;
  }

  function desenha() {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    for (const b of corpos) {
      if (!noMundo.has(b)) continue;
      const p = b.plugin;
      const s = sombraDe(b);
      ctx.save();
      ctx.translate(b.position.x, b.position.y + s.desce);
      ctx.rotate(b.angle);
      ctx.drawImage(s.c, -(s.w / 2 + s.pad) / dpr, -(s.h / 2 + s.pad) / dpr, s.c.width / dpr, s.c.height / dpr);
      ctx.restore();
      ctx.save();
      ctx.translate(b.position.x, b.position.y);
      ctx.rotate(b.angle);
      if (p.tipo === 'rede') {
        ctx.fillStyle = '#fff1de';
        ctx.beginPath(); ctx.arc(0, 0, p.raio, 0, Math.PI * 2); ctx.fill();
        const k = (p.raio * 1.08) / 24;
        ctx.scale(k, k);
        ctx.translate(-12, -12);
        ctx.fillStyle = '#3b1a12';
        if (ICONES[p.icone]) ctx.fill(ICONES[p.icone]);
      } else {
        ctx.drawImage(p.img, -p.w / 2, -p.h / 2, p.w, p.h);
      }
      ctx.restore();
    }
  }

  // ---- pegar e jogar
  let pega = null, cancelaClique = false, inicio = null, agora = null, espera = null;
  const ponto = (e) => { const r = el.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const acha = (pt) => Query.point(corpos.filter((b) => noMundo.has(b)), pt)[0];
  function pegaCorpo(b, pt, id) {
    const local = { x: pt.x - b.position.x, y: pt.y - b.position.y };
    const c = Math.cos(-b.angle), s = Math.sin(-b.angle);
    pega = Constraint.create({ pointA: pt, bodyB: b, pointB: { x: local.x * c - local.y * s, y: local.x * s + local.y * c }, stiffness: 0.2, damping: 0.1, length: 0 });
    Composite.add(mundo, pega);
    try { el.setPointerCapture(id); } catch { /* o dedo já saiu */ }
    el.classList.add('is-pegando');
  }
  el.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || !corpos.length) return;
    const pt = ponto(e), b = acha(pt);
    cancelaClique = !!b;
    if (!b) return;
    inicio = { ...pt, b };
    agora = pt;
    if (e.pointerType === 'mouse') { e.preventDefault(); pegaCorpo(b, pt, e.pointerId); return; }
    // no toque, espera 70 ms: se o navegador assumir o gesto (rolagem vertical), o corpo nem chega a ser puxado
    clearTimeout(espera);
    espera = setTimeout(() => { espera = null; if (inicio) pegaCorpo(b, agora, e.pointerId); }, 70);
  });
  el.addEventListener('pointermove', (e) => {
    const pt = ponto(e);
    if (inicio) agora = pt;
    if (pega) { pega.pointA = pt; return; }
    if (e.pointerType === 'mouse') el.classList.toggle('is-sobre', !!acha(pt));
  });
  const solta2 = (e) => {
    clearTimeout(espera);
    espera = null;
    if (pega) {
      Composite.remove(mundo, pega);
      pega = null;
      el.classList.remove('is-pegando');
    }
    if (!inicio) return;
    const pt = ponto(e);
    // um toque sem arrastar é clique: o pote leva ao sabor, o ícone abre a rede
    if (e.type === 'pointerup' && Math.hypot(pt.x - inicio.x, pt.y - inicio.y) < 6) {
      const p = inicio.b.plugin;
      if (p.tipo === 'pote') irParaSabor?.(p.sabor);
      if (p.tipo === 'rede' && p.href) location.href = p.href;
    }
    inicio = null;
  };
  el.addEventListener('pointerup', solta2);
  el.addEventListener('pointercancel', solta2);
  // o clique que pegou um corpo não vale para o link que estiver embaixo
  el.addEventListener('click', (e) => { if (cancelaClique) { e.preventDefault(); e.stopPropagation(); cancelaClique = false; } }, true);

  // só calcula com o rodapé na tela
  new IntersectionObserver(([en]) => { visivel = en.isIntersecting; }, { rootMargin: '100px' }).observe(el);
  // só redesenha enquanto algo se mexe (assentada a pilha, o canvas fica como está)
  gsap.ticker.add((t, dtMs) => {
    if (!visivel || !jogou || reduzido) return;
    Engine.update(engine, Math.min(dtMs, 1000 / 60));
    let mexendo = !!pega;
    for (const b of noMundo) if (b.speed > 0.03 || b.angularSpeed > 0.002) { mexendo = true; break; }
    if (mexendo || sujo) { desenha(); sujo = mexendo; }
  });

  ScrollTrigger.create({ trigger: el, start: 'top 35%', once: true, onEnter: solta });
  let rt;
  addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(tamanho, 150); });
  tamanho();
}
