// Mural: a porta da geladeira. Os objetos andam em paralaxe presos à rolagem; o texto do papel kraft aparece
// letra a letra em ordem aleatória quando o papel chega (por marco, com tempo fixo; ao sair, fica como está).
import { quebraLetras } from './letras.js';
import { paralaxe, letrasAleatorias } from './paralaxe.js';

export function mural({ el, reduzido }) {
  const texto = el.querySelector('.kraft__texto');
  const letras = [...texto.querySelectorAll('.l')].flatMap((l) => quebraLetras(l));
  if (reduzido) return;
  paralaxe(el);
  letrasAleatorias(letras, texto);
}
