// Barra de rolagem própria: a nativa fica escondida (base.css). Esta flutua por cima, sem trilho: um fio creme
// que aparece ao rolar e some parado; no mouse, engrossa ao passar e dá para arrastar.
export function scrollbar({ lenis }) {
  const html = document.documentElement;
  const bar = document.createElement('div');
  bar.className = 'barra';
  bar.setAttribute('aria-hidden', 'true');
  bar.innerHTML = '<div class="barra__fio"></div>';
  document.body.append(bar);
  const fio = bar.firstChild;
  let idle, h = 0;
  const max = () => Math.max(0, html.scrollHeight - innerHeight);
  const pos = () => (lenis ? lenis.scroll : scrollY);
  function draw() {
    const m = max();
    bar.classList.toggle('barra--nada', m < 2);
    if (m < 2) return;
    const track = bar.clientHeight;
    h = Math.max(36, track * (innerHeight / (m + innerHeight)));
    fio.style.height = `${h}px`;
    fio.style.transform = `translateY(${((track - h) * Math.min(1, Math.max(0, pos() / m))).toFixed(1)}px)`;
  }
  function wake() {
    draw();
    bar.classList.add('barra--on');
    clearTimeout(idle);
    idle = setTimeout(() => !bar.classList.contains('barra--arrasto') && bar.classList.remove('barra--on'), 900);
  }
  if (lenis) lenis.on('scroll', wake);
  else addEventListener('scroll', wake, { passive: true });
  addEventListener('resize', draw);
  new ResizeObserver(draw).observe(document.body);
  draw();

  let y0 = 0, s0 = 0;
  fio.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    fio.setPointerCapture(e.pointerId);
    y0 = e.clientY;
    s0 = pos();
    bar.classList.add('barra--arrasto', 'barra--on');
  });
  fio.addEventListener('pointermove', (e) => {
    if (!bar.classList.contains('barra--arrasto')) return;
    const y = s0 + ((e.clientY - y0) / (bar.clientHeight - h)) * max();
    lenis ? lenis.scrollTo(y, { immediate: true, force: true }) : scrollTo(0, y);
  });
  const drop = () => { bar.classList.remove('barra--arrasto'); wake(); };
  fio.addEventListener('pointerup', drop);
  fio.addEventListener('pointercancel', drop);
}
