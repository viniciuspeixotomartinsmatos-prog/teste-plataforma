// Momentos: o título monta com as letras em ordem aleatória; cada linha gigante anda de lado presa à rolagem
// (uma para cada lado), com os potes e as tampas em adesivo em profundidades diferentes.
import { gsap } from 'gsap';
import { quebraLetras } from './letras.js';
import { paralaxe, letrasAleatorias } from './paralaxe.js';

export function momentos({ el, reduzido }) {
  const titulo = el.querySelector('.momentos__titulo');
  const letras = [...titulo.querySelectorAll('.l')].flatMap((l) => quebraLetras(l));
  if (reduzido) return;
  letrasAleatorias(letras, titulo, { inicio: 'top 78%', espalha: 0.7 });
  paralaxe(el);
  el.querySelectorAll('.linha').forEach((linha) => {
    const trilho = linha.querySelector('.linha__trilho');
    const dir = +linha.dataset.dir;
    // quanto o trilho passa da tela: anda isso e mais um pouco, para a palavra entrar e sair
    const sobra = () => Math.max(0, trilho.scrollWidth - innerWidth * 0.86);
    const a = () => (dir < 0 ? innerWidth * 0.12 : -sobra() - innerWidth * 0.1);
    const b = () => (dir < 0 ? -sobra() - innerWidth * 0.1 : innerWidth * 0.12);
    gsap.fromTo(trilho, { x: a }, {
      x: b, ease: 'none',
      scrollTrigger: { trigger: linha, start: 'top bottom', end: 'bottom top', scrub: true, invalidateOnRefresh: true },
    });
  });
}
