// Retratos do pote: cada sabor em 3/4 (a tampa e o selo do rótulo de frente) e a tampa vista de cima, desenhados
// pelo mesmo 3D num canvas à parte, depois da abertura. O seletor, os adesivos dos momentos e a física do rodapé usam
// estes retratos: trocar a marca, o rótulo ou a embalagem muda tudo junto, sem gerar arquivo nenhum. As imagens de
// public/img (pote-*.webp, tampa-*.webp) ficam só de reserva, para quando o WebGL falhar.
import * as THREE from 'three';
import { criaPote, textura, luzEstudio } from './pote.js';
import { uniformesFita } from './fita.js';
import { desenhaRotulo, desenhaTampa, desenhaFaixa, carregaArte, arteDe } from './artes.js';

const PX = 560; // lado do quadro; o retrato sai recortado no que o pote ocupa

export async function criaRetratos({ marca, frase }) {
  const tela = document.createElement('canvas');
  const renderer = new THREE.WebGLRenderer({ canvas: tela, antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(1);
  renderer.setSize(PX, PX, false);
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene();
  await luzEstudio(renderer, scene);
  const camera = new THREE.PerspectiveCamera(20, 1, 1, 400);
  camera.position.set(0, 0, 70);
  const raiz = new THREE.Group();
  scene.add(raiz);
  const caixa = new THREE.Box3(), tam = new THREE.Vector3(), meio = new THREE.Vector3(), v = new THREE.Vector3();
  const altVisivel = 2 * camera.position.z * Math.tan(THREE.MathUtils.degToRad(10));
  let compilado = false;

  // o retângulo que o pote ocupa no quadro, pelos vértices projetados (sem ler os pixels de volta da GPU)
  function recorte() {
    let x0 = PX, y0 = PX, x1 = 0, y1 = 0;
    raiz.updateMatrixWorld(true);
    raiz.traverse((o) => {
      const pos = o.isMesh && o.geometry.attributes.position;
      if (!pos) return;
      for (let i = 0; i < pos.count; i++) {
        v.fromBufferAttribute(pos, i).applyMatrix4(o.matrixWorld).project(camera);
        const x = (v.x * 0.5 + 0.5) * PX, y = (0.5 - v.y * 0.5) * PX;
        if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      }
    });
    const m = 3; // a borda suavizada passa um pouco do contorno
    x0 = Math.max(0, Math.floor(x0 - m)); y0 = Math.max(0, Math.floor(y0 - m));
    x1 = Math.min(PX, Math.ceil(x1 + m)); y1 = Math.min(PX, Math.ceil(y1 + m));
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }

  // enquadra o pote na pose, desenha e recorta no que ele ocupa; devolve o endereço da imagem
  function foto(pote, vista) {
    if (vista === 'tampa') { raiz.rotation.set(Math.PI / 2 - 0.02, 0, 0); pote.rotation.y = 0; }
    else { raiz.rotation.set(0.42, 0, 0); pote.rotation.y = -0.12; }
    raiz.position.set(0, 0, 0);
    raiz.scale.setScalar(1);
    raiz.updateMatrixWorld(true);
    caixa.setFromObject(raiz, true);
    caixa.getSize(tam);
    caixa.getCenter(meio);
    const k = (altVisivel * 0.92) / Math.max(tam.x, tam.y);
    raiz.scale.setScalar(k);
    raiz.position.copy(meio).multiplyScalar(-k);
    renderer.render(scene, camera);
    const r = recorte();
    const saida = document.createElement('canvas');
    saida.width = r.w;
    saida.height = r.h;
    saida.getContext('2d').drawImage(tela, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h);
    // a codificação da imagem roda fora da thread principal
    return new Promise((ok, erro) => saida.toBlob((b) => (b ? ok(URL.createObjectURL(b)) : erro(new Error('toBlob'))), 'image/webp', 0.9));
  }

  /** o pote do sabor em 3/4 e a tampa de cima: { pote, tampa } com os endereços das imagens */
  async function retratos(sabor) {
    const arte = await carregaArte(arteDe(sabor));
    const fita = uniformesFita();
    const texturas = [];
    const tx = (c, o) => { const t = textura(c, renderer, o); texturas.push(t); return t; };
    fita.uRotulo.value = tx(desenhaRotulo(arte, { sabor: sabor.nome }), { repete: true });
    fita.uArte.value = tx(arte, { repete: true });
    const tampa = desenhaTampa({ nome: marca, sabor: sabor.nome });
    fita.uFaixa.value = tx(desenhaFaixa({ frase, tampa }).canvas, { repete: true, premultiplica: true });
    const pote = criaPote({ fita, tampa: tx(tampa) });
    raiz.add(pote);
    // os shaders compilam em paralelo, sem travar a página (na primeira vez; os outros sabores usam os mesmos)
    if (!compilado) { await renderer.compileAsync(scene, camera); compilado = true; }
    texturas.forEach((t) => renderer.initTexture(t));
    try {
      return { pote: await foto(pote, 'pote'), tampa: await foto(pote, 'tampa') };
    } finally {
      raiz.remove(pote);
      pote.traverse((o) => { o.geometry?.dispose(); o.material?.dispose(); });
      texturas.forEach((t) => t.dispose());
    }
  }

  function descarta() {
    renderer.dispose();
    renderer.forceContextLoss();
  }

  return { retratos, descarta };
}
