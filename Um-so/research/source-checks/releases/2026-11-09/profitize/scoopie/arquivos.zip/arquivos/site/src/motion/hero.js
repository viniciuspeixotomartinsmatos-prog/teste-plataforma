// Hero: "A [logo] TÁ AQUI PRA" e ESFRIAR / A CABEÇA, com as letras pulando uma a uma quando a abertura descobre a
// página (por tempo, não pela rolagem).
import { gsap } from 'gsap';
import { canvasMarca } from '../three/marca.js';
import { quebraLetras, animaLetras } from './letras.js';

export function hero({ el, marca, reduzido }) {
  const lugar = el.querySelector('.hero__marca');
  // o tamanho do logo vem do CSS (font-size de .hero__marca), que já muda no celular
  const desenhaLogo = () => {
    lugar.querySelector('canvas')?.remove();
    lugar.append(canvasMarca(marca, { px: Math.round(parseFloat(getComputedStyle(lugar).fontSize)) }));
  };
  document.fonts.load('100px "Bagel Fat One"').then(desenhaLogo);
  let rt, ultW = innerWidth, ultH = innerHeight;
  addEventListener('resize', () => {
    if (innerWidth === ultW && Math.abs(innerHeight - ultH) < 120) return; // a barra do navegador no toque
    ultW = innerWidth;
    ultH = innerHeight;
    clearTimeout(rt);
    rt = setTimeout(desenhaLogo, 150);
  });

  const letras = [...el.querySelectorAll('[data-letras]')].flatMap((l) => quebraLetras(l));
  const linha = el.querySelector('.hero__linha');
  if (!reduzido) gsap.set([...letras, linha], { opacity: 0 });

  function entra() {
    if (reduzido) return;
    gsap.fromTo(linha, { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' });
    animaLetras(letras, {
      de: () => ({ y: 70, r: gsap.utils.random(-16, 16), s: 0.6, a: 0 }),
      duracao: 0.7, atraso: (i) => 0.08 + i * 0.035, ease: 'back.out(2.2)',
    }).catch(() => {});
  }
  return { entra };
}
