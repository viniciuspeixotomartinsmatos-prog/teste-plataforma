// Pote de sorvete de papel: corpo com a fita (tronco de cone), fundo e tampa com saia. Medidas em cm.
import * as THREE from 'three';
import { injetaFita } from './fita.js';
import { EMBALAGEM } from '../config.js';

export const MEDIDAS = EMBALAGEM; // as medidas moram em src/config.js

export function textura(canvas, renderer, { repete = false, premultiplica = false } = {}) {
  const t = canvas instanceof HTMLImageElement ? new THREE.Texture(canvas) : new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repete) t.wrapS = THREE.RepeatWrapping;
  t.premultiplyAlpha = premultiplica;
  t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  t.needsUpdate = true;
  return t;
}

export function criaPote({ fita, tampa, corTampa = EMBALAGEM.corTampa, corFundo = EMBALAGEM.corFundo }) {
  const { rTopo, rBase, altura } = EMBALAGEM;
  const desce = EMBALAGEM.saia; // quanto a saia da tampa desce pelo corpo
  const pote = new THREE.Group();
  const papel = { roughness: 0.55, metalness: 0, clearcoat: 0.3, clearcoatRoughness: 0.45 };

  const corpo = new THREE.Mesh(
    new THREE.CylinderGeometry(rTopo, rBase, altura, 180, 1, true),
    injetaFita(new THREE.MeshPhysicalMaterial({ ...papel }), fita, 'pote'),
  );
  pote.add(corpo);

  const fundo = new THREE.Mesh(
    new THREE.CircleGeometry(rBase, 96),
    new THREE.MeshStandardMaterial({ color: corFundo, roughness: 0.8 }),
  );
  fundo.rotation.x = Math.PI / 2;
  fundo.position.y = -altura / 2;
  pote.add(fundo);

  // tampa: a saia desce por fora da boca do pote, a borda de cima é arredondada
  const perfil = [
    [rTopo + 0.18, -desce], [rTopo + 0.27, -desce + 0.04], [rTopo + 0.3, -desce + 0.2], [rTopo + 0.3, 0.12],
    [rTopo + 0.26, 0.3], [rTopo + 0.14, 0.41], [rTopo - 0.05, 0.45],
  ].map(([x, y]) => new THREE.Vector2(x, y));
  const saia = new THREE.Mesh(
    new THREE.LatheGeometry(perfil, 180),
    new THREE.MeshPhysicalMaterial({ color: corTampa, side: THREE.DoubleSide, ...papel, clearcoat: 0.4, envMapIntensity: 0.7 }),
  );
  saia.position.y = altura / 2;
  pote.add(saia);

  // o topo da tampa reflete pouco: visto de cima, o verniz forte deixava o chocolate cinza
  const topo = new THREE.Mesh(
    new THREE.CircleGeometry(rTopo - 0.05, 128),
    new THREE.MeshPhysicalMaterial({ map: tampa, roughness: 0.62, clearcoat: 0.22, clearcoatRoughness: 0.6, envMapIntensity: 0.45 }),
  );
  topo.rotation.x = -Math.PI / 2;
  topo.position.y = altura / 2 + 0.45;
  pote.add(topo);

  pote.userData.topo = topo; // para trocar a arte da tampa junto com o sabor
  return pote;
}

/** luz de estúdio: ambiente neutro + luz principal do alto à esquerda + recorte atrás à direita */
export async function luzEstudio(renderer, scene) {
  const { RoomEnvironment } = await import('three/addons/environments/RoomEnvironment.js');
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environmentIntensity = 0.75;
  const principal = new THREE.DirectionalLight('#fff6ec', 1.7);
  principal.position.set(-7, 11, 9);
  const recorte = new THREE.DirectionalLight('#ffffff', 1.1);
  recorte.position.set(9, 5, -7);
  scene.add(principal, recorte);
  pmrem.dispose();
}
