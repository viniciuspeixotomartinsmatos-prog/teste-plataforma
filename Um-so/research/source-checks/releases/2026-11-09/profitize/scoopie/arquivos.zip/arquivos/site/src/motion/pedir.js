// BORA PEDIR?: as letras sobem quando o card chega (por marco).
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { quebraLetras, animaLetras } from './letras.js';

export function pedir({ el, reduzido }) {
  const titulo = el.querySelector('.pedir__titulo');
  const letras = [...titulo.querySelectorAll('.l')].flatMap((l) => quebraLetras(l));
  if (reduzido) return;
  gsap.set(letras, { opacity: 0 });
  ScrollTrigger.create({
    trigger: titulo, start: 'top 80%', once: true,
    onEnter: () => animaLetras(letras, {
      de: () => ({ y: 80, r: gsap.utils.random(-14, 14), a: 0 }),
      duracao: 0.6, atraso: (i) => i * 0.045, ease: 'back.out(2.4)',
    }).catch(() => {}),
  });
}
