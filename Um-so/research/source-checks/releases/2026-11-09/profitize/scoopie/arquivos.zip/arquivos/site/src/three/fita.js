// A fita: o rótulo do pote e a faixa ondulada são o mesmo material. Cada ponto da fita tem uma posição sigma
// (cm, ao longo do comprimento). A primeira volta é o rótulo (arte + selo do sabor); depois dela vem a faixa
// creme com a frase, como num rolo que não acaba. Rolando, o pote cola a fita na página a partir da frente:
// o que já colou vira a faixa, e o pote mostra a camada seguinte.
import * as THREE from 'three';
import { EMBALAGEM } from '../config.js';

const { rTopo, rBase, altura, saia } = EMBALAGEM;
export const ALT = altura; // altura do corpo do pote (cm)
export const V_TOPO = (altura - saia) / altura; // a saia da tampa cobre o fim do rótulo
export const V_MEIO = V_TOPO / 2; // a linha do meio da faixa
export const R_MEIO = rBase + (rTopo - rBase) * V_MEIO; // raio na altura do meio do rótulo
export const FAIXA_MEIA = 0.27; // meia altura da faixa creme, em fração da altura do rótulo

export function uniformesFita() {
  return {
    uRotulo: { value: null },
    uRotuloB: { value: null }, // o rótulo novo, entrando pela parte de trás enquanto o pote gira
    uTrocaIni: { value: 0 }, // ângulo (no pote) da parte de trás quando a troca começou
    uTrocaAng: { value: 0 }, // quanto o pote já girou desde então (rad); 0 = sem troca
    uArte: { value: null },
    uFaixa: { value: null },
    uTheta0: { value: 0 }, // ângulo (no pote) do ponto de contato quando a rolagem começa
    uR: { value: R_MEIO },
    uD: { value: 0 }, // a posição da fita (cm) que está no ponto de contato do pote
    uLimite: { value: 0 }, // na faixa: até onde (cm, na geometria) a fita já colou
    uDesliza: { value: 0 }, // a faixa correndo para a esquerda (cm)
    uFaixaLen: { value: 1 }, // comprimento de uma volta do texto da faixa (cm)
    uFaixaV0: { value: 0 }, // a textura da faixa cobre v de uFaixaV0 a uFaixaV1 (com a margem)
    uFaixaV1: { value: 1 },
    uCapR: { value: FAIXA_MEIA * ALT }, // raio da ponta arredondada onde a faixa começa
    uMeioV: { value: V_MEIO },
    uAlt: { value: ALT },
  };
}

const PARS = /* glsl */ `
uniform sampler2D uRotulo;
uniform sampler2D uRotuloB;
uniform sampler2D uArte;
uniform sampler2D uFaixa;
uniform float uTrocaIni, uTrocaAng, uTheta0, uR, uD, uLimite, uDesliza, uFaixaLen, uFaixaV0, uFaixaV1, uCapR, uMeioV, uAlt;
varying vec2 vFita;
const float PI_F = 3.141592653589793;

// cor da fita no ponto sigma (cm), altura v; gx/gy: derivadas de (sigma, v) na tela, sem os saltos de camada
vec4 fitaCor(float sigma, float v, vec2 gx, vec2 gy, float novo) {
  float C = 2.0 * PI_F * uR;
  float k = 1.0 / (uR * PI_F);
  vec2 uvR = vec2((uTheta0 + sigma / uR) / PI_F + 0.5, v);
  vec2 dRx = vec2(gx.x * k, gx.y), dRy = vec2(gy.x * k, gy.y);
  vec4 rot = textureGrad(uRotulo, uvR, dRx, dRy);
  if (novo > 0.5) rot = textureGrad(uRotuloB, uvR, dRx, dRy);
  vec4 arte = textureGrad(uArte, uvR, dRx, dRy);
  float s = sigma - C;
  float hb = uFaixaV1 - uFaixaV0;
  vec2 uvF = vec2(s / uFaixaLen, (v - uFaixaV0) / hb);
  vec4 fx = textureGrad(uFaixa, uvF, vec2(gx.x / uFaixaLen, gx.y / hb), vec2(gy.x / uFaixaLen, gy.y / hb));
  // a faixa começa com a ponta arredondada, como o selo do rótulo
  float aa = max(length(vec2(gx.x, gy.x)), 1e-4);
  float dx = s - uCapR;
  float dy = (v - uMeioV) * uAlt;
  float ponta = dx >= 0.0 ? 1.0 : 1.0 - smoothstep(uCapR - aa, uCapR + aa, length(vec2(dx, dy)));
  vec3 faixa = arte.rgb * (1.0 - fx.a * ponta) + fx.rgb * ponta; // fx vem pré-multiplicada
  return sigma < C ? rot : vec4(faixa, 1.0);
}
`;

// no pote: a camada visível em cada ponto depende de quanto da fita já colou
const FRAG_POTE = /* glsl */ `
{
  float th = vFita.x * 2.0 * PI_F;
  float C = 2.0 * PI_F * uR;
  float sf = uR * mod(th - uTheta0, 2.0 * PI_F);
  float camada = max(0.0, ceil((uD - sf) / C));
  float sigma = sf + camada * C;
  vec2 gx = vec2(dFdx(th) * uR, dFdx(vFita.y));
  vec2 gy = vec2(dFdy(th) * uR, dFdy(vFita.y));
  float novo = uTrocaAng > 0.0 ? step(mod(uTrocaIni - th, 2.0 * PI_F), uTrocaAng) : 0.0;
  diffuseColor *= fitaCor(sigma, vFita.y, gx, gy, novo);
}
`;

// na página: só aparece o que já colou, e a faixa corre para a esquerda (a ponta solta sai pela borda)
const FRAG_FAIXA = /* glsl */ `
{
  if (vFita.x > uLimite) discard;
  float sigma = vFita.x + uDesliza;
  if (sigma < 0.0) discard;
  vec2 gx = vec2(dFdx(vFita.x), dFdx(vFita.y));
  vec2 gy = vec2(dFdy(vFita.x), dFdy(vFita.y));
  diffuseColor *= fitaCor(sigma, vFita.y, gx, gy, 0.0);
}
`;

export function injetaFita(material, uniforms, modo) {
  material.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec2 vFita;')
      .replace('#include <uv_vertex>', '#include <uv_vertex>\nvFita = uv;');
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', `#include <common>\n${PARS}`)
      .replace('#include <map_fragment>', modo === 'pote' ? FRAG_POTE : FRAG_FAIXA);
  };
  material.customProgramCacheKey = () => `fita-${modo}`;
  return material;
}

/**
 * A onda da divisa entre o mural e a seção do sabor, em px de tela, relativa à linha de base:
 * y(x) = A sen(2πx/λ + φ). A mesma conta recorta a borda da seção (DOM) e desenha a faixa (WebGL).
 */
export function onda(W, H) {
  const A = Math.round(Math.min(64, Math.max(26, W * 0.036)));
  const lambda = W * 1.32;
  const fase = -0.55 * Math.PI;
  const k = (2 * Math.PI) / lambda;
  return {
    A,
    y: (x) => A * Math.sin(k * x + fase),
    dy: (x) => A * k * Math.cos(k * x + fase),
  };
}

/**
 * Geometria da faixa ao longo da onda, de xIni a xFim (px de tela). S = px por cm na hora de colar.
 * Posição: x centrado na tela, y para cima, relativa à linha de base. uv = (sigma em cm, v do rótulo), com sigma
 * medido a partir de x0, o ponto onde o pote pousa (negativo à esquerda dele).
 * Devolve também as tabelas comprimento (px, desde x0) ↔ x, para saber onde o pote está.
 */
export function geometriaFaixa({ W, onda: o, xIni, x0, xFim, S, z, n = 760 }) {
  const x1 = xFim;
  const larguraV = V_TOPO; // a faixa mostra o rótulo de v = 0 a V_TOPO
  const pos = new Float32Array((n + 1) * 2 * 3);
  const uv = new Float32Array((n + 1) * 2 * 2);
  const xs = new Float32Array(n + 1), ss = new Float32Array(n + 1);
  let s = 0, px = xIni, py = o.y(xIni);
  for (let i = 0; i <= n; i++) {
    const x = xIni + ((x1 - xIni) * i) / n, y = o.y(x);
    if (i) s += Math.hypot(x - px, y - py);
    px = x; py = y;
    xs[i] = x; ss[i] = s;
    const d = o.dy(x), len = Math.hypot(1, d);
    const nx = d / len, ny = -1 / len; // normal "para cima" na tela (y para baixo)
    for (let j = 0; j < 2; j++) {
      const v = j ? larguraV : 0;
      const off = (v - V_MEIO) * ALT * S; // px ao longo da normal
      const sx = x + nx * off, sy = y + ny * off;
      const k = (i * 2 + j) * 3;
      pos[k] = sx - W / 2;
      pos[k + 1] = -sy;
      pos[k + 2] = z;
      const t = (i * 2 + j) * 2;
      uv[t] = s; // em px por enquanto; vira cm desde x0 logo abaixo
      uv[t + 1] = v;
    }
  }
  // comprimento desde xIni até x0, para medir a partir do pouso
  const f0 = ((x0 - xIni) / (x1 - xIni)) * n, i0 = Math.min(n - 1, Math.floor(f0));
  const s0 = ss[i0] + (f0 - i0) * (ss[i0 + 1] - ss[i0]);
  for (let i = 0; i <= n; i++) ss[i] -= s0;
  for (let t = 0; t < uv.length; t += 2) uv[t] = (uv[t] - s0) / S;
  const idx = [];
  for (let i = 0; i < n; i++) {
    const a = i * 2, b = a + 1, c = a + 2, d = a + 3;
    idx.push(a, c, b, b, c, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  // comprimento (px) → x, por busca binária na tabela
  const xDeS = (alvo) => {
    if (alvo <= ss[0]) return xs[0];
    if (alvo >= ss[n]) return xs[n];
    let lo = 0, hi = n;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (ss[m] < alvo) lo = m; else hi = m; }
    return xs[lo] + ((alvo - ss[lo]) / (ss[hi] - ss[lo])) * (xs[hi] - xs[lo]);
  };
  const sDeX = (x) => {
    const f = Math.min(n, Math.max(0, ((x - xIni) / (x1 - xIni)) * n));
    const i = Math.min(n - 1, Math.floor(f));
    return ss[i] + (f - i) * (ss[i + 1] - ss[i]);
  };
  return { geometria: g, comprimento: ss[n], xDeS, sDeX };
}
