// Converte uma imagem da pessoa para o tamanho e o formato que o site usa (WebP em public/img), com o recorte certo.
// uso: npm run imagens -- <tipo> [nome] <arquivo>
//   rotulo  <sabor>  a arte do rótulo de um sabor (o `id` em src/config.js): corta em 3:2 e grava
//                    rotulo-<sabor>.webp (1536 × 1024) e rotulo-<sabor>-m.webp (1024 × 683, a do celular)
//   foto    <nome>   uma foto quadrada dos adesivos e das linhas dos momentos: foto-<nome>.webp (760 × 760)
//   chamada          a foto em pé da chamada "Bora pedir?": foto-maos.webp (900 × 1350)
//   objeto  <nome>   um objeto recortado do mural, com fundo transparente: <nome>.webp, na largura de LARGURAS
// ex.: npm run imagens -- rotulo pistache ~/Downloads/rotulo-pistache.png
//      npm run imagens -- foto colher ~/Downloads/colher.jpg
import sharp from 'sharp';
import { existsSync } from 'node:fs';

const LARGURAS = { kraft: 900, lista: 640, polaroide: 640, desenho: 720, convite: 640, ingresso: 720, 'colher-1': 360, 'colher-2': 360, 'colher-3': 360, 'ima-1': 240, 'ima-2': 240, 'ima-3': 240, 'ima-4': 240, 'ima-5': 240 };
const [tipo, ...resto] = process.argv.slice(2);
const arquivo = resto.at(-1);
const nome = resto.length > 1 ? resto[0] : null;
const destino = (n) => `public/img/${n}.webp`;

function uso(msg) {
  console.error(msg);
  console.error('uso: npm run imagens -- rotulo <sabor> <arquivo> | foto <nome> <arquivo> | chamada <arquivo> | objeto <nome> <arquivo>');
  process.exit(1);
}
if (!arquivo || !existsSync(arquivo)) uso(`arquivo não encontrado: ${arquivo ?? '(faltou)'}`);

const corta = (w, h, q) => sharp(arquivo).rotate().resize(w, h, { fit: 'cover', position: 'attention' }).webp({ quality: q });

// Objeto sem transparência de verdade: o gerador deu fundo verde #00FF00 (ou magenta #FF00FF, para objeto verde)
// chapado. A cor do canto diz qual é; ela vira alfa, com a borda suavizada e sem a franja da cor.
async function recorta(arq) {
  const { data, info } = await sharp(arq).rotate().ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width: w, height: h } = info;
  const canto = (x, y) => { const i = (y * w + x) * 4; return [data[i], data[i + 1], data[i + 2], data[i + 3]]; };
  const cantos = [canto(2, 2), canto(w - 3, 2), canto(2, h - 3), canto(w - 3, h - 3)];
  if (cantos.every((c) => c[3] < 20)) return sharp(data, { raw: info }); // já tem alfa
  const verde = cantos.every(([r, g, b]) => g - Math.max(r, b) > 90);
  const magenta = cantos.every(([r, g, b]) => Math.min(r, b) - g > 110);
  if (!verde && !magenta) return sharp(data, { raw: info }); // fundo comum: fica como está
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    if (verde) {
      const v = g - Math.max(r, b);
      if (v > 90) data[i + 3] = 0;
      else if (v > 30) { data[i + 1] = Math.min(g, Math.max(r, b) + 30); data[i + 3] = Math.round(data[i + 3] * (1 - (v - 30) / 60)); }
    } else {
      const m = Math.min(r, b) - g;
      if (m > 110) data[i + 3] = 0;
      else if (m > 40) { const t = g + 100; data[i] = Math.min(r, t); data[i + 2] = Math.min(b, t); data[i + 3] = Math.round(data[i + 3] * (1 - (m - 40) / 70)); }
    }
  }
  return sharp(data, { raw: info });
}

if (tipo === 'rotulo') {
  if (!nome) uso('faltou o sabor (o id em src/config.js)');
  await corta(1536, 1024, 88).toFile(destino(`rotulo-${nome}`));
  await corta(1024, 683, 80).toFile(destino(`rotulo-${nome}-m`));
  console.log(`${destino(`rotulo-${nome}`)} e ${destino(`rotulo-${nome}-m`)}`);
} else if (tipo === 'foto') {
  if (!nome) uso('faltou o nome da foto (foto-<nome>.webp)');
  await corta(760, 760, 82).toFile(destino(`foto-${nome}`));
  console.log(destino(`foto-${nome}`));
} else if (tipo === 'chamada') {
  await corta(900, 1350, 82).toFile(destino('foto-maos'));
  console.log(destino('foto-maos'));
} else if (tipo === 'objeto') {
  if (!nome || !LARGURAS[nome]) uso(`objeto desconhecido: ${nome}. Os do mural: ${Object.keys(LARGURAS).join(', ')}`);
  const img = await recorta(arquivo);
  await img.trim().resize({ width: LARGURAS[nome] }).webp({ quality: 90, alphaQuality: 100 }).toFile(destino(nome));
  console.log(destino(nome));
} else {
  uso(`tipo desconhecido: ${tipo}`);
}
