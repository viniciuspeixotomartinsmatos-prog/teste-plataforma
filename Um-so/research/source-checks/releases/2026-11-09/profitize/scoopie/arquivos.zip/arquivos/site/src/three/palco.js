// O palco 3D: um canvas fixo por cima das seções, com o pote e a faixa. O pote faz o roteiro preso à rolagem:
// no hero, a tampa virada para quem olha e o pote seguindo o mouse numa mola; no mural, desce girando; na divisa
// com a seção do sabor, pousa na onda e rola para a direita colando o rótulo na página, que vira a faixa; depois
// cai no palco do sabor, visto de cima, e dá uma volta a cada sabor, trocando o rótulo pela parte de trás.
import * as THREE from 'three';
import { gsap } from 'gsap';
import { criaPote, textura, luzEstudio } from './pote.js';
import { uniformesFita, geometriaFaixa, injetaFita, onda as criaOnda, ALT, V_TOPO, V_MEIO, FAIXA_MEIA, R_MEIO } from './fita.js';
import { desenhaRotulo, desenhaTampa, desenhaFaixa, carregaArte, fontesProntas, arteDe } from './artes.js';
import { toque } from '../motion/smooth.js';
import { EMBALAGEM } from '../config.js';
import { criaSombra } from './sombra.js';

const FOV = 20;
const TAN = Math.tan(THREE.MathUtils.degToRad(FOV / 2));
// inclinação para trás que deixa a frente do tronco de cone vertical, e a distância (cm) do eixo até essa frente
const INCLINA_ROLA = -Math.atan((EMBALAGEM.rTopo - EMBALAGEM.rBase) / EMBALAGEM.altura);
const FRENTE = ((EMBALAGEM.rTopo + EMBALAGEM.rBase) / 2) * Math.cos(INCLINA_ROLA);
const VISTO = EMBALAGEM.altura + 1.6; // a altura (cm) que o pote inclinado ocupa na tela, com a tampa
const DOIS_PI = Math.PI * 2;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const suave = (t) => t * t * (3 - 2 * t);
const lerp = (a, b, t) => a + (b - a) * t;
// cai e quica de leve no fim (preso à rolagem)
const quica = (t) => { const c = 1.4; const u = t - 1; return 1 + (c + 1) * u * u * u + c * u * u; };

// curva por marcos: Hermite monótona (passa por todos sem parar no meio e sem passar do ponto)
function curva(marcos, chave, y) {
  const n = marcos.length;
  if (y <= marcos[0].y) return marcos[0][chave];
  if (y >= marcos[n - 1].y) return marcos[n - 1][chave];
  let i = 0;
  while (y > marcos[i + 1].y) i++;
  const a = marcos[i], b = marcos[i + 1], h = b.y - a.y, t = (y - a.y) / h;
  const tan = (k) => {
    if (k === 0 || k === n - 1) return 0;
    const d0 = (marcos[k][chave] - marcos[k - 1][chave]) / (marcos[k].y - marcos[k - 1].y);
    const d1 = (marcos[k + 1][chave] - marcos[k][chave]) / (marcos[k + 1].y - marcos[k].y);
    return d0 * d1 <= 0 ? 0 : (2 * d0 * d1) / (d0 + d1); // média harmônica: não ultrapassa
  };
  const m0 = tan(i) * h, m1 = tan(i + 1) * h;
  const t2 = t * t, t3 = t2 * t;
  return (2 * t3 - 3 * t2 + 1) * a[chave] + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * b[chave] + (t3 - t2) * m1;
}

// a rolagem começa parada (o pote acabou de pousar) e acelera: rampa C1, depois linear
const ACEL = 0.3;
const rampa = (u) => (u < ACEL ? (u * u) / (2 * ACEL) : u - ACEL / 2) / (1 - ACEL / 2);

// o giro na descida termina com velocidade zero no pouso
const GIRO_FIM = 0.2, GIRO_M = 1 / (1 - GIRO_FIM / 2);
const giroDescida = (u) => (u <= 1 - GIRO_FIM ? GIRO_M * u
  : GIRO_M * u - (GIRO_M * (u - (1 - GIRO_FIM)) ** 2) / (2 * GIRO_FIM));

export async function criaPalco({ canvas, marca, sabores, frase, secoes }) {
  const celular = toque || innerWidth < 760;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, celular ? 1.5 : 2));
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(FOV, 1, 10, 20000);
  const sombra = criaSombra(renderer); // a sombra do pote e da faixa, no próprio WebGL (sombra.js)
  await luzEstudio(renderer, scene);
  await fontesProntas();

  // rótulo e tampa de cada sabor, carregados quando precisam (o primeiro já na abertura)
  const artes = [], rotulos = [], tampas = [];
  async function garante(i) {
    if (rotulos[i]) return;
    const s = sabores[i];
    const img = await carregaArte(arteDe(s));
    if (rotulos[i]) return;
    artes[i] = textura(img, renderer, { repete: true });
    rotulos[i] = textura(desenhaRotulo(img, { sabor: s.nome }), renderer, { repete: true });
    tampas[i] = textura(desenhaTampa({ nome: marca, sabor: s.nome }), renderer);
    // sobe para a GPU agora (num respiro), e não no primeiro quadro em que o sabor aparece, no meio da rolagem
    [artes[i], rotulos[i], tampas[i]].forEach((tx) => renderer.initTexture(tx));
  }
  /** carrega os outros sabores um por vez, cada um num respiro do navegador (folga() devolve quando dá) */
  async function aquece(folga) {
    for (let i = 0; i < sabores.length; i++) {
      if (rotulos[i]) continue;
      await folga();
      await garante(i);
    }
  }
  await garante(0);

  // a fita do pote; a faixa tem as próprias texturas (fica sempre com o rótulo do primeiro sabor)
  const fita = uniformesFita();
  fita.uRotulo.value = rotulos[0];
  fita.uArte.value = artes[0];
  const faixa = desenhaFaixa({ frase, tampa: desenhaTampa({ nome: marca, sabor: sabores[0].nome }) });
  fita.uFaixa.value = textura(faixa.canvas, renderer, { repete: true, premultiplica: true });
  const pxPorCm = faixa.altura / (2 * FAIXA_MEIA * ALT);
  const margemV = faixa.margem / pxPorCm / ALT;
  fita.uFaixaV0.value = V_MEIO - FAIXA_MEIA - margemV;
  fita.uFaixaV1.value = V_MEIO + FAIXA_MEIA + margemV;
  fita.uFaixaLen.value = faixa.canvas.width / pxPorCm;
  const fitaFaixa = { ...fita, uRotulo: { value: rotulos[0] }, uArte: { value: artes[0] }, uTrocaAng: { value: 0 } };

  const pote = criaPote({ fita, tampa: tampas[0] });
  const raiz = new THREE.Group(); // posição, escala e inclinação; o pote gira dentro dela
  raiz.add(pote);
  scene.add(raiz);

  // a faixa está colada na página: sem luz, com as cores exatas da página
  const malhaFaixa = new THREE.Mesh(
    new THREE.BufferGeometry(),
    injetaFita(new THREE.MeshBasicMaterial({ side: THREE.DoubleSide, toneMapped: false }), fitaFaixa, 'faixa'),
  );
  malhaFaixa.frustumCulled = false;
  scene.add(malhaFaixa);

  // mouse: o pote do hero segue o cursor numa mola subamortecida
  const alvo = { x: 0, y: 0 }, mola = { x: 0, y: 0, vx: 0, vy: 0 };
  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse') return;
    alvo.x = (e.clientX / innerWidth) * 2 - 1;
    alvo.y = (e.clientY / innerHeight) * 2 - 1;
  }, { passive: true });

  // ---- troca de sabor: o pote dá uma volta e o rótulo novo entra pela parte de trás
  let atual = 0, pedido = 0, girando = null, destino = 0, giroAtual = 0, giroIni = 0, encadeada = false;
  const troca = { extra: 0 }; // a volta da troca, somada ao giro do palco
  const varrido = () => giroAtual - giroIni; // quanto o pote girou desde o começo da troca
  function proximaTroca() {
    if (girando || pedido === atual) { encadeada = false; return; }
    const i = pedido;
    garante(i).then(() => {
      if (girando || pedido !== i || i === atual) { proximaTroca(); return; }
      destino = i;
      fita.uRotuloB.value = rotulos[i];
      fita.uTrocaIni.value = Math.PI - giroAtual; // a parte de trás, no pote, agora
      giroIni = giroAtual;
      let tampaTrocada = false;
      girando = gsap.to(troca, {
        extra: troca.extra + DOIS_PI,
        duration: encadeada ? 0.55 : 0.8, // rolando rápido, as voltas encurtam para não ficar para trás
        ease: 'power2.inOut',
        onUpdate: () => {
          fita.uTrocaAng.value = Math.max(1e-4, varrido());
          if (!tampaTrocada && varrido() > Math.PI) { tampaTrocada = true; pote.userData.topo.material.map = tampas[destino]; }
        },
        onComplete: () => {
          fita.uRotulo.value = rotulos[destino];
          fita.uTrocaAng.value = 0;
          pote.userData.topo.material.map = tampas[destino];
          troca.extra -= DOIS_PI;
          atual = destino;
          girando = null;
          encadeada = true;
          proximaTroca();
        },
      });
    });
  }
  function trocaSabor(i) {
    pedido = i;
    // no meio de uma volta, enquanto o rótulo novo ainda está na parte de trás, só troca o destino
    if (girando && i !== destino && varrido() < Math.PI * 0.55 && rotulos[i]) {
      destino = i;
      fita.uRotuloB.value = rotulos[i];
      return;
    }
    proximaTroca();
  }
  // volta ao primeiro sabor sem animação (o pote está fora da tela)
  function zeraSabor() {
    if (atual === 0 && pedido === 0 && !girando) return;
    girando?.kill();
    girando = null;
    troca.extra = 0;
    atual = pedido = destino = 0;
    fita.uRotulo.value = rotulos[0];
    fita.uTrocaAng.value = 0;
    pote.userData.topo.material.map = tampas[0];
  }

  let W = 0, H = 0, L = null;
  // no toque, a altura do palco é a da tela grande (100lvh, como o canvas): a barra do navegador some e volta
  // rolando, e o palco não muda de tamanho por isso
  const sonda = document.createElement('div');
  sonda.style.cssText = 'position:fixed;left:0;top:0;width:0;height:100lvh;visibility:hidden;pointer-events:none';
  document.body.append(sonda);
  const alturaTela = () => (toque ? sonda.offsetHeight || innerHeight : innerHeight);

  // a caixa que o pote ocupa na tela numa pose, por px/cm (Box3 pelos vértices: exata com o pote inclinado)
  const caixa = new THREE.Box3(), tam = new THREE.Vector3(), meio = new THREE.Vector3();
  function caixaPose(rx, rz) {
    const p = raiz.position.clone(), r = raiz.rotation.clone(), k = raiz.scale.x, gy = pote.rotation.y;
    raiz.position.set(0, 0, 0);
    raiz.scale.setScalar(1);
    raiz.rotation.set(rx, 0, rz);
    pote.rotation.y = 0;
    raiz.updateMatrixWorld(true);
    caixa.setFromObject(raiz, true);
    caixa.getSize(tam);
    caixa.getCenter(meio);
    raiz.position.copy(p);
    raiz.rotation.copy(r);
    raiz.scale.setScalar(k);
    pote.rotation.y = gy;
    return { w: tam.x, h: tam.y, cx: meio.x, cy: meio.y };
  }
  // pose que põe o pote inteiro entre as alturas cima e baixo da tela, centrado em x e sem passar de larguraMax
  function encaixa({ rx, rz }, x, cima, baixo, larguraMax) {
    const c = caixaPose(rx, rz);
    const s = Math.max(4, Math.min((baixo - cima) / c.h, larguraMax / c.w));
    // a tela tem y para baixo e o mundo, para cima: o meio da caixa fica no meio da faixa livre
    return { x: x - c.cx * s, yy: (cima + baixo) / 2 + c.cy * s, s };
  }

  function layout() {
    W = innerWidth;
    H = alturaTela();
    versao++;
    renderer.setSize(W, H, false);
    sombra.tamanho(W, H, W < 760 ? Math.min(W / 390, H / 700) : Math.min(W / 1440, H / 900));
    const D = H / 2 / TAN;
    camera.aspect = W / H;
    camera.position.set(0, 0, D);
    camera.near = D * 0.3;
    camera.far = D * 3;
    camera.updateProjectionMatrix();

    const topo = (el) => el.getBoundingClientRect().top + scrollY;
    const o = criaOnda(W, H);
    const saborTopo = topo(secoes.sabores);
    const base = saborTopo + o.A; // linha de base da onda, na página
    // a borda de cima da seção do sabor segue a mesma onda
    const pts = [];
    for (let x = 0; x <= W + 8; x += 8) pts.push(`${x.toFixed(0)},${(o.A + o.y(x)).toFixed(1)}`);
    const alt = secoes.saboresFundo.offsetHeight;
    secoes.saboresFundo.style.clipPath = `path("M${pts.join(' L')} L${W + 8},${alt} L0,${alt} Z")`;

    // no hero o pote inclinado ocupa 40% da altura da tela; no celular, ele encaixa no espaço livre entre
    // o título e o pé do hero (a tela do celular varia muito de altura, com e sem a barra do navegador)
    const cel = W < 760;
    let heroPose = { x: W * 0.5, yy: H * 0.765, s: (H * 0.4) / VISTO };
    if (cel) {
      const t = secoes.heroTitulo, cima = t.offsetTop + t.offsetHeight + H * 0.025;
      const baixo = secoes.hero.offsetHeight - H * 0.03;
      heroPose = encaixa({ rx: 0.6, rz: 0.14 }, W * 0.5, cima, baixo, W * 0.8);
    }
    const sHero = heroPose.s;
    const larguraFaixa = cel ? Math.min(clamp(H * 0.2, 130, 210), W * 0.36) : clamp(H * 0.2, 130, 210);
    const sRola = larguraFaixa / (V_TOPO * ALT); // px por cm quando o pote cola a fita
    const rPx = R_MEIO * sRola;
    const x0 = rPx * 1.25; // o pote pousa inteiro na tela, perto da borda esquerda
    const zFaixa = 0.25 * sRola;
    const g = geometriaFaixa({ W, onda: o, xIni: -0.06 * W, x0, xFim: W + rPx * 3, S: sRola, z: zFaixa });
    malhaFaixa.geometry.dispose();
    malhaFaixa.geometry = g.geometria;
    const sFim = g.sDeX(W + rPx * 1.35); // o pote some pela direita

    // começa a rolar quando a divisa, no ponto de pouso, passa por 88% da tela; rola por 0,56 tela
    const yR0 = Math.max(H * 1.2, base + o.y(x0) - H * 0.88);
    const yR1 = yR0 + H * 0.56;

    // giro: da pose do hero até um ângulo em que a frente do pote mostra a emenda entre duas artes
    // (a ponta da faixa começa limpa, sem cortar o selo)
    const giroHero = -0.22;
    const giroBruto = giroHero - 3.4 * (yR0 / H);
    const giro0 = Math.PI / 2 + Math.PI * Math.round((giroBruto - Math.PI / 2) / Math.PI);
    fita.uTheta0.value = -giro0;

    // pouso: o centro do pote fica 0,5 cm acima da linha do meio da faixa, na normal da onda
    const d0 = o.dy(x0), len0 = Math.hypot(1, d0);
    const pouso = {
      y: yR0,
      x: x0 + (d0 / len0) * 0.5 * sRola,
      yy: H * 0.88 - (1 / len0) * 0.5 * sRola,
      s: sRola, rx: INCLINA_ROLA, rz: -Math.atan(d0), z: -FRENTE * sRola,
    };
    const K2 = Math.max(H * 0.9, yR0 - H * 0.75);
    const marcos = cel ? [
      // celular: o mural é uma coluna com o papel kraft à direita; o pote desce pela beirada esquerda, menor que no
      // pouso, sem cobrir o texto
      { y: 0, x: heroPose.x, yy: heroPose.yy, s: sHero, rx: 0.6, rz: 0.14, z: 0 },
      { y: H * 0.6, x: W * 0.21, yy: H * 0.52, s: sRola * 0.8, rx: 0.38, rz: 0.05, z: 0 },
      { y: K2, x: W * 0.21, yy: H * 0.47, s: sRola * 0.84, rx: 0.22, rz: -0.05, z: 0 },
      pouso,
    ] : [
      { y: 0, x: W * 0.5, yy: H * 0.765, s: sHero, rx: 0.6, rz: 0.14, z: 0 },
      { y: H * 0.6, x: W * 0.42, yy: H * 0.54, s: sHero * 0.92, rx: 0.38, rz: 0.05, z: 0 },
      { y: K2, x: W * 0.37, yy: H * 0.47, s: sHero * 0.82, rx: 0.22, rz: -0.05, z: 0 },
      pouso,
    ];
    // a faixa corre para a esquerda enquanto o pote rola para a direita (e continua depois que ele sai)
    const desliza = 0.32;
    const vDepois = (desliza * sFim) / ((1 - ACEL / 2) * (yR1 - yR0)); // px por px de rolagem, sem tranco

    // o palco do sabor: preso enquanto a seção rola; o pote cai do alto e fica no meio, visto de cima
    const yS0 = saborTopo, yS1 = saborTopo + secoes.sabores.offsetHeight - H;
    const yQ0 = Math.max(yR1 + H * 0.03, yS0 - H * 0.45), yQ1 = yS0 + H * 0.12;
    // no celular, o pote do palco encaixa entre o texto do sabor (no alto) e o "O" do título (embaixo)
    let palco = { x: W * 0.5, yy: H * 0.5, s: (H * 0.5) / VISTO, rx: 0.92, rz: -0.06 };
    if (cel) {
      const info = secoes.saboresInfo, oEl = secoes.saboresO;
      const cima = info.offsetTop + info.offsetHeight + H * 0.015, baixo = oEl.offsetTop - H * 0.01;
      palco = { ...encaixa({ rx: 0.92, rz: -0.06 }, W * 0.5, cima, baixo, W * 0.78), rx: 0.92, rz: -0.06 };
    }

    L = { o, base, sRola, rPx, x0, zFaixa, yR0, yR1, sFim, xDeS: g.xDeS, giroHero, giro0, marcos, desliza, vDepois, yS0, yS1, yQ0, yQ1, palco };
  }

  let ultimo = performance.now(), parado = false, todos = false, versao = 0, ultimaChave = '';

  function atualiza(Y) {
    if (!L) return;
    const agora = performance.now();
    const dt = Math.min(0.05, (agora - ultimo) / 1000);
    ultimo = agora;

    // mola do mouse (só pesa no hero)
    for (const k of ['x', 'y']) {
      const v = k === 'x' ? 'vx' : 'vy';
      mola[v] += ((alvo[k] - mola[k]) * 90 - mola[v] * 9) * dt;
      mola[k] += mola[v] * dt;
    }

    let px = 0, py = 0, s = 1, rx = 0, rz = 0, z = 0, giro = 0, d = 0, desliza = 0, vePote = true;
    if (Y < L.yQ0) zeraSabor();
    // reserva: se a página chegar perto do palco do sabor antes do aquece() terminar, carrega o que falta já
    if (!todos && Y > L.yR0 * 0.5) { todos = true; sabores.forEach((_, i) => garante(i)); }

    if (Y < L.yR0) {
      const m = L.marcos, noHero = 1 - suave(clamp(Y / (H * 0.4), 0, 1));
      px = curva(m, 'x', Y); py = curva(m, 'yy', Y); s = curva(m, 's', Y);
      rx = curva(m, 'rx', Y); rz = curva(m, 'rz', Y); z = curva(m, 'z', Y);
      giro = L.giroHero + (L.giro0 - L.giroHero) * giroDescida(clamp(Y / L.yR0, 0, 1));
      px += mola.x * 22 * noHero;
      py += mola.y * 12 * noHero;
      rx += mola.y * 0.16 * noHero;
      giro += mola.x * 0.45 * noHero;
    } else if (Y < L.yR1) {
      // rolando: o ponto de contato anda pela onda e o pote gira sem escorregar
      const u = clamp((Y - L.yR0) / (L.yR1 - L.yR0), 0, 1);
      const sPx = rampa(u) * L.sFim;
      const xc = L.xDeS(sPx);
      const dy = L.o.dy(xc), len = Math.hypot(1, dy);
      const yc = L.base - Y + L.o.y(xc);
      s = L.sRola;
      px = xc + (dy / len) * 0.5 * s;
      py = yc - (1 / len) * 0.5 * s;
      rx = INCLINA_ROLA;
      rz = -Math.atan(dy);
      z = -FRENTE * s;
      d = sPx / s;
      desliza = (L.desliza * sPx) / s;
      giro = L.giro0 - (d + desliza) / R_MEIO;
    } else {
      vePote = false;
      desliza = (L.desliza * L.sFim + (Y - L.yR1) * L.vDepois) / L.sRola;
      const P = L.palco;
      // o palco na tela: sobe com a seção antes de prender e depois de soltar
      const palcoY = P.yy + Math.max(0, L.yS0 - Y) - Math.max(0, Y - L.yS1);
      const deriva = (Y - L.yS0) * 0.0007; // gira devagar enquanto a página rola
      if (Y >= L.yQ0 && palcoY > -H * 0.4) {
        vePote = true;
        const t = clamp((Y - L.yQ0) / (L.yQ1 - L.yQ0), 0, 1);
        const k = quica(t);
        px = lerp(W * 0.62, P.x, suave(t));
        py = lerp(-H * 0.32, palcoY, k);
        s = lerp(P.s * 0.8, P.s, suave(t));
        rx = lerp(0.35, P.rx, suave(t));
        rz = lerp(0.3, P.rz, suave(t));
        giro = lerp(-DOIS_PI, 0, suave(t)) + deriva + troca.extra;
        py += Math.sin(clamp((Y - L.yS0) / (L.yS1 - L.yS0), 0, 1) * Math.PI * 4) * H * 0.008;
      }
    }

    // a faixa: só o que já colou; depois que o pote sai, ela inteira corre de lado com a rolagem
    const saiu = Y >= L.yR1;
    fita.uD.value = saiu ? 0 : d + desliza; // no palco do sabor o pote mostra o rótulo inteiro
    fitaFaixa.uLimite.value = saiu ? 1e6 : d;
    fitaFaixa.uDesliza.value = desliza;
    const faixaNaTela = L.base - Y > -H * 0.4 && (d > 0 || saiu);

    // depois que tudo sai da tela, o palco descansa
    if (!vePote && !faixaNaTela) {
      if (!parado) { renderer.setRenderTarget(null); renderer.clear(); parado = true; ultimaChave = ''; }
      return;
    }
    parado = false;

    // nada mudou desde o último desenho (a pose, a fita, as texturas, o tamanho): não desenha de novo. Parado no
    // hero, ou lendo um sabor, a GPU descansa
    const q = (v) => Math.round(v * 1000);
    const chave = [versao, vePote, faixaNaTela, saiu, q(px), q(py), q(z), q(s), q(rx), q(rz), q(giro), q(L.base - Y),
      q(fita.uD.value), q(fitaFaixa.uLimite.value), q(desliza), q(fita.uTrocaAng.value), q(fita.uTrocaIni.value),
      fita.uRotulo.value?.id, fita.uRotuloB.value?.id, pote.userData.topo.material.map?.id].join();
    if (chave === ultimaChave) return;
    ultimaChave = chave;

    raiz.visible = vePote;
    malhaFaixa.visible = faixaNaTela;
    // depois que o pote sai rolando, a faixa é só a borda da página: ela vai antes e não marca profundidade, então o
    // pote que cai no palco do sabor passa inteiro por cima dela (pela profundidade ele a atravessaria no meio)
    malhaFaixa.renderOrder = saiu ? -1 : 0;
    malhaFaixa.material.depthWrite = !saiu;
    giroAtual = giro;
    raiz.position.set(px - W / 2, H / 2 - py, z);
    raiz.scale.setScalar(s);
    raiz.rotation.set(rx, 0, rz);
    pote.rotation.y = giro;
    malhaFaixa.position.y = H / 2 - (L.base - Y);
    // a sombra primeiro (limpa o canvas), o palco por cima
    sombra.desenha(scene, camera);
    renderer.autoClear = false;
    renderer.render(scene, camera);
    renderer.autoClear = true;
  }

  layout();
  // os shaders (o pote, a fita, a sombra) compilam em paralelo e a textura da faixa sobe antes do primeiro quadro:
  // sem isso, o primeiro desenho do palco travava a página por ~60 ms bem no meio da abertura
  renderer.initTexture(fita.uFaixa.value);
  await Promise.all([renderer.compileAsync(scene, camera), sombra.compila(scene, camera)]);
  return { layout, atualiza, aquece, renderer, trocaSabor, get marcos() { return L; } };
}
