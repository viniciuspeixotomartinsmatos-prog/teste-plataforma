// Tudo o que muda de uma marca para outra fica aqui: trocar o nome muda o logo, a tampa e a faixa.
export const MARCA = 'scoopie';

// cor: fundo da seção do sabor; titulo: o nome gigante, tom sobre tom; tinta: o texto pequeno sobre o fundo
export const SABORES = [
  { id: 'pistache', nome: 'PISTACHE', cor: '#7fc241', titulo: '#c8ee5c', tinta: '#3b1a12', arte: '/img/rotulo-pistache.webp',
    desc: 'Pistache torrado e moído na hora, com pedaço inteiro no meio de cada colherada.' },
  { id: 'morango', nome: 'MORANGO', cor: '#e8263d', titulo: '#ff8d9c', tinta: '#fff1de', arte: '/img/rotulo-morango.webp',
    desc: 'Morango de verdade batido com creme, e mais pedaço guardado no fundo do pote.' },
  { id: 'maracuja', nome: 'MARACUJÁ', cor: '#ffc21f', titulo: '#ff8a1a', tinta: '#3b1a12', arte: '/img/rotulo-maracuja.webp',
    desc: 'Azedinho na medida, com calda de maracujá e as sementes, do jeito que tem que ser.' },
  { id: 'acai', nome: 'AÇAÍ', cor: '#5b2a86', titulo: '#9a5fd0', tinta: '#fff1de', arte: '/img/rotulo-acai.webp',
    desc: 'Açaí grosso e cremoso, com banana no meio e aquele roxo que mancha a colher.' },
  { id: 'chocolate', nome: 'CHOCOLATE', cor: '#6b3a23', titulo: '#a8673f', tinta: '#fff1de', arte: '/img/rotulo-chocolate.webp',
    desc: 'Chocolate meio amargo, bem cremoso, com raspas por cima pra quem não divide.' },
];

// a frase que o rótulo vira quando descola do pote
export const FRASE_FAIXA = 'QUANDO A VIDA ESQUENTA, A GENTE GELA';

// A embalagem em 3D, em cm: um tronco de cone (o corpo, com o rótulo) e a tampa com saia. O rótulo, a faixa, o rolar
// na onda e o tamanho do pote em cada pose saem destas medidas: um copo, um pote baixo ou uma lata são outros números
// aqui (o guia ensina a tirar as medidas de uma foto ou de uma descrição).
export const EMBALAGEM = {
  rTopo: 4.8, // raio da boca
  rBase: 4.0, // raio do fundo
  altura: 9.4, // altura do corpo
  saia: 1.0, // quanto a saia da tampa desce pelo corpo (o rótulo acaba embaixo dela)
  corTampa: '#3b1a12',
  corFundo: '#efe2c8',
  linhaRotulo: 'sorvete artesanal · 500 ml', // embaixo do nome do sabor, no selo do rótulo
  voltaTampa: ['SORVETE ARTESANAL', '500 ML'], // o texto em volta da tampa, com o sabor entre os dois
};
