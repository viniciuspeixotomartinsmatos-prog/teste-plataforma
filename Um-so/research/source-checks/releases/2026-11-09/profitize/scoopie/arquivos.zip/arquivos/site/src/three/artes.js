// Artes desenhadas em canvas: rótulo (arte do Codex + selo do sabor), tampa (texto em volta + logo) e a faixa
// (o que o rótulo vira quando descola: faixa creme com a frase e a tampa entre as frases).
import { desenhaMarca, carregaFonteMarca } from './marca.js';
import { EMBALAGEM } from '../config.js';

export const COR = { rosa: '#ff6db8', choco: '#3b1a12', creme: '#fff1de' };
const FONTE = '"Bricolage Grotesque Variable"';

export async function fontesProntas() {
  await Promise.all([
    document.fonts.load(`800 100px ${FONTE}`),
    document.fonts.load(`700 40px ${FONTE}`),
    carregaFonteMarca(),
  ]);
}

function texto(ctx, { t, x, y, px, peso = 800, cor, alinha = 'center', base = 'middle', espaco = 0 }) {
  ctx.save();
  ctx.font = `${peso} ${px}px ${FONTE}`;
  ctx.fontStretch = 'condensed';
  ctx.letterSpacing = `${espaco}px`;
  ctx.fillStyle = cor;
  ctx.textAlign = alinha;
  ctx.textBaseline = base;
  ctx.fillText(t, x, y);
  ctx.restore();
}

/** rótulo: a arte inteira + selo creme com o sabor no meio (a frente do pote) */
export function desenhaRotulo(arte, { sabor, linha = EMBALAGEM.linhaRotulo, cor = COR.choco }) {
  const c = document.createElement('canvas');
  c.width = 1536;
  c.height = 1024;
  const ctx = c.getContext('2d');
  ctx.drawImage(arte, 0, 0, c.width, c.height);
  if (sabor) {
    const w = 640, h = 300, x = (c.width - w) / 2, y = 380;
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,.18)';
    ctx.shadowOffsetY = 10;
    ctx.fillStyle = COR.creme;
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 150);
    ctx.fill();
    ctx.restore();
    texto(ctx, { t: sabor, x: c.width / 2, y: y + 135, px: 170, cor });
    texto(ctx, { t: linha.toUpperCase(), x: c.width / 2, y: y + 238, px: 30, peso: 700, cor, espaco: 2 });
  }
  return c;
}

/** tampa: disco de chocolate com o texto em volta e o logo no meio */
export function desenhaTampa({ nome, sabor, cor = EMBALAGEM.corTampa, letra = COR.creme, selo = COR.rosa }) {
  const c = document.createElement('canvas');
  c.width = c.height = 1024;
  const ctx = c.getContext('2d');
  const m = 512;
  ctx.fillStyle = cor;
  ctx.fillRect(0, 0, 1024, 1024);
  ctx.strokeStyle = letra;
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.arc(m, m, 380, 0, Math.PI * 2);
  ctx.stroke();
  const [antes, depois] = EMBALAGEM.voltaTampa;
  const volta = `${antes} • ${sabor} • ${depois} • `.repeat(2);
  ctx.save();
  ctx.font = `800 58px ${FONTE}`;
  ctx.fontStretch = 'condensed';
  ctx.fillStyle = letra;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const total = [...volta].reduce((s, ch) => s + ctx.measureText(ch).width, 0);
  const raio = 440, escala = (Math.PI * 2 * raio) / total;
  let ang = -Math.PI / 2;
  for (const ch of volta) {
    const a = (ctx.measureText(ch).width * escala) / raio;
    ctx.save();
    ctx.translate(m + Math.cos(ang + a / 2) * raio, m + Math.sin(ang + a / 2) * raio);
    ctx.rotate(ang + a / 2 + Math.PI / 2);
    ctx.scale(escala, 1);
    ctx.fillText(ch, 0, 0);
    ctx.restore();
    ang += a;
  }
  ctx.restore();
  desenhaMarca(ctx, { nome, cx: m, cy: m - 10, px: 190, larguraMax: 600, recheio: selo, contorno: COR.creme });
  return c;
}

/**
 * A faixa: uma volta do texto que corre no meio da fita (creme, com a frase e a tampa entre as frases).
 * altura = px da faixa creme; margem = linhas transparentes em cima e embaixo (a borda sai suave).
 */
export function desenhaFaixa({ frase, tampa, altura = 256, margem = 4 }) {
  const medir = document.createElement('canvas').getContext('2d');
  const fonte = (px) => `800 ${px}px ${FONTE}`;
  // corpo da letra: a caixa alta ocupa ~52% da faixa
  medir.font = fonte(100);
  medir.fontStretch = 'condensed';
  const capa = medir.measureText('H').actualBoundingBoxAscent / 100;
  const px = Math.round((altura * 0.52) / capa);
  medir.font = fonte(px);
  medir.fontStretch = 'condensed';
  const larguraFrase = medir.measureText(frase).width;
  const selo = Math.round(altura * 0.84);
  const folga = Math.round(altura * 0.42);
  const largura = Math.ceil(folga + larguraFrase + folga + selo + folga);
  const c = document.createElement('canvas');
  c.width = largura;
  c.height = altura + margem * 2;
  const ctx = c.getContext('2d');
  ctx.fillStyle = COR.creme;
  ctx.fillRect(0, margem, largura, altura);
  texto(ctx, { t: frase, x: folga, y: margem + altura / 2 + altura * 0.03, px, cor: COR.choco, alinha: 'left' });
  // a tampa vista de cima entre as frases
  const tx = folga + larguraFrase + folga, ty = margem + (altura - selo) / 2;
  ctx.save();
  ctx.beginPath();
  ctx.arc(tx + selo / 2, ty + selo / 2, selo / 2, 0, Math.PI * 2);
  ctx.clip();
  ctx.drawImage(tampa, tx, ty, selo, selo);
  ctx.restore();
  return { canvas: c, altura, margem };
}

/** a arte do rótulo de um sabor; no celular, a versão de 1024 px (o pote é pequeno na tela e o peso ao abrir importa) */
export const arteDe = (sabor) => (innerWidth < 760 ? sabor.arte.replace(/\.webp$/, '-m.webp') : sabor.arte);

/**
 * A arte de um rótulo, decodificada fora da thread principal (createImageBitmap) e já num canvas: desenhar o rótulo
 * e virar textura não decodificam mais a imagem no meio de um quadro (eram ~25 ms por sabor).
 */
const artes = new Map(); // a mesma arte serve ao palco e aos retratos: baixa e decodifica uma vez só
export function carregaArte(src) {
  if (!artes.has(src)) artes.set(src, decodificaArte(src));
  return artes.get(src);
}
async function decodificaArte(src) {
  try {
    const bmp = await createImageBitmap(await (await fetch(src)).blob());
    const c = document.createElement('canvas');
    c.width = bmp.width;
    c.height = bmp.height;
    c.getContext('2d').drawImage(bmp, 0, 0);
    bmp.close();
    return c;
  } catch {
    return carregaImagem(src); // navegador sem createImageBitmap: a imagem comum
  }
}

// a imagem já chega decodificada (fora da thread principal): virar textura não trava o quadro
export const carregaImagem = (src) => new Promise((ok, erro) => {
  const i = new Image();
  i.decoding = 'async';
  i.onload = () => (i.decode ? i.decode().catch(() => {}).then(() => ok(i)) : ok(i));
  i.onerror = erro;
  i.src = src;
});
