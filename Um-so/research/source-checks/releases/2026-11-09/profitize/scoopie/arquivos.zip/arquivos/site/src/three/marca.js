// Logo cremoso: Bagel Fat One em caixa baixa, cada letra num giro e numa altura (pulando), contorno creme de
// adesivo por trás e gotas escorrendo dele. Desenhado em canvas: entra na página, na tampa e na abertura.
const FONTE = '"Bagel Fat One"';
const GIROS = [-5, 4, -3, 5, -4, 3, -5, 4]; // graus
const ALTURAS = [0, -0.05, 0.035, -0.045, 0.04, -0.035, 0.03, -0.04]; // em em
// [letra, comprimento da gota em em]; nome sem entrada aqui pinga na 2ª e na penúltima letra
const GOTAS = { scoopie: [[2, 0.36], [6, 0.27]] };

export const carregaFonteMarca = () => document.fonts.load(`100px ${FONTE}`);

function gotasDe(nome) {
  const n = [...nome].length;
  return GOTAS[nome] || [[1, 0.36], [Math.max(2, n - 2), 0.28]];
}

// gota de creme: escorre do contorno embaixo do meio da letra (não vira perna de letra); as pontas de cima entram
// na letra, senão sobra um bico onde a barriga da letra sobe (o, e)
function gota(i, comp, px) {
  const w = px * 0.15, r = w * 0.62, gx = (i % 2 ? 0.05 : -0.05) * px, y0 = px * 0.05, h = px * comp;
  const aba = w * 1.15, topo = y0 - px * 0.07;
  const p = new Path2D();
  p.moveTo(gx - aba, topo);
  p.bezierCurveTo(gx - w * 0.45, y0, gx - w * 0.42, y0 + h * 0.22, gx - w * 0.42, y0 + h * 0.45);
  p.lineTo(gx - w * 0.42, y0 + h - r * 1.3);
  p.bezierCurveTo(gx - r * 1.08, y0 + h - r * 0.6, gx - r, y0 + h + r * 0.2, gx, y0 + h + r * 0.25);
  p.bezierCurveTo(gx + r, y0 + h + r * 0.2, gx + r * 1.08, y0 + h - r * 0.6, gx + w * 0.42, y0 + h - r * 1.3);
  p.lineTo(gx + w * 0.42, y0 + h * 0.45);
  p.bezierCurveTo(gx + w * 0.42, y0 + h * 0.22, gx + w * 0.45, y0, gx + aba, topo);
  p.closePath();
  return p;
}

// O adesivo creme de uma letra (contorno + gota) num canvas próprio, com os miolos fechados: o furo do p, do g ou
// do a vira creme como o resto, em vez de um pontinho do fundo. Guardado por chave (a abertura redesenha a cada
// quadro); x, y, w, h em unidades do canvas, com a origem na base da letra.
const adesivos = new Map();
function adesivo(l, i, comp, px, k, cor) {
  const chave = `${l}|${i}|${comp}|${px.toFixed(2)}|${k.toFixed(2)}|${cor}`;
  const pronto = adesivos.get(chave);
  if (pronto) return pronto;
  if (adesivos.size > 96) adesivos.clear();
  const regua = document.createElement('canvas').getContext('2d');
  regua.font = `${px}px ${FONTE}`;
  regua.textAlign = 'center';
  const m = regua.measureText(l), folga = px * 0.16;
  const x0 = Math.min(-m.actualBoundingBoxLeft, -0.25 * px) - folga, x1 = Math.max(m.actualBoundingBoxRight, 0.25 * px) + folga;
  const y0 = -m.actualBoundingBoxAscent - folga, y1 = Math.max(m.actualBoundingBoxDescent + folga, px * (0.12 + comp));
  const W = Math.ceil((x1 - x0) * k) + 2, H = Math.ceil((y1 - y0) * k) + 2;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.setTransform(k, 0, 0, k, 1 - x0 * k, 1 - y0 * k);
  g.font = `${px}px ${FONTE}`;
  g.textAlign = 'center';
  g.textBaseline = 'alphabetic';
  g.lineJoin = 'round';
  g.lineWidth = px * 0.2;
  g.strokeStyle = g.fillStyle = cor;
  g.strokeText(l, 0, 0);
  g.fillText(l, 0, 0);
  if (comp) g.fill(gota(i, comp, px));
  // fora = o que a borda alcança passando pelo transparente; o resto que não é cheio é miolo e vira creme
  const img = g.getImageData(0, 0, W, H), d = img.data, n = W * H;
  const fora = new Uint8Array(n), pilha = new Int32Array(n);
  let topo = 0;
  const entra = (p) => { if (!fora[p] && d[p * 4 + 3] < 250) { fora[p] = 1; pilha[topo++] = p; } };
  for (let x = 0; x < W; x++) { entra(x); entra(n - W + x); }
  for (let y = 0; y < H; y++) { entra(y * W); entra(y * W + W - 1); }
  while (topo) {
    const p = pilha[--topo], x = p % W;
    if (x > 0) entra(p - 1);
    if (x < W - 1) entra(p + 1);
    if (p >= W) entra(p - W);
    if (p < n - W) entra(p + W);
  }
  let cheio = -1;
  for (let p = 0; p < n && cheio < 0; p++) if (d[p * 4 + 3] === 255) cheio = p * 4;
  let miolo = false;
  if (cheio >= 0) {
    for (let p = 0; p < n; p++) {
      const q = p * 4;
      if (fora[p] || d[q + 3] === 255) continue;
      d[q] = d[cheio]; d[q + 1] = d[cheio + 1]; d[q + 2] = d[cheio + 2]; d[q + 3] = 255;
      miolo = true;
    }
  }
  if (miolo) g.putImageData(img, 0, 0);
  const s = { c, x: x0 - 1 / k, y: y0 - 1 / k, w: W / k, h: H / k };
  if (document.fonts.check(`${px}px ${FONTE}`)) adesivos.set(chave, s); // com a fonte reserva não guarda
  return s;
}

/**
 * Desenha o logo num canvas. (cx, cy) é o meio, px o corpo da letra, cabe em larguraMax.
 * anima (opcional): por letra, { s: escala, y: deslocamento em em, a: opacidade } — usado na abertura.
 */
export function desenhaMarca(ctx, { nome, cx, cy, px = 140, larguraMax = 600, recheio = '#3b1a12', contorno = '#fff1de', anima = null }) {
  const letras = [...nome.toLowerCase()];
  ctx.save();
  ctx.font = `${px}px ${FONTE}`;
  const esp = 0.035 * px;
  let largura = letras.reduce((s, l) => s + ctx.measureText(l).width + esp, -esp);
  if (largura > larguraMax) {
    px *= larguraMax / largura;
    ctx.font = `${px}px ${FONTE}`;
    largura = larguraMax;
  }
  const ws = letras.map((l) => ctx.measureText(l).width);
  const espPx = 0.035 * px;
  const base = cy + px * 0.33;
  const pos = [];
  let x = cx - largura / 2;
  for (let i = 0; i < letras.length; i++) { pos.push(x + ws[i] / 2); x += ws[i] + espPx; }
  const gotas = gotasDe(nome.toLowerCase());
  const t = ctx.getTransform();
  const k = Math.hypot(t.a, t.b) || 1; // pixels do aparelho por unidade do canvas
  const cada = (fn) => letras.forEach((l, i) => {
    const a = anima ? anima[i] : null;
    if (a && (a.a <= 0 || a.s <= 0)) return;
    ctx.save();
    ctx.translate(pos[i], base + (ALTURAS[i % 8] + (a ? a.y : 0)) * px);
    ctx.rotate((GIROS[i % 8] * Math.PI) / 180);
    if (a) { ctx.scale(a.s, a.s); ctx.globalAlpha = a.a; }
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    fn(l, i);
    ctx.restore();
  });
  cada((l, i) => {
    const g = gotas.find(([n]) => n === i);
    const s = adesivo(l, i, g ? g[1] : 0, px, k, contorno);
    ctx.drawImage(s.c, s.x, s.y, s.w, s.h);
  });
  ctx.fillStyle = recheio;
  cada((l) => ctx.fillText(l, 0, 0));
  ctx.restore();
}

/**
 * As letras do logo separadas, para o navegador animar cada uma fora da thread principal (a abertura): por letra,
 * um canvas com o adesivo creme e outro com o recheio, já girados, e o ponto de apoio (a base da letra). Tudo em
 * px CSS relativos a (cx, cy), o mesmo centro de desenhaMarca: no fim da animação o logo bate pixel a pixel com o
 * desenhado no canvas. O creme de todas as letras vai por baixo do recheio de todas, como em desenhaMarca.
 */
export function letrasMarca(nome, { cx, cy, px = 140, larguraMax = 600, recheio = '#3b1a12', contorno = '#fff1de', dpr = 1 }) {
  const letras = [...nome.toLowerCase()];
  const regua = document.createElement('canvas').getContext('2d');
  regua.font = `${px}px ${FONTE}`;
  const esp = 0.035 * px;
  let largura = letras.reduce((s, l) => s + regua.measureText(l).width + esp, -esp);
  if (largura > larguraMax) {
    px *= larguraMax / largura;
    regua.font = `${px}px ${FONTE}`;
    largura = larguraMax;
  }
  const ws = letras.map((l) => regua.measureText(l).width);
  const base = cy + px * 0.33;
  const gotas = gotasDe(nome.toLowerCase());
  let x = cx - largura / 2;
  return letras.map((l, i) => {
    const ax = x + ws[i] / 2, ay = base + ALTURAS[i % 8] * px; // o ponto de apoio, exato
    x += ws[i] + esp;
    const g = gotas.find(([n]) => n === i);
    const s = adesivo(l, i, g ? g[1] : 0, px, dpr, contorno);
    // a caixa do adesivo, com folga para o giro; o canvas encosta num pixel inteiro do aparelho e o desenho dentro
    // dele fica na posição exata (sem reamostrar no fim)
    const m = Math.max(s.w, s.h) * 0.1;
    const exX = ax + s.x - m, exY = ay + s.y - m;
    const left = Math.floor(exX * dpr) / dpr, top = Math.floor(exY * dpr) / dpr;
    const ox = ax - left, oy = ay - top; // o apoio dentro do canvas
    const w = s.w + m * 2 + 1 / dpr, h = s.h + m * 2 + 1 / dpr;
    const camada = (pinta) => {
      const c = document.createElement('canvas');
      c.width = Math.ceil(w * dpr);
      c.height = Math.ceil(h * dpr);
      c.style.cssText = `position:absolute;left:${left}px;top:${top}px;width:${c.width / dpr}px;height:${c.height / dpr}px;transform-origin:${ox}px ${oy}px`;
      const ctx = c.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.translate(ox, oy);
      ctx.rotate((GIROS[i % 8] * Math.PI) / 180);
      pinta(ctx);
      return c;
    };
    const creme = camada((ctx) => ctx.drawImage(s.c, s.x, s.y, s.w, s.h));
    const cheio = camada((ctx) => {
      ctx.font = `${px}px ${FONTE}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';
      ctx.fillStyle = recheio;
      ctx.fillText(l, 0, 0);
    });
    return { creme, cheio, px };
  });
}

/** o logo como <canvas> pronto para a página (nítido em retina); o nome vai para leitores de tela */
export function canvasMarca(nome, { px = 56, recheio, contorno } = {}) {
  const c = document.createElement('canvas');
  const dpr = Math.min(devicePixelRatio || 1, 3);
  const ctx0 = c.getContext('2d');
  ctx0.font = `${px}px ${FONTE}`;
  const largura = [...nome.toLowerCase()].reduce((s, l) => s + ctx0.measureText(l).width, 0) + px * 0.035 * (nome.length - 1);
  const w = largura + px * 0.6, h = px * 1.75;
  c.width = Math.ceil(w * dpr);
  c.height = Math.ceil(h * dpr);
  c.style.width = `${w}px`;
  c.style.height = `${h}px`;
  const ctx = c.getContext('2d');
  ctx.scale(dpr, dpr);
  desenhaMarca(ctx, { nome, cx: w / 2, cy: h * 0.38, px, larguraMax: w, recheio, contorno });
  c.setAttribute('aria-hidden', 'true');
  return c;
}
