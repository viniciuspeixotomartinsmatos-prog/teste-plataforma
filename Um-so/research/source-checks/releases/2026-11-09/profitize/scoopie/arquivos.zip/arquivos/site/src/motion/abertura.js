// Abertura: o logo entra no rosa letra por letra, pulando; quando o site está pronto, faixas em arco nas cores
// dos sabores sobem de baixo e descobrem o hero. ~2,5 s no total.
// As letras do logo são animadas pelo próprio navegador (Web Animations, fora da thread principal): enquanto elas
// entram, o pote 3D está sendo montado (texturas, shaders), e uma animação na thread principal travava no "sco".
// Quando a última letra assenta, o canvas desenha o logo pronto no mesmo quadro e as faixas seguem no canvas.
import { gsap } from 'gsap';
import { desenhaMarca, letrasMarca } from '../three/marca.js';
import { curva } from './letras.js';

const CORES = ['#e8263d', '#ffc21f', '#7fc241', '#5b2a86', '#6b3a23'];

export function abertura({ el, marca, reduzido }) {
  const ctx = el.getContext('2d');
  const est = { sobe: 0 };
  let W = 0, H = 0, dpr = 1, vivo = true, comLogo = false, camadas = null;

  function tamanho() {
    dpr = Math.min(devicePixelRatio || 1, 2);
    W = innerWidth;
    H = innerHeight;
    el.width = Math.round(W * dpr);
    el.height = Math.round(H * dpr);
  }
  const medidas = () => {
    const px = Math.min(W * 0.2, H * 0.3, 250);
    return { px, cx: W / 2, cy: H / 2 - px * 0.12, larguraMax: W * 0.8 };
  };

  function arco(y, c) {
    ctx.beginPath();
    ctx.moveTo(-20, y + c);
    ctx.quadraticCurveTo(W / 2, y - c, W + 20, y + c);
    ctx.lineTo(W + 20, H + 40);
    ctx.lineTo(-20, H + 40);
    ctx.closePath();
  }

  function desenha() {
    if (!vivo) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#ff6db8';
    ctx.fillRect(0, 0, W, H);
    if (comLogo) {
      const { px, cx, cy, larguraMax } = medidas();
      desenhaMarca(ctx, { nome: marca, cx, cy, px, larguraMax });
    }
    if (est.sobe > 0) {
      const c = H * 0.13, g = H * 0.12, n = CORES.length;
      const total = H + 8 + c + n * g + c;
      const y = H + 4 - est.sobe * total;
      CORES.forEach((cor, i) => { ctx.fillStyle = cor; arco(y + i * g, c); ctx.fill(); });
      // abaixo do último arco, a página aparece
      ctx.globalCompositeOperation = 'destination-out';
      arco(y + n * g, c);
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
    }
  }

  // o logo passa para o canvas (pronto) e as letras soltas saem, no mesmo quadro
  function logoNoCanvas() {
    comLogo = true;
    desenha();
    camadas?.remove();
    camadas = null;
  }

  tamanho();
  desenha();
  el.style.background = 'none'; // o canvas já pinta o rosa; embaixo do último arco ele precisa ser transparente
  addEventListener('resize', () => { if (!vivo) return; tamanho(); if (camadas) logoNoCanvas(); else desenha(); });

  // o logo entra assim que a fonte chega
  const entrou = document.fonts.load('100px "Bagel Fat One"').then(() => {
    if (reduzido) { logoNoCanvas(); return; }
    const { px, cx, cy, larguraMax } = medidas();
    const letras = letrasMarca(marca, { cx, cy, px, larguraMax, dpr });
    camadas = document.createElement('div');
    camadas.className = 'abertura__letras';
    camadas.setAttribute('aria-hidden', 'true');
    // todo o creme por baixo, todo o recheio por cima (como o canvas desenha)
    letras.forEach((l) => camadas.append(l.creme));
    letras.forEach((l) => camadas.append(l.cheio));
    el.after(camadas);
    const easing = curva('back.out(2.6)');
    const fins = letras.flatMap((l, i) => [l.creme, l.cheio].map((c) => c.animate(
      [{ transform: `translateY(${0.4 * l.px}px) scale(0)`, opacity: 0 }, { transform: 'none', opacity: 1 }],
      { duration: 500, delay: i * 75, easing, fill: 'both' },
    ).finished));
    return Promise.all(fins).then(logoNoCanvas, logoNoCanvas);
  });

  /** as faixas sobem e descobrem a página; aoDescobrir dispara quando o hero começa a aparecer */
  function revela({ aoDescobrir, aoFim }) {
    return entrou.then(() => {
      if (!comLogo) logoNoCanvas();
      if (reduzido) {
        aoDescobrir?.();
        gsap.to(el, { opacity: 0, duration: 0.4, onComplete: () => { vivo = false; el.remove(); aoFim?.(); } });
        return;
      }
      let avisou = false;
      gsap.to(est, {
        sobe: 1, duration: 1.45, ease: 'power2.inOut',
        onUpdate: () => {
          desenha();
          if (!avisou && est.sobe > 0.5) { avisou = true; aoDescobrir?.(); }
        },
        onComplete: () => { vivo = false; el.remove(); aoFim?.(); },
      });
    });
  }

  return { revela };
}
