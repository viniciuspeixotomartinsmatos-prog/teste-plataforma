# Receitas das imagens da Trami

As imagens da demo foram geradas por IA e tratadas por script. Estes são os prompts que as geraram. Eles ficam em inglês porque os geradores de imagem seguem melhor assim; o que adaptar está em português abaixo. Trocar qualquer uma delas é opcional: as da demo não têm marca e servem para qualquer produto.

## Ordem
1. **Paisagem do hero** (`paisagem.prompt.txt`): 16:9, o maior tamanho que o gerador der. Salve como `fonte/paisagem.png` e rode `python3 fonte/camadas.py --conferir /tmp/conferir`. O script escurece o céu, puxa a luz da copa para o rosa, recorta a copa pela crista e grava `public/img/hero-fundo*.webp`, `hero-copa*.webp` e `fonte/camadas.json`. Se o tamanho ou a crista mudarem, ajuste as constantes do `hero.css` e do `hero.html` (o guia, "Personalizar", diz quais).
2. **Folhas** (`folhas.prompt.txt`): folhas desfocadas sobre preto puro. Recorte a parte com as folhas (836 × 1024) e salve em `public/img/folhas.webp`. Entram nas Integrações em mesclagem *screen*: o preto some.
3. **Floresta vista de cima** (`clientes-fundo.prompt.txt`): anexe a paisagem do hero como referência. 2:1; salve em `public/img/clientes-fundo.webp` (1672 px) e `clientes-fundo-1100.webp` (1100 px).
4. **Rostos** (`avatares.prompt.txt`): uma folha 4 × 2 de retratos sobre fundo branco. Salve como `fonte/avatares.png` e rode `python3 fonte/avatares.py`: grava os oito em `public/img/avatar/` com os nomes da demo. São figurantes da interface; depoimento de cliente real usa a foto real dele.

## Ferramenta e custo
- Qualquer gerador de imagem serve (o do ChatGPT, Gemini, Midjourney, Firefly ou outro). Para a floresta vista de cima, use um que aceite imagem de referência.
- Cada receita é uma imagem. Nos planos pagos dos geradores, sai dentro da cota; por API, alguns centavos de dólar por imagem. Gere duas ou três e escolha.
- Os scripts pedem Python 3 com `pip install numpy pillow`.

## O que adaptar
- **Cores**: os prompts trazem os códigos de cor da demo (céu grafite e malva, luz rosa-coral na copa). Para outra paleta, troque os códigos e mude junto o `--rosa` em `src/styles/tokens.css` e os alvos de cor do `camadas.py` (bloco "copa").
- **Composição da paisagem**: mantenha o céu nos 28% de cima, os morros, a faixa de névoa e a crista da copa entre 54% e 66% da altura. O hero se posiciona pela crista: uma copa muito mais alta cobre o painel, uma muito mais baixa o deixa solto no céu.
- **Sem imagem nova**: fique com as da demo. Nenhuma tem marca, texto ou gente reconhecível.
