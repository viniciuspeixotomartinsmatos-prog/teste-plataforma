// Ajudantes da câmera: a pose da hero (com o giro do mouse em volta da parede e o balanço de cruzeiro) e o caminho
// por quadros-chave (Catmull-Rom na posição, nos ângulos e no deslocamento de lente).
import * as THREE from 'three';

const sm = (t) => t * t * (3 - 2 * t);

// giro da hero: órbita em volta do centro das janelas (a moldura fica, a vista anda) e o balanço de cruzeiro.
// Devolve o desvio em relação à pose reta (0, 0, L), para cada cena somar na sua câmera com a força que quiser.
export function orbita(mouse, t, L, reduzido = false) {
  const b = reduzido ? 0 : 1;
  const Y = mouse.x * 0.036 + Math.sin(t * 0.29) * 0.006 * b;
  const P = mouse.y * 0.024 + Math.sin(t * 0.21 + 1.3) * 0.004 * b;
  return {
    dx: L * Math.sin(Y) * Math.cos(P),
    dy: -L * Math.sin(P),
    dz: L * Math.cos(Y) * Math.cos(P) - L,
    yaw: Y,
    pitch: P,
    roll: Math.sin(t * 0.17) * 0.0025 * b,
  };
}

// aplica uma pose base + a órbita com força amp
export function aplicar(cab, base, orb, amp, lente = 1, heroi = null) {
  cab.rig.pos.set(base.pos[0] + orb.dx * amp, base.pos[1] + orb.dy * amp, base.pos[2] + orb.dz * amp);
  cab.rig.yaw = (base.yaw || 0) + orb.yaw * amp;
  cab.rig.pitch = (base.pitch || 0) + orb.pitch * amp;
  cab.rig.roll = orb.roll * amp;
  if (heroi) { cab.rig.sx = heroi.sx * lente; cab.rig.sy = heroi.sy * lente; }
}

// amostra quadros-chave { p, pos:[x,y,z], pitch (graus), lente (0..1), yaw? } no progresso p
export function caminho(K, p) {
  p = Math.min(1, Math.max(0, p));
  let i = 0;
  while (i < K.length - 2 && p > K[i + 1].p) i++;
  const k0 = K[Math.max(0, i - 1)], k1 = K[i], k2 = K[i + 1], k3 = K[Math.min(K.length - 1, i + 2)];
  const t = (p - k1.p) / Math.max(1e-6, k2.p - k1.p);
  const cr = (a, b, c, d) => {
    const t2 = t * t, t3 = t2 * t;
    return 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
  };
  const pos = [0, 1, 2].map((e) => cr(k0.pos[e], k1.pos[e], k2.pos[e], k3.pos[e]));
  const pitch = cr(k0.pitch, k1.pitch, k2.pitch, k3.pitch);
  const yaw = cr(k0.yaw || 0, k1.yaw || 0, k2.yaw || 0, k3.yaw || 0);
  const lente = k1.lente + (k2.lente - k1.lente) * sm(t);
  return { pos, pitch: THREE.MathUtils.degToRad(pitch), yaw: THREE.MathUtils.degToRad(yaw), lente, i, t };
}

// altura da câmera para a foto do chão (largura w, proporção r) cobrir a tela inteira, olhando reto para baixo
export function alturaCobre(fovGraus, aspecto, w, r) {
  const tg = Math.tan(THREE.MathUtils.degToRad(fovGraus) / 2);
  const h = w / r;
  return Math.min(w / (2 * aspecto * tg), h / (2 * tg));
}

export const suave = sm;
export const faixa = (x, a, b) => Math.min(1, Math.max(0, (x - a) / (b - a)));
