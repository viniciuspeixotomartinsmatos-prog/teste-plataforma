// 3 · Destinos: a foto zenital da ilha (fim da descida) vira o primeiro card. O card assume em tela cheia, no mesmo
// enquadramento do 3D, e encolhe até o quadro de largura inteira com cantos arredondados (preso ao scroll: é imagem).
// Depois, a pilha anda presa ao scroll: cada card sobe por baixo na proporção da rolagem e cobre o anterior, que
// recua e escurece na mesma proporção e fica espiando por cima. Só o texto do card troca por marco (por tempo),
// quando o card está chegando.
import { linhas, pecas } from '../split.js';
import { faixa } from '../stage/rig.js';
import { REDUZIDO } from '../ease.js';
import { CHAO_MEIO } from './voo.js';

const easeIO = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
// trecho do scroll (fração da cena) em que cada card sobe; o primeiro já está no lugar (vem da descida)
const SOBE = [null, [0.16, 0.38], [0.42, 0.64], [0.68, 0.9]];
// o texto de cada card entra quando ele está chegando (70% da subida); o do primeiro, depois de encolher
const MARCOS = [0.12, ...SOBE.slice(1).map(([a, b]) => a + (b - a) * 0.7)];

export function cenaDestinos(ctx) {
  const el = document.querySelector('.destinos');
  const sonda = document.createElement('div');
  sonda.style.cssText = 'position:absolute;inset:var(--ft) var(--fr) var(--fb) var(--fl);pointer-events:none;visibility:hidden';
  el.append(sonda);

  const cards = [...el.querySelectorAll('.card')].map((card, i) => {
    const esc = document.createElement('div');
    esc.className = 'card__escuro';
    card.querySelector('.card__sombra').after(esc);
    // o card inteiro leva ao formulário com o tipo marcado (o mesmo que o botão dele)
    card.addEventListener('click', (e) => {
      if (!e.target.closest('a')) card.querySelector('.card__ir').click();
    });
    return {
      card, i, esc,
      img: card.querySelector('.card__foto img'),
      sombra: card.querySelector('.card__sombra'),
      titulo: linhas(card.querySelector('.card__titulo')),
      frase: linhas(card.querySelector('.card__frase')),
      vidro: pecas([card.querySelector('.card__vidro')]),
      y: i === 0 ? 0 : 1, // 0 no lugar, 1 embaixo (fração da altura)
      atras: 0,           // quantos cards estão na frente dele (fração: o da frente ainda subindo conta em parte)
      texto: false,
    };
  });
  const st = { ativo: 0, quadro: null, raio: 28, livre: true };

  function medir() {
    const r = sonda.getBoundingClientRect();
    const p = el.getBoundingClientRect();
    st.quadro = { t: r.top - p.top, l: r.left - p.left, r: p.right - r.right, b: p.bottom - r.bottom, w: r.width, h: r.height, W: p.width, H: p.height };
    st.raio = parseFloat(getComputedStyle(el).getPropertyValue('--raio-card')) || 28;
  }

  function pintar(c, encolhe = 1) {
    // encolhe: 0 tela cheia, 1 no quadro (só o primeiro card passa por 0)
    const q = st.quadro;
    const e = encolhe;
    const t = q.t * e, r = q.r * e, b = q.b * e, l = q.l * e;
    const raio = st.raio * e;
    c.card.style.clipPath = `inset(${t}px ${r}px ${b}px ${l}px round ${raio}px)`;
    // os de trás recuam (escala) e sobem um pouco: no máximo dois aparecem, e a borda fica abaixo da nav
    const atras = Math.min(c.atras, 2);
    const s = 1 - 0.05 * atras;
    const yPx = c.y * q.H * 1.04 - 7 * atras;
    c.card.style.transform = c.atras || c.y ? `translate3d(0, ${yPx}px, 0) scale(${s})` : 'none';
    // escurece na proporção do card que sobe na frente (1 card: 0,56; 2: 0,72; 3: 0,78)
    const a = c.atras;
    c.esc.style.opacity = Math.min(0.78, a <= 1 ? 0.56 * a : 0.56 + 0.16 * (a - 1)).toFixed(3);
    c.card.style.visibility = c.atras > 2.5 ? 'hidden' : '';
    // a sombra do texto só vem com o encolher: na troca com o 3D a imagem é idêntica
    c.sombra.style.opacity = e;
  }

  function foto(c, encolhe, deriva) {
    const q = st.quadro;
    // em tela cheia o card começa no mesmo enquadramento do fim da descida (os 89% do meio da foto)
    const kQuadro = Math.max(q.w / q.W, q.h / q.H);
    const k0 = c.i === 0 ? 1 / CHAO_MEIO : 1;
    const k = k0 + (kQuadro - k0) * encolhe;
    const cy = (q.t + q.h / 2 - q.H / 2) * encolhe;
    const folga = (q.H * k - q.h) / 2;
    c.img.style.transform = `translate(-50%, -50%) translate3d(0, ${cy + deriva * folga * 0.8}px, 0) scale(${k})`;
  }

  function textos(c, entrar, atraso = 0) {
    if (entrar === c.texto) return;
    c.texto = entrar;
    if (entrar) { c.titulo.entrar(atraso, 1.1); c.frase.entrar(atraso + 0.14); c.vidro.entrar(atraso + 0.24); }
    else { c.titulo.sair(); c.frase.sair(); c.vidro.sair(); }
  }

  // a pilha no ponto p do scroll: quanto cada card já subiu (linear com a rolagem) e quantos estão na frente dele
  function empilhar(p) {
    const sobe = SOBE.map((t) => {
      if (!t) return 1;
      if (REDUZIDO) return p >= t[1] ? 1 : 0;
      return faixa(p, t[0], t[1]);
    });
    cards.forEach((c) => {
      c.y = 1 - sobe[c.i];
      let atras = 0;
      for (let k = c.i + 1; k < cards.length; k++) atras += sobe[k];
      c.atras = atras;
    });
  }

  return {
    id: 'destinos',
    telas: ctx.celular ? 3 : 3.2,
    marcos: MARCOS,
    camada: el,
    vis: [-0.005, 1.6], // a camada fica ligada durante o voo dos cards até o globo (cena seguinte)
    set: null,
    medir,
    cards,
    st,
    pintar,
    foto,

    ligou(on) { if (on) medir(); },

    passo(i, antes, pulo) {
      st.marco = i;
      st.ativo = Math.max(0, i - 1);
      cards.forEach((c) => textos(c, i >= 1 && c.i === st.ativo, 0));
    },

    // ponto do scroll (fração da cena) com o card i assentado e o texto dele na tela (links do rodapé)
    alvoCard: (i) => (i === 0 ? MARCOS[0] + 0.015 : SOBE[i][1] + 0.01),

    // os textos saem quando o mundo começa (os cards voam até o globo) e voltam quando a pilha volta
    sairTextos() { cards.forEach((c) => textos(c, false)); },
    voltarTextos() { cards.forEach((c) => textos(c, (st.marco || 0) >= 1 && c.i === st.ativo, 0.1)); },

    atualizar(p) {
      if (!st.quadro) medir();
      empilhar(Math.min(1, Math.max(0, p)));
      if (!st.livre) return; // o mundo está controlando os cards
      const e = REDUZIDO ? (p > 0.02 ? 1 : 0) : easeIO(faixa(p, 0, 0.1));
      cards.forEach((c) => {
        c.card.classList.toggle('is-ativo', c.i === st.ativo && p > 0.1 && p < 0.99);
        const vivo = p >= 0 && (c.i === 0 || c.y < 0.999 || c.atras > 0);
        c.card.classList.toggle('is-vivo', vivo);
        if (!vivo) return;
        // deriva lenta da foto dentro do card enquanto ele está ativo
        const a = c.i === 0 ? 0 : SOBE[c.i][0];
        const b = SOBE[c.i + 1]?.[1] ?? 1;
        const deriva = REDUZIDO ? 0 : 0.5 - faixa(p, a, b);
        pintar(c, c.i === 0 ? e : 1);
        foto(c, c.i === 0 ? e : 1, c.i === 0 ? deriva * e : deriva);
      });
    },
  };
}
