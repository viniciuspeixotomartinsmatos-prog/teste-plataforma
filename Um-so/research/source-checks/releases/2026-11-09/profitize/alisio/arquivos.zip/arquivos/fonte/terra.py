# Máscara de continentes do globo (public/globo/terra.png) a partir do Natural Earth (domínio público).
# Baixe ne_50m_land.geojson de github.com/nvkelso/natural-earth-vector (pasta geojson) e rode:
#   python3 fonte/scripts/terra.py ne_50m_land.geojson public/globo/terra.png
import json, sys
from PIL import Image, ImageDraw
src, out = sys.argv[1], sys.argv[2]
W, H = 4096, 2048
img = Image.new('L', (W, H), 0)
d = ImageDraw.Draw(img)
def ring(coords):
    return [((lon + 180) / 360 * W, (90 - lat) / 180 * H) for lon, lat in coords]
data = json.load(open(src))
for f in data['features']:
    g = f['geometry']
    polys = [g['coordinates']] if g['type'] == 'Polygon' else g['coordinates']
    for p in polys:
        d.polygon(ring(p[0]), fill=255)
        for hole in p[1:]:
            d.polygon(ring(hole), fill=0)
img = img.resize((1024, 512), Image.LANCZOS)
img.save(out, optimize=True)
print('ok', out)
