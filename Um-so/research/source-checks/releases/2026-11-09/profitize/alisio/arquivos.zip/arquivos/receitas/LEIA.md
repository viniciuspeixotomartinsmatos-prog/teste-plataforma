# Receitas: como as imagens da Alísio foram feitas

Todas as fotos do site foram geradas por IA a partir destes prompts. Aqui estão eles, na ordem em que foram feitos, para você refazer as imagens com os **seus** destinos. Os prompts estão em inglês porque os geradores entendem melhor; o que muda de uma agência para outra está marcado em cada passo.

As janelas, a parede, as persianas, o globo e o cartão de embarque **não são imagem**: são código e mudam de cor e texto direto no projeto. Só a vista pela janela, as nuvens, os destinos e a gravura do rodapé são fotos.

## Do que você precisa

- **Um gerador de imagem que aceite foto de referência**: ChatGPT (imagens), Gemini, Midjourney (com referência de imagem) ou outro. São umas 12 imagens; nos geradores pagos por imagem, de US$ 0,05 a US$ 0,20 cada.
- **A referência**: anexe em cada prompt o print da hero da demo (`arquivos/conceito/00-hero-desktop.jpg`). É o que mantém a luz, as cores e o tipo de foto iguais em todas.
- Para montar as camadas: Python 3 com Pillow e NumPy, e o `cwebp` (a IA do seu editor instala).

## Passo a passo

1. **Estilo** (`_estilo.txt`). É o bloco que entra em todos os prompts de foto aérea. Se os seus destinos são outros (serra, praia de rio, cidade histórica), reescreva a cena e as cores aqui primeiro.
2. **A vista da janela** (`vista-larga`). Uma panorâmica bem larga (3:1), tirada do alto, com o horizonte a um quarto da altura e o lugar principal **pequeno no meio** (um quinto da largura): é o que deixa cada janela mostrar um pedaço diferente da mesma vista. Sem nuvens (elas vêm em camadas separadas). Troque a ilha pelo seu lugar-símbolo. O céu, o mar que continua para os lados e para baixo e a versão da noite saem dessa mesma foto pelo script (passo 8).
3. **Nuvens** (`nuvens-perto`). PNG com fundo transparente de verdade: as nuvens grandes do pé das janelas. O script corta dela os recortes da descida e monta a faixa de nuvens ao longe; servem para qualquer destino. Se o seu gerador fizer transparência bem, `nuvens-longe` e `nuvens-recortes` são as versões feitas à parte (opcionais: o script prefere elas quando existem).
4. **O destino visto de cima** (`destino-ilhas`). Foto zenital do mesmo lugar da panorâmica, com o canto de baixo à esquerda calmo (o texto do card fica ali). Ela é ao mesmo tempo o fim da descida e o primeiro card.
4b. **O mar em volta dela** (`destino-ilhas-fora`). Na descida a câmera vê bem mais que a foto, então ela precisa de mar aberto em volta. Rode o script uma vez (passo 8) com a foto zenital em `fonte/`: ele gera `fonte/destino-ilhas-tela.png` (a foto no meio de uma tela cinza). Mande essa tela para o gerador com o prompt `destino-ilhas-fora.prompt.txt` (ele preenche o cinza com mar e nuvens soltas) e salve o resultado em `fonte/destino-ilhas-fora.png`. O script põe a foto original por cima em resolução cheia, então o card continua idêntico ao fim da descida. Sem esse passo, a borda da foto aparece como um retângulo esticado no meio do mar.
5. **Os outros destinos** (`destino-serras`, `destino-neve`, `destino-deserto`). Paisagem 16:9, o canto de baixo à esquerda calmo. Troque pelos tipos de viagem que a sua agência vende.
6. **Noite** (`noite-asa`, opcional). A ponta da asa no escuro, com fundo transparente (a luz vermelha é feita no código e aparece mesmo sem a asa). A vista da noite não precisa de prompt: o script faz a mesma panorâmica "dia por noite".
7. **Rodapé** (`rodape-gravura`). Uma gravura em tinta preta no branco com as paisagens dos seus destinos, céu vazio em cima e um avião pequeno com rastro nesse céu; o script transforma em linhas creme sobre a parede, separa o avião (`rodape-aviao`, que no site voa no canto vazio do rodapé), corta o céu que sobra e imprime as duas proporções que o `rodape.css` usa.
8. **Montar as camadas.** Ponha os PNGs em `fonte/` com estes nomes e rode, da raiz do projeto, `python3 fonte/scripts/camadas.py`. O script faz o céu a partir da panorâmica, esfuma o horizonte, estende o mar para baixo e para os lados, faz a noite, corta os recortes de nuvem e a faixa ao longe, monta o chão da descida (a foto zenital no meio do mar estendido, com a borda dissolvida em volta) e converte tudo para WebP em `public/img/`. Ele imprime `HORIZONTE_FOTO` e a largura extra: atualize `HORIZONTE_FOTO` e `PAN_LARGURA` em `src/motion/stage/vista.js`.
9. **O globo** (`fonte/scripts/terra.py`) já vem pronto em `public/globo/terra.png` (Natural Earth, domínio público). Só rode de novo se quiser outra resolução.

Formatos que o site espera: fotos em WebP com até 2048 px de largura (o script redimensiona), recortes com alfa, a panorâmica com o horizonte medido.

## Sem foto nova

Dá para ter o site com a sua marca sem gerar nada: a vista pela janela e a descida continuam com o mar e a ilha da demo, e você troca só os quatro cards dos destinos por fotos suas (16:9, 1600 px ou mais). O resto (janelas, globo, cartão, cabine à noite) é código.
