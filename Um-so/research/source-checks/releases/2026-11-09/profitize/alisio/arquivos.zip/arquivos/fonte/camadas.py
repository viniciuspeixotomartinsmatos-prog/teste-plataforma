# Monta as imagens do site (public/img/*.webp) a partir dos PNGs do Codex em fonte/.
# Roda da raiz da template: python3 fonte/scripts/camadas.py   (pula o que ainda não existe)
#
# - vista-ceu: degradê do céu tirado da própria panorâmica (coluna média) e esticado para cima
# - vista-ilha: a panorâmica com o alto esfumado no alfa (casa com o céu atrás)
# - noite-vista: a mesma panorâmica "dia por noite" (céu azul-noite, luar, mar escuro), se o Codex não fizer uma
# - nuvem-0..n: recortes da folha de nuvens (componentes do alfa)
# - destino-ilhas-chao: o chão da descida. A foto zenital no meio do mar aberto que o Codex estendeu em volta
#   (fonte/destino-ilhas-fora.png, feito a partir de fonte/destino-ilhas-tela.png, que este script gera), com a foto
#   original por cima em resolução cheia e a borda dissolvida no mar. Sem a extensão, cai no jeito antigo (borda
#   esticada e borrada), que mostra o retângulo da foto na descida.
# - rodape-gravura: a gravura em tinta preta vira alfa em creme, sem o céu vazio; o avião do céu vira rodape-aviao
import os, sys, subprocess
import numpy as np
from PIL import Image, ImageFilter

F = 'fonte'
OUT = 'public/img'
os.makedirs(OUT, exist_ok=True)


def caminho(nome):
    # as fotos sem transparência ficam em JPG q90; as com alfa, em PNG
    for ext in ('png', 'jpg'):
        if os.path.exists(f'{F}/{nome}.{ext}'):
            return f'{F}/{nome}.{ext}'
    return None


def tem(nome):
    return caminho(nome) is not None


def webp(img, nome, q=84, largura=None):
    if largura and img.width > largura:
        img = img.resize((largura, round(img.height * largura / img.width)), Image.LANCZOS)
    tmp = f'{OUT}/{nome}.tmp.png'
    img.save(tmp)
    alfa = ['-alpha_q', '90', '-exact'] if img.mode == 'RGBA' else []
    subprocess.run(['cwebp', '-quiet', '-q', str(q), '-m', '6', *alfa, tmp, '-o', f'{OUT}/{nome}.webp'], check=True)
    os.remove(tmp)
    print(f'{nome}.webp {img.width}x{img.height}')


def horizonte(arr):
    # linha onde o céu termina: maior salto de luminância média entre linhas no terço de cima
    lum = arr[..., :3].mean(axis=(1, 2))
    d = np.abs(np.diff(lum[: int(len(lum) * 0.45)]))
    return int(np.argmax(d)) + 1


def estender_embaixo(img, k=0.75):
    # o mar continua para baixo: primeiro o espelho da última faixa (a textura do mar segue sem emenda),
    # que vai borrando e derrete no azul médio do mar (nada de ilha: só as últimas linhas, que são mar aberto)
    W, H = img.size
    extra = round(H * k)
    a = np.asarray(img).astype(np.float32)
    mar = np.median(a[-max(8, H // 40):].reshape(-1, 3), axis=0) * 0.92
    n = min(H, round(extra * 0.35))
    esp = a[H - n:][::-1]                                 # espelho das últimas n linhas
    esp = np.concatenate([esp, np.repeat(esp[-1:], extra - n, axis=0)], axis=0)
    borr = np.asarray(Image.fromarray(esp.astype(np.uint8)).filter(ImageFilter.GaussianBlur(40))).astype(np.float32)
    y = np.arange(extra)[:, None, None]
    t = np.clip(y / (extra * 0.22), 0, 1) ** 1.2          # a nitidez some aos poucos
    u = np.clip((y - extra * 0.12) / (extra * 0.35), 0, 1)
    ext = esp * (1 - t) + borr * t
    ext = ext * (1 - u) + mar * u
    out = Image.new('RGB', (W, H + extra))
    out.paste(img, (0, 0))
    out.paste(Image.fromarray(np.clip(ext, 0, 255).astype(np.uint8)), (0, H))
    return out


def estender_lados(img, k=0.36):
    # margem dos dois lados (na aproximação as janelas laterais olham bem para os lados): espelho perto da emenda,
    # cada vez mais borrado e derretido no degradê médio de cada linha (céu e mar), sem ilha repetida ao longe
    W, H = img.size
    m = round(W * k)
    a = np.asarray(img).astype(np.float32)
    media = a.mean(axis=1, keepdims=True)                # cor média de cada linha
    def lado(trecho):
        esp = np.asarray(Image.fromarray(trecho.astype(np.uint8)).transpose(Image.FLIP_LEFT_RIGHT)).astype(np.float32)
        borr = np.asarray(Image.fromarray(esp.astype(np.uint8)).filter(ImageFilter.GaussianBlur(24))).astype(np.float32)
        return esp, borr
    esq_e, esq_b = lado(a[:, :m])
    dir_e, dir_b = lado(a[:, W - m:])
    t = np.linspace(0, 1, m)[None, :, None]              # 0 na emenda, 1 na borda de fora
    def misturar(esp, borr, t):
        x = esp * (1 - np.clip(t * 3, 0, 1)) + borr * np.clip(t * 3, 0, 1)
        return x * (1 - np.clip(t * 1.3, 0, 0.9)) + media * np.clip(t * 1.3, 0, 0.9)
    esq = misturar(esq_e, esq_b, t[:, ::-1])
    dir_ = misturar(dir_e, dir_b, t)
    out = np.concatenate([esq, a, dir_], axis=1)
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))


def ceu_e_ilha():
    # a panorâmica da hero: vista-larga (ilha pequena no meio, como na hero aprovada); vista-ilha é a primeira versão
    fonte = 'vista-larga' if tem('vista-larga') else 'vista-ilha'
    pan0 = Image.open(caminho(fonte)).convert('RGB')
    W0 = pan0.width
    pan0 = estender_lados(pan0)
    print(f'panorâmica {fonte}: LARGURA_EXTRA = {pan0.width / W0:.4f}')
    h = horizonte(np.asarray(pan0).astype(np.float32))
    pan = estender_embaixo(pan0)
    a = np.asarray(pan).astype(np.float32)
    print('horizonte da panorâmica em', h, 'de', a.shape[0], f'(HORIZONTE_FOTO = {h / a.shape[0]:.4f})')
    # céu: média das colunas do céu da panorâmica, esticada para cima até um azul mais fundo
    col = a[: max(4, h - 6)].mean(axis=1)               # (h, 3) por linha
    col = np.array([col[: max(1, h - 6)].mean(axis=0)]) if col.shape[0] < 4 else col
    linhas = 1024
    topo = col[0] * np.array([0.78, 0.84, 0.95])        # mais fundo no alto
    ceu = np.zeros((linhas, 3), np.float32)
    corte = int(linhas * 0.62)                           # parte de cima: extrapolação; de baixo: o céu da foto
    for y in range(linhas):
        if y < corte:
            t = y / corte
            ceu[y] = topo * (1 - t) + col[0] * t
        else:
            t = (y - corte) / (linhas - corte - 1)
            ceu[y] = col[min(len(col) - 1, int(t * (len(col) - 1)))]
    img = np.repeat(ceu[:, None, :], 64, axis=1)
    img += np.random.default_rng(3).normal(0, 0.9, img.shape)
    webp(Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)), 'vista-ceu', q=90)
    # ilha: alto esfumado no alfa (as primeiras linhas viram o céu de trás)
    alfa = np.ones(a.shape[:2], np.float32)
    faixa = int(h * 0.55)
    rampa = np.clip(np.arange(a.shape[0]) / faixa, 0, 1) ** 1.6
    H0 = pan0.height
    fundo = 1 - np.clip((np.arange(a.shape[0]) - (H0 + 0.1 * (a.shape[0] - H0))) / (0.75 * (a.shape[0] - H0)), 0, 1) ** 1.2
    alfa *= (rampa * fundo)[:, None]
    rgba = np.dstack([a, alfa * 255]).astype(np.uint8)
    webp(Image.fromarray(rgba), 'vista-ilha', q=86)
    return pan, h, H0


def noite_da_panoramica(pan, h, H0):
    # "dia por noite": céu azul-noite com luar no alto à direita, mar escuro com o brilho do sol virando luar
    a = np.asarray(pan).astype(np.float32) / 255
    H, W = a.shape[:2]
    lum = (a * [0.3, 0.55, 0.15]).sum(axis=2)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    # chão: luminância comprimida em azul-prata
    mar = lum[..., None] ** 1.35 * np.array([0.34, 0.42, 0.6]) * 0.62
    mar += (np.clip(lum - 0.62, 0, 1) ** 1.5)[..., None] * np.array([0.55, 0.62, 0.78]) * 1.1  # reflexos viram luar
    # céu: degradê azul-noite, mais claro no horizonte e com o halo da lua no alto à direita
    t = np.clip(yy / max(1, h), 0, 1)[..., None]
    ceu = np.array([0.02, 0.035, 0.075]) * (1 - t) + np.array([0.1, 0.14, 0.22]) * t
    lua = np.exp(-(((xx - W * 0.86) / (W * 0.16)) ** 2 + ((yy - h * 0.15) / (h * 0.75)) ** 2))[..., None]
    ceu += lua * np.array([0.16, 0.19, 0.26])
    m = np.clip((yy - h + 2) / 6, 0, 1)[..., None]
    out = ceu * (1 - m) + mar * m
    out = np.clip(out, 0, 1) ** (1 / 1.0)
    rampa = np.clip(np.arange(H) / int(h * 0.55), 0, 1) ** 1.6
    rampa *= 1 - np.clip((np.arange(H) - (H0 + 0.1 * (H - H0))) / (0.75 * (H - H0)), 0, 1) ** 1.2
    rgba = np.dstack([out * 255, rampa[:, None].repeat(W, 1) * 255]).astype(np.uint8)
    img = Image.fromarray(rgba).filter(ImageFilter.GaussianBlur(0.6))
    webp(img, 'noite-vista', q=86)


def recortes(nome='nuvens-recortes', base='nuvem', minimo=0.004):
    img = Image.open(caminho(nome)).convert('RGBA')
    a = np.asarray(img)
    alfa = a[..., 3] > 18
    from collections import deque
    H, W = alfa.shape
    marca = np.zeros((H, W), np.int32)
    n = 0
    caixas = []
    for y0 in range(0, H, 2):
        for x0 in range(0, W, 2):
            if alfa[y0, x0] and not marca[y0, x0]:
                n += 1
                q = deque([(y0, x0)]); marca[y0, x0] = n
                ys, xs = [y0, y0], [x0, x0]; cont = 0
                while q:
                    y, x = q.popleft(); cont += 1
                    ys[0] = min(ys[0], y); ys[1] = max(ys[1], y); xs[0] = min(xs[0], x); xs[1] = max(xs[1], x)
                    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        yy, xx = y + dy, x + dx
                        if 0 <= yy < H and 0 <= xx < W and alfa[yy, xx] and not marca[yy, xx]:
                            marca[yy, xx] = n; q.append((yy, xx))
                if cont > minimo * H * W:
                    caixas.append((xs[0], ys[0], xs[1], ys[1], cont))
    caixas.sort(key=lambda c: -c[4])
    for i, (x0, y0, x1, y1, _) in enumerate(caixas[:12]):
        m = 12
        c = img.crop((max(0, x0 - m), max(0, y0 - m), min(W, x1 + m), min(H, y1 + m)))
        webp(c, f'{base}-{i}', q=82, largura=640)
    return len(caixas[:12])


def oceano_da_borda(a):
    # cor média da borda da foto (é o mar em volta), para o plano do oceano e o fundo do chão
    b = np.concatenate([a[:6].reshape(-1, 3), a[-6:].reshape(-1, 3), a[:, :6].reshape(-1, 3), a[:, -6:].reshape(-1, 3)])
    return np.median(b, axis=0)


PERTO_EXTRA = 0.6  # fração da altura acrescentada embaixo das nuvens perto (vista.js usa o mesmo número)


def perto_estendido():
    # o pé das nuvens perto continua para baixo: espelho da faixa de baixo, borrando aos poucos (sempre opaco)
    img = Image.open(caminho('nuvens-perto')).convert('RGBA')
    W, H = img.size
    extra = round(H * PERTO_EXTRA)
    a = np.asarray(img).astype(np.float32)
    n = min(H, extra)
    esp = a[H - n:][::-1]
    borr = np.asarray(Image.fromarray(esp.astype(np.uint8)).filter(ImageFilter.GaussianBlur(18))).astype(np.float32)
    t = np.clip(np.arange(n) / (n * 0.6), 0, 1)[:, None, None]
    ext = esp * (1 - t) + borr * t
    out = np.concatenate([a, ext], axis=0)
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))


def recortes_do_perto():
    # sem a folha de nuvens: 9 recortes tirados das nuvens perto, com as bordas cortadas esfumadas no alfa
    img = Image.open(caminho('nuvens-perto')).convert('RGBA')
    W, H = img.size
    caixas = [  # (x0, y0, x1, y1) em fração da imagem
        (0.0, 0.12, 0.26, 1.0), (0.12, 0.3, 0.4, 1.0), (0.74, 0.12, 1.0, 1.0),
        (0.56, 0.3, 0.84, 1.0), (0.36, 0.5, 0.66, 1.0), (0.04, 0.45, 0.22, 0.95),
        (0.8, 0.4, 0.98, 0.95), (0.25, 0.55, 0.47, 1.0), (0.62, 0.48, 0.8, 1.0),
    ]
    for i, (x0, y0, x1, y1) in enumerate(caixas):
        c = img.crop((round(x0 * W), round(y0 * H), round(x1 * W), round(y1 * H)))
        a = np.asarray(c).astype(np.float32)
        h, w = a.shape[:2]
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        lado = np.clip(np.minimum(xx, w - 1 - xx) / (w * 0.3), 0, 1)
        baixo = np.clip((h - 1 - yy) / (h * 0.3), 0, 1)
        cima = np.clip(yy / (h * 0.06), 0, 1)
        # borda redonda: o recorte nunca fica com cara de retângulo, mesmo tirado do meio da nuvem
        # (oval dentro do recorte, com a borda irregular puxada pela própria textura da nuvem)
        r = np.sqrt(((xx - w / 2) / (w * 0.47)) ** 2 + ((yy - h * 0.54) / (h * 0.5)) ** 2)
        lum = a[..., :3].mean(axis=2) / 255
        r = r - (lum - 0.75) * 0.35                      # o claro da nuvem empurra a borda para fora
        elipse = np.clip((1.0 - r) / 0.42, 0, 1) ** 1.2
        m = (lado * baixo * cima) ** 1.3 * elipse
        a[..., 3] *= m
        webp(Image.fromarray(a.astype(np.uint8)), f'nuvem-{i}', q=82, largura=640)


def nuvens_longe_composto():
    # faixa de nuvens ao longe montada com os recortes (o Codex não entregou a dele): pequenas, achatadas,
    # menores e mais azuladas perto do horizonte (o alto da faixa)
    rng = np.random.default_rng(11)
    W, H = 2400, 800
    tela = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    # só os recortes com contorno de nuvem (os tirados do miolo, 5 e 6, viram caixinhas quando pequenos)
    sprites = [Image.open(f'{OUT}/nuvem-{i}.webp').convert('RGBA') for i in (0, 1, 2, 3, 4, 7, 8) if os.path.exists(f'{OUT}/nuvem-{i}.webp')]
    pontos = []
    while len(pontos) < 150:
        v = rng.random() ** 1.6                      # 0 = horizonte (alto), 1 = perto (baixo)
        u = rng.random()
        if 0.445 < u < 0.555 and 0.12 < v < 0.6:      # vão no meio: a ilha aparece entre as nuvens
            continue
        pontos.append((v, u))
    for v, u in sorted(pontos):                        # de trás para a frente
        sp = sprites[int(rng.integers(len(sprites)))]
        if rng.random() > 0.5:
            sp = sp.transpose(Image.FLIP_LEFT_RIGHT)
        larg = int(W * (0.03 + 0.1 * v ** 1.1) * (0.7 + 0.6 * rng.random()))
        alt = int(larg * sp.height / sp.width * (0.45 + 0.25 * v))
        c = np.asarray(sp.resize((max(8, larg), max(6, alt)), Image.LANCZOS)).astype(np.float32)
        neblina = 0.3 * (1 - v)                        # longe: mais claro e azulado, menos contraste
        c[..., :3] = c[..., :3] * (1 - neblina) + np.array([205, 222, 238]) * neblina
        # só a nuvem densa: o véu fraco do recorte (que fica claro com a neblina) sai do alfa
        c[..., 3] = np.clip((c[..., 3] / 255 - 0.3) / 0.7, 0, 1) ** 1.1 * 255
        x = int(u * W - larg / 2)
        y = int(H * (0.1 + 0.8 * v) - alt * 0.6)
        if y >= 0:
            tela.alpha_composite(Image.fromarray(c.astype(np.uint8)), (x, y))
    # o pé da faixa some no alfa (no celular a câmera vê bem mais para baixo)
    a = np.asarray(tela).astype(np.float32)
    pe = 1 - np.clip((np.arange(H) - H * 0.62) / (H * 0.3), 0, 1) ** 1.2
    a[..., 3] *= pe[:, None]
    tela = Image.fromarray(a.astype(np.uint8))
    webp(tela, 'nuvens-longe', q=82)


CHAO_K = 2  # a imagem do chão tem o dobro da largura da foto (vista.js: CHAO_IMG)
TELA = (1792, 1008)  # a tela que vai para o Codex: a foto no meio, com metade da largura


def chao_tela(foto):
    # a foto no meio de uma tela cinza, para o Codex preencher o cinza com mar aberto (prompt em destino-ilhas-fora.prompt.txt)
    tw, th = TELA
    w = tw // CHAO_K
    h = round(foto.height * w / foto.width)
    tela = Image.new('RGB', TELA, (128, 128, 128))
    tela.paste(foto.resize((w, h), Image.LANCZOS), ((tw - w) // 2, (th - h) // 2))
    tela.save(f'{F}/destino-ilhas-tela.png')
    print(f'{F}/destino-ilhas-tela.png gerada: rode o Codex com ela e o prompt destino-ilhas-fora.prompt.txt,'
          f' salve em {F}/destino-ilhas-fora.png e rode de novo')


def chao_estendido(foto):
    W, H = foto.size
    fora = Image.open(caminho('destino-ilhas-fora')).convert('RGB').resize(TELA, Image.LANCZOS)
    k = W / (TELA[0] // CHAO_K)  # da tela para a escala da foto
    EW, EH = round(TELA[0] * k), round(TELA[1] * k)
    big = np.asarray(fora.resize((EW, EH), Image.LANCZOS)).astype(np.float32)
    a = np.asarray(foto).astype(np.float32)
    ox, oy = (EW - W) // 2, (EH - H) // 2
    # o Codex redesenha a foto um pouco fora do lugar: acha o deslocamento (até 16 px) que mais casa com o original
    g = lambda x: x.mean(-1)[::4, ::4]
    alvo = g(a)
    melhor = (1e9, 0, 0)
    for dy in range(-16, 17, 2):
        for dx in range(-16, 17, 2):
            reg = big[oy + dy:oy + dy + H, ox + dx:ox + dx + W]
            if reg.shape[:2] != (H, W):
                continue
            e = np.abs(g(reg) - alvo).mean()
            melhor = min(melhor, (e, dx, dy))
    e, dx, dy = melhor
    print(f'extensão alinhada: desloca {dx},{dy} px (diferença média {e:.1f}/255)')
    big = np.roll(big, (-dy, -dx), axis=(0, 1))
    reg = big[oy:oy + H, ox:ox + W]
    # a foto original por cima, com rampa de 110 px até a borda dela
    fy, fx = np.mgrid[0:H, 0:W].astype(np.float32)
    m = np.clip(np.minimum.reduce([fx, fy, W - 1 - fx, H - 1 - fy]) / 110, 0, 1)
    m = (m * m * (3 - 2 * m))[..., None]
    big[oy:oy + H, ox:ox + W] = a * m + reg * (1 - m)
    # a borda da imagem dissolvida no mar em superelipse (sem cantos de retângulo): de 72% do raio até a borda
    mar = np.median(np.concatenate([big[:120].reshape(-1, 3), big[-120:].reshape(-1, 3),
                                    big[:, :120].reshape(-1, 3), big[:, -120:].reshape(-1, 3)]), axis=0)
    yy, xx = np.mgrid[0:EH, 0:EW].astype(np.float32)
    r = (np.abs(xx / (EW - 1) * 2 - 1) ** 4 + np.abs(yy / (EH - 1) * 2 - 1) ** 4) ** 0.25
    d = np.clip((r - 0.72) / 0.27, 0, 1)
    d = (d * d * (3 - 2 * d))[..., None]
    out = big * (1 - d) + mar * d
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)), mar


def chao():
    foto = Image.open(caminho('destino-ilhas')).convert('RGB')
    if tem('destino-ilhas-fora'):
        out, mar = chao_estendido(foto)
        print('cor do oceano em volta:', '#%02x%02x%02x' % tuple(int(v) for v in mar), '(vista.js, voo.js e noite.js)')
        webp(out, 'destino-ilhas-chao', q=86)
        webp(nitida(foto), 'destino-ilhas', q=88, largura=2048)
        with open(f'{OUT}/oceano.txt', 'w') as f:
            f.write('#%02x%02x%02x\n' % tuple(int(v) for v in mar))
        return
    chao_tela(foto)
    W, H = foto.size
    k = 1.6
    EW, EH = round(W * k), round(H * k)
    ox, oy = (EW - W) // 2, (EH - H) // 2
    a = np.asarray(foto).astype(np.float32)
    mar = oceano_da_borda(a)
    print('cor do oceano em volta:', '#%02x%02x%02x' % tuple(int(v) for v in mar))
    # a borda da foto esticada para fora (sem espelhar ilhas), borrada e dissolvida no azul do mar
    est = np.pad(a, ((oy, EH - H - oy), (ox, EW - W - ox), (0, 0)), mode='edge')
    borr = np.asarray(Image.fromarray(est.astype(np.uint8)).filter(ImageFilter.GaussianBlur(90))).astype(np.float32)
    yy, xx = np.mgrid[0:EH, 0:EW].astype(np.float32)
    dx = np.maximum(0, np.maximum(ox - xx, xx - (ox + W - 1))) / ox
    dy = np.maximum(0, np.maximum(oy - yy, yy - (oy + H - 1))) / oy
    d = np.clip(np.maximum(dx, dy), 0, 1)[..., None]
    perto = np.clip(d * 14, 0, 1)                       # sai da foto nítida para a borrada logo na borda
    longe = np.clip((d - 0.02) / 0.2, 0, 1) ** 0.8       # e da borrada para o azul liso, logo
    out = est * (1 - perto) + borr * perto
    out = out * (1 - longe) + mar * longe
    out = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))
    # a foto entra com a borda (6%) dissolvida no mar: o retângulo dela não aparece enquanto a câmera desce
    # (o fim da descida enquadra só os 89% do meio, então o card assume sem diferença)
    fy, fx = np.mgrid[0:H, 0:W].astype(np.float32)
    bx = np.minimum(fx, W - 1 - fx) / (W * 0.06)
    by = np.minimum(fy, H - 1 - fy) / (H * 0.06)
    mascara = (np.clip(np.minimum(bx, by), 0, 1) ** 1.5 * 255).astype(np.uint8)
    out.paste(foto, (ox, oy), Image.fromarray(mascara))
    webp(out, 'destino-ilhas-chao', q=84)
    webp(nitida(foto), 'destino-ilhas', q=88, largura=2048)
    with open(f'{OUT}/oceano.txt', 'w') as f:
        f.write('#%02x%02x%02x\n' % tuple(int(v) for v in mar))


def nitida(img):
    # as fotos do Codex vêm com ~1700 px; um realce leve segura a nitidez em tela cheia
    return img.filter(ImageFilter.UnsharpMask(radius=1.4, percent=55, threshold=2))


def gravura():
    g = Image.open(caminho('rodape-gravura')).convert('L')
    a = 255 - np.asarray(g).astype(np.float32)
    a = np.clip((a - 18) * 1.25, 0, 255)
    H, W = a.shape
    creme = np.zeros((H, W, 4), np.uint8)
    creme[..., 0], creme[..., 1], creme[..., 2] = 233, 223, 207
    creme[..., 3] = a.astype(np.uint8)
    # o avião (e o rastro) no céu vira uma imagem à parte: no site ele voa no canto vazio do rodapé
    # a paisagem é o bloco contínuo de tinta que sobe do pé da imagem; o céu começa no primeiro vão vazio acima dele
    tinta = (a > 40).sum(axis=1) > 2
    terra, vao = H - 1, 0
    for y in range(H - 1, -1, -1):
        if tinta[y]:
            terra, vao = y, 0
        else:
            vao += 1
            if vao > H * 0.02:
                break
    ceu = a[: max(0, terra - int(H * 0.04))]
    # o avião é o traço mais forte do céu; o rastro é a tinta ligada a ele (os fiapos de nuvem soltos ficam)
    ys, xs = np.array([], int), np.array([], int)
    if ceu.size and ceu.max() > 60:
        solta = Image.fromarray(((ceu > 20) * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(21))
        pode = np.asarray(solta) > 0
        reg = np.zeros_like(pode)
        reg[np.unravel_index(np.argmax(ceu), ceu.shape)] = True
        while True:  # crescimento da região dentro da máscara (até parar de mudar)
            cresce = (np.asarray(Image.fromarray(reg.astype(np.uint8) * 255).filter(ImageFilter.MaxFilter(3))) > 0) & pode
            if cresce.sum() == reg.sum():
                break
            reg = cresce
        ys, xs = np.where(reg & (ceu > 20))
    aviao_w = 0
    if len(ys):
        y0, y1 = max(0, ys.min() - 10), ys.max() + 11
        x0, x1 = max(0, xs.min() - 10), min(W, xs.max() + 11)
        aviao_w = x1 - x0
        webp(Image.fromarray(creme[y0:y1, x0:x1].copy()), 'rodape-aviao', q=92)
        creme[y0:y1, x0:x1, 3] = 0
    # o céu vazio sai: sobra uma faixa de 14% da altura acima do pico mais alto (as colunas do rodapé ficam nela)
    topo = int(np.argmax((creme[..., 3] > 40).any(axis=1)))
    corte = max(0, topo - int(H * 0.14))
    creme = creme[corte:]
    webp(Image.fromarray(creme), 'rodape-gravura', q=86, largura=2400)
    # as proporções que o CSS do rodapé usa (src/sections/rodape.css)
    print(f'  rodape.css: --grav-h = 100vw * {creme.shape[0] / W:.4f}; .rodape__aviao width = 100vw * {aviao_w / W:.3f}')


if __name__ == '__main__':
    so = set(sys.argv[1:])
    quer = lambda n: not so or n in so
    if tem('vista-ilha') and quer('vista'):
        pan, h, H0 = ceu_e_ilha()
        if not tem('noite-vista') and quer('noite'):
            noite_da_panoramica(pan, h, H0)
    if tem('noite-vista') and quer('noite'):
        webp(Image.open(caminho('noite-vista')).convert('RGB'), 'noite-vista', q=86)
    for n in ('nuvens-longe', 'noite-asa'):
        if tem(n) and quer(n):
            webp(Image.open(caminho(n)).convert('RGBA'), n, q=84, largura=2048)
    if tem('nuvens-perto') and quer('nuvens-perto'):
        webp(perto_estendido(), 'nuvens-perto', q=84, largura=2048)
    if tem('nuvens-recortes') and quer('recortes'):
        print('nuvens:', recortes())
    elif tem('nuvens-perto') and quer('recortes'):
        recortes_do_perto()
    if not tem('nuvens-longe') and (quer('nuvens-longe') or quer('recortes')):
        nuvens_longe_composto()  # usa os recortes
    if tem('destino-ilhas') and quer('ilhas'):
        chao()
    for n in ('destino-serras', 'destino-neve', 'destino-deserto'):
        if tem(n) and quer(n):
            webp(nitida(Image.open(caminho(n)).convert('RGB')), n, q=86, largura=2048)
    if tem('rodape-gravura') and quer('gravura'):
        gravura()
