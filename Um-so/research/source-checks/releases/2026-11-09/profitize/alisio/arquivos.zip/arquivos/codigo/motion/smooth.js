// Lenis + ScrollTrigger num relógio só (o do GSAP). Sem Lenis com movimento reduzido.
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import { REDUZIDO } from './ease.js';

gsap.registerPlugin(ScrollTrigger);

export function criarScroll() {
  ScrollTrigger.config({ ignoreMobileResize: true });
  if (REDUZIDO) return null;
  // syncTouch: o toque também passa pelo Lenis, para o guia pôr teto na inércia (src/motion/guia.js)
  const lenis = new Lenis({ lerp: 0.1, wheelMultiplier: 1, smoothWheel: true, syncTouch: true, syncTouchLerp: 0.075 });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((t) => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);
  return lenis;
}
