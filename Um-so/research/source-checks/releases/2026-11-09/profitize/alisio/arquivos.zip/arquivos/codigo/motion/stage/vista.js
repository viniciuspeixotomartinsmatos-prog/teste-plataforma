// A vista lá fora: fotos em camadas, cada uma numa profundidade da mesma cena da janela, então o parallax é real.
// Dia: céu (z −60), mar com a ilha (z −40), nuvens longe (z −22), nuvens perto (z −6).
// Descida: recortes de nuvem de frente para a câmera, com névoa de profundidade, e a ilha vista de cima num plano
// horizontal. Noite: a mesma vista ao luar, estrelas, a ponta da asa e a luz de navegação.
import * as THREE from 'three';

const vert = /* glsl */ `
  varying vec2 vUv; varying float vDist;
  void main() {
    vUv = uv;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vDist = -mv.z;
    gl_Position = projectionMatrix * mv;
  }
`;
const frag = /* glsl */ `
  uniform sampler2D map;
  uniform float uAlfa, uNevoaIni, uNevoaFim, uNevoaForca, uPertoIni, uPertoFim, uBrilho;
  uniform vec3 uTom, uNevoa;
  uniform vec4 uRecorte;
  varying vec2 vUv; varying float vDist;
  void main() {
    vec4 t = texture2D(map, uRecorte.xy + vUv * uRecorte.zw);
    vec3 c = t.rgb * uTom * uBrilho;
    c = mix(c, uNevoa, smoothstep(uNevoaIni, uNevoaFim, vDist) * uNevoaForca);
    float a = t.a * uAlfa * smoothstep(uPertoIni, uPertoFim, vDist);
    if (a < 0.002) discard;
    gl_FragColor = vec4(c, a);
    #include <colorspace_fragment>
  }
`;

export function materialFoto(map, extra = {}) {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    uniforms: {
      map: { value: map },
      uAlfa: { value: 1 },
      uBrilho: { value: 1 },
      uTom: { value: new THREE.Color(1, 1, 1) },
      uNevoa: { value: new THREE.Color('#dbe8f0') },
      uNevoaIni: { value: 1000 },
      uNevoaFim: { value: 2000 },
      uNevoaForca: { value: 0 },
      uPertoIni: { value: -2 },
      uPertoFim: { value: -1 },
      uRecorte: { value: new THREE.Vector4(0, 0, 1, 1) },
      ...extra,
    },
    vertexShader: vert,
    fragmentShader: frag,
  });
}

function aspecto(t) {
  const i = t.image;
  return i && i.width ? i.width / i.height : 1.5;
}

function plano(tex, largura, opcoes = {}) {
  const h = opcoes.altura || largura / aspecto(tex);
  const m = new THREE.Mesh(new THREE.PlaneGeometry(largura, h), materialFoto(tex, opcoes.uniforms));
  m.userData.h = h;
  m.userData.w = largura;
  return m;
}

// gerador determinístico (a cena é igual em toda visita)
function semente(s) {
  return () => ((s = Math.imul(s ^ (s >>> 15), 1 | s), s ^= s + Math.imul(s ^ (s >>> 7), 61 | s), ((s ^ (s >>> 14)) >>> 0) / 4294967296));
}

export const CHAO = { y: -16, w: 6.4 };
export const HORIZONTE = 1.8;
// fração (de cima) onde fica o horizonte em vista-ilha.webp e noite-vista.webp (fonte/scripts/camadas.py imprime)
export const HORIZONTE_FOTO = 0.1792;
// a panorâmica tem 35 de largura útil (a ilha enche a janela do meio) + 36% de margem de cada lado
const PAN_LARGURA = 35 * 1.7201;
const ESPACO_ASA = 2.4; // a asa aparece na janela da direita
// a foto zenital (o card da ilha) tem 6,4 de largura; a imagem do chão é ela no meio do mar aberto que o Codex
// estendeu, com o dobro da largura e a borda dissolvida em superelipse na cor do mar (fonte/scripts/camadas.py, CHAO_K)
const CHAO_IMG = 2;

export function criarVista(tex, { celular = false } = {}) {
  const dia = new THREE.Group();
  const noite = new THREE.Group();
  const descida = new THREE.Group();

  // ---- dia
  // HORIZONTE: altura do horizonte da foto na profundidade da ilha (acima do centro das janelas, como na hero)
  // o céu é um degradê (64 × 1024 px): altura fixa, o pé um pouco abaixo do horizonte
  const ceu = plano(tex.ceu, 150, { altura: 46 });
  ceu.position.set(0, HORIZONTE * 1.44 - 2.5 + ceu.userData.h / 2, -60);
  const ilha = plano(tex.ilha, PAN_LARGURA);
  ilha.position.set(0, HORIZONTE - (0.5 - HORIZONTE_FOTO) * ilha.userData.h, -40);
  // nuvens longe: o alto da faixa (10% da imagem) encosta no horizonte; o vão do meio deixa a ilha aparecer
  const longe = plano(tex.longe, 34);
  longe.position.set(0, HORIZONTE * 0.6 + 0.1 * longe.userData.h - longe.userData.h / 2, -22);
  // nuvens perto: cabeças grandes nos lados (meio de baixo das janelas laterais), só o topo na do meio;
  // somem quando a câmera chega perto (a descida usa os recortes)
  // (a imagem tem 60% a mais embaixo, PERTO_EXTRA no camadas.py: o alto continua no mesmo lugar)
  const perto = plano(tex.perto, 14);
  perto.position.set(0, 0.2 - (perto.userData.h - perto.userData.h / 1.6) / 2, -6);
  perto.material.uniforms.uPertoIni.value = 1.2;
  perto.material.uniforms.uPertoFim.value = 3.4;
  dia.add(ceu, ilha, longe, perto);

  // ---- noite
  // a mesma vista à noite, no mesmo plano da ilha (o céu escuro continua atrás)
  const fundoNoite = plano(tex.ceu, 150, { altura: 46 });
  fundoNoite.position.copy(ceu.position);
  fundoNoite.material.uniforms.uTom.value.setRGB(0.012, 0.022, 0.06);
  const ceuNoite = plano(tex.noite, PAN_LARGURA);
  ceuNoite.position.copy(ilha.position);
  const pertoNoite = plano(tex.perto, 14);
  pertoNoite.position.copy(perto.position);
  pertoNoite.material.uniforms.uPertoIni.value = 1.2;
  pertoNoite.material.uniforms.uPertoFim.value = 3.4;
  pertoNoite.material.uniforms.uTom.value.set('#3b4a66');
  // a ponta da asa é opcional (public/img/noite-asa.webp): sem ela, a luz de navegação aparece sozinha
  const asa = tex.asa ? plano(tex.asa, 3.2) : null;
  const luzAsa = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 1),
    new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uForca: { value: 0 }, uCor: { value: new THREE.Color('#ff5a40') } },
      vertexShader: vert,
      fragmentShader: /* glsl */ `
        uniform float uForca; uniform vec3 uCor; varying vec2 vUv;
        void main() {
          float r = length(vUv - 0.5) * 2.0;
          float a = (exp(-r * r * 9.0) * 0.9 + exp(-r * 3.2) * 0.25) * uForca;
          gl_FragColor = vec4(uCor * a, a);
          #include <colorspace_fragment>
        }`,
    }),
  );
  // a ponta da asa (com a luz) aparece no quarto de baixo da janela da direita
  asa?.position.set(ESPACO_ASA - 0.2, -1.35, -4.2);
  luzAsa.scale.setScalar(0.42);
  luzAsa.position.set(ESPACO_ASA + 0.78, -0.62, -4.15);
  const estrelas = criarEstrelas(celular ? 160 : 260);
  noite.add(...[fundoNoite, ceuNoite, estrelas, pertoNoite, asa, luzAsa].filter(Boolean));
  noite.visible = false;

  // ---- descida: recortes de nuvem e a ilha lá embaixo
  const rnd = semente(7);
  const nuvens = [];
  const total = celular ? 14 : 20;
  const sprites = tex.nuvens; // lista de texturas
  for (let i = 0; i < total; i++) {
    const t = sprites[i % sprites.length];
    const larg = 2.6 + rnd() * 4.2;
    const m = plano(t, larg);
    // espalhadas em volta do caminho da câmera, entre y −1,6 e −10,5
    const k = i / (total - 1);
    const ang = rnd() * Math.PI * 2;
    const raio = 1.2 + rnd() * 3.8;
    const y = -1.5 - k * 9.6 - rnd() * 0.7;
    const z = -3.6 - k * 11.6 + Math.sin(ang) * raio * 0.7;
    m.position.set(Math.cos(ang) * raio, y, z);
    m.userData.giro = (rnd() - 0.5) * 0.5;
    m.userData.espelho = rnd() > 0.5 ? -1 : 1;
    const u = m.material.uniforms;
    u.uNevoa.value.set('#d6e6f1');
    u.uNevoaIni.value = 2;
    u.uNevoaFim.value = 14;
    u.uNevoaForca.value = 0.7;
    u.uPertoIni.value = 0.9;   // some antes de encostar na câmera: nada de tela branca nem borda de recorte
    u.uPertoFim.value = 3.2;
    m.material.side = THREE.DoubleSide; // o espelho (escala −1) vira o plano
    nuvens.push(m);
    descida.add(m);
  }
  // o mar em volta da foto do chão: um plano grande da cor da borda, com névoa
  const branco = new THREE.DataTexture(new Uint8Array([255, 255, 255, 255]), 1, 1);
  branco.needsUpdate = true;
  const oceano = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), materialFoto(branco));
  oceano.rotation.x = -Math.PI / 2;
  oceano.position.set(0, CHAO.y - 0.02, -60);
  // fundo: não escreve profundidade (senão corta a panorâmica vertical na linha do mar)
  oceano.material.transparent = false;
  oceano.material.depthWrite = false;
  oceano.material.uniforms.uTom.value.set('#024983');
  oceano.renderOrder = -2;
  descida.add(oceano);
  const chao = plano(tex.chao, CHAO.w * CHAO_IMG);
  chao.rotation.x = -Math.PI / 2;
  chao.position.set(0, CHAO.y, 0);
  chao.material.depthWrite = true;
  chao.material.transparent = false;
  chao.renderOrder = -1;
  descida.add(chao);

  return { dia, noite, descida, oceano, ceu, ilha, longe, perto, fundoNoite, ceuNoite, pertoNoite, asa, luzAsa, estrelas, nuvens, chao };
}

function criarEstrelas(n) {
  const rnd = semente(21);
  const pos = new Float32Array(n * 3);
  const tam = new Float32Array(n);
  const fase = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    pos[i * 3] = (rnd() - 0.5) * 70;
    pos[i * 3 + 1] = HORIZONTE + 0.8 + rnd() ** 0.8 * 14;
    pos[i * 3 + 2] = -39.5;
    tam[i] = 0.6 + rnd() ** 3 * 2.2;
    fase[i] = rnd() * 6.28;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('tam', new THREE.BufferAttribute(tam, 1));
  g.setAttribute('fase', new THREE.BufferAttribute(fase, 1));
  const m = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: { uT: { value: 0 }, uAlfa: { value: 1 }, uDpr: { value: 1 } },
    vertexShader: /* glsl */ `
      attribute float tam, fase; uniform float uT, uDpr; varying float vA;
      void main() {
        vA = 0.55 + 0.45 * sin(uT * 1.3 + fase);
        gl_PointSize = tam * uDpr;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: /* glsl */ `
      uniform float uAlfa; varying float vA;
      void main() {
        float r = length(gl_PointCoord - 0.5) * 2.0;
        float a = smoothstep(1.0, 0.2, r) * vA * uAlfa;
        gl_FragColor = vec4(vec3(0.85, 0.9, 1.0) * a, a);
      }`,
  });
  return new THREE.Points(g, m);
}
