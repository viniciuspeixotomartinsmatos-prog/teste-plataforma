// 6a · Noite: o cartão sobe com o scroll e atrás dele está o mar escuro. A câmera sobe do mar pelas nuvens ao luar
// (o espelho da descida), levanta até o horizonte com estrelas e volta de ré pela janela do meio para a cabine.
import { caminho, alturaCobre, faixa, orbita, aplicar } from '../stage/rig.js';
import { CHAO } from '../stage/vista.js';
import { Z_CHAO } from './voo.js';

export function cenaNoite(ctx) {
  const bilhete = document.querySelector('.bilhete');
  let fogeBilhete = 0;

  function quadros() {
    const { cab, heroi, celular } = ctx;
    const L = heroi.L;
    const r = cab.vista.chao.userData.w / cab.vista.chao.userData.h;
    const h = alturaCobre(cab.rig.fov, ctx.tam.w / ctx.tam.h, CHAO.w, r) * 1.35;
    return [
      { p: 0.0, pos: [0, CHAO.y + h, Z_CHAO], pitch: -90, lente: 0 },
      { p: 0.2, pos: [0, -8.2, -14.2], pitch: -80, lente: 0 },
      { p: 0.4, pos: [0, -3.4, -8.6], pitch: -44, lente: 0 },
      { p: 0.56, pos: [0, -0.5, -3.4], pitch: -6, lente: 0 },
      { p: 0.66, pos: [0, -0.06, -1.2], pitch: -0.5, lente: 0 },
      { p: 0.74, pos: [0, -0.01, 0.2], pitch: 0, lente: 0 },
      { p: 0.86, pos: [0, 0, celular ? 1.7 : 1.4], pitch: 0, lente: 0.25 },
      { p: 1.0, pos: [0, 0, L], pitch: 0, lente: 1 },
    ];
  }

  return {
    id: 'noite',
    telas: ctx.celular ? 2.2 : 2.4,
    camada: null,
    set: 'cabine',

    atualizar(p, dt, ativa) {
      // o cartão sai para cima junto com o scroll (é a página rolando)
      const f = faixa(p, 0, 0.3);
      if (f !== fogeBilhete) {
        fogeBilhete = f;
        // sobe o bastante para o canhoto (que caiu abaixo do cartão) sair junto
        bilhete.style.transform = f > 0 ? `translate3d(0, ${-f * ctx.tam.h * 1.42}px, 0)` : '';
      }
      if (!ativa) return;
      const { cab, heroi } = ctx;
      if (ctx.reduzido) p = p < 0.7 ? 0.62 : 1;
      const k = caminho(quadros(), p);
      const amp = faixa(p, 0.9, 1);
      aplicar(cab, k, orbita(ctx.mouse, ctx.t, heroi.L, ctx.reduzido), amp, k.lente, heroi);

      cab.estado.noite = 1;
      cab.estado.rasa = 1;
      cab.estado.vidro = faixa(p, 0.76, 0.86);
      cab.janelas.forEach((j) => { if (!j._fecho) j.abre = 1; });
      const graus = -k.pitch * 57.3;
      const v = cab.vista;
      v.dia.visible = false;
      v.noite.visible = graus < 70;
      const nA = 1 - faixa(graus, 40, 66);
      for (const m of [v.fundoNoite, v.ceuNoite, v.pertoNoite, v.asa].filter(Boolean)) m.material.uniforms.uAlfa.value = nA;
      v.estrelas.material.uniforms.uAlfa.value = nA;
      // o mar escuro acende devagar (vem do escuro do cartão) e as nuvens ao luar passam
      v.descida.visible = p < 0.62;
      v.chao.position.z = Z_CHAO;
      const luz = faixa(p, 0.02, 0.24);
      for (const m of [v.chao, v.oceano]) {
        const u = m.material.uniforms;
        u.uBrilho.value = 0.55 * luz;
        u.uNevoa.value.set('#0d1626');
        u.uNevoaIni.value = 2;
        u.uNevoaFim.value = 18;
        u.uNevoaForca.value = 0.85;
      }
      // o mar em volta tem a mesma cor da borda da foto, com o mesmo tom de noite (sem retângulo aparecendo)
      v.chao.material.uniforms.uTom.value.setRGB(0.2, 0.27, 0.42);
      v.oceano.material.uniforms.uTom.value.set('#024983').multiply(v.chao.material.uniforms.uTom.value);
      for (const n of v.nuvens) {
        n.material.uniforms.uAlfa.value = faixa(p, 0.06, 0.18) * (1 - faixa(p, 0.5, 0.6));
        n.material.uniforms.uTom.value.setRGB(0.42, 0.5, 0.68);
        n.material.uniforms.uNevoa.value.set('#0d1626');
      }
    },
  };
}
