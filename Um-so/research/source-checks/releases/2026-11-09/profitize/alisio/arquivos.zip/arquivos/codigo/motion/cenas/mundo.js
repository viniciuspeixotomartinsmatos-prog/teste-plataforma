// 4 · Mundo: a câmera recua. Presa ao scroll, a pilha de cards encolhe junta até ficar pequena no meio do globo, e
// dali os cards saem cada um para o seu ponto, quase juntos, do fundo para a frente (a ilha primeiro), e somem nele. O globo aparece de perto e se afasta até caber na tela no mesmo trecho, com a palavra "Mundo" atrás. Depois, um marco por rota: o
// arco sai de "Você" e se desenha até o destino, a ponta acende e o rótulo do tipo aparece. O globo gira com o scroll.
import gsap from 'gsap';
import { linhas, pecas } from '../split.js';
import { faixa } from '../stage/rig.js';
import { REDUZIDO } from '../ease.js';

const rad = (g) => (g * Math.PI) / 180;
const io = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const suave = (t) => t * t * (3 - 2 * t);

export function cenaMundo(ctx, destinos) {
  const el = document.querySelector('.mundo');
  const palavra = document.querySelector('.palco__palavra');
  const esq = linhas(el.querySelector('.mundo__esq'));
  const dir = linhas(el.querySelector('.mundo__dir'));
  const cta = pecas([el.querySelector('.mundo__cta')]);
  const rotulos = [...el.querySelectorAll('.rotulo')];
  const st = { voo: 0, textos: false, palavra: 0 };
  // trecho do voo dos cards (em telas) antes do globo assentar; o resto segue o ritmo de antes
  const TV = ctx.celular ? 1.3 : 1.5;
  const telas = TV + (ctx.celular ? 2.8 : 3);
  const fr = (t) => t / telas;
  const VOO = [fr(0.3), fr(TV)]; // os textos do card saem no marco 1 (0,02 tela) e levam 0,42 s: o voo espera

  // onde o globo fica na tela: centro e raio em px
  function lugar() {
    const { w, h } = ctx.tam;
    if (ctx.celular) {
      // o globo assenta acima dos dois textos de baixo (o de cima começa ~184 px acima do pé da parte visível) e
      // sobe no máximo até o meio de "Mundo" (nav 68 + 4vh + metade da palavra de 31vw): "Você" e as rotas nunca
      // passam por trás do texto
      const base = Math.min(h, innerHeight) - 200;
      const topo = 68 + h * 0.04 + w * 0.13;
      const r = Math.min(w * 0.46, (base - topo) / 2);
      return { cx: w * 0.5, cy: base - r, r };
    }
    return { cx: w * 0.5, cy: h * 0.62, r: Math.min(h * 0.37, w * 0.25) };
  }

  // o voo dos cards em duas fases (frações do voo):
  // 1) JUNTA: a pilha encolhe e se abre numa fileira de cards pequenos sobre o globo (2 × 2 no celular), cada um no
  //    seu lugar, lado a lado; os de trás saem de trás do da frente e clareiam. O globo aparece e assenta em volta;
  // 2) SAI: da fileira, cada card vai para o seu ponto, quase juntos, do fundo da pilha para a frente (a ilha
  //    primeiro) e some nele. Pequenos e lado a lado, nenhum cobre o globo nem os outros.
  const JUNTA = [0, 0.42];
  const SAI = 0.36, PASSO = 0.1, DUR = 0.34;
  // a fileira: largura de cada card (fração do quadro) e o lugar do card i
  function fileira(i, q, L) {
    if (ctx.celular) {
      const w = q.w * 0.28, h = w * (q.h / q.w), g = w * 0.1;
      return { x: L.cx + (i % 2 - 0.5) * (w + g), y: L.cy + (Math.floor(i / 2) - 0.5) * (h + g), w, h };
    }
    const w = q.w * 0.17, g = w * 0.12;
    return { x: L.cx + (i - 1.5) * (w + g), y: L.cy - L.r * 0.08, w, h: w * (q.h / q.w) };
  }
  const lerp = (a, b, t) => a + (b - a) * t;
  function pintarCards() {
    const q = destinos.st.quadro;
    if (!q) return;
    const n = destinos.st.ativo + 1; // os de baixo da pilha ainda não subiram: ficam fora
    const L = lugar();
    const junta = suave(faixa(st.voo, JUNTA[0], JUNTA[1]));
    const kQ = Math.max(q.w / q.W, q.h / q.H);
    const folga = (q.H * kQ - q.h) / 2;
    // retângulos: o quadro, o lugar na fileira e o ponto
    const R0 = { x: q.l + q.w / 2, y: q.t + q.h / 2, w: q.w, h: q.h };
    const s = 16; // tamanho do card quando vira ponto
    destinos.cards.forEach((c) => {
      const fc = c.i >= n ? 1 : suave(faixa(st.voo, SAI + c.i * PASSO, SAI + c.i * PASSO + DUR));
      const vivo = c.i < n && fc < 0.999;
      c.card.classList.toggle('is-vivo', vivo);
      if (!vivo) return;
      const p = ctx.rotas.ponto(c.i) || [L.cx, L.cy];
      const Rm = fileira(c.i, q, L);
      const A = { x: lerp(R0.x, Rm.x, junta), y: lerp(R0.y, Rm.y, junta), w: lerp(R0.w, Rm.w, junta), h: lerp(R0.h, Rm.h, junta) };
      const R = { x: lerp(A.x, p[0], fc), y: lerp(A.y, p[1], fc), w: lerp(A.w, s, fc), h: lerp(A.h, s, fc) };
      // o recuo da pilha (o mesmo de destinos.pintar: 5% menor e 7 px acima por card na frente), desfeito ao abrir a fileira
      const atras = n - 1 - c.i;
      const a2 = Math.min(atras, 2) * (1 - junta);
      const esc = R.w / q.w;
      const top0 = R.y - R.h / 2;
      R.w *= 1 - 0.05 * a2; R.h *= 1 - 0.05 * a2;
      R.y = top0 + R.h / 2 - 7 * a2 * Math.max(esc, 0.4);
      const raio = lerp(destinos.st.raio * Math.max(esc, 0.45), s / 2, fc);
      c.card.style.clipPath = `inset(${R.y - R.h / 2}px ${q.W - R.x - R.w / 2}px ${q.H - R.y - R.h / 2}px ${R.x - R.w / 2}px round ${raio}px)`;
      c.card.style.transform = 'none';
      c.card.style.visibility = '';
      const e = Math.min(0.78, atras <= 1 ? 0.56 * atras : 0.56 + 0.16 * (atras - 1));
      c.esc.style.opacity = (e * (1 - junta)).toFixed(3);
      c.card.style.opacity = (1 - faixa(fc, 0.8, 1)).toFixed(3);
      // a foto acompanha o retângulo com o mesmo recorte (e a deriva em que a pilha deixou: -0,5)
      const k = kQ * (R.w / q.w);
      const cy = R.y - q.H / 2 - 0.4 * folga * (R.w / q.w);
      c.img.style.transform = `translate(-50%, -50%) translate3d(${R.x - q.W / 2}px, ${cy}px, 0) scale(${k})`;
    });
  }

  // devolve os cards à pilha (opacidade que o voo mexeu)
  function soltarCards() {
    destinos.cards.forEach((c) => { c.card.style.opacity = ''; });
  }

  function textos(entrar) {
    if (entrar === st.textos) return;
    st.textos = entrar;
    if (entrar) { esq.entrar(0); dir.entrar(0.1); cta.entrar(0.2); }
    else { esq.sair(); dir.sair(); cta.sair(); }
  }

  function rota(i, desenhar, pulo) {
    const r = ctx.rotas.rotas[i];
    gsap.killTweensOf(r);
    if (pulo || REDUZIDO) { r.prog = desenhar ? 1 : 0; r.luz = desenhar ? 1 : 0; return; }
    if (desenhar) {
      gsap.to(r, { prog: 1, duration: 1.25, ease: 'al-io' });
      gsap.to(r, { luz: 1, duration: 0.6, ease: 'al-out', delay: 1.05 });
    } else {
      gsap.to(r, { prog: 0, duration: 0.55, ease: 'al-in' });
      gsap.to(r, { luz: 0, duration: 0.3 });
    }
  }

  return {
    id: 'mundo',
    telas,
    // 1: os textos do card saem (o voo começa logo depois, preso ao scroll); 2: textos do mundo; 3–6: uma rota cada
    marcos: [fr(0.02), fr(TV + 0.1), fr(TV + 0.5), fr(TV + 0.95), fr(TV + 1.4), fr(TV + 1.85)],
    alvo: fr(TV + 2.3), // link da nav: todas as rotas desenhadas
    camada: el,
    vis: [0, 1.25],
    set: 'globo',
    st,

    passo(i, antes, pulo) {
      if (i >= 1 && antes < 1) destinos.sairTextos();
      else if (i < 1 && antes >= 1 && destinos.st.livre) destinos.voltarTextos();
      textos(i >= 2);
      const casa = ctx.rotas.casa;
      gsap.to(casa, { prog: i >= 2 ? 1 : 0, duration: pulo ? 0 : 0.6 });
      for (let k = 0; k < 4; k++) {
        const quer = i >= 3 + k;
        const tem = antes >= 3 + k;
        if (quer !== tem || pulo) rota(k, quer, pulo);
      }
    },

    sairTextos() { textos(false); },
    voltarTextos() { textos(this.i >= 2); },

    rotulos: () => rotulos,

    // a câmera do globo no fim do mundo (o cartão desenrola a partir dela)
    camFinal() {
      const glo = ctx.glo;
      const L = lugar();
      glo.estado.D = glo.distancia(L.r, ctx.tam.h);
      glo.estado.sx = 0;
      glo.estado.sy = 1 - (L.cy / ctx.tam.h) * 2;
      glo.estado.rot = rad(-20);
      glo.estado.tilt = rad(9);
    },

    atualizar(p, dt, ativa) {
      const glo = ctx.glo;
      // o voo dos cards preso ao scroll; os cards são DOM: pintar mesmo quando a cena ainda não é a "ativa"
      const voo = REDUZIDO ? (p >= VOO[0] ? 1 : 0) : faixa(p, VOO[0], VOO[1]);
      const livre = voo <= 0;
      if (livre !== destinos.st.livre) {
        destinos.st.livre = livre;
        if (livre) { soltarCards(); destinos.atualizar(1); if (this.i < 1) destinos.voltarTextos(); }
      }
      st.voo = voo;
      if (!livre) pintarCards();
      if (!ativa) return;
      const { h } = ctx.tam;
      const L = lugar();
      const longe = glo.distancia(L.r, h);
      // recuo da câmera: de perto da superfície até o globo caber
      const perto = 1.32;
      const rec = io(faixa(st.voo, 0, 0.5)); // assenta antes de os cards saírem da pilha pequena
      glo.estado.D = perto + (longe - perto) * rec;
      glo.estado.sx = 0;
      glo.estado.sy = 1 - (L.cy / h) * 2;
      glo.estado.rot = rad(REDUZIDO ? -20 : -50 + 30 * faixa(p, VOO[1] * 0.4, 1));
      glo.estado.tilt = rad(9);
      glo.estado.flat = 0;
      glo.estado.alfa = 1;
      ctx.rotasEstado = { flat: 0, rect: { x: 0, y: 0, w: 1, h: 1 }, lon0: -20, alfa: 1 };
      // a palavra "Mundo" aparece com o recuo
      st.palavra = rec;
      palavra.style.opacity = rec;
      // rótulos presos aos pontos
      ctx.rotulosMundo(rotulos, 0);
    },
  };
}
