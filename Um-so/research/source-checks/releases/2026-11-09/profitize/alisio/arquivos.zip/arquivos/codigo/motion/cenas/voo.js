// 2 · Pela janela: a câmera avança para a janela do meio, a moldura passa rente às bordas da tela, o vidro some e a
// câmera atravessa a abertura. Lá fora a vista se abre inteira; depois a câmera inclina para baixo e desce pelos
// recortes de nuvem até a ilha em foto zenital, que termina ocupando a tela inteira (é a foto do primeiro card).
import gsap from 'gsap';
import { linhas } from '../split.js';
import { caminho, alturaCobre, faixa, orbita, aplicar } from '../stage/rig.js';
import { CHAO } from '../stage/vista.js';
import { alturasDeDia } from './abertura.js';

export const Z_CHAO = -16;
export const CHAO_MEIO = 0.89;

export function cenaVoo(ctx) {
  const el = document.querySelector('.voo');
  const titulo = linhas(el.querySelector('.voo__titulo'));
  const texto = linhas(el.querySelector('.voo__texto'));

  function quadros() {
    const { cab, heroi, celular } = ctx;
    const L = heroi.L;
    const r = cab.vista.chao.userData.w / cab.vista.chao.userData.h;
    // a descida termina enquadrando os 89% do meio da foto (a borda dela se dissolve no mar)
    const h = alturaCobre(cab.rig.fov, ctx.tam.w / ctx.tam.h, CHAO.w * CHAO_MEIO, r);
    const yFim = CHAO.y + h;
    return [
      { p: 0.0, pos: [0, 0, L], pitch: 0, lente: 1 },
      { p: 0.15, pos: [0, 0, L * 0.5 + 0.6], pitch: 0, lente: 0.62 },
      { p: 0.28, pos: [0, 0, celular ? 1.25 : 0.95], pitch: 0, lente: 0.08 },
      { p: 0.35, pos: [0, -0.03, -0.32], pitch: -0.5, lente: 0 },
      { p: 0.46, pos: [0, -0.14, -2.3], pitch: -3, lente: 0 },
      { p: 0.6, pos: [0, -1.3, -5.6], pitch: -24, lente: 0 },
      { p: 0.73, pos: [0, -3.9, -9.6], pitch: -48, lente: 0 },
      { p: 0.87, pos: [0, -7.2, -13.7], pitch: -76, lente: 0 },
      { p: 1.0, pos: [0, yFim, Z_CHAO], pitch: -90, lente: 0 },
    ];
  }

  return {
    id: 'voo',
    telas: ctx.celular ? 3.2 : 3.6,
    marcos: [0.44, 0.585],
    camada: el,
    vis: [0.3, 0.75],
    set: 'cabine',

    passo(i) {
      if (i === 1) { titulo.entrar(0); texto.entrar(0.16); }
      else { titulo.sair(); texto.sair(); }
      gsap.to(el, { '--veu': i === 1 ? 1 : 0, duration: i === 1 ? 0.9 : 0.5, ease: i === 1 ? 'al-out' : 'al-in' });
    },

    atualizar(p, dt, ativa) {
      if (!ativa) return;
      const { cab, heroi } = ctx;
      // movimento reduzido: a câmera troca por corte entre três estados (janelas, lá fora, a ilha de cima)
      if (ctx.reduzido) p = p < 0.4 ? 0 : p < 0.86 ? 0.47 : 1;
      const k = caminho(quadros(), p);
      // o giro do mouse some no começo da aproximação
      const amp = 1 - faixa(p, 0, 0.12);
      aplicar(cab, k, orbita(ctx.mouse, ctx.t, heroi.L, ctx.reduzido), amp, k.lente, heroi);

      cab.estado.noite = 0;
      cab.estado.vidro = 1 - faixa(p, 0.2, 0.3);
      if (p < 0.36) alturasDeDia(cab, dt);
      const graus = -k.pitch * 57.3;
      const v = cab.vista;
      v.dia.visible = graus < 62;
      v.noite.visible = false;
      const diaA = 1 - faixa(graus, 30, 58);
      for (const m of [v.ceu, v.ilha, v.longe, v.perto]) m.material.uniforms.uAlfa.value = diaA;
      // descida: nuvens e a ilha lá embaixo, com névoa que abre perto do fim
      v.descida.visible = p > 0.18; // o mar de fundo já existe quando a câmera chega na janela (no celular ela vê mais para baixo)
      v.chao.position.z = Z_CHAO;
      const nuv = faixa(p, 0.38, 0.5);
      const fim = faixa(p, 0.9, 0.985);
      for (const n of v.nuvens) {
        n.material.uniforms.uAlfa.value = nuv * (1 - fim);
        n.material.uniforms.uTom.value.setRGB(1, 1, 1);
        n.material.uniforms.uNevoa.value.set('#9fc1dc');
      }
      for (const m of [v.chao, v.oceano]) {
        const u = m.material.uniforms;
        u.uBrilho.value = 1;
        u.uNevoa.value.set('#86aed0');
        u.uNevoaIni.value = 5;
        u.uNevoaFim.value = 30;
        u.uNevoaForca.value = (1 - faixa(p, 0.8, 0.975)) * 0.82; // o chão e o mar em volta clareiam juntos
        u.uAlfa.value = 1;
      }
      v.chao.material.uniforms.uTom.value.setRGB(1, 1, 1);
      v.oceano.material.uniforms.uTom.value.set('#024983'); // cor da borda da foto (public/img/oceano.txt)
    },
  };
}
