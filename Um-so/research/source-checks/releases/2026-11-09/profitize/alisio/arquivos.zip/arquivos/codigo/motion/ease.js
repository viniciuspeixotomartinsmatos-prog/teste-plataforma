// Curvas da marca (as mesmas das variáveis CSS em tokens.css)
import gsap from 'gsap';
import { CustomEase } from 'gsap/CustomEase';

gsap.registerPlugin(CustomEase);

CustomEase.create('al-out', '0.16, 1, 0.3, 1');
CustomEase.create('al-in', '0.7, 0, 0.84, 0');
CustomEase.create('al-io', '0.86, 0, 0.07, 1');
// persiana: sobe, passa um pouco do ponto e assenta, como a de verdade
CustomEase.create('al-quique', 'M0,0 C0.22,0 0.36,1.055 0.56,1.055 0.7,1.055 0.75,0.988 0.84,0.988 0.91,0.988 0.94,1 1,1');
// persiana descendo: desce firme e assenta sem quicar
CustomEase.create('al-desce', 'M0,0 C0.3,0 0.38,0.92 0.62,0.99 0.78,1.012 0.88,1 1,1');

export const REDUZIDO = matchMedia('(prefers-reduced-motion: reduce)').matches;
