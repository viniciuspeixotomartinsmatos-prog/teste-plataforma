// A parede da cabine: um plano com três furos e um shader próprio. A luz de cada janela esquenta a parede em volta,
// na proporção em que a persiana dela abre; uma fresta escura marca o encontro com a moldura. À noite, a luz das
// janelas fica fria e fraca e uma luz quente de cabine vem de cima.
import * as THREE from 'three';
import { CONTORNO, caminho } from './janela.js';

export function criarParede({ centros, largura = 60, altura = 40 }) {
  const forma = new THREE.Shape();
  forma.moveTo(-largura / 2, -altura / 2);
  forma.lineTo(largura / 2, -altura / 2);
  forma.lineTo(largura / 2, altura / 2);
  forma.lineTo(-largura / 2, altura / 2);
  forma.closePath();
  // o furo fica um pouco para dentro do contorno: a moldura cobre a emenda
  for (const [cx, cy] of centros) forma.holes.push(caminho(CONTORNO, cx, cy, 0.02));
  const geo = new THREE.ShapeGeometry(forma, 24);

  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uBase: { value: new THREE.Color('#1b1714') },
      uQuente: { value: new THREE.Color('#5a4433') },
      uFria: { value: new THREE.Color('#22324d') },
      uCabine: { value: new THREE.Color('#3a2a1e') },
      uJan: { value: centros.map(([x, y]) => new THREE.Vector4(x, y, CONTORNO.a, CONTORNO.b)) },
      uLuz: { value: new THREE.Vector3(0, 0, 0) },
      uN: { value: CONTORNO.n },
      uNoite: { value: 0 },
      uTopo: { value: 3.2 },   // altura (y) do alto da tela, para a luz de cabine
      uRasa: { value: 0 },     // brilho geral (baixo na cabine escura da abertura)
    },
    vertexShader: /* glsl */ `
      varying vec2 vP;
      void main() { vP = position.xy; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uBase, uQuente, uFria, uCabine;
      uniform vec4 uJan[3];
      uniform vec3 uLuz;
      uniform float uN, uNoite, uTopo, uRasa;
      varying vec2 vP;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float se(vec2 p, vec4 j) {
        vec2 q = abs((p - j.xy) / j.zw);
        return pow(pow(q.x, uN) + pow(q.y, uN), 1.0 / uN);
      }
      void main() {
        float luz = 0.0, ao = 1.0, fenda = 1.0;
        for (int i = 0; i < 3; i++) {
          float d = max(se(vP, uJan[i]) - 1.0, 0.0);
          float L = i == 0 ? uLuz.x : (i == 1 ? uLuz.y : uLuz.z);
          // halo largo + halo curto colado na moldura
          luz += L * (0.62 * exp(-d * 2.4) + 0.5 * exp(-d * 8.0));
          ao *= 1.0 - 0.5 * exp(-d * 30.0);
          fenda *= 1.0 - 0.7 * exp(-d * 260.0);
        }
        vec3 brilho = mix(uQuente, uFria, uNoite);
        float base = mix(0.86, 1.0, smoothstep(-6.0, 1.0, vP.y)) * (1.0 - 0.25 * smoothstep(1.5, 5.0, abs(vP.x)));
        vec3 c = uBase * base * mix(0.55, 1.0, uRasa);
        c += brilho * luz * mix(1.0, 0.55, uNoite) * ao;
        // noite: luz quente de cabine que desce do alto
        c += uCabine * uNoite * smoothstep(-2.2, uTopo, vP.y) * 0.9;
        c *= fenda;
        c += (hash(floor(gl_FragCoord.xy)) - 0.5) * 0.008;
        gl_FragColor = vec4(c, 1.0);
        #include <colorspace_fragment>
      }
    `,
  });

  const mesh = new THREE.Mesh(geo, mat);
  return { mesh, mat };
}
