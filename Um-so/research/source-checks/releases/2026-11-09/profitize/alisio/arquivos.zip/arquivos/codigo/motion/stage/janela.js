// A janela do avião: moldura, persiana e vidro.
// A moldura é um perfil varrido entre dois contornos (o de fora, que encosta na parede, e a abertura): almofada que
// sai da parede, funil que desce até o vidro e um lábio fino em volta da vista. É o "chanfro" que a câmera vê rente
// quando atravessa a janela do meio. A oclusão fica assada nas cores dos vértices.
import * as THREE from 'three';

// medidas em unidades da cena: a abertura tem 1 de largura
export const ABERTURA = { a: 0.5, b: 0.685, n: 2.8 };
export const CONTORNO = { a: 0.74, b: 0.965, n: 3.3 };
export const FUNDO = -0.282; // profundidade do vidro (o forro desce até ele: a faixa clara em volta da vista)
export const PERSIANA_Z = -0.24;

// ponto da superelipse |x/a|^n + |y/b|^n = 1 no parâmetro t
export function superelipse({ a, b, n }, t) {
  const c = Math.cos(t), s = Math.sin(t);
  return [a * Math.sign(c) * Math.abs(c) ** (2 / n), b * Math.sign(s) * Math.abs(s) ** (2 / n)];
}

// perfil: [mistura do contorno de fora (0) até a abertura (1), profundidade z, oclusão, peça (0 almofada, 1 forro)]
// Duas peças como na hero: a almofada de fora (bege mais escuro, de frente para a cabine) e o forro de dentro (mais
// claro, de frente para a luz da janela), separados por um vinco sombreado.
const PERFIL = [
  [0.0, 0.0, 0.34, 0],
  [0.012, 0.022, 0.55, 0],
  [0.04, 0.05, 0.8, 0],
  [0.09, 0.07, 0.95, 0],
  [0.16, 0.078, 1.0, 0],
  [0.25, 0.07, 1.0, 0.05],
  [0.34, 0.046, 0.96, 0.2],
  [0.43, 0.008, 0.9, 0.5],
  [0.52, -0.038, 0.88, 0.8],
  [0.61, -0.084, 0.93, 1],
  [0.71, -0.13, 0.98, 1],
  [0.8, -0.172, 1.0, 1],
  [0.88, -0.2, 1.0, 1],
  [0.93, -0.212, 0.95, 1],
  [0.955, -0.21, 1.0, 1],
  [0.975, -0.2, 1.0, 1],
  [0.99, -0.206, 0.92, 1],
  [1.0, -0.226, 0.82, 1],
  [1.0, FUNDO - 0.01, 0.55, 1],
];

// reamostra o perfil com Catmull-Rom (mantém os pontos-chave; o lábio fica fino)
function amostrar(perfil, passos = 5) {
  const out = [];
  for (let i = 0; i < perfil.length - 1; i++) {
    const p0 = perfil[Math.max(0, i - 1)], p1 = perfil[i], p2 = perfil[i + 1], p3 = perfil[Math.min(perfil.length - 1, i + 2)];
    const n = i >= perfil.length - 6 ? 2 : passos; // o lábio não precisa de tantos
    for (let k = 0; k < n; k++) {
      const t = k / n, t2 = t * t, t3 = t2 * t;
      const cr = (a, b, c, d) => 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      out.push([cr(p0[0], p1[0], p2[0], p3[0]), cr(p0[1], p1[1], p2[1], p3[1]), cr(p0[2], p1[2], p2[2], p3[2]), p1[3] + (p2[3] - p1[3]) * t]);
    }
  }
  out.push(perfil[perfil.length - 1]);
  return out;
}

export function geometriaMoldura(segmentos = 240) {
  const P = amostrar(PERFIL);
  const M = P.length, N = segmentos;
  const pos = new Float32Array(N * M * 3);
  const cor = new Float32Array(N * M * 3);
  const uv = new Float32Array(N * M * 2);
  for (let i = 0; i < N; i++) {
    const t = (i / N) * Math.PI * 2;
    const [xo, yo] = superelipse(CONTORNO, t);
    const [xi, yi] = superelipse(ABERTURA, t);
    const alto = THREE.MathUtils.smoothstep(Math.sin(t), 0.15, 0.85); // a caixa da persiana sombreia o alto do funil
    for (let j = 0; j < M; j++) {
      const [w, z, ao, peca] = P[j];
      const k = (i * M + j) * 3;
      pos[k] = xo + (xi - xo) * w;
      pos[k + 1] = yo + (yi - yo) * w;
      pos[k + 2] = z;
      const forro = THREE.MathUtils.smoothstep(w, 0.45, 0.6) * (1 - THREE.MathUtils.smoothstep(w, 0.97, 1));
      // a almofada escurece para fora (a luz vem da janela); o alto do forro fica na sombra da caixa da persiana
      const fora = 0.6 + 0.4 * THREE.MathUtils.smoothstep(w, 0.02, 0.42);
      const caixa = alto * forro * (0.5 + 0.5 * THREE.MathUtils.smoothstep(Math.abs(Math.cos(t)), 0.9, 0.2));
      const o = ao * (peca > 0.5 ? 1 : fora) * (1 - 0.72 * caixa);
      // almofada um pouco mais escura e quente que o forro
      cor[k] = o * (0.64 + 0.24 * peca);
      cor[k + 1] = o * (0.605 + 0.255 * peca);
      cor[k + 2] = o * (0.56 + 0.27 * peca);
      uv[(i * M + j) * 2] = i / N;
      uv[(i * M + j) * 2 + 1] = j / (M - 1);
    }
  }
  const idx = [];
  for (let i = 0; i < N; i++) {
    const i2 = (i + 1) % N;
    for (let j = 0; j < M - 1; j++) {
      const a = i * M + j, b = i2 * M + j, c = i2 * M + j + 1, d = i * M + j + 1;
      idx.push(a, b, d, b, c, d); // frente para +z (a câmera)
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(cor, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

// contorno como THREE.Path (para o furo na parede)
export function caminho(forma, cx, cy, inset = 0, n = 160) {
  const p = new THREE.Path();
  for (let i = 0; i <= n; i++) {
    const [x, y] = superelipse({ a: forma.a - inset, b: forma.b - inset, n: forma.n }, (i / n) * Math.PI * 2);
    i ? p.lineTo(cx + x, cy + y) : p.moveTo(cx + x, cy + y);
  }
  return p;
}

export function materialMoldura(envMap) {
  return new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#efe9e1'),
    vertexColors: true,
    roughness: 0.4,
    metalness: 0,
    clearcoat: 0.4,
    clearcoatRoughness: 0.24,
    envMap,
    envMapIntensity: 0.6,
  });
}

// persiana: um plano com o lábio no pé, a sombra da caixa no alto e a luz que atravessa quando está fechada
export const PERSIANA = { w: 1.08, h: 1.46 };

export function materialPersiana() {
  return new THREE.ShaderMaterial({
    uniforms: {
      uCor: { value: new THREE.Color('#cbc1b2') },
      uLuz: { value: 1 },       // luz que chega do lado de dentro (cabine + reflexo da vista)
      uFundo: { value: 0 },     // sol atravessando o plástico (dia, persiana fechada)
      uFrio: { value: 0 },      // 0 dia, 1 noite
      uH: { value: PERSIANA.h },
    },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uCor; uniform float uLuz, uFundo, uFrio, uH;
      varying vec2 vUv;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
      void main() {
        float y = vUv.y * uH;                       // 0 no pé
        float grad = mix(1.04, 0.62, smoothstep(0.02, 0.75, y));
        float lado = 1.0 - 0.1 * pow(abs(vUv.x - 0.5) * 2.0, 2.0);
        vec3 c = uCor * grad * lado;
        // lábio do pé: faixa mais clara, fio de luz em cima, sombra embaixo
        float labio = 1.0 - smoothstep(0.036, 0.042, y);
        c *= mix(1.0, 1.1, labio);
        c += vec3(0.18, 0.16, 0.13) * exp(-pow((y - 0.041) / 0.0035, 2.0));
        c *= mix(1.0, 0.55, exp(-pow(y / 0.006, 2.0)));
        // sol atravessando o plástico quando cobre a abertura
        float centro = exp(-pow((vUv.x - 0.5) / 0.32, 2.0)) * smoothstep(0.0, 0.25, y);
        c += vec3(1.0, 0.78, 0.5) * uFundo * 0.16 * centro;
        c *= uLuz;
        c = mix(c, c * vec3(0.55, 0.62, 0.8), uFrio);
        c += (hash(vUv * 900.0) - 0.5) * 0.012;
        gl_FragColor = vec4(c, 1.0);
        #include <colorspace_fragment>
      }
    `,
  });
}

// vidro: quase invisível; um brilho diagonal e a borda mais escura dizem que tem vidro ali
export function materialVidro() {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    uniforms: { uAlfa: { value: 1 }, uFrio: { value: 0 } },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
    `,
    fragmentShader: /* glsl */ `
      uniform float uAlfa, uFrio;
      varying vec2 vUv;
      void main() {
        vec2 p = (vUv - 0.5) * vec2(1.48, 1.41); // o plano é o contorno de fora; o desenho segue a abertura
        float diag = exp(-pow((p.x * 0.9 + p.y * 0.55 - 0.1) / 0.09, 2.0)) * 0.05
                   + exp(-pow((p.x * 0.9 + p.y * 0.55 + 0.16) / 0.035, 2.0)) * 0.03;
        float borda = smoothstep(0.32, 0.5, max(abs(p.x) * 1.3, abs(p.y))) * 0.08;
        vec3 c = mix(vec3(1.0, 0.98, 0.95), vec3(0.75, 0.82, 1.0), uFrio);
        float a = (diag + borda * 0.5) * uAlfa;
        gl_FragColor = vec4(c, a);
        #include <colorspace_fragment>
      }
    `,
  });
}
