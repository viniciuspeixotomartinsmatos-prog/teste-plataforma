// O globo "Mundo": pontos (THREE.Points) amostrados de uma esfera de Fibonacci e filtrados pela máscara de
// continentes (public/globo/terra.png, rasterizada do Natural Earth, domínio público). Um shader só faz o globo e
// o mapa plano: uFlat 0 → 1 desenrola a esfera a partir do meridiano da frente, como casca de laranja, até o
// retângulo do mapa impresso no cartão de embarque. As rotas e os pontos dos destinos são desenhados num canvas 2D
// por cima, com a mesma conta (o cartão imprime o mesmo desenho, então a troca não tem emenda).
import * as THREE from 'three';

export const LAT_MIN = -58;
export const LAT_MAX = 78;

// Você (Brasil, sem cidade) e os quatro tipos de destino, em regiões genéricas
export const CASA = { lat: -15, lon: -48 };
export const DESTINOS = [
  { nome: 'Ilhas', lat: 17, lon: -63 },
  { nome: 'Serras', lat: -13, lon: -73 },
  { nome: 'Neve', lat: 46.5, lon: 9 },
  { nome: 'Deserto', lat: 23.5, lon: 46 },
];

const rad = THREE.MathUtils.degToRad;

function lerMascara(img) {
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.drawImage(img, 0, 0);
  const d = g.getImageData(0, 0, c.width, c.height).data;
  return (lat, lon) => {
    const x = Math.min(c.width - 1, Math.max(0, Math.floor(((lon + 180) / 360) * c.width)));
    const y = Math.min(c.height - 1, Math.max(0, Math.floor(((90 - lat) / 180) * c.height)));
    return d[(y * c.width + x) * 4] > 127;
  };
}

// pontos de terra (lat, lon em graus) a partir da máscara
export function pontosTerra(img, candidatos) {
  const terra = lerMascara(img);
  const out = [];
  const ouro = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < candidatos; i++) {
    const y = 1 - ((i + 0.5) / candidatos) * 2;
    const lat = THREE.MathUtils.radToDeg(Math.asin(y));
    let lon = THREE.MathUtils.radToDeg((i * ouro) % (Math.PI * 2));
    if (lon > 180) lon -= 360;
    if (terra(lat, lon)) out.push(lat, lon);
  }
  return new Float32Array(out);
}

// posição no mapa plano (0..1) de uma lat/lon, com o mapa centrado em lon0
export function noMapa(lat, lon, lon0) {
  let u = (lon - lon0) / 360 + 0.5;
  u -= Math.floor(u);
  return [u, (lat - LAT_MIN) / (LAT_MAX - LAT_MIN)];
}

// arco da rota no mapa plano: curva quadrática com barriga para o norte
export function arcoPlano(a, b, t) {
  const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
  const dist = Math.hypot(b[0] - a[0], b[1] - a[1]);
  const cx = mx, cy = my + dist * 0.32;
  const s = 1 - t;
  return [s * s * a[0] + 2 * s * t * cx + t * t * b[0], s * s * a[1] + 2 * s * t * cy + t * t * b[1]];
}

export function criarGlobo(renderer, mascara, { celular = false } = {}) {
  const cena = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(celular ? 34 : 28, 1, 0.05, 100);
  const R = 1;

  const ll = pontosTerra(mascara, celular ? 28000 : 46000);
  const n = ll.length / 2;
  const aLat = new Float32Array(n), aLon = new Float32Array(n), aRnd = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    aLat[i] = rad(ll[i * 2]);
    aLon[i] = rad(ll[i * 2 + 1]);
    aRnd[i] = Math.random();
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3)); // calculada no shader
  geo.setAttribute('aLat', new THREE.BufferAttribute(aLat, 1));
  geo.setAttribute('aLon', new THREE.BufferAttribute(aLon, 1));
  geo.setAttribute('aRnd', new THREE.BufferAttribute(aRnd, 1));
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 50);

  const u = {
    uRot: { value: 0 },          // longitude que fica de frente (rad)
    uTilt: { value: rad(8) },    // inclinação para mostrar o hemisfério norte um pouco
    uR: { value: R },
    uFlat: { value: 0 },
    uRect: { value: new THREE.Vector4(-0.8, -0.3, 0.8, 0.3) }, // retângulo do mapa em NDC
    uLon0: { value: rad(-20) },
    uLatMin: { value: rad(LAT_MIN) },
    uLatMax: { value: rad(LAT_MAX) },
    uTam: { value: celular ? 2 : 2.3 },
    uTamPlano: { value: 1 },
    uDpr: { value: 1 },
    uCor: { value: new THREE.Color('#efe3d0') },
    uAlfa: { value: 1 },
    uLuz: { value: new THREE.Vector3(-0.55, 0.45, 0.7).normalize() },
  };
  const mat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    uniforms: u,
    vertexShader: /* glsl */ `
      attribute float aLat, aLon, aRnd;
      uniform float uRot, uTilt, uR, uFlat, uLon0, uLatMin, uLatMax, uTam, uTamPlano, uDpr;
      uniform vec4 uRect; uniform vec3 uLuz;
      varying float vA, vL;
      void main() {
        float lon = aLon - uRot;
        vec3 p = vec3(cos(aLat) * sin(lon), sin(aLat), cos(aLat) * cos(lon));
        float ct = cos(uTilt), st = sin(uTilt);
        p = vec3(p.x, p.y * ct - p.z * st, p.y * st + p.z * ct);
        vec4 clipA = projectionMatrix * viewMatrix * vec4(p * uR, 1.0);
        // mapa plano
        float u = fract((aLon - uLon0) / 6.2831853 + 0.5);
        float v = (aLat - uLatMin) / (uLatMax - uLatMin);
        vec2 ndcB = mix(uRect.xy, uRect.zw, vec2(u, v));
        float d = abs(u - 0.5) * 2.0;
        float k = clamp(uFlat * 1.75 - d * 0.75 - aRnd * 0.04, 0.0, 1.0);
        k = k * k * (3.0 - 2.0 * k);
        vec2 ndcA = clipA.xy / clipA.w;
        gl_Position = vec4(mix(ndcA, ndcB, k), mix(clipA.z / clipA.w, 0.0, k), 1.0);
        float frente = smoothstep(-0.02, 0.3, p.z);
        float dentro = step(0.0, v) * step(v, 1.0);
        vA = mix(frente, dentro, k);
        vL = mix(0.32 + 0.68 * max(dot(p, uLuz), 0.0), 1.0, k);
        gl_PointSize = uTam * uDpr * mix(1.0, uTamPlano, k) * (0.85 + 0.3 * aRnd);
      }`,
    fragmentShader: /* glsl */ `
      uniform vec3 uCor; uniform float uAlfa;
      varying float vA, vL;
      void main() {
        float r = length(gl_PointCoord - 0.5) * 2.0;
        float a = smoothstep(1.0, 0.55, r) * vA * uAlfa;
        if (a < 0.01) discard;
        gl_FragColor = vec4(uCor * vL, a);
        #include <colorspace_fragment>
      }`,
  });
  const pontos = new THREE.Points(geo, mat);
  pontos.frustumCulled = false;

  // o corpo escuro do globo (esconde os pontos de trás) com uma borda de luz fraca
  const corpo = new THREE.Mesh(
    new THREE.SphereGeometry(R * 0.992, 64, 48),
    new THREE.ShaderMaterial({
      transparent: true,
      uniforms: { uAlfa: { value: 1 } },
      vertexShader: 'varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }',
      fragmentShader: /* glsl */ `
        uniform float uAlfa; varying vec3 vN; varying vec3 vV;
        void main() {
          float f = 1.0 - max(dot(vN, vV), 0.0);
          vec3 c = vec3(0.011, 0.0095, 0.0085) + vec3(0.2, 0.16, 0.13) * pow(f, 2.6) * 0.5;
          gl_FragColor = vec4(c, uAlfa);
          #include <colorspace_fragment>
        }`,
    }),
  );
  corpo.renderOrder = 0;
  pontos.renderOrder = 1;
  cena.add(corpo, pontos);

  const estado = { recuo: 1, rot: rad(-48), tilt: rad(8), flat: 0, alfa: 1, D: 4, sx: 0, sy: -0.25 };

  // posição 3D (antes da câmera) de uma lat/lon na esfera girada
  const v3 = new THREE.Vector3();
  function naEsfera(lat, lon, alt = 0, out = v3) {
    const la = rad(lat), lo = rad(lon) - estado.rot;
    out.set(Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo));
    const ct = Math.cos(estado.tilt), st = Math.sin(estado.tilt);
    out.set(out.x, out.y * ct - out.z * st, out.y * st + out.z * ct);
    return out.multiplyScalar(R * (1 + alt));
  }

  // projeta para pixels da tela; devolve null se o ponto está escondido atrás do globo
  const tmp = new THREE.Vector3();
  function tela(p, w, h, checar = true) {
    if (checar) {
      // raio câmera → ponto: bate na esfera antes de chegar?
      const c = camera.position;
      const dx = p.x - c.x, dy = p.y - c.y, dz = p.z - c.z;
      const a = dx * dx + dy * dy + dz * dz;
      const b = 2 * (c.x * dx + c.y * dy + c.z * dz);
      const cc = c.x * c.x + c.y * c.y + c.z * c.z - R * R * 0.995;
      const disc = b * b - 4 * a * cc;
      if (disc > 0) {
        const t1 = (-b - Math.sqrt(disc)) / (2 * a);
        if (t1 > 0 && t1 < 0.995) return null;
      }
    }
    tmp.copy(p).project(camera);
    return [(tmp.x * 0.5 + 0.5) * w, (0.5 - tmp.y * 0.5) * h];
  }

  function aplicar(w, h, dpr) {
    camera.aspect = w / h;
    camera.position.set(0, 0, estado.D);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
    camera.projectionMatrix.elements[8] = -estado.sx;
    camera.projectionMatrix.elements[9] = -estado.sy;
    camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
    camera.updateMatrixWorld();
    u.uRot.value = estado.rot;
    u.uTilt.value = estado.tilt;
    u.uFlat.value = estado.flat;
    u.uDpr.value = dpr;
    u.uAlfa.value = estado.alfa;
    corpo.material.uniforms.uAlfa.value = estado.alfa * (1 - Math.min(1, estado.flat * 4));
    corpo.visible = estado.flat < 0.25;
  }

  // distância da câmera para o globo ter raio rPx na tela
  function distancia(rPx, h) {
    const tg = Math.tan(rad(camera.fov) / 2);
    const ang = Math.atan((rPx / (h / 2)) * tg);
    return R / Math.sin(ang);
  }

  return { cena, camera, estado, u, naEsfera, tela, aplicar, distancia, pontosLL: ll, n };
}
