// 5 · Como funciona: o globo desenrola em mapa plano (preso ao scroll: é imagem) até o retângulo do cartão de
// embarque; o papel é impresso por cima e os pontos viram a tinta do mapa, no mesmo lugar. Os campos preenchem por
// marco (conversa, roteiro, viagem) e, no último, o canhoto destaca no picote e revela "Montar roteiro".
import gsap from 'gsap';
import { pecas } from '../split.js';
import { flap } from '../flap.js';
import { faixa } from '../stage/rig.js';
import { imprimirMapa } from '../stage/rotas.js';
import { REDUZIDO } from '../ease.js';

const LON0 = -20;
const sm = (t) => t * t * (3 - 2 * t);

export function cenaCartao(ctx, mundo) {
  const el = document.querySelector('.cartao');
  const bilhete = el.querySelector('.bilhete');
  const papel = el.querySelector('.bilhete__papel');
  const mapa = el.querySelector('.bilhete__mapa');
  const corpo = el.querySelector('.bilhete__corpo');
  const canhoto = el.querySelector('.canhoto');
  const baixo = el.querySelector('.bilhete__baixo');
  const palavra = document.querySelector('.palco__palavra');
  const campos = [...el.querySelectorAll('.campo')].map((c) => ({
    valor: flap(c.querySelector('.campo__valor')),
    texto: pecas([c.querySelector('.campo__texto')]),
  }));

  // código de barras do canhoto (determinístico)
  const barras = el.querySelector('.canhoto__barras');
  let s = 11;
  const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 38; i++) {
    const b = document.createElement('i');
    const larg = [1, 1, 2, 3][(rnd() * 4) | 0];
    b.style.flex = `0 0 ${larg}px`;
    if (rnd() > 0.82) b.style.opacity = '0';
    barras.append(b);
  }

  const st = { impresso: 0, rasgo: 0, campos: 0, mapaUrl: null, rect: null, descola: 0 };

  // o canhoto também destaca no clique ou no toque: hover e foco descolam a ponta no picote,
  // apertar descola mais, e o clique leva a rolagem até o marco do rasgo (o estado continua preso ao scroll)
  const rasgado = () => bilhete.classList.contains('is-rasgado');
  const descolar = (alvo, dur, ease) => {
    if (rasgado()) alvo = 0;
    gsap.to(st, { descola: alvo, duration: REDUZIDO ? 0 : dur, ease, overwrite: 'auto' });
  };
  canhoto.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse') descolar(1, 0.6, 'al-out'); });
  canhoto.addEventListener('pointerleave', () => descolar(0, 0.35, 'al-in'));
  canhoto.addEventListener('pointerdown', () => descolar(1.7, 0.18, 'al-out'));
  canhoto.addEventListener('pointerup', (e) => descolar(e.pointerType === 'mouse' ? 1 : 0, 0.35, 'al-out'));
  canhoto.addEventListener('pointercancel', () => descolar(0, 0.35, 'al-in'));
  canhoto.addEventListener('focus', () => { if (canhoto.matches(':focus-visible')) descolar(1, 0.6, 'al-out'); });
  canhoto.addEventListener('blur', () => descolar(0, 0.35, 'al-in'));
  const destacar = () => { if (!rasgado()) ctx.irPara('cartao', 0.9); };
  canhoto.addEventListener('click', destacar);
  canhoto.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); descolar(1.7, 0.18, 'al-out'); destacar(); }
  });

  function medir() {
    const r = mapa.getBoundingClientRect();
    const rc = corpo.getBoundingClientRect();
    const rp = ctx.palco.getBoundingClientRect();
    st.rect = { x: r.left - rp.left, y: r.top - rp.top, w: r.width, h: r.height };
    // o mapa vira imagem de fundo das duas peças (o canhoto leva o pedaço dele quando destaca)
    imprimirMapa(mapa, ctx.glo.pontosLL, LON0, { tam: ctx.celular ? 1.1 : 1.5 });
    mapa.toBlob((b) => {
      if (!b) return;
      if (st.mapaUrl) URL.revokeObjectURL(st.mapaUrl);
      st.mapaUrl = URL.createObjectURL(b);
      bilhete.style.setProperty('--mapa', `url(${st.mapaUrl})`);
    });
    bilhete.style.setProperty('--mapa-w', `${r.width}px`);
    bilhete.style.setProperty('--mapa-h', `${r.height}px`);
    bilhete.style.setProperty('--mapa-x', `${r.left - rc.left}px`);
    bilhete.style.setProperty('--mapa-y', `${r.top - rc.top}px`);
    bilhete.style.setProperty('--corpo-w', `${rc.width}px`);
    bilhete.style.setProperty('--corpo-h', `${rc.height}px`);
    campos.forEach((c) => c.valor.medir());
  }

  function imprimir(sim, pulo) {
    gsap.killTweensOf(st, 'impresso');
    if (pulo || REDUZIDO) { st.impresso = sim ? 1 : 0; return; }
    gsap.to(st, { impresso: sim ? 1 : 0, duration: sim ? 1.25 : 0.5, ease: sim ? 'al-io' : 'al-in' });
  }

  function campo(i, sim, pulo) {
    const c = campos[i];
    if (pulo) { c.valor.ja(sim); c.texto.ja(sim); return; }
    if (sim) { c.valor.tocar(0); c.texto.entrar(0.35); }
    else { c.valor.sair(); c.texto.sair(); }
  }

  function rasgar(sim, pulo) {
    gsap.killTweensOf(st, 'rasgo');
    bilhete.classList.toggle('is-rasgado', sim);
    // destacado, o canhoto deixa de ser botão
    canhoto.tabIndex = sim ? -1 : 0;
    canhoto.setAttribute('aria-disabled', sim ? 'true' : 'false');
    if (sim) gsap.to(st, { descola: 0, duration: 0.3, overwrite: 'auto' });
    if (pulo || REDUZIDO) { st.rasgo = sim ? 1 : 0; return; }
    if (sim) {
      gsap.timeline()
        .to(st, { rasgo: -0.04, duration: 0.16, ease: 'power2.out' })
        .to(st, { rasgo: 1, duration: 1.05, ease: 'al-out' });
    } else gsap.to(st, { rasgo: 0, duration: 0.6, ease: 'al-io' });
  }

  return {
    id: 'cartao',
    telas: ctx.celular ? 3 : 3.2,
    marcos: [0.02, 0.26, 0.41, 0.55, 0.69, 0.84],
    camada: el,
    vis: [0.12, 1.5],
    set: 'globo',
    st,
    medir,

    ligou(on) { if (on && !st.rect) medir(); },

    passo(i, antes, pulo) {
      if (i >= 1) mundo.sairTextos();
      else if (antes >= 1) mundo.voltarTextos();
      if ((i >= 2) !== (antes >= 2)) imprimir(i >= 2, pulo);
      for (let k = 0; k < 3; k++) {
        const quer = i >= 3 + k, tinha = antes >= 3 + k;
        if (quer !== tinha || pulo) campo(k, quer, pulo);
      }
      if ((i >= 6) !== (antes >= 6) || pulo) rasgar(i >= 6, pulo);
    },

    atualizar(p, dt, ativa) {
      if (!st.rect) medir();
      // papel impresso de cima para baixo, descendo um pouco da "fenda"
      const imp = st.impresso;
      papel.style.clipPath = imp >= 1 ? 'none' : `inset(0 0 ${(1 - imp) * 100}% 0 round 26px)`;
      papel.style.transform = `translate3d(0, ${(1 - sm(Math.min(1, imp))) * -18}px, 0)`;
      // canhoto destacando
      const r = st.rasgo;
      // primeiro puxa (r < 0,25: rasga no picote), depois cai e gira
      const puxa = Math.min(1, Math.max(0, r / 0.25)), cai = Math.max(0, (r - 0.25) / 0.75);
      const hC = canhoto.offsetHeight;
      const d = st.descola; // hover/foco/toque: a ponta descola no picote
      if (ctx.celular) canhoto.style.transform = r ? `translate3d(${-10 * puxa - 6 * cai}px, ${8 * puxa + cai * hC * 0.62}px, 0) rotate(${-2 * puxa - 6 * cai}deg)` : d ? `translate3d(${-2 * d}px, ${4 * d}px, 0) rotate(${-1.8 * d}deg)` : 'none';
      else canhoto.style.transform = r ? `translate3d(${14 * puxa + 46 * cai}px, ${cai * hC * 0.6}px, 0) rotate(${1.5 * puxa + 8.5 * cai}deg)` : d ? `translate3d(${5 * d}px, ${-2 * d}px, 0) rotate(${2.2 * d}deg)` : 'none';
      const sombra = Math.max(r, 0.35 * Math.min(d, 1.7));
      canhoto.style.filter = sombra > 0.02 ? `drop-shadow(0 ${18 * sombra}px ${30 * sombra}px rgba(0,0,0,${0.35 * sombra}))` : 'none';
      canhoto.style.setProperty('--furo', (0.22 + 0.28 * Math.min(1, d)).toFixed(3));
      baixo.style.opacity = faixa(r, 0.35, 0.8);
      baixo.style.visibility = r > 0.3 ? '' : 'hidden'; // o botão de baixo só entra no Tab quando aparece
      baixo.style.transform = `translate3d(0, ${(1 - faixa(r, 0.35, 1)) * 14}px, 0)`;

      if (!ativa) return;
      const glo = ctx.glo;
      const flat = REDUZIDO ? (p > 0.12 ? 1 : 0) : sm(faixa(p, 0.03, 0.235));
      mundo.camFinal();
      glo.estado.flat = flat;
      const { w, h } = ctx.tam;
      const R = st.rect;
      glo.u.uRect.value.set((R.x / w) * 2 - 1, 1 - ((R.y + R.h) / h) * 2, ((R.x + R.w) / w) * 2 - 1, 1 - (R.y / h) * 2);
      glo.u.uLon0.value = (LON0 * Math.PI) / 180;
      glo.u.uTamPlano.value = ctx.celular ? 0.5 : 0.62;
      // os pontos somem quando o papel termina de cobrir (estão embaixo dele)
      glo.estado.alfa = imp >= 0.999 ? 0 : 1;
      ctx.rotasEstado = { flat, rect: R, lon0: LON0, alfa: imp >= 0.999 ? 0 : 1 };
      palavra.style.opacity = mundo.st.palavra * (1 - faixa(p, 0.02, 0.14));
      ctx.rotulosMundo(mundo.rotulos(), flat);
    },
  };
}
