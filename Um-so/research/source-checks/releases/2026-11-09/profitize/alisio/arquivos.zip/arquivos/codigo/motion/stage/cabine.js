// A cabine: parede, três janelas (moldura, persiana, vidro, luz retangular na abertura) e a vista atrás delas.
// O mesmo cenário serve à hero (dia) e ao fecho (noite). A câmera tem um "rig" com posição, giro e deslocamento de
// lente (a janela do meio fica onde o layout quer, sem inclinar a parede).
import * as THREE from 'three';
import { RectAreaLightUniformsLib } from 'three/examples/jsm/lights/RectAreaLightUniformsLib.js';
import { ABERTURA, CONTORNO, FUNDO, PERSIANA, PERSIANA_Z, geometriaMoldura, materialMoldura, materialPersiana, materialVidro } from './janela.js';
import { criarParede } from './parede.js';
import { criarVista, CHAO } from './vista.js';

export const ESPACO = 1.63; // distância entre os centros das janelas
const CENTROS = [[-ESPACO, 0], [0, 0], [ESPACO, 0]];

function ambienteCabine(renderer) {
  // o que o plástico reflete: teto quente, chão escuro e as janelas do outro lado do corredor
  const cena = new THREE.Scene();
  const esfera = new THREE.Mesh(
    new THREE.SphereGeometry(10, 48, 24),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: /* glsl */ `
        varying vec3 vD;
        float mancha(vec3 d, vec3 c, float r) { return exp(-pow(distance(d, normalize(c)) / r, 2.0)); }
        void main() {
          vec3 base = mix(vec3(0.035, 0.028, 0.024), vec3(0.32, 0.25, 0.2), smoothstep(-0.2, 0.9, vD.y));
          vec3 jan = vec3(1.6, 1.45, 1.25);
          base += jan * (mancha(vD, vec3(-0.75, 0.15, 0.65), 0.22) + mancha(vD, vec3(0.75, 0.15, 0.65), 0.22) + mancha(vD, vec3(0.0, 0.2, 1.0), 0.18) * 0.6);
          base += vec3(0.9, 0.75, 0.6) * mancha(vD, vec3(0.0, 1.0, 0.4), 0.35) * 0.5;
          gl_FragColor = vec4(base, 1.0);
        }`,
    }),
  );
  cena.add(esfera);
  const pm = new THREE.PMREMGenerator(renderer);
  const rt = pm.fromScene(cena, 0.02);
  pm.dispose();
  return rt.texture;
}

export function criarCabine(renderer, tex, { celular = false } = {}) {
  RectAreaLightUniformsLib.init();
  const cena = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(celular ? 50 : 32, 1, 0.03, 220);
  camera.rotation.order = 'YXZ';

  const env = ambienteCabine(renderer);
  const geoMoldura = geometriaMoldura(celular ? 180 : 240);
  const geoPersiana = new THREE.PlaneGeometry(PERSIANA.w, PERSIANA.h);
  // o vidro é bem maior que a abertura: vista de lado, a borda dele nunca aparece dentro do poço
  const geoVidro = new THREE.PlaneGeometry(CONTORNO.a * 2, CONTORNO.b * 2);

  const parede = criarParede({ centros: CENTROS });
  cena.add(parede.mesh);

  const janelas = CENTROS.map(([cx, cy], i) => {
    const g = new THREE.Group();
    g.position.set(cx, cy, 0);
    const moldura = new THREE.Mesh(geoMoldura, materialMoldura(env));
    const persiana = new THREE.Mesh(geoPersiana, materialPersiana());
    persiana.position.z = PERSIANA_Z;
    const vidro = new THREE.Mesh(geoVidro, materialVidro());
    vidro.position.z = FUNDO - 0.006;
    const luz = new THREE.RectAreaLight('#fff1dc', 0, ABERTURA.a * 2, ABERTURA.b * 2);
    luz.position.set(0, 0, FUNDO - 0.02);
    luz.lookAt(0, 0, 10);
    g.add(moldura, persiana, vidro, luz);
    cena.add(g);
    return { g, moldura, persiana, vidro, luz, abre: 0, i };
  });

  cena.add(new THREE.HemisphereLight('#6a5646', '#0e0a08', 0.22));
  const frente = new THREE.DirectionalLight('#ffe8d0', 0.1);
  frente.position.set(0, 2.5, 7);
  cena.add(frente);
  const cabineNoite = new THREE.PointLight('#ffe3c6', 0, 14, 1.4);
  cabineNoite.position.set(0, 2.8, 3.2);
  cena.add(cabineNoite);

  const vista = criarVista(tex, { celular });
  cena.add(vista.dia, vista.noite, vista.descida);

  // ---- estado
  const estado = {
    noite: 0,          // 0 dia, 1 noite
    rasa: 1,           // brilho da parede (baixo na cabine escura da abertura)
    vidro: 1,          // o vidro some quando a câmera chega perto
    t: 0,
    luzAsa: 0,
  };
  const rig = { pos: new THREE.Vector3(0, 0, 10), yaw: 0, pitch: 0, roll: 0, sx: 0, sy: 0, fov: camera.fov };

  // posição da persiana: 0 fechada (pé encostado no fundo da abertura), 1 aberta (sobra o lábio)
  const peFechada = -ABERTURA.b - 0.03;
  const peAberta = ABERTURA.b - 0.085;
  function aplicarPersianas() {
    const L = [0, 0, 0];
    janelas.forEach((j, i) => {
      const pe = peFechada + (peAberta - peFechada) * j.abre;
      j.persiana.position.y = pe + PERSIANA.h / 2;
      const livre = THREE.MathUtils.clamp((pe - -ABERTURA.b) / (2 * ABERTURA.b), 0, 1);
      // luz: o que a persiana deixa passar (+ um vazamento mínimo quando fechada)
      const dia = 1 - estado.noite;
      L[i] = (0.04 + 0.96 * Math.pow(livre, 0.8)) * (dia + estado.noite * 0.32);
      j.luz.intensity = L[i] * (dia * 7 + estado.noite * 5);
      j.luz.color.set(estado.noite > 0.5 ? '#b9c6dd' : '#fff1dc');
      const pu = j.persiana.material.uniforms;
      pu.uFundo.value = dia * (1 - livre);
      pu.uLuz.value = (0.42 + 0.58 * Math.min(1, L[i] * 1.2)) * (1 - estado.noite * 0.35);
      pu.uFrio.value = estado.noite;
      j.moldura.material.envMapIntensity = (0.22 + 0.26 * L[i]) * (1 - 0.55 * estado.noite);
      j.vidro.material.uniforms.uAlfa.value = estado.vidro;
      j.vidro.material.uniforms.uFrio.value = estado.noite;
    });
    parede.mat.uniforms.uLuz.value.set(L[0], L[1], L[2]);
    parede.mat.uniforms.uNoite.value = estado.noite;
    parede.mat.uniforms.uRasa.value = estado.rasa;
    cabineNoite.intensity = estado.noite * 3.6;
  }

  function aplicarCamera(w, h) {
    camera.aspect = w / h;
    camera.fov = rig.fov;
    camera.position.copy(rig.pos);
    camera.rotation.set(rig.pitch, rig.yaw, rig.roll, 'YXZ');
    camera.updateProjectionMatrix();
    // deslocamento de lente: o eixo da câmera aparece em (sx, sy) da tela, em coordenadas normalizadas
    camera.projectionMatrix.elements[8] = -rig.sx;
    camera.projectionMatrix.elements[9] = -rig.sy;
    camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
    camera.updateMatrixWorld();
  }

  // enquadramento da hero: as três janelas cabem no retângulo do layout (no celular, a do meio com 62% da largura)
  function enquadrar(ret, vw, vh) {
    const larguraGrupo = 2 * ESPACO + 2 * CONTORNO.a;
    const alturaGrupo = 2 * CONTORNO.b;
    // celular e qualquer tela em pé: a janela do meio grande, as laterais cortadas pelas bordas
    const emPe = celular || vw / vh < 0.95;
    const ppu = emPe
      ? Math.min((vw * (celular ? 0.78 : 0.62)) / (2 * CONTORNO.a), ret.height / alturaGrupo)
      : Math.min(ret.width / larguraGrupo, ret.height / alturaGrupo);
    const fov = THREE.MathUtils.degToRad(rig.fov);
    const L = vh / (ppu * 2 * Math.tan(fov / 2));
    return {
      L,
      sx: ((ret.left + ret.width / 2) / vw) * 2 - 1,
      sy: 1 - ((ret.top + ret.height / 2) / vh) * 2,
      ppu,
    };
  }

  function atualizar(dt, w, h) {
    estado.t += dt;
    aplicarPersianas();
    aplicarCamera(w, h);
    // nuvens da descida sempre de frente para a câmera
    for (const n of vista.nuvens) {
      n.quaternion.copy(camera.quaternion);
      n.rotateZ(n.userData.giro);
      n.scale.x = n.userData.espelho;
    }
    vista.estrelas.material.uniforms.uT.value = estado.t;
    vista.luzAsa.material.uniforms.uForca.value = estado.luzAsa;
  }

  return { cena, camera, janelas, parede, vista, estado, rig, enquadrar, atualizar, CHAO };
}
