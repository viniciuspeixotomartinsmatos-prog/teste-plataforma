// 7 · Rodapé: a gravura sobe mais devagar que o texto e o avião avança um pouco no céu (presos ao scroll: são imagem).
import gsap from 'gsap';
import { REDUZIDO } from './ease.js';

export function criarRodape() {
  if (REDUZIDO) return;
  const st = { trigger: '.rodape', start: 'top bottom', end: 'bottom bottom', scrub: true };
  gsap.fromTo('.rodape__gravura img', { yPercent: 22 }, { yPercent: 0, ease: 'none', scrollTrigger: st });
  gsap.fromTo('.rodape__aviao', { xPercent: -14, yPercent: 30 }, { xPercent: 0, yPercent: 0, ease: 'none', scrollTrigger: { ...st } });
}
