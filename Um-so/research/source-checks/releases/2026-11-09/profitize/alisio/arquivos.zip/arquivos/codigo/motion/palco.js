// O palco: um pin só para o filme inteiro. Cada cena ocupa um trecho do scroll (em telas) e recebe:
// - atualizar(p, dt): o progresso suavizado da cena (câmera e imagens seguem o scroll, sem pressa);
// - passo(i, anterior, pulo): o marco atual pelo scroll cru (texto e estados trocam por tempo, com duração fixa).
// Rolando rápido, vários marcos passam de uma vez: a cena recebe só o último e vai direto ao estado final.
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { REDUZIDO } from './ease.js';

export function criarPalco(el, cenas) {
  let total = 0;
  for (const c of cenas) {
    c.a = total;
    total += c.telas;
    c.b = total;
    c.i = 0;
    c.marcos = c.marcos || [];
    c.vis = c.vis || [-0.04, 1.04];
    c.camada = c.camada || null;
    c.ligada = false;
  }
  const estado = { raw: 0, suave: 0, total, pulo: false };

  const st = ScrollTrigger.create({
    trigger: el,
    pin: true,
    start: 'top top',
    end: () => `+=${total * innerHeight}`,
    refreshPriority: 1,
    invalidateOnRefresh: true,
    onUpdate: (s) => { estado.raw = s.progress * total; },
  });

  const contar = (marcos, p) => { let n = 0; for (const m of marcos) if (p >= m) n++; return n; };

  function tick(dt) {
    const k = REDUZIDO || estado.pulo ? 1 : 1 - Math.exp(-dt * 8.5);
    estado.suave += (estado.raw - estado.suave) * k;
    if (Math.abs(estado.raw - estado.suave) < 1e-5) estado.suave = estado.raw;
    const pulo = estado.pulo;
    estado.pulo = false;
    const ativa = atual();

    for (const c of cenas) {
      const pr = (estado.raw - c.a) / c.telas;
      const ps = (estado.suave - c.a) / c.telas;
      // camada de texto ligada só perto do trecho dela
      const ligar = ps >= c.vis[0] && ps <= c.vis[1];
      if (ligar !== c.ligada) {
        c.ligada = ligar;
        c.camada?.classList.toggle('is-on', ligar);
        c.ligou?.(ligar);
      }
      const i = contar(c.marcos, pr);
      if (i !== c.i) {
        const antes = c.i;
        c.i = i;
        c.passo?.(i, antes, pulo || Math.abs(i - antes) > 1);
      }
      if (ps > -0.6 && ps < 1.6) c.atualizar?.(Math.min(1.6, Math.max(-0.6, ps)), dt, c === ativa);
    }
  }

  // a cena onde o scroll suavizado está agora (para escolher o que o canvas desenha)
  function atual() {
    for (const c of cenas) if (estado.suave < c.b) return c;
    return cenas[cenas.length - 1];
  }

  // posição de scroll (px) de um ponto da cena (fração do trecho dela)
  function px(id, f = 0) {
    const c = cenas.find((x) => x.id === id);
    return st.start + (c.a + c.telas * f) * innerHeight;
  }

  return { estado, tick, atual, px, st, cenas, total };
}
