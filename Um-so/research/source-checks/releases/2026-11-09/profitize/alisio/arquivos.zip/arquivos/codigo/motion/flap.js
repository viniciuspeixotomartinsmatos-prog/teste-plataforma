// Valor do cartão de embarque que gira como painel de aeroporto antes de assentar. Cada caractere tem a largura do
// seu caractere final (o resultado continua proporcional); os sorteados giram dentro dessa célula.
import gsap from 'gsap';
import { REDUZIDO } from './ease.js';

const DIGITOS = '0123456789';
const LETRAS = 'abcdefghijlmnopqrstuvxz';

export function flap(el) {
  const final = el.dataset.flap || el.textContent;
  el.setAttribute('aria-label', final);
  el.textContent = '';
  const celulas = [...final].map((ch) => {
    const s = document.createElement('span');
    s.className = 'flap__c';
    s.textContent = ch === ' ' ? '\u00a0' : ch;
    s.setAttribute('aria-hidden', 'true');
    el.append(s);
    return { s, ch: ch === ' ' ? '\u00a0' : ch, pool: /\d/.test(ch) ? DIGITOS : /\s/.test(ch) ? null : LETRAS };
  });
  const medir = () => celulas.forEach((c) => {
    c.s.style.width = '';
    c.s.style.width = `${c.s.getBoundingClientRect().width}px`;
  });
  let tl = null;
  gsap.set(el, { opacity: 0 });

  return {
    medir,
    tocar(atraso = 0) {
      tl?.kill();
      if (REDUZIDO) { gsap.to(el, { opacity: 1, duration: 0.3, delay: atraso }); return; }
      tl = gsap.timeline({ delay: atraso });
      tl.set(el, { opacity: 1 });
      celulas.forEach((c, i) => {
        if (!c.pool) return;
        const giros = 7 + i * 2;
        for (let k = 0; k < giros; k++) {
          tl.call(() => { c.s.textContent = c.pool[(Math.random() * c.pool.length) | 0]; c.s.classList.add('is-gira'); }, null, i * 0.045 + k * 0.042);
        }
        tl.call(() => { c.s.textContent = c.ch; c.s.classList.remove('is-gira'); }, null, i * 0.045 + giros * 0.042);
      });
    },
    ja(visivel) {
      tl?.kill();
      celulas.forEach((c) => { c.s.textContent = c.ch; c.s.classList.remove('is-gira'); });
      gsap.set(el, { opacity: visivel ? 1 : 0 });
    },
    sair() {
      tl?.kill();
      gsap.to(el, { opacity: 0, duration: 0.3, onComplete: () => celulas.forEach((c) => (c.s.textContent = c.ch)) });
    },
  };
}
