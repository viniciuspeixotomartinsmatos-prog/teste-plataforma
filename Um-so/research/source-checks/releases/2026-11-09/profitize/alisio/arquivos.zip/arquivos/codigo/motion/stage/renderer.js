// O renderizador do palco: um canvas só para o site inteiro. No desktop desenha sempre em 2× (numa tela 1× é
// supersampling: o navegador reduz o canvas e a borda das janelas, branco contra o azul, sai lisa; só com o MSAA de 4
// amostras ela fica em degraus). No celular, até 1,5. Se os quadros pesarem de verdade, desce um degrau (2 → 1,5 no
// desktop, 1,5 → 1 no celular) e só uma vez: nunca para um valor quebrado nem para 1× no desktop.
import * as THREE from 'three';

export function criarRenderer(canvas, { celular = false } = {}) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.95;
  renderer.setClearColor(0x000000, 0);

  let dpr = celular ? Math.min(devicePixelRatio || 1, 1.5) : 2;
  const piso = celular ? 1 : 1.5;
  const tam = { w: 1, h: 1, dpr };

  function medir() {
    tam.w = canvas.clientWidth || innerWidth;
    tam.h = canvas.clientHeight || innerHeight;
    renderer.setPixelRatio(dpr);
    renderer.setSize(tam.w, tam.h, false);
    tam.dpr = dpr;
  }
  medir();
  new ResizeObserver(medir).observe(canvas);

  // se a média dos quadros passar de 24 ms por três janelas seguidas de 1,5 s, desce um degrau. Os primeiros 4 s
  // (fotos subindo para a GPU, shaders) e quadros de aba escondida (dt enorme) não contam.
  const inicio = performance.now();
  let acum = 0, n = 0, lentas = 0;
  function amostra(dtMs) {
    if (performance.now() - inicio < 4000 || dtMs > 200 || dpr <= piso) return;
    acum += dtMs; n++;
    if (acum > 1500) {
      lentas = acum / n > 24 ? lentas + 1 : 0;
      acum = 0; n = 0;
      if (lentas >= 3) { dpr = piso; medir(); }
    }
  }

  return { renderer, tam, medir, amostra };
}
