// Nav fixa: some ao descer e volta ao subir. Os links pulam para o ponto da cena dentro do palco com uma cortina
// curta da cor da parede (o filme não atravessa o site inteiro correndo).
import gsap from 'gsap';
import { REDUZIDO } from './ease.js';

export function criarNav({ lenis, palco, alvos, card }) {
  const nav = document.querySelector('.nav');
  const cortina = document.createElement('div');
  cortina.className = 'cortina';
  document.body.append(cortina);

  let ultimo = 0;
  const onScroll = (y) => {
    const desce = y > ultimo + 2, sobe = y < ultimo - 2;
    if (desce && y > 120) nav.classList.add('is-escondida');
    else if (sobe || y < 60) nav.classList.remove('is-escondida');
    ultimo = y;
  };
  if (lenis) lenis.on('scroll', ({ scroll }) => onScroll(scroll));
  else addEventListener('scroll', () => onScroll(scrollY), { passive: true });

  function ir(destino, fracao) {
    const y = palco.px(destino, fracao ?? alvos[destino] ?? 0);
    const pular = () => {
      if (lenis) lenis.scrollTo(y, { immediate: true, force: true });
      else scrollTo(0, y);
      palco.estado.raw = Math.max(0, Math.min(palco.total, (y - palco.st.start) / innerHeight));
      palco.estado.pulo = true;
    };
    if (REDUZIDO) { pular(); return; }
    gsap.timeline()
      .to(cortina, { opacity: 1, duration: 0.38, ease: 'al-in' })
      .call(pular)
      .to(cortina, { opacity: 0, duration: 0.7, ease: 'al-out' }, '+=0.08');
  }

  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-ir]');
    if (!a) return;
    e.preventDefault();
    ir(a.dataset.ir, a.dataset.card ? card(Number(a.dataset.card)) : undefined);
    nav.classList.remove('is-escondida');
  });

  return { ir };
}
