// 1 · Abertura: as três persianas sobem uma depois da outra (com quique), a luz de cada janela esquenta a parede,
// e os textos da hero entram. O mouse gira a câmera em volta da parede: a moldura quase não sai do lugar e a vista
// anda atrás dela. No primeiro toque do scroll os textos saem.
import gsap from 'gsap';
import { linhas, pecas } from '../split.js';
import { REDUZIDO } from '../ease.js';
import { orbita, aplicar } from '../stage/rig.js';

export const ALTURAS_HERO = [0.74, 1, 0.83]; // esquerda cobre ~um terço, meio aberta, direita ~um quarto

// de volta da noite (persianas abertas ou na metade), as persianas voltam devagar às alturas da hero
// Só depois da abertura (cab.abriu): antes, isso abria as persianas fechadas do começo e a abertura abria de novo.
export function alturasDeDia(cab, dt) {
  if (!cab.abriu) return;
  const k = 1 - Math.exp(-dt * 4);
  cab.janelas.forEach((j, i) => {
    if (gsap.isTweening(j)) return;
    j._fecho = false;
    j.abre += (ALTURAS_HERO[i] - j.abre) * k;
  });
}

export function cenaAbertura(ctx) {
  const el = document.querySelector('.abertura');
  const titulo = linhas(el.querySelector('.abertura__titulo'));
  const sub = linhas(el.querySelector('.abertura__sub'));
  const esq = linhas(el.querySelector('.abertura__esq'));
  const dir = linhas(el.querySelector('.abertura__dir'));
  const cta = pecas([el.querySelector('.abertura__cta')]);
  let aberta = false;

  function textos(entrar, atraso = 0) {
    if (entrar) {
      titulo.entrar(atraso, 1.15);
      sub.entrar(atraso + 0.18);
      esq.entrar(atraso + 0.3);
      dir.entrar(atraso + 0.36);
      cta.entrar(atraso + 0.42);
    } else {
      [titulo, sub, esq, dir, cta].forEach((t) => t.sair());
    }
  }

  return {
    id: 'abertura',
    telas: 0.24,
    marcos: [0.1],
    camada: el,
    vis: [-1, 1.25],
    set: 'cabine',

    // os textos da hero entram assim que as fontes chegam (antes da cabine, que ainda está baixando)
    entrar(atraso = 0) {
      aberta = true;
      textos(true, REDUZIDO ? 0 : atraso);
    },

    // com a cabine carregada: ela aparece com as persianas fechadas e elas sobem uma a uma
    abrir() {
      const { cab } = ctx;
      if (REDUZIDO) {
        cab.janelas.forEach((j, i) => (j.abre = ALTURAS_HERO[i]));
        cab.estado.rasa = 1;
        cab.abriu = true;
        return;
      }
      cab.janelas.forEach((j) => (j.abre = 0));
      gsap.to(cab.estado, { rasa: 1, duration: 2.6, ease: 'sine.inOut' });
      cab.janelas.forEach((j, i) => {
        gsap.to(j, {
          abre: ALTURAS_HERO[i], duration: 1.55, ease: 'al-quique', delay: 0.25 + i * 0.36,
          onComplete: i === cab.janelas.length - 1 ? () => { cab.abriu = true; } : undefined,
        });
      });
    },

    passo(i) {
      if (!aberta) return;
      textos(i === 0);
    },

    atualizar(p, dt, ativa) {
      if (!ativa) return;
      const { cab } = ctx;
      // persianas da hero no lugar (para quem volta do filme)
      cab.estado.noite = 0;
      cab.estado.vidro = 1;
      aplicar(cab, { pos: [0, 0, ctx.heroi.L] }, orbita(ctx.mouse, ctx.t, ctx.heroi.L, REDUZIDO), 1, 1, ctx.heroi);
      cab.vista.dia.visible = true;
      cab.vista.noite.visible = false;
      cab.vista.descida.visible = false;
      alturasDeDia(cab, dt);
    },
  };
}
