// Carrega as fotos da cena (a abertura espera por elas para acender a cabine) e avisa o progresso.
// Se uma foto não existir, devolve um degradê no lugar, para a cena nunca quebrar.
// As fotos são decodificadas fora do thread principal (ImageBitmap), já na carga: com <img>, o navegador decodifica
// na hora do primeiro desenho, no meio do quadro (a foto do chão travava a descida por ~40 ms). Safari antes do 17 e
// Firefox antes do 98 têm bugs com ImageBitmap: lá fica o carregador comum.
import * as THREE from 'three';

const ua = navigator.userAgent;
const safari = /^((?!chrome|android).)*safari/i.test(ua) && !/crios|fxios/i.test(ua);
const vSafari = safari && ua.match(/version\/(\d+)/i) ? +ua.match(/version\/(\d+)/i)[1] : 99;
const vFirefox = ua.match(/firefox\/(\d+)/i) ? +ua.match(/firefox\/(\d+)/i)[1] : 99;
const bitmap = typeof createImageBitmap !== 'undefined' && vSafari >= 17 && vFirefox >= 98;

const loader = new THREE.TextureLoader();
const loaderBitmap = bitmap ? new THREE.ImageBitmapLoader().setOptions({ imageOrientation: 'flipY', premultiplyAlpha: 'none' }) : null;

function carregar(url, ok, erro) {
  if (!loaderBitmap) return loader.load(url, ok, undefined, erro);
  loaderBitmap.load(url, (img) => {
    const t = new THREE.Texture(img);
    t.flipY = false; // já veio virada (imageOrientation)
    t.needsUpdate = true;
    ok(t);
  }, undefined, erro);
}

function reserva(tipo) {
  const c = document.createElement('canvas');
  c.width = 96; c.height = 64; // mesma proporção das fotos (3:2)
  const g = c.getContext('2d');
  const grad = g.createLinearGradient(0, 0, 0, 64);
  if (tipo === 'ceu') { grad.addColorStop(0, '#3f7fd0'); grad.addColorStop(1, '#cfe2f2'); }
  else if (tipo === 'mar') { grad.addColorStop(0, 'rgba(0,0,0,0)'); grad.addColorStop(0.3, '#4f9fc9'); grad.addColorStop(1, '#16618f'); }
  else { grad.addColorStop(0, 'rgba(255,255,255,0)'); grad.addColorStop(1, 'rgba(255,255,255,0)'); }
  g.fillStyle = grad; g.fillRect(0, 0, 96, 64);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function carregarTexturas(lista, onProgresso = () => {}) {
  let feitos = 0;
  const total = lista.length;
  return Promise.all(lista.map(({ nome, url, tipo, rep = false }) => new Promise((ok) => {
    carregar(url, (t) => {
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 8;
      if (rep) t.wrapS = t.wrapT = THREE.MirroredRepeatWrapping;
      onProgresso(++feitos / total);
      ok([nome, t]);
    }, () => {
      onProgresso(++feitos / total);
      ok([nome, reserva(tipo)]);
    });
  }))).then(Object.fromEntries);
}
