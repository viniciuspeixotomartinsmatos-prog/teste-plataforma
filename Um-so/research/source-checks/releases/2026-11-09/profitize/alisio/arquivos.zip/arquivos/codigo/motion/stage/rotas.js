// As rotas do globo num canvas 2D por cima do WebGL: de "Você" até cada destino, em arco de grande círculo que se
// desenha por marco. A mesma conta segue o globo desenrolando até o mapa plano, e imprimirMapa() desenha o mesmo
// mapa (pontos e rotas) em tinta no cartão de embarque.
import { CASA, DESTINOS, noMapa, arcoPlano } from './globo.js';

const PASSOS = 72;
const sm = (k) => k * k * (3 - 2 * k);

// mesma curva do shader: a frente achata primeiro, as bordas por último
export const kPlano = (flat, u) => sm(Math.min(1, Math.max(0, flat * 1.75 - Math.abs(u - 0.5) * 2 * 0.75)));

function slerp(a, b, t) {
  const d = Math.min(1, Math.max(-1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]));
  const om = Math.acos(d);
  if (om < 1e-5) return a.slice();
  const s = Math.sin(om);
  const ka = Math.sin((1 - t) * om) / s, kb = Math.sin(t * om) / s;
  return [a[0] * ka + b[0] * kb, a[1] * ka + b[1] * kb, a[2] * ka + b[2] * kb];
}

const unit = (lat, lon) => {
  const la = (lat * Math.PI) / 180, lo = (lon * Math.PI) / 180;
  return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
};
const latlon = (v) => [(Math.asin(v[1]) * 180) / Math.PI, (Math.atan2(v[0], v[2]) * 180) / Math.PI];

export function criarRotas(canvas, glo) {
  const g = canvas.getContext('2d');
  const rotas = DESTINOS.map((d) => {
    const a = unit(CASA.lat, CASA.lon), b = unit(d.lat, d.lon);
    const ang = Math.acos(a[0] * b[0] + a[1] * b[1] + a[2] * b[2]);
    // pontos do arco em lat/lon + altura
    const pts = [];
    for (let i = 0; i <= PASSOS; i++) {
      const t = i / PASSOS;
      const [lat, lon] = latlon(slerp(a, b, t));
      pts.push({ lat, lon, alt: (0.035 + 0.16 * (ang / Math.PI)) * Math.sin(Math.PI * t), t });
    }
    return { ...d, pts, prog: 0, luz: 0, foco: 0 };
  });
  const casa = { prog: 0 };
  const v = { x: 0, y: 0, z: 0 };
  let W = 0, H = 0, D = 1;

  function medir(w, h, dpr) {
    if (w !== W || h !== H || dpr !== D) {
      W = w; H = h; D = dpr;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
  }

  // posição de tela de um ponto da rota (globo ↔ mapa plano), ou null se escondido
  function posicao(pt, flat, rect, lon0) {
    const [u, vv] = noMapa(pt.lat, pt.lon, lon0);
    const k = kPlano(flat, u);
    const p3 = glo.naEsfera(pt.lat, pt.lon, pt.alt * (1 - k));
    const s = glo.tela(p3, W, H, k < 0.5);
    if (!s) return null;
    if (k <= 0) return s;
    return [s[0] + (rect.x + u * rect.w - s[0]) * k, s[1] + (rect.y + (1 - vv) * rect.h - s[1]) * k];
  }

  // posição da rota no plano usa o arco plano, não o de grande círculo
  function posicaoPlana(r, t, flat, rect, lon0) {
    const a = noMapa(CASA.lat, CASA.lon, lon0), b = noMapa(r.lat, r.lon, lon0);
    const [u, vv] = arcoPlano(a, b, t);
    return [rect.x + u * rect.w, rect.y + (1 - vv) * rect.h];
  }

  function desenhar({ w, h, dpr, flat = 0, rect, lon0 = -20, alfa = 1, cor = '53,185,196' }) {
    medir(w, h, dpr);
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, canvas.width, canvas.height);
    if (alfa <= 0.001) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.globalAlpha = alfa;
    g.lineCap = 'round';
    g.lineJoin = 'round';

    for (const r of rotas) {
      if (r.prog <= 0) continue;
      const fim = Math.round(r.prog * PASSOS);
      g.beginPath();
      let aberto = false, ultimo = null;
      for (let i = 0; i <= fim; i++) {
        const pt = r.pts[i];
        let s = posicao(pt, flat, rect, lon0);
        if (s && flat > 0) {
          // perto do plano, a rota vira o arco plano do mapa
          const [u] = noMapa(pt.lat, pt.lon, lon0);
          const k = kPlano(flat, u);
          if (k > 0) {
            const q = posicaoPlana(r, pt.t, flat, rect, lon0);
            s = [s[0] + (q[0] - s[0]) * k, s[1] + (q[1] - s[1]) * k];
          }
        }
        if (!s) { aberto = false; continue; }
        if (!aberto) { g.moveTo(s[0], s[1]); aberto = true; } else g.lineTo(s[0], s[1]);
        ultimo = s;
      }
      // rota em foco (hover ou foco no rótulo): um halo largo por baixo e a linha mais grossa
      if (r.foco > 0.01) {
        g.strokeStyle = `rgba(${cor}, ${0.22 * r.foco})`;
        g.lineWidth = 7 * r.foco;
        g.stroke();
      }
      g.strokeStyle = `rgba(${cor}, ${0.9 + 0.1 * r.foco})`;
      g.lineWidth = 1.6 + 1.2 * r.foco;
      g.stroke();
      // cabeça da rota enquanto desenha
      if (ultimo && r.prog < 1) {
        const grad = g.createRadialGradient(ultimo[0], ultimo[1], 0, ultimo[0], ultimo[1], 10);
        grad.addColorStop(0, `rgba(${cor}, 0.9)`);
        grad.addColorStop(1, `rgba(${cor}, 0)`);
        g.fillStyle = grad;
        g.beginPath(); g.arc(ultimo[0], ultimo[1], 10, 0, Math.PI * 2); g.fill();
      }
      // ponto do destino
      if (r.luz > 0) {
        const s = posicao({ lat: r.lat, lon: r.lon, alt: 0 }, flat, rect, lon0);
        if (s) {
          r.tela = s;
          const rr = 3.4 + 5 * (1 - r.luz) * r.luz * 4 * 0.25 + 1.6 * r.foco;
          g.fillStyle = `rgba(${cor}, ${0.22 * r.luz + 0.12 * r.foco})`;
          g.beginPath(); g.arc(s[0], s[1], rr * (2.6 + 1.4 * r.foco), 0, Math.PI * 2); g.fill();
          g.fillStyle = `rgba(${cor}, ${r.luz})`;
          g.beginPath(); g.arc(s[0], s[1], rr, 0, Math.PI * 2); g.fill();
        } else r.tela = null;
      }
    }
    // Você
    if (casa.prog > 0) {
      const s = posicao({ lat: CASA.lat, lon: CASA.lon, alt: 0 }, flat, rect, lon0);
      casa.tela = s;
      if (s) {
        g.fillStyle = `rgba(244,239,231,${0.25 * casa.prog})`;
        g.beginPath(); g.arc(s[0], s[1], 9, 0, Math.PI * 2); g.fill();
        g.fillStyle = `rgba(244,239,231,${casa.prog})`;
        g.beginPath(); g.arc(s[0], s[1], 3.6, 0, Math.PI * 2); g.fill();
      }
    }
    g.globalAlpha = 1;
  }

  // posição de tela de um destino ou da casa sem desenhar (para os cards voarem até o ponto)
  function ponto(i, flat = 0, rect = null, lon0 = -20) {
    const d = i < 0 ? CASA : DESTINOS[i];
    return posicao({ lat: d.lat, lon: d.lon, alt: 0 }, flat, rect || { x: 0, y: 0, w: 1, h: 1 }, lon0);
  }

  return { rotas, casa, desenhar, ponto, medir };
}

// o mapa impresso no cartão: os mesmos pontos e as mesmas rotas, em tinta
export function imprimirMapa(canvas, ll, lon0, { tam = 1.5, tinta = '27,23,20', alfaPontos = 0.27, alfaRotas = 0.6 } = {}) {
  const r = canvas.getBoundingClientRect();
  const dpr = Math.min(devicePixelRatio || 1, 2);
  canvas.width = Math.round(r.width * dpr);
  canvas.height = Math.round(r.height * dpr);
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, r.width, r.height);
  g.fillStyle = `rgba(${tinta}, ${alfaPontos})`;
  const rad = tam / 2;
  for (let i = 0; i < ll.length; i += 2) {
    const [u, v] = noMapa(ll[i], ll[i + 1], lon0);
    if (v < 0 || v > 1) continue;
    g.beginPath();
    g.arc(u * r.width, (1 - v) * r.height, rad, 0, Math.PI * 2);
    g.fill();
  }
  g.strokeStyle = `rgba(${tinta}, ${alfaRotas})`;
  g.lineWidth = 1.2;
  g.setLineDash([3, 4]);
  const a = noMapa(CASA.lat, CASA.lon, lon0);
  for (const d of DESTINOS) {
    const b = noMapa(d.lat, d.lon, lon0);
    g.beginPath();
    for (let i = 0; i <= 48; i++) {
      const [u, v] = arcoPlano(a, b, i / 48);
      const x = u * r.width, y = (1 - v) * r.height;
      i ? g.lineTo(x, y) : g.moveTo(x, y);
    }
    g.stroke();
    g.setLineDash([]);
    g.fillStyle = `rgba(${tinta}, 0.7)`;
    g.beginPath(); g.arc(b[0] * r.width, (1 - b[1]) * r.height, 3, 0, Math.PI * 2); g.fill();
    g.setLineDash([3, 4]);
  }
  g.setLineDash([]);
  g.fillStyle = `rgba(${tinta}, 0.85)`;
  g.beginPath(); g.arc(a[0] * r.width, (1 - a[1]) * r.height, 3.4, 0, Math.PI * 2); g.fill();
}
