import './styles/tokens.css';
import './styles/base.css';
import './sections/nav.css';
import './sections/palco.css';
import './sections/abertura.css';
import './sections/voo.css';
import './sections/destinos.css';
import './sections/mundo.css';
import './sections/cartao.css';
import './sections/fecho.css';
import './sections/rodape.css';
import './styles/interacoes.css'; // os estados de hover, foco, clique e toque (por último: vale sobre as seções)

import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { REDUZIDO } from './motion/ease.js';
import { criarScroll } from './motion/smooth.js';
import { criarGuia } from './motion/guia.js';
import { scrollbar } from './motion/scrollbar.js';
import { criarPalco } from './motion/palco.js';
import { criarNav } from './motion/nav.js';
import { criarRodape } from './motion/rodape.js';
import { criarRenderer } from './motion/stage/renderer.js';
import { carregarTexturas } from './motion/stage/texturas.js';
import { criarCabine } from './motion/stage/cabine.js';
import { criarGlobo } from './motion/stage/globo.js';
import { criarRotas } from './motion/stage/rotas.js';
import { cenaAbertura } from './motion/cenas/abertura.js';
import { cenaVoo } from './motion/cenas/voo.js';
import { cenaDestinos } from './motion/cenas/destinos.js';
import { cenaMundo } from './motion/cenas/mundo.js';
import { cenaCartao } from './motion/cenas/cartao.js';
import { cenaNoite } from './motion/cenas/noite.js';
import { cenaFecho } from './motion/cenas/fecho.js';

gsap.registerPlugin(ScrollTrigger);
document.documentElement.classList.add('estilo'); // o CSS já entrou (imports acima): a página pode aparecer
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
scrollTo(0, 0);

const celular = matchMedia('(max-width: 760px)').matches;
const palcoEl = document.querySelector('.palco');
const palavra = document.querySelector('.palco__palavra');
const canvas = document.querySelector('.palco__gl');
const canvasRotas = document.querySelector('.palco__rotas');
const { renderer, tam, amostra } = criarRenderer(canvas, { celular });

// ---- contexto compartilhado pelas cenas (a cabine, o globo e as rotas chegam depois da carga)
const ctx = {
  celular,
  reduzido: REDUZIDO,
  mouse: { x: 0, y: 0 },
  alvoMouse: { x: 0, y: 0 },
  t: 0,
  tam,
  cab: null,
  glo: null,
  rotas: null,
  palco: palcoEl,
  heroi: { L: 10, sx: 0, sy: 0, ppu: 100 },
  retJanelas: null,
  rotasEstado: null,
  rotulosMundo,
};

// ---- abertura sem tela de carregamento: assim que as fontes chegam, a nav e os textos da hero entram sobre a
// parede; a cabine acende quando as fotos dela terminam de baixar e as persianas sobem (é o próprio carregamento)
await document.fonts.ready;
const abertura = cenaAbertura(ctx);
abertura.camada.classList.add('is-on');
abertura.entrar(0.1);
gsap.delayedCall(0.2, () => document.documentElement.classList.remove('inicio')); // a nav acende pela transição dela

// ---- carga: as fotos da cena 3D e a máscara do globo
const N_NUVENS = 9;
const lista = [
  { nome: 'ceu', url: '/img/vista-ceu.webp', tipo: 'ceu' },
  { nome: 'ilha', url: '/img/vista-ilha.webp', tipo: 'mar' },
  { nome: 'longe', url: '/img/nuvens-longe.webp' },
  { nome: 'perto', url: '/img/nuvens-perto.webp' },
  { nome: 'chao', url: '/img/destino-ilhas-chao.webp', tipo: 'mar', rep: true },
  { nome: 'noite', url: '/img/noite-vista.webp', tipo: 'ceu' },
  ...Array.from({ length: N_NUVENS }, (_, i) => ({ nome: `n${i}`, url: `/img/nuvem-${i}.webp` })),
];
const imagem = (url) => new Promise((ok) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ok(i); i.src = url; });
const [tex, mascara] = await Promise.all([
  carregarTexturas(lista),
  imagem('/globo/terra.png'),
]);
tex.nuvens = Array.from({ length: N_NUVENS }, (_, i) => tex[`n${i}`]);

const cab = criarCabine(renderer, tex, { celular });
const glo = criarGlobo(renderer, mascara, { celular });
const rotas = criarRotas(canvasRotas, glo);
Object.assign(ctx, { cab, glo, rotas });

function enquadrar() {
  const r = document.querySelector('.abertura__janelas').getBoundingClientRect();
  const rp = palcoEl.getBoundingClientRect();
  ctx.retJanelas = { left: r.left - rp.left, top: r.top - rp.top, width: r.width, height: r.height };
  Object.assign(ctx.heroi, cab.enquadrar(ctx.retJanelas, tam.w, tam.h));
}
enquadrar();

// estado inicial: cabine no escuro, persianas fechadas (a abertura acende e abre)
cab.estado.rasa = 0.35;
cab.janelas.forEach((j) => (j.abre = 0));

const voo = cenaVoo(ctx);
const destinos = cenaDestinos(ctx);
const mundo = cenaMundo(ctx, destinos);
const cartao = cenaCartao(ctx, mundo);
const noite = cenaNoite(ctx);
const fecho = cenaFecho(ctx);
mundo.fundo = cartao.fundo = '#0f0c0a';
noite.fundo = '#0a0c11';

// pin do palco antes do Lenis
const palco = criarPalco(palcoEl, [abertura, voo, destinos, mundo, cartao, noite, fecho]);
const lenis = criarScroll();
// rolagem suave até um ponto de uma cena (o clique no canhoto leva até o marco do rasgo)
ctx.irPara = (id, f) => {
  const y = palco.px(id, f);
  if (lenis) lenis.scrollTo(y, { duration: 1.1, easing: (t) => 1 - Math.pow(1 - t, 4) });
  else scrollTo(0, y);
};
// o freio: teto de velocidade da roda e da inércia do toque
criarGuia({ lenis });
lenis?.stop();
scrollbar({ lenis });
criarNav({
  lenis,
  palco,
  alvos: { abertura: 0, destinos: 0.14, mundo: mundo.alvo, cartao: 0.74, fecho: 0.5 },
  card: (i) => destinos.alvoCard(i),
});
criarRodape();

// ---- rótulos do globo presos aos pontos
const visRot = new WeakMap();
function rotulosMundo(els, flat) {
  const st = ctx.rotasEstado || { flat: 0, rect: { x: 0, y: 0, w: 1, h: 1 }, lon0: -20 };
  els.forEach((el, i) => {
    const quer = flat < 0.06 && (i === 0 ? rotas.casa.prog > 0.5 : rotas.rotas[i - 1].luz > 0.6);
    const p = quer ? rotas.ponto(i - 1, st.flat, st.rect, st.lon0) : null;
    let v = visRot.get(el) || 0;
    v += ((p ? 1 : 0) - v) * 0.18;
    visRot.set(el, v);
    el.style.opacity = v.toFixed(3);
    if (p) {
      // à direita do ponto (Você à esquerda); vira de lado perto da borda e nunca sai da tela
      const w = el.offsetWidth, h = el.offsetHeight, m = 10;
      // "Você" fica embaixo do ponto (as rotas saem para cima e para os lados)
      let x = i === 0 ? p[0] - w / 2 : p[0] + 12;
      if (x + w > tam.w - m) x = p[0] - w - 12;
      if (x < m) x = i === 0 ? m : p[0] + 12;
      const y = Math.min(tam.h - h - m, Math.max(m, i === 0 ? p[1] + 12 : p[1] - h / 2));
      el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(var(--aperto, 1))`;
    }
    // os destinos só recebem clique e foco quando estão na tela
    const vis = v > 0.5;
    if (el.tagName === 'BUTTON' && el._vis !== vis) {
      el._vis = vis;
      el.classList.toggle('is-vis', vis);
      el.tabIndex = vis ? 0 : -1;
    }
  });
}

// ---- rótulos do globo: hover, foco e toque acendem a rota daquele destino
document.querySelectorAll('button.rotulo').forEach((el) => {
  const r = rotas.rotas[Number(el.dataset.card)];
  const acende = () => gsap.to(r, { foco: 1, duration: REDUZIDO ? 0 : 0.6, ease: 'al-out', overwrite: 'auto' });
  const apaga = () => gsap.to(r, { foco: 0, duration: REDUZIDO ? 0 : 0.35, ease: 'al-in', overwrite: 'auto' });
  el.addEventListener('pointerenter', acende);
  el.addEventListener('pointerleave', apaga);
  el.addEventListener('focus', acende);
  el.addEventListener('blur', apaga);
});
// no iOS o :active (estado de toque) só funciona com um ouvinte de toque na página
document.addEventListener('touchstart', () => {}, { passive: true });

// ---- mouse (só ponteiro de mouse; no toque fica o balanço lento)
addEventListener('pointermove', (e) => {
  if (e.pointerType !== 'mouse' || REDUZIDO) return;
  ctx.alvoMouse.x = (e.clientX / innerWidth) * 2 - 1;
  ctx.alvoMouse.y = (e.clientY / innerHeight) * 2 - 1;
});

// ---- medidas
// "Mundo" na largura da tela (96%)
function ajustarPalavra() {
  const sp = palavra.querySelector('span');
  sp.style.fontSize = '100px';
  const w = sp.getBoundingClientRect().width || 1;
  sp.style.fontSize = `${(100 * tam.w * 0.965) / w}px`;
}

function medirTudo() {
  ajustarPalavra();
  enquadrar();
  destinos.medir();
  cartao.medir();
  fecho.posicionar();
}
let rz;
addEventListener('resize', () => {
  clearTimeout(rz);
  rz = setTimeout(() => { medirTudo(); ScrollTrigger.refresh(); lenis?.resize(); }, 160);
});

// ---- o laço: as cenas atualizam e o canvas desenha o conjunto da cena atual
// (o 3D para quando o palco sai da tela, no rodapé)
let palcoNaTela = true;
new IntersectionObserver(([e]) => { palcoNaTela = e.isIntersecting; }).observe(palcoEl);
let ultimoSet = 'x';
let rotasLimpas = false;
function quadro(time, deltaMs) {
  const dt = Math.min(0.05, deltaMs / 1000);
  ctx.t += dt;
  const km = 1 - Math.exp(-dt * 3.2);
  ctx.mouse.x += (ctx.alvoMouse.x - ctx.mouse.x) * km;
  ctx.mouse.y += (ctx.alvoMouse.y - ctx.mouse.y) * km;

  palco.tick(dt);
  if (!palcoNaTela) return;
  const c = palco.atual();
  const set = c.set;
  palcoEl.style.backgroundColor = c.fundo || '';
  const globo = c.id === 'mundo' || c.id === 'cartao';
  palavra.style.visibility = globo ? 'visible' : 'hidden';

  if (set === 'cabine') {
    cab.atualizar(dt, tam.w, tam.h);
    renderer.render(cab.cena, cab.camera);
  } else if (set === 'globo') {
    glo.aplicar(tam.w, tam.h, tam.dpr);
    renderer.render(glo.cena, glo.camera);
  } else if (ultimoSet !== set) {
    renderer.clear();
  }
  ultimoSet = set;

  if (globo && ctx.rotasEstado) {
    rotas.desenhar({ w: tam.w, h: tam.h, dpr: tam.dpr, ...ctx.rotasEstado });
    rotasLimpas = false;
  } else if (!rotasLimpas) {
    rotas.desenhar({ w: tam.w, h: tam.h, dpr: tam.dpr, alfa: 0 });
    rotasLimpas = true;
  }
  if (set) amostra(deltaMs);
  subirUma();
}

// as fotos que a hero não usa (descida, noite) sobem para a GPU uma por quadro logo depois que as persianas abrem,
// com a hero parada: sem isso, a primeira passagem pelas nuvens travava enviando a foto do chão no meio da descida
const fila = [tex.chao, tex.noite, ...tex.nuvens].filter(Boolean);
function subirUma() {
  if (!fila.length || !cab.abriu) return;
  renderer.initTexture(fila.shift());
}

// compila os shaders antes de abrir (sem engasgo no primeiro scroll)
renderer.compile(cab.cena, cab.camera);
renderer.compile(glo.cena, glo.camera);
gsap.ticker.add(quadro);
medirTudo();
ScrollTrigger.refresh();

// a cabine aparece no escuro e as persianas sobem; a página só rola depois disso
gsap.to(canvas, { opacity: 1, duration: REDUZIDO ? 0.3 : 1.1, ease: 'sine.inOut' });
gsap.delayedCall(REDUZIDO ? 0 : 0.3, () => abertura.abrir());
document.documentElement.classList.remove('carregando');
lenis?.start();
lenis?.resize();

// acesso para depuração e para a revisão headless
window.__alisio = { ctx, palco, lenis, cenas: { abertura, voo, destinos, mundo, cartao, noite, fecho } };
