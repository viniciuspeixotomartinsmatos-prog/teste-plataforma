// 6b · Fecho: a cabine à noite. No marco, as persianas descem uma depois da outra até a metade e encostam no
// formulário, um painel de vidro fosco sobre a metade de baixo das janelas. O título e o formulário entram juntos.
import gsap from 'gsap';
import { linhas, pecas } from '../split.js';
import { orbita, aplicar } from '../stage/rig.js';
import { ABERTURA, CONTORNO } from '../stage/janela.js';
import { ESPACO } from '../stage/cabine.js';
import { REDUZIDO } from '../ease.js';

// persiana com o pé no meio da abertura (onde começa o formulário)
const METADE = (0 - (-ABERTURA.b - 0.03)) / (ABERTURA.b - 0.085 - (-ABERTURA.b - 0.03));

export function cenaFecho(ctx) {
  const el = document.querySelector('.fecho');
  const form = el.querySelector('.form');
  const titulo = linhas(el.querySelector('.fecho__titulo'));
  const sub = linhas(el.querySelector('.fecho__sub'));
  const painel = pecas([form]);
  const ok = form.querySelector('.form__ok');
  let fechou = false;

  // o formulário começa no quarto de baixo das janelas e ocupa a largura das três (no celular, a tela): as persianas
  // descem até o meio e a faixa da noite fica entre elas e o vidro fosco
  function posicionar() {
    const r = ctx.retJanelas;
    if (!r) return;
    const ppu = ctx.heroi.ppu;
    const larg = ctx.celular ? ctx.tam.w - 24 : (2 * ESPACO + 2 * CONTORNO.a) * ppu;
    el.style.setProperty('--form-x', `${r.left + r.width / 2 - larg / 2}px`);
    const alvo = r.top + r.height * (ctx.celular ? 0.74 : 0.76);
    // folga da barra do navegador no celular (--vb em tokens.css), medida num elemento de prova
    const prova = document.createElement('div');
    prova.style.cssText = 'position:absolute;visibility:hidden;height:var(--vb)';
    document.body.append(prova);
    const vb = prova.offsetHeight;
    prova.remove();
    const teto = ctx.tam.h - vb - (ctx.celular ? 14 : 24) - form.offsetHeight;
    el.style.setProperty('--form-y', `${Math.max(ctx.celular ? 150 : 0, Math.min(alvo, teto))}px`);
    el.style.setProperty('--form-w', `${larg}px`);
  }

  function persianas(descer, pulo) {
    const { cab } = ctx;
    cab.janelas.forEach((j, i) => {
      j._fecho = descer;
      gsap.killTweensOf(j, 'abre');
      const alvo = descer ? METADE : 1;
      if (pulo || REDUZIDO) j.abre = alvo;
      else gsap.to(j, { abre: alvo, duration: descer ? 1.5 : 0.8, ease: descer ? 'al-desce' : 'al-io', delay: descer ? i * 0.22 : 0 });
    });
  }

  // ---- estados do formulário: preenchido, erro, enviando e enviado (sem servidor na demo)
  const campoNome = form.nome.closest('.form__campo');
  const campoZap = form.whatsapp.closest('.form__campo');
  const enviar = form.querySelector('.form__enviar');
  const valido = {
    nome: () => form.nome.value.trim().length >= 2,
    zap: () => form.whatsapp.value.replace(/\D/g, '').length >= 10,
  };
  function marcar(campo, input, ok, erro) {
    campo.classList.toggle('is-cheio', ok);
    campo.classList.toggle('is-erro', erro);
    input.toggleAttribute('aria-invalid', erro);
  }
  // máscara do WhatsApp: (00) 00000-0000
  form.whatsapp.addEventListener('input', () => {
    const d = form.whatsapp.value.replace(/\D/g, '').slice(0, 11);
    let v = d;
    if (d.length > 2) v = `(${d.slice(0, 2)}) ${d.slice(2)}`;
    if (d.length > 7) v = `(${d.slice(0, 2)}) ${d.slice(2, d.length - 4)}-${d.slice(-4)}`;
    form.whatsapp.value = v;
  });
  // enquanto digita, o erro some assim que o campo fica certo; ao sair do campo, marca preenchido
  form.nome.addEventListener('input', () => { if (valido.nome()) marcar(campoNome, form.nome, false, false); });
  form.whatsapp.addEventListener('input', () => { if (valido.zap()) marcar(campoZap, form.whatsapp, false, false); });
  // ao sair do campo: marca preenchido; um erro já mostrado só sai quando o campo fica certo
  const aoSair = (campo, input, ok) => marcar(campo, input, ok, !ok && campo.classList.contains('is-erro'));
  form.nome.addEventListener('blur', () => aoSair(campoNome, form.nome, valido.nome()));
  form.whatsapp.addEventListener('blur', () => aoSair(campoZap, form.whatsapp, valido.zap()));

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (form.classList.contains('is-enviando') || form.classList.contains('is-enviado')) return;
    const okNome = valido.nome(), okZap = valido.zap();
    marcar(campoNome, form.nome, okNome, !okNome);
    marcar(campoZap, form.whatsapp, okZap, !okZap);
    if (!okNome || !okZap) {
      (okNome ? form.whatsapp : form.nome).focus();
      return;
    }
    // enviando: a persiana do botão desce devagar
    form.classList.add('is-enviando');
    enviar.disabled = true;
    trocarTexto('Enviando…');
    setTimeout(() => {
      form.classList.remove('is-enviando');
      form.classList.add('is-enviado');
      form.querySelectorAll('input, select').forEach((el) => { el.disabled = true; });
      trocarTexto('Recebido');
      enviar.disabled = false; // sem o cursor de espera; o formulário enviado ignora novos envios
      enviar.setAttribute('aria-disabled', 'true');
      ok.textContent = `Recebido, ${form.nome.value.trim().split(' ')[0]}. Um especialista chama você no WhatsApp em até 2 horas.`;
      ok.classList.add('is-on');
      posicionar(); // a mensagem aumenta o formulário: ele sobe para caber inteiro na tela
      abrirPersianas();
    }, REDUZIDO ? 0 : 900);
  });
  function trocarTexto(t) {
    enviar.querySelectorAll('.btn__txt span').forEach((sp) => { sp.textContent = t; });
  }
  // enviado: as persianas sobem de novo, uma depois da outra, com o quique da abertura — a viagem começa
  function abrirPersianas() {
    ctx.cab.janelas.forEach((j, i) => {
      gsap.killTweensOf(j, 'abre');
      if (REDUZIDO) { j.abre = 1; return; }
      gsap.to(j, { abre: 1, duration: 1.55, ease: 'al-quique', delay: 0.15 + i * 0.36 });
    });
  }

  // os cards e os botões "Montar roteiro" já marcam o tipo de viagem
  document.querySelectorAll('[data-tipo-escolhe]').forEach((a) => a.addEventListener('click', () => {
    const r = form.querySelector(`input[name="tipo"][value="${a.dataset.tipoEscolhe}"]`);
    if (r) r.checked = true;
  }));

  return {
    id: 'fecho',
    telas: ctx.celular ? 1.1 : 1,
    marcos: [0.04],
    camada: el,
    vis: [-0.05, 1.6],
    set: 'cabine',
    posicionar,

    ligou(on) { if (on) posicionar(); },

    passo(i, antes, pulo) {
      fechou = i >= 1;
      persianas(fechou, pulo);
      if (fechou) { titulo.entrar(0.15); sub.entrar(0.3); painel.entrar(0.55); }
      else { titulo.sair(); sub.sair(); painel.sair(); }
    },

    atualizar(p, dt, ativa) {
      if (!ativa) return;
      const { cab, heroi } = ctx;
      aplicar(cab, { pos: [0, 0, heroi.L] }, orbita(ctx.mouse, ctx.t, heroi.L, REDUZIDO), 1, 1, heroi);
      cab.estado.noite = 1;
      cab.estado.vidro = 1;
      if (!fechou) cab.janelas.forEach((j) => { if (!gsap.isTweening(j)) j.abre = 1; });
      const v = cab.vista;
      v.dia.visible = false;
      v.noite.visible = true;
      v.descida.visible = false;
      for (const m of [v.fundoNoite, v.ceuNoite, v.pertoNoite, v.asa].filter(Boolean)) m.material.uniforms.uAlfa.value = 1;
      v.estrelas.material.uniforms.uAlfa.value = 1;
      // a luz da asa pulsa devagar (acende em 0,5 s, apaga em 0,9 s, a cada 2,4 s)
      const t = (ctx.t % 2.4) / 2.4;
      cab.estado.luzAsa = REDUZIDO ? 0.7 : t < 0.2 ? t / 0.2 : Math.max(0, 1 - (t - 0.2) / 0.38);
    },
  };
}
